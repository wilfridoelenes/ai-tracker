// [PP] mod:70 · autor:Rune · 2026-07-05 05:50 UTC-6
// TKT2 (REQ-[pendiente-ID] · Ingesta batch de CHECKPOINTs con resolución de [tmp:slug]
//   cross-CHECKPOINT): _assignPendingIds(tgItems, seedSlugMap?) — parámetro nuevo, opcional,
//   sin cambio de comportamiento si ausente. Seed copiado al inicio del slugMap con precedencia
//   — guard nuevo en sub-paso 1a evita reasignar código a un [tmp:slug] ya resuelto en el seed.
//   mergeBacklogFromTG(tgItems, sessionId, opts?) — propaga opts.seedSlugMap a _assignPendingIds;
//   slugMap ya se retornaba desde B-202606-022, agregado también al early-return de tgItems
//   vacío para no romper la cadena del orquestador de batch. Ver contrato completo y la función
//   orquestadora nueva (_applyCheckpointBatch) en locus-session-save.js.
// [PP] mod:61 · autor:Rune · 2026-07-01 UTC-6
// INC-[pendiente-ID] (triggered_by TKT1 REQ1 S'02 — _getActiveRoleFilter eliminada de
//   locus-backlog-core.js sin actualizar este consumidor): import roto → SyntaxError en
//   carga de módulo, bloqueaba toda la app. Import retirado + roleOk eliminado de
//   _renderKanban (línea ~132). El filtro de rol en Kanban queda inactivo — mismo estado
//   que ya tenía el resto del backlog tras la eliminación intencional en core.js.
// TKT-202606-013 (REQ-202606-003 · AC1/AC2): mergeBacklogFromTG — gate duro REQ nuevo sin TKT
//   hijo. Reemplaza la degradación orphaned:true (T-202606-010) por bloqueo real: ignored con
//   reason 'req-sin-tkt', sin creación, toast en corrida real. __BR-Core §4 Gate de parser.
// TKT-PARSER-2b (REQ-[pendiente-ID] · fix chk_status_by_type para INC/PRB/KE/CHG nuevos):
//   Gate en bloque Scrum de merge (L2007 orig.): INC/PRB/KE excluidos vía _skipScrumGate —
//   ahora llegan con item.status poblado (mirror, ver locus-session-parse.js) y sin esta
//   exclusión validateLifecycleTransitions (vocabulario Scrum) rechazaría transiciones ITIL
//   válidas. CHG no se excluye — vocabulario Scrum-compatible. Rama de creación de ítem nuevo:
//   agregados los 7 campos ITIL (incidentStatus, slaPriority, slaDeadline, comportamientoActual,
//   originModule, derivedItems, resolutionType) + queue — antes solo la rama merge-sobre-existente
//   los persistía, dejando INC/PRB/KE/CHG nuevos sin estos campos desde su creación.
// TKT-PARSER-2a (REQ-[pendiente-ID] · validación de transición ITIL y merge de campos ITIL):
//   validateIncidentTransitions() nueva — valida pares origen→destino de incidentStatus contra
//   _VALID_INCIDENT_TRANSITIONS, independiente de validateLifecycleTransitions (Scrum, sin
//   cambio). mergeBacklogFromTG: rama paralela al bloque de status Scrum — invoca la validación
//   cuando existing es ITIL e incidentStatus entrante difiere del existente; transición inválida
//   → invalidTransition (mismo array que ya recibe gaps de Scrum), resto de campos sí mergea.
//   Bloque de campos no-status ampliado con los 7 campos ITIL (incidentStatus, slaPriority,
//   slaDeadline, resolutionType, comportamientoActual, originModule, derivedItems) — mismo
//   patrón entrante-gana-si-trae-valor ya usado para title/desc/effort/area.
// TKT-C2 (REQ-C): status 'promovida'→'promoted' en comparaciones de status (L99, L1022,
//   L1612, L1630, L1892). Selector sprint: option icebox→value='' label 'Q-Backlog (sin sprint)'.
//   Edge case: datos legacy con 'promovida' cubiertos por compatibilidad de lectura (ver L99).
// Responsabilidad: Renderizado de ítems individuales — Kanban, buildBacklogItem, promoción, merge desde TRACKER-GLOBAL.
//   showMergeDiffPanel + modales de confirmación migrados a locus-backlog-merge.js (R-202605-033)
// Dependencias: locus-backlog-core.js · locus-backlog-sprints.js · locus-backlog-editor.js · locus-toast.js
import { _applyDoneStatus, _getActiveEfforts, _getActiveStatuses, _getActiveTypes, _getBacklogKanbanMode, _getBacklogNoAcMode, _getNextItemCode, _hasDepsBlocked, _hasRecentSession, _isBlocked, _isCountableItem, _openItemEditorSafe, _skelHide, _undoSnapshot, buildItemRefs, effortDots, getItems, itemKind, renderStats, setItemStatus, toggleSectionGroup, toggleVersionCollapse, updateBacklogBanner, toggleBacklogMikeMode, toggleTypeFilter, toggleStatusFilter, toggleEffortFilter, toggleItemExpand, _quickAssignEffort, setItemRole, clearAllFilters, _getBacklogSearchQuery, _getActiveSessionAiId, _GEN2_TYPES } from './locus-backlog-core.js'; // T-202606-089 AC-1+AC-3: 8 funciones · T-202606-099: _getBacklogSearchQuery · B-202606-012: _getActiveSessionAiId · TKT0-gen2: itemType→itemKind · TKT1: _GEN2_TYPES (REQ-[pendiente-ID]) · INC-[pendiente-ID]: _getActiveRoleFilter retirado del import — no exportada desde TKT1 REQ1 S'02 (core.js:2142)
import { _markBacklogListDirty, renderBacklogList, updateClearFilterBtn, toggleChildrenBlock, setItemParent, _updateSubtabBadges } from './locus-backlog-render.js'; // T-202606-089 AC-3 · T-202606-093: _updateSubtabBadges
import { _normalizeSprint, _VALID_INCIDENT_STATUS } from './locus-session-parse.js'; // TKT-PARSER-2a: constantes ITIL exportadas
import { _blogLog, _tplKey, getAI, getActiveSprints, _sprintDisplay, getAllSessions, saveBacklog, getActivePlan, getState } from './locus-storage.js'; // T-202606-023: getState añadido — migración window.state → import explícito


import { _buildItemMentionedIn, _buildItemMigratedBlock, openItemPanel, _openMigrateItem, _acvToggle, _acvStartEdit, _acvConfirm } from './locus-backlog-panel.js'; // T-202606-089 AC-3

import { _getActiveSprint, navigateToItem, setItemSprint, openSprintRetroView } from './locus-backlog-sprints.js'; // T-202606-089 AC-3
import { openProjPanel } from './locus-sprint-project.js'; // T-202606-089 AC-1

import { _setBacklogModified } from './locus-docs.js';

import { _gconfirmOpen } from './locus-modals.js';

import { validateLifecycleTransitions } from './locus-session-save.js'; // T-202606-020

import { render } from './locus-sesiones.js';

import { showToast } from './locus-toast.js';

import { esc, getCurrentTab, switchTab } from './locus-ui-shell.js';
import { openDetail } from './locus-session-popup.js';

// Constantes canónicas del ecosistema — roles disponibles para el select de ítem
// Fuente: OB-STRATEGY §6. Actualizar aquí si se agregan/eliminan roles.
const _ECOSYSTEM_ROLES = [
  'ST · Vera', 'GW · Lena', 'CPO · Noa', 'CMO · Maya',
  'PO · Cael', 'FS · Rune', 'UX · Nova', 'QA · Finn',
  'CC · Flux', 'ET · Eden', 'GC · Sage', 'DA · Iris'
];

// Días sin cambio de status para considerar un ítem bloqueado (alineado con _isBlocked en core)
const _BLOCKED_DAYS = 14;

// Estado de colapso de bloques de hijos (R → Ts) — compartido con locus-backlog-render.js via export
export const _collapsedChildren = new Set();

// Estado de colapso del footer de filtros del backlog
let _blFooterCollapsed = false;

// Labels de tipo de ítem para display en UI
const TYPE_LABELS = { REQ: 'Requerimiento', TKT: 'Ticket', INC: 'Incidente', DISC: 'Discovery', PRB: 'Problem', KE: 'Known Error', CHG: 'Change' }; // TKT-B2a: PRB/KE/CHG — ningún ítem ITIL muestra undefined en badge de tipo

// Helpers de badge — funciones del monolito original declaradas localmente al modularizar
function badgeLabel(priority) {
  return { high: 'Alta', medium: 'Media', low: 'Baja' }[priority] || priority || '—';
}
function badgeClass(priority) {
  return 'badge-prio-' + (priority || 'medium');
}
function statusLabel(status) {
  return { pendiente: 'Pendiente', 'en-revision': 'En revisión', done: 'Done', descartado: 'Descartado', historico: 'Histórico' }[status] || status || '—';
}
function statusClass(status) {
  return 'badge-status-' + (status || 'pendiente');
}

// B-202604-194: flag de sesión — ítems cuyo AC fue reemplazado via merge. Se vacía al recargar.
const _acReplacedSet = new Set();

// ── Estado del módulo ──────────────────────────────────────────────────────
// T-202606-099: backlogSearchQuery local eliminado — consumir _getBacklogSearchQuery() desde locus-backlog-core.js
// Filtro de tipo activo
let currentFilter = 'all';
// B-202606-023: guard de delegación como variable de módulo — evita que la propiedad DOM
// persista entre renders cuando renderBacklogList reemplaza innerHTML de #backlog-list.
// renderBacklogList llama _resetBacklogListDelegation() antes de llamar _attachBacklogListDelegation().
// INC-[pendiente-ID]: state por contenedor — antes un solo flag/AbortController module-level
// asumía #backlog-list como único caller posible. Un Map permite adjuntar la misma delegación
// a #qbacklog-panel-body y #qdisc-panel-body sin que el guard de uno bloquee a los otros.
const _blListDelegationState = new Map(); // containerId -> { attached: bool, abortCtrl: AbortController|null }
function _getBlListState(containerId) {
  let state = _blListDelegationState.get(containerId);
  if (!state) {
    state = { attached: false, abortCtrl: null };
    _blListDelegationState.set(containerId, state);
  }
  return state;
}
export function _resetBacklogListDelegation(containerId = 'backlog-list') {
  const state = _getBlListState(containerId);
  if (state.abortCtrl) { state.abortCtrl.abort(); }
  state.abortCtrl = new AbortController();
  state.attached = false;
}
// ──────────────────────────────────────────────────────────────────────────

export function _renderKanban(listEl) {
  // R-202604-091: 3 columnas — 'en curso' eliminado, ítems activos decorados en 'pendiente'
  const COLS = [
    { id: 'pendiente',  label: 'Pendiente',  status: 'pendiente',  colorVar: 'var(--text2)',  accentColor: 'rgba(124,106,247,0.4)' },
    { id: 'done',       label: 'Hecho',        status: 'done',       colorVar: '#2ecc78',       accentColor: 'rgba(46,204,120,0.4)' },
    { id: 'descartado', label: 'Descartado',  status: 'descartado', colorVar: 'var(--hint)',   accentColor: 'rgba(120,120,120,0.3)' }
  ];

  // Mapeo de status normalizados para compatibilidad
  function _kanbanStatus(item) {
    // R-202604-091: 'en curso' → 'pendiente'
    const s = item.status;
    if (s === 'in-progress' || s === 'en progreso' || s === 'progreso' || s === 'en curso') return 'pendiente';
    // TKT-C2: 'promovida'→'promoted' (Gen2 canónico). Edge case: datos legacy con 'promovida'
    // en storage también mapean a 'descartado' — misma rama, sin retrocompatibilidad adicional.
    if (s === 'promoted' || s === 'promovida') return 'descartado';
    return s; // pendiente | done | descartado
  }

  // Filtrar aplicando los mismos filtros activos del backlog
  const q = _getBacklogSearchQuery();
  let allFiltered = getItems().filter(i => {
    const type = itemKind(i);
    const typeOk = type ? _getActiveTypes().has(type) : true;
    const _rawEffortK = i.effort;
    const _normEffortK = _rawEffortK > 3 ? 3 : _rawEffortK < 1 ? 1 : _rawEffortK;
    const effortOk = _getActiveEfforts().has(_normEffortK); // B-202605-233: effort >3 normalizado a 3
    // INC-[pendiente-ID]: roleOk removido — dependía de _getActiveRoleFilter, no exportada
    // desde TKT1 REQ1 S'02 (core.js:2142, feature desconectada). Kanban ya no filtra por rol.
    return typeOk && effortOk && i.status !== 'historico'; // B-202605-266
  });
  if (q) {
    allFiltered = allFiltered.filter(i =>
      i.code.toLowerCase().includes(q) ||
      i.title.toLowerCase().includes(q) ||
      (i.area || '').toLowerCase().includes(q)
    );
  }

  // Agrupar por columna
  const byCol = {};
  COLS.forEach(c => { byCol[c.id] = []; });
  allFiltered.forEach(item => {
    const cs = _kanbanStatus(item);
    if (byCol[cs]) byCol[cs].push(item);
    else byCol['pendiente'].push(item); // fallback
  });

  // Construir card Kanban (compacta: código + tipo + título + sprint + effort)
  function _kanbanCard(item) {
    const type = itemKind(item) || '';
    const typeColors = { TKT:'#2ecc78', REQ:'#38bdf8', INC:'#e85555', DISC:'#7c6af7' };
    const typeColor = typeColors[type] || 'var(--hint)';
    const effortN = parseInt(item.effort) || 0;
    const dots = Array.from({length:3}, (_,i) =>
      `<span class="kb-effort-dot${i < effortN ? ' on' : ''}"></span>`
    ).join('');
    const sprintBadge = item.sprint ? `<span class="kb-card-sprint">${esc(item.sprint)}</span>` : '';
    const prioBadge = (!item.status || item.status === 'pendiente') && item.priority && item.priority !== 'medium'
      ? `<span class="kb-card-prio kb-prio-${item.priority}">${badgeLabel(item.priority)}</span>` : '';
    const kbIsActive = _isActiveRecently(item);
    // T-202605-449: tratamiento visual Kanban para ítems bloqueados por dependencia
    const kbIsDepBlocked = _hasDepsBlocked(item);
    const kbDepBadge = kbIsDepBlocked ? '<span class="kb-dep-blocked-badge" title="Tiene dependencias pendientes">🔒</span>' : '';
    return `<div class="kb-card${kbIsActive ? ' kb-card--active' : ''}${kbIsDepBlocked ? ' kb-card--dep-blocked' : ''}" data-code="${esc(item.code)}" data-status="${esc(item.status)}"
        style="--kb-type-color:${typeColor}"
        draggable="true">
      <div class="kb-card-header">
        <span class="kb-card-type">${type}</span>
        <span class="kb-card-code">${esc(item.code)}</span>
        <div class="kb-card-header-right">${kbDepBadge}${kbIsActive ? '<span class="kb-activity-dot" title="Actividad reciente"></span>' : ''}${prioBadge}</div>
      </div>
      <div class="kb-card-title">${esc(item.title)}</div>
      <div class="kb-card-footer">
        ${sprintBadge}
        <div class="kb-effort-dots">${dots}</div>
        ${item.area ? `<span class="kb-card-area">${esc(item.area)}</span>` : ''}
      </div>
    </div>`;
  }

  // Construir HTML de columnas
  let html = '<div class="kb-board">';
  COLS.forEach(col => {
    const colItems = byCol[col.id];
    html += `<div class="kb-col" id="kb-col-${col.id}"
        data-col-status="${col.id}">
      <div class="kb-col-header" style="--col-accent:${col.accentColor}">
        <span class="kb-col-title">${col.label}</span>
        <span class="kb-col-count">${colItems.length}</span>
      </div>
      <div class="kb-col-body" id="kb-body-${col.id}">
        ${colItems.length ? colItems.map(_kanbanCard).join('') : `<div class="kb-col-empty">Sin ítems</div>`}
      </div>
    </div>`;
  });
  html += '</div>';

  listEl.classList.add('kb-active');
  listEl.innerHTML = html;
  _skelHide(listEl);
}

// T-202604-287: handler drop Kanban — reutiliza setItemStatus con lógica de confirmación existente
function _kbDrop(event, toStatus) {
  event.preventDefault();
  const col = event.currentTarget;
  col.classList.remove('kb-col-dragover');
  const code = event.dataTransfer.getData('text/plain');
  if (!code) return;
  // Mapear columna 'progreso' al status real del sistema
  // R-202604-091: solo 3 columnas — 'en-curso' eliminado
  // Se almacena como 'in-progress' en item.status para conservar estado
  // R-202604-091: 'en-curso' eliminado del statusMap
  const statusMap = { pendiente: 'pendiente', done: 'done', descartado: 'descartado' };
  const newStatus = statusMap[toStatus] || toStatus;
  setItemStatus(code, newStatus);
}

// T-202604-287: click en card Kanban abre el editor del ítem
function _kbCardClick(event, code) {
  // No abrir si fue un drag (el drag pone clase antes del click)
  if (event.defaultPrevented) return;
  const item = getItems().find(i => i.code === code);
  if (!item) return;
  _openItemEditorSafe(item.id || null, code); // B-202605-012
}

// T-202605-054: delegación de eventos para #backlog-list — reemplaza handlers inline
// Cubre: copyItemCode · copyItemToClipboard · _inlineEditTitle · _confirmUnlinkChild
//        child-expand · drag-handle · kanban card (click + drag) · kb-col (drag) · _promoteSelectType
export function _attachBacklogListDelegation(containerId = 'backlog-list') {
  const listEl = document.getElementById(containerId);
  const _state = _getBlListState(containerId);
  if (!listEl || _state.attached) return;
  if (!_state.abortCtrl) { _state.abortCtrl = new AbortController(); }
  _state.attached = true;
  const _blListAbortCtrl = _state.abortCtrl; // alias local — sin cambiar las 8 referencias de signal abajo

  // --- Click delegation ---
  listEl.addEventListener('click', function _blListClick(e) {
    const action = e.target.closest('[data-action]');
    if (!action) return;
    const act = action.dataset.action;

    if (act === 'copy-code') {
      e.stopPropagation();
      const code = action.dataset.code;
      const idx  = parseInt(action.dataset.idx, 10);
      copyItemCode(e, code, idx);
      return;
    }
    if (act === 'copy-item') {
      e.stopPropagation();
      copyItemToClipboard(e, action.dataset.code);
      return;
    }
    if (act === 'unlink-child') {
      e.stopPropagation();
      _confirmUnlinkChild(action.dataset.childCode, action.dataset.rCode);
      return;
    }
    if (act === 'child-expand') {
      e.stopPropagation();
      const code   = action.dataset.childCode;
      const safeId = action.dataset.safeId;
      const ci = getItems().findIndex(x => x.code === code);
      if (ci >= 0) toggleItemExpand(ci);
      const arrow = document.getElementById('ciarrow-' + safeId);
      const body  = document.getElementById('ibody-'  + safeId);
      if (arrow && body) arrow.textContent = body.classList.contains('open') ? '▾' : '▸';
      return;
    }
    if (act === 'drag-handle') {
      e.stopPropagation();
      return;
    }
    // kanban card click
    if (act === 'kb-card-click' || e.target.closest('.kb-card')) {
      const card = e.target.closest('.kb-card');
      if (!card) return;
      if (e.defaultPrevented) return;
      _kbCardClick(e, card.dataset.code);
      return;
    }
    if (act === 'ref-chip-session') {
      switchTab('sesiones');
      setTimeout(() => { openDetail(action.dataset.aiId, action.dataset.sessId); }, 120);
      return;
    }
    if (act === 'item-expand') {
      const idx = parseInt(action.dataset.idx, 10);
      toggleItemExpand(idx);
      return;
    }
    if (act === 'edit-child') {
      e.stopPropagation();
      _openItemEditorSafe(null, action.dataset.code);
      return;
    }
    if (act === 'toggle-children') {
      e.stopPropagation();
      toggleChildrenBlock(action.dataset.rCode);
      return;
    }
    if (act === 'navigate-origin') {
      e.stopPropagation();
      navigateToItem(action.dataset.origin);
      return;
    }
    if (act === 'quick-assign-effort') {
      e.stopPropagation();
      _quickAssignEffort(action.dataset.code);
      return;
    }
    if (act === 'open-blocker') {
      e.stopPropagation();
      openItemPanel(action.dataset.code);
      return;
    }
    if (act === 'promote-item') {
      e.stopPropagation();
      _promoteItem(action.dataset.code);
      return;
    }
    if (act === 'discard-idea') {
      e.stopPropagation();
      setItemStatus(action.dataset.code, 'descartado');
      return;
    }
    if (act === 'open-status-popover') {
      _openStatusPopover(e, action.dataset.code);
      return;
    }
    if (act === 'navigate-discard-ref') {
      e.stopPropagation();
      navigateToItem(action.dataset.ref);
      return;
    }
    if (act === 'bitem-edit') {
      _openItemEditorSafe(null, action.dataset.code);
      return;
    }
    if (act === 'bitem-promote') {
      e.stopPropagation();
      _promoteItem(action.dataset.code);
      return;
    }
    if (act === 'bitem-promote-tkt-to-req') {
      e.stopPropagation();
      _promoteTktToReq(action.dataset.code);
      return;
    }
    if (act === 'bitem-migrate') {
      e.stopPropagation();
      _openMigrateItem(action.dataset.code);
      return;
    }
    if (act === 'promote-modal-cancel') {
      const overlay = document.getElementById('promote-modal-overlay');
      if (overlay) overlay.classList.remove('open');
      return;
    }
    if (act === 'promote-confirm') {
      _promoteConfirm(action.dataset.code);
      return;
    }
    if (act === 'promote-tkt-to-req-cancel') {
      const overlay = document.getElementById('promote-modal-overlay');
      if (overlay) overlay.classList.remove('open');
      return;
    }
    if (act === 'promote-tkt-to-req-confirm') {
      _promoteTktToReqConfirm(action.dataset.code);
      return;
    }
    if (act === 'acv-toggle') {
      e.stopPropagation();
      _acvToggle(action.dataset.panelId);
      return;
    }
    if (act === 'acv-open-editor') {
      e.stopPropagation();
      _openItemEditorSafe(null, action.dataset.code);
      return;
    }
    if (act === 'acv-clarify') {
      e.stopPropagation();
      _acvStartEdit(action.dataset.rowId, action.dataset.code, parseInt(action.dataset.ci, 10));
      return;
    }
    if (act === 'acv-confirm') {
      e.stopPropagation();
      _acvConfirm(action.dataset.code, action.dataset.panelId);
      return;
    }
    if (act === 'bitem-meta-stop') {
      e.stopPropagation();
      return;
    }
    if (act === 'status-change') {
      e.stopPropagation();
      setItemStatus(action.dataset.code, action.value || action.dataset.value);
      return;
    }
    // Render-level actions (from locus-backlog-render.js)
    if (act === 'bl-sprint-retro') {
      e.stopPropagation();
      openSprintRetroView(action.dataset.sprintId);
      return;
    }
    if (act === 'bl-plan-close') {
      const cb = action.dataset.callback;
      if (cb && window[cb]) { window[cb](); }
      return;
    }
    if (act === 'es-switch-tab') {
      switchTab(action.dataset.tab);
      return;
    }
    if (act === 'es-open-proj-panel') {
      openProjPanel();
      return;
    }
    if (act === 'es-clear-search') {
      clearBacklogSearch();
      return;
    }
    if (act === 'es-toggle-mike') {
      toggleBacklogMikeMode();
      return;
    }
    if (act === 'es-filter-all') {
      setFilter('all');
      return;
    }
    if (act === 'es-clear-filters') {
      clearAllFilters(); // T-202606-107 fix-inline: llamada directa — elimina dependencia frágil de filter-clear-btn en DOM
      return;
    }
    if (act === 'es-import') {
      // T-202606-107: CTA de empty state vacío real — dispara click en el input de importar
      const fileInput = document.getElementById('backlog-file-input');
      if (fileInput) fileInput.click();
      return;
    }
    if (act === 'version-collapse') {
      toggleVersionCollapse(action.dataset.groupId);
      return;
    }
    if (act === 'section-group-toggle') {
      toggleSectionGroup(action.dataset.group);
      return;
    }
    // B-202606-XXX: bl-r-toggle — vista sprints de backlog list (locus-backlog-render.js ~L1173)
    // T-202606-062 eliminó el handler anterior; el render sigue emitiendo bl-r-toggle + #bl-children-[rCode]
    if (act === 'bl-r-toggle') {
      e.stopPropagation();
      const rCode = action.dataset.rCode;
      if (!rCode) return;
      const body = document.getElementById('bl-children-' + CSS.escape(rCode));
      if (!body) return;
      const isNowCollapsed = !body.classList.contains('collapsed');
      body.classList.toggle('collapsed', isNowCollapsed);
      action.classList.toggle('collapsed', isNowCollapsed);
      const _collapseKey = 'locus-r-collapsed-' + rCode;
      if (isNowCollapsed) {
        localStorage.setItem(_collapseKey, '1');
      } else {
        localStorage.removeItem(_collapseKey);
      }
      return;
    }
  }, { signal: _blListAbortCtrl.signal });

  // --- Change delegation (status-select, role, sprint, parent) ---
  listEl.addEventListener('change', function _blListChange(e) {
    const sel = e.target.closest('.item-status-select');
    if (!sel) return;
    e.stopPropagation();
    const code = sel.dataset.code;
    const type = sel.dataset.selectType;
    if (!code) return;
    if (type === 'role') {
      setItemRole(code, sel.value);
    } else if (type === 'sprint') {
      // INC-[pendiente-ID]: renderBacklogList() directo removido — ciego a qué panel disparó
      // el cambio (rompía Q-Backlog/Q-DISC al reasignar sprint desde esas cards). setItemSprint
      // ahora despacha shell:backlog-render-dirty (ver locus-backlog-sprints.js) — mismo patrón
      // ya usado por setItemRole, refresca el panel que esté activo sin importar cuál sea.
      setItemSprint(code, sel.value);
    } else if (type === 'parent') {
      setItemParent(code, sel.value);
    } else {
      // status select (no data-select-type)
      setItemStatus(code, sel.value);
    }
  }, { signal: _blListAbortCtrl.signal });

  // --- Dblclick delegation (inline edit title) ---
  listEl.addEventListener('dblclick', function _blListDblClick(e) {
    const action = e.target.closest('[data-action="inline-edit-title"]');
    if (!action) return;
    e.stopPropagation();
    _inlineEditTitle(action.dataset.code, e);
  }, { signal: _blListAbortCtrl.signal });

  // --- Kanban card drag ---
  listEl.addEventListener('dragstart', function _blListDragStart(e) {
    // kb-card drag
    const card = e.target.closest('.kb-card');
    if (card) {
      e.dataTransfer.setData('text/plain', card.dataset.code);
      card.classList.add('kanban-card--dragging');
      return;
    }
  }, { signal: _blListAbortCtrl.signal });
  listEl.addEventListener('dragend', function _blListDragEnd(e) {
    const card = e.target.closest('.kb-card');
    if (card) { card.classList.remove('kanban-card--dragging'); return; }
  }, { signal: _blListAbortCtrl.signal });

  // --- Kanban column drag (kb-col) ---
  listEl.addEventListener('dragover', function _blListDragOver(e) {
    const col = e.target.closest('.kb-col');
    if (col) { e.preventDefault(); col.classList.add('kb-col-dragover'); }
  }, { signal: _blListAbortCtrl.signal });
  listEl.addEventListener('dragleave', function _blListDragLeave(e) {
    const col = e.target.closest('.kb-col');
    if (col) col.classList.remove('kb-col-dragover');
  }, { signal: _blListAbortCtrl.signal });
  listEl.addEventListener('drop', function _blListDrop(e) {
    const col = e.target.closest('.kb-col');
    if (col) {
      e.preventDefault();
      col.classList.remove('kb-col-dragover');
      _kbDrop(e, col.dataset.colStatus);
    }
  }, { signal: _blListAbortCtrl.signal });
}

// _attachBacklogListDelegation: llamado al final de renderBacklogList (ver locus-backlog-render.js)

// Promote modal delegation — #promote-modal-overlay es DOM estático, attachment único
(function _attachPromoteModalDelegation() {
  document.addEventListener('DOMContentLoaded', function() {
    const overlay = document.getElementById('promote-modal-overlay');
    if (!overlay) return;
    overlay.addEventListener('click', function(e) {
      const action = e.target.closest('[data-action="promote-select-type"]');
      if (!action) return;
      _promoteSelectType(action.dataset.type);
    });
  });
})();

// T-202604-076: DnD para reordenar ítems dentro de grupo sprint (no aplica a done/descartado ni a modo plano)
export function _attachBacklogDnD() {
  // T-202606-062: _getBacklogSprintGroupMode eliminada — vista lista es el modo por defecto.
  // DnD activo cuando no hay modo exclusivo que tome el rendering.
  if (_getBacklogKanbanMode() || _getBacklogNoAcMode()) return;
  // Solo grupos sprint: vbody-{groupId} — excluye sgbody-done, sgbody-discarded y vbody-flat
  const sprintBodies = document.querySelectorAll('[id^="vbody-"]:not(#vbody-flat)');
  sprintBodies.forEach(body => {
    const items = body.querySelectorAll('.item[data-code]');
    items.forEach(el => {
      const handle = el.querySelector('.item-drag-handle');
      if (!handle) return; // sin handle = sin sprint = no draggable
      el.draggable = true;
      handle.addEventListener('mousedown', () => { handle.classList.add('cursor-grabbing'); });
      handle.addEventListener('mouseup', () => { handle.classList.remove('cursor-grabbing'); });
      el.addEventListener('dragstart', e => {
        // B-202605-013: eliminado guard e.target === handle — dragstart dispara en el (.item), no en el handle
        // La activación ya está acotada: solo ítems con .item-drag-handle llegan aquí (guard L3650)
        e.dataTransfer.setData('text/plain', el.dataset.code);
        el.classList.add('item-dragging');
      });
      el.addEventListener('dragend', () => {
        el.classList.remove('item-dragging');
        handle.classList.remove('cursor-grabbing');
      });
      el.addEventListener('dragover', e => {
        e.preventDefault();
        el.classList.add('item-drag-over');
      });
      el.addEventListener('dragleave', () => {
        el.classList.remove('item-drag-over');
      });
      el.addEventListener('drop', e => {
        e.preventDefault();
        el.classList.remove('item-drag-over');
        const fromCode = e.dataTransfer.getData('text/plain');
        const toCode = el.dataset.code;
        if (!fromCode || fromCode === toCode) return;
        const fromIdx = getItems().findIndex(i => i.code === fromCode);
        const toIdx   = getItems().findIndex(i => i.code === toCode);
        if (fromIdx < 0 || toIdx < 0) return;
        const fromItem = getItems()[fromIdx];
        const toItem   = getItems()[toIdx];
        // T-202606-160: TKT con parent — bloquear drop a sprint distinto al del parent REQ con mensaje
        if (fromItem.parentId && fromItem.code && itemKind(fromItem) === 'TKT') {
          const _dndParent = getItems().find(i => i.code === fromItem.parentId);
          if (_dndParent && ((_dndParent.sprint || '') !== (toItem.sprint || ''))) {
            showToast('warning', 'El sprint del TKT se hereda de su parent ' + fromItem.parentId);
            return;
          }
        }
        // T sin parent — bloqueo genérico cross-sprint (reordenación dentro del mismo sprint)
        if ((fromItem.sprint || '') !== (toItem.sprint || '')) return;
        const [moved] = getItems().splice(fromIdx, 1);
        getItems().splice(toIdx, 0, moved);
        _undoSnapshot();
        saveBacklog();
        _markBacklogListDirty(); renderBacklogList();
      });
    });
  });
}

// T-202604-074: edición inline de título con doble click
function _inlineEditTitle(code, e) {
  e.stopPropagation(); // evitar toggleItemExpand
  const span = e.target.closest('[data-action="inline-edit-title"]');
  const item = getItems().find(i => i.code === code);
  if (!item) return;

  const originalTitle = item.title;
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'item-title-edit-input';
  input.value = originalTitle;

  span.replaceWith(input);
  input.focus();
  input.select();

  function _commit() {
    const newTitle = input.value.trim();
    if (newTitle && newTitle !== originalTitle) {
      item.title = newTitle;
      _undoSnapshot();
      saveBacklog();
    }
    _markBacklogListDirty(); renderBacklogList();
  }

  function _cancel() {
    _markBacklogListDirty(); renderBacklogList();
  }

  input.addEventListener('keydown', e => {
    if (e.key === 'Enter')  { e.preventDefault(); _commit(); }
    if (e.key === 'Escape') { e.preventDefault(); _cancel(); }
    e.stopPropagation();
  });
  input.addEventListener('blur', _commit);
  input.addEventListener('click', e => e.stopPropagation());
}

// T-202604-048: construir mini progress-bar de hijos para R
// T-202604-187/188: _buildChildrenBlock con colapsable y progreso
function _buildChildrenBlock(rCode) {
  // B-202604-158: respetar filtros activos — solo mostrar hijos que pasan tipo y status
  const allChildren = getItems().filter(i => i.parentId === rCode);
  if (!allChildren.length) return '';
  const children = allChildren.filter(i => {
    const t = itemKind(i);
    const typeOk = t ? _getActiveTypes().has(t) : true;
    const statusOk = _getActiveStatuses().has(i.status);
    return typeOk && statusOk;
  });
  if (!children.length) return '';
  const doneCount = children.filter(i => i.status === 'done').length;
  const pct = Math.round((doneCount / children.length) * 100);
  const isCollapsed = _collapsedChildren.has(rCode);

  const childRows = children.map(child => {
    // B-202605-011: IDs de DOM desde item.code — estables ante mutaciones de getItems()
    const cSafeId = child.code.replace(/[^a-zA-Z0-9-_]/g, '_');
    const cType = itemKind(child) || '';
    const isDoneC = child.status === 'done';
    return `<div class="child-item t-item${isDoneC ? ' is-done' : ''}">
      <span class="child-collapse-arrow" id="ciarrow-${cSafeId}" data-action="child-expand" data-child-code="${esc(child.code)}" data-safe-id="${cSafeId}">&#x25B8;</span>
      <span class="item-type-pill ${cType} item-type-pill--sm">${cType}</span>
      <span class="child-title" data-action="child-expand" data-child-code="${esc(child.code)}" data-safe-id="${cSafeId}">${esc(child.title)}</span>
      <span class="badge ${statusClass(child.status)} badge--sm">${statusLabel(child.status)}</span>
    </div>
    <div class="item-body item-body--child" id="ibody-${cSafeId}">
      <div id="code-badge-${cSafeId}" data-action="copy-code" data-code="${esc(child.code)}" data-idx="-1" title="Click para copiar ID" class="item-code-badge">${esc(child.code)}</div>
      <div class="child-meta-row">
        <span class="badge ${badgeClass(child.priority)} badge--sm">${badgeLabel(child.priority)}</span>
        ${child.area ? `<span class="badge badge-area badge--sm">${esc(child.area)}</span>` : ''}
        ${child.effort ? `<div class="effort-dots effort-dots--inline">${effortDots(child.effort)}</div>` : ''}
      </div>
      ${child.ac && child.ac.length ? `<ul class="ac-list open ac-list--child">${child.ac.map(c => `<li class="ac-list-item--sm">${esc(c)}</li>`).join('')}</ul>` : ''}
      <div class="child-actions">
        <button data-action="edit-child" data-code="${esc(child.code)}" class="btn-ghost btn-ghost--sm" title="Editar ítem">✎ Editar</button>
        <button data-action="unlink-child" data-child-code="${esc(child.code)}" data-r-code="${esc(rCode)}" class="btn-ghost btn-ghost--sm btn-ghost--muted" title="Desvincular del R padre">⊠ Desvincular</button>
      </div>
    </div>`;
  }).join('');

  return `<div class="req-children-block">
    <div class="req-children-header" data-action="toggle-children" data-r-code="${esc(rCode)}">>
      <span class="req-children-tickets-label">Ítems</span>
      <div class="req-children-bar-wrap"><div class="req-children-bar" style="--rch-bar-w:${pct}%"></div></div>
      <span class="req-children-label">${doneCount}/${children.length} · ${pct}%</span>
      <span id="req-children-arrow-${esc(rCode)}" class="req-children-arrow">${isCollapsed ? '▸' : '▾'}</span>
    </div>
    <div class="req-children-list${isCollapsed ? ' collapsed' : ''}" id="req-children-body-${esc(rCode)}"><div class="req-children-inner">${childRows}</div></div>
  </div>`;
}

// T-202604-004: desvincular child de R padre con confirmación
function _confirmUnlinkChild(childCode, rCode) {
  _gconfirmOpen({
    title: 'Desvincular ítem',
    msg: `¿Desvincular ${childCode} de ${rCode}? El ítem quedará sin padre.`,
    okLabel: 'Desvincular',
    danger: true
  }, () => {
    const item = getItems().find(i => i.code === childCode);
    if (item) { item.parentId = null; saveBacklog(); _markBacklogListDirty(); renderBacklogList(); renderStats(); showToast('success', `${childCode} desvinculado`); }
  });
}

// T-202604-028: timestamps legibles para item-body
function _buildItemTimestamps(item) {
  const _fmt = ts => {
    if (!ts) return null;
    const d = new Date(ts);
    const now = new Date();
    const diffMs = now - d;
    const diffMin = Math.floor(diffMs / 60000);
    const diffHrs = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffDays === 0) {
      if (diffMin < 2)  return 'ahora';
      if (diffMin < 60) return `hace ${diffMin} min`;
      return `hace ${diffHrs} h`;
    }
    if (diffDays === 1) return 'ayer';
    if (diffDays < 7) return `hace ${diffDays} días`;
    if (diffDays < 30) return `hace ${Math.floor(diffDays/7)} sem.`;
    if (diffDays < 365) return `hace ${Math.floor(diffDays/30)} mes${Math.floor(diffDays/30)>1?'es':''}`;
    return d.toLocaleDateString('es-MX', { day:'2-digit', month:'short', year:'numeric' });
  };
  const _iso = ts => ts ? new Date(ts).toLocaleString('es-MX', { dateStyle:'short', timeStyle:'short' }) : '';
  const rows = [];
  if (item.createdAt) rows.push(`<span title="${_iso(item.createdAt)}">📅 Creado: <strong>${_fmt(item.createdAt)}</strong></span>`);
  if (item.statusChangedAt) rows.push(`<span title="${_iso(item.statusChangedAt)}">🔄 Último cambio: <strong>${_fmt(item.statusChangedAt)}</strong></span>`);
  if (item.doneAt) rows.push(`<span title="${_iso(item.doneAt)}">✅ Completado: <strong>${_fmt(item.doneAt)}</strong></span>`);
  if (!rows.length) return '';
  return `<div class="bitem-timestamps">${rows.join('')}</div>`;
}

// R-[pendiente-ID]: bloque de origen P padre — muestra enlace al P que originó este ítem
function _buildItemPOriginBlock(item) {
  if (!item.origin) return '';
  const pItem = getItems().find(i => i.code === item.origin);
  const pTitle = pItem ? esc(pItem.title) : '';
  return `<div class="bitem-origin-p-block">
    <span class="bitem-origin-p-label">Origen</span>
    <button class="bitem-origin-p-link" data-action="navigate-origin" data-origin="${esc(item.origin)}" title="${pTitle}">${esc(item.origin)}</button>
    ${pTitle ? `<span class="bitem-origin-p-name" title="${pTitle}">${pTitle}</span>` : ''}
  </div>`;
}

// T-202604-NNN: bloque de origen — IA, sesión y archivos relacionados del ítem
function _buildItemOriginBlock(item) {
  if (!item.sessionId) return '';

  // getAllSessions() retorna sesiones planas con s.aiId — no {sess,ai} pairs
  const allSessions = getAllSessions();
  const foundSess = allSessions.find(s => s && s.id === item.sessionId);
  if (!foundSess) return '';

  const foundAi = getAI(foundSess.aiId);

  const aiName = foundAi ? esc(foundAi.name || foundAi.id) : '—';
  const aiAvatar = (foundAi && foundAi.avatar) ? `<span class="bitem-origin-avatar">${foundAi.avatar}</span>` : '';

  // Fecha de sesión
  const _fmtSessDate = ts => {
    if (!ts) return '';
    const d = new Date(ts);
    return d.toLocaleDateString('es-MX', { day:'2-digit', month:'short', year:'numeric' });
  };
  const sessDate = foundSess.date ? esc(foundSess.date) : _fmtSessDate(foundSess.savedAt || foundSess.createdAt);
  const sessTitle = foundSess.title ? esc(foundSess.title) : '';
  const sessLabel = sessTitle ? `${sessTitle}${sessDate ? ' · ' + sessDate : ''}` : (sessDate || foundSess.id);

  // Archivos relacionados — sess.files es string (texto libre del paste), convertir a array
  const _filesRaw = foundSess.files || foundSess.archivos || '';
  const files = Array.isArray(_filesRaw)
    ? _filesRaw.filter(Boolean)
    : _filesRaw.split(/[\n,]+/).map(f => f.trim()).filter(Boolean);
  const filesHtml = files.length
    ? `<div class="bitem-origin-row bitem-origin-row--files">
        <span class="bitem-origin-label">Archivos</span>
        <div class="bitem-origin-files">
          ${files.map(f => `<span class="bitem-origin-file-pill" title="${esc(f)}">${esc(f)}</span>`).join('')}
        </div>
       </div>`
    : '';

  return `<div class="bitem-origin-block">
    <div class="bitem-origin-row">
      <span class="bitem-origin-label">IA</span>
      <span class="bitem-origin-value">${aiAvatar}${aiName}</span>
    </div>
    <div class="bitem-origin-row bitem-origin-row--mt">
      <span class="bitem-origin-label">Sesión</span>
      <span class="bitem-origin-value" title="${esc(foundSess.id || '')}">${sessLabel}</span>
    </div>
    ${filesHtml}
  </div>`;
}

// R-202605-010: status chip popover — un solo popover activo a la vez
let _statusPopoverCode = null;
function _openStatusPopover(e, code) {
  e.stopPropagation();
  // Cerrar popover previo
  const prev = document.getElementById('status-popover');
  if (prev) prev.remove();
  if (_statusPopoverCode === code) { _statusPopoverCode = null; return; }
  _statusPopoverCode = code;

  const item = getItems().find(i => i.code === code);
  if (!item) { _statusPopoverCode = null; return; }

  const isIdea = itemKind(item) === 'DISC';
  const options = [
    { val: 'pendiente', label: 'Pendiente' },
    ...(!isIdea ? [{ val: 'en-revision', label: 'En revisión' }] : []),
    ...(!isIdea ? [{ val: 'done', label: 'Hecho' }] : []),
    { val: 'descartado', label: 'Descartado' }
  ];

  const pop = document.createElement('div');
  pop.id = 'status-popover';
  pop.className = 'bitem-status-popover';
  pop.setAttribute('role', 'menu');
  pop.onclick = e2 => e2.stopPropagation();

  pop.innerHTML = options.map(o =>
    `<button class="bitem-status-popover-btn${item.status === o.val ? ' is-current' : ''}" data-val="${o.val}">${o.label}</button>`
  ).join('');

  pop.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', ev => {
      ev.stopPropagation();
      const newVal = btn.dataset.val;
      pop.remove();
      _statusPopoverCode = null;
      if (newVal !== item.status) {
        try {
          setItemStatus(code, newVal);
        } catch(err) {
          showToast('error', 'Error al cambiar status', null, 3000);
          // chip revierte automáticamente tras el re-render de renderBacklogList
        }
      }
    });
  });

  document.body.appendChild(pop);

  // Posicionar bajo el chip trigger
  const trigger = e.currentTarget;
  const rect = trigger.getBoundingClientRect();
  const popW = 120;
  let left = rect.left + window.scrollX;
  if (left + popW > window.innerWidth) left = window.innerWidth - popW - 8;
  pop.style.setProperty('--sp-top', (rect.bottom + window.scrollY + 4) + 'px');
  pop.style.setProperty('--sp-left', left + 'px');

  // Cerrar con Escape
  const _escHandler = ev => {
    if (ev.key === 'Escape') { pop.remove(); _statusPopoverCode = null; document.removeEventListener('keydown', _escHandler); }
  };
  document.addEventListener('keydown', _escHandler);

  // Cerrar al click fuera
  const _outsideHandler = ev => {
    if (!pop.contains(ev.target) && ev.target !== trigger) {
      pop.remove();
      _statusPopoverCode = null;
      document.removeEventListener('click', _outsideHandler, true);
    }
  };
  setTimeout(() => document.addEventListener('click', _outsideHandler, true), 0);
}

// T-108: construir un ítem colapsado
// opts.suppressChildren: true — omite _buildChildrenBlock() cuando el caller ya inyecta
// hijos en un wrapper externo (ej. bl-vl-req en _renderVistaLista). Sin este flag, los hijos
// aparecen duplicados: una vez en el wrapper externo y otra en el body expandido del R.
// Contextos sin wrapper externo (Kanban, Icebox, Hotfix) NO deben pasar este flag.
export function buildBacklogItem(item, opts = {}) {
  const globalIdx = getItems().indexOf(item);
  const isDone = item.status === 'done';
  const isDiscarded = item.status === 'descartado';
  const isHistorico = item.status === 'historico'; // B-202604-193: read-only
  const type = itemKind(item) || '';
  const typeLabel = TYPE_LABELS[type] || type;
  // R-202605-098: gate único para toda lógica diferenciada de tipo DISC
  const isIdea = type === 'DISC';

  // T-202604-050: detectar campos obligatorios faltantes (no aplica a descartados ni a P)
  // R-202605-098: P no tiene effort ni AC obligatorios — son conceptos que emergen al promoverse
  const missingFields = [];
  if (!isDiscarded) {
    if (!isIdea && !item.effort) missingFields.push('effort');
    if (!item.area)   missingFields.push('area');
    if (!isIdea && (!item.ac || !item.ac.length)) missingFields.push('ac');
  }
  // R-202605-122 AC2/AC3: badge 'sin effort' con acción rápida de asignación
  const _missingEffort = !isDiscarded && !isIdea && !item.effort;
  const _effortQuickBadge = _missingEffort
    ? `<span class="badge-missing badge-missing--effort" title="Esfuerzo no declarado — requerido para burndown">⚠ sin effort <button class="badge-effort-quick" data-action="quick-assign-effort" data-code="${esc(item.code || item.id)}" title="Asignar effort rápidamente">Asignar</button></span>`
    : '';
  const _otherMissing = missingFields.filter(f => f !== 'effort');
  const missingAlert = (_missingEffort || _otherMissing.length)
    ? `<div class="bitem-missing-row">${_effortQuickBadge}${_otherMissing.map(f => `<span class="badge-missing">⚠ falta ${f}</span>`).join(' ')}</div>`
    : '';

  // AC list
  const acHtml = item.ac && item.ac.length
    ? `<div class="bitem-ac-block">
        <div class="bitem-ac-header">
          <span class="bitem-ac-check">✓</span>
          <span class="bitem-ac-count">${item.ac.length} criterio${item.ac.length !== 1 ? 's' : ''}</span>
        </div>
        <ul class="bitem-ac-list open">
          ${item.ac.map(c => `<li><span class="bitem-ac-dot"></span><span>${esc(c)}</span></li>`).join('')}
        </ul>
       </div>`
    : `<div class="bitem-ac-block"><div class="bitem-ac-header bitem-ac-header--empty">Sin criterios de aceptación</div></div>`;

  // Effort dots — large version for header, styled
  const effortN = parseInt(item.effort) || 0;
  const effortDotsHtml = (() => {
    let d = '';
    for (let i = 0; i < 3; i++) d += `<span class="bitem-effort-dot${i < effortN ? ' on' : ''}"></span>`;
    return `<div class="bitem-effort-dots" title="Esfuerzo ${effortN}/3">${d}</div>`;
  })();

  // Priority color
  const prioColors = { high:'#e85555', medium:'#f59e0b', low:'var(--hint)' };
  const prioColor = prioColors[item.priority] || 'var(--hint)';
  const prioBadgeHtml = (!isDone && !isDiscarded && item.priority)
    ? `<span class="bitem-prio-badge prio-${item.priority}">${badgeLabel(item.priority)}</span>`
    : '';
  // T-202604-199: badge "Sin AC" — solo en pendiente sin criterios
  const noAcBadge = (!isDone && !isDiscarded && item.status === 'pendiente' && (!item.ac || !item.ac.length))
    ? '<span class="badge-missing badge-missing--warning">Sin AC</span>'
    : '';
  // T-202604-261: badge "bloqueado" — pendiente con sprint >14 días sin cambio de status
  const blockedBadge = _isBlocked(item)
    ? '<span class="badge-missing badge-missing--blocked" title="Sin cambio de status en más de 14 días">⛔ bloqueado</span>'
    : '';
  // R-202605-045 · T-202605-083: staleness-pill — punto único de cálculo via _staleness()
  // B-202605-048: omitir pill si item.createdAt es inválido (legacy sin timestamp) — manejado en _staleness()
  const _stalenessData = (!isDone && !isDiscarded) ? _staleness(item) : null;
  const noSessionBadge = _stalenessData
    ? `<span class="staleness-pill staleness--${_stalenessData.modifier}" title="Sin sesión vinculada — ${_stalenessData.days}d desde último cambio de status">${_stalenessData.label}</span>`
    : '';

  // B-202606-015: badge "Sin Ts" — R con orphaned:true (sin Ts válidos)
  const orphanedBadge = (!isDone && !isDiscarded && type === 'REQ' && item.orphaned)
    ? '<span class="staleness-pill staleness--orphaned" title="R sin Ts válidos — especificar T1 antes de ejecutar">Sin Ts</span>'
    : '';

  // Children count + progreso para R type (T-188)
  // B-202605-052: usar getItems() sin filtrar como denominador — los filtros activos no afectan el porcentaje
  // B-202606-016: denominador = todos los hijos sin filtro · numerador = done + descartado (ambos cuentan como cerrados)
  // B-202606-019: denominador excluye hijos descartados — solo Ts no descartados forman el total
  const childCount = type === 'REQ' ? getItems().filter(i => i.parentId === item.code && i.status !== 'descartado').length : 0;
  const childDoneCount = type === 'REQ' ? getItems().filter(i => i.parentId === item.code && i.status === 'done').length : 0;
  const childBadge = (type === 'REQ' && childCount > 0 && !isDone && !isDiscarded)
    ? `<span class="bitem-child-badge" title="${childDoneCount}/${childCount} ítems done">${childDoneCount}/${childCount} <span class="bitem-child-badge-label">ítems</span></span>`
    : '';

  // T-202604-288: badge "Bloqueado por [código]" — blockedBy explícito pendiente
  const blockedByItems = (!isDone && !isDiscarded && item.blockedBy && item.blockedBy.length)
    ? item.blockedBy.filter(c => { const dep = getItems().find(i => i.code === c); return !dep || dep.status !== 'done'; })
    : [];
  const blockedByBadge = blockedByItems.length
    ? blockedByItems.map(c =>
        `<span class="badge-missing badge-missing--blocked badge-blocked-by" data-action="open-blocker" data-code="${esc(c)}" title="Ir al ítem bloqueante">🔒 ${esc(c)}</span>`
      ).join('')
    : '';

  // T-202606-142: badge "bloqueado por T-XXX" — depends_on con T bloqueante no done
  // Solo aplica a Ts no done ni descartados con dependencias activas no resueltas.
  // T-202606-013: filtrar valores placeholder ([pendiente-ID], [tmp:slug]) antes de evaluar existencia en backlog
  const _depPlaceholderRe = /^\[pendiente-ID\]$|^\[tmp:.+\]$/;
  const _depBlockedCodes = (!isDone && !isDiscarded && type === 'TKT' && Array.isArray(item.dependsOn) && item.dependsOn.length)
    ? item.dependsOn.filter(c => !_depPlaceholderRe.test(c)).filter(c => { const dep = getItems().find(i => i.code === c); return !dep || dep.status !== 'done'; })
    : [];
  const depBlockedBadge = _depBlockedCodes.length
    ? _depBlockedCodes.map(c =>
        `<span class="badge-missing badge-missing--dep-blocked" title="Depende de ${esc(c)} — no completado">⛔ bloqueado por ${esc(c)}</span>`
      ).join('')
    : '';
  const _isDepBlocked = _depBlockedCodes.length > 0;

  // R-202604-051: badge blocking:true — ítem bloqueante activo
  const blockingBadge = (!isDone && !isDiscarded && item.blocking)
    ? `<span class="badge-blocking" title="Este ítem bloquea a otros — debe resolverse primero">⚠ bloqueante</span>`
    : '';

  // B-202604-194: badge "AC actualizados" — flag de sesión en _acReplacedSet, desaparece al recargar
  const acReplacedBadge = (!isDone && !isDiscarded && _acReplacedSet.has(item.id))
    ? '<span class="badge-ac-replaced" title="Los criterios de aceptación fueron reemplazados en esta sesión via merge">↺ AC</span>'
    : '';

  // R-202604-091: decorador de actividad reciente — sesión vinculada en los últimos 7 días
  const isActive = (!isDone && !isDiscarded) ? _isActiveRecently(item) : false;

  // R-202605-131: badge scope added — ítem añadido durante el sprint activo
  const scopeAddedBadge = (!isDone && !isDiscarded && item.scope_added)
    ? '<span class="badge-scope-added" title="Añadido al sprint después de su apertura">＋ scope</span>'
    : '';

  // Header right slot
  // R-202605-098: para P pendiente — acciones inline en header sin necesidad de expandir
  const _ideaQuickActions = (isIdea && !isDiscarded && !isDone)
    ? `<div class="item-quick-actions">
        <button class="btn-promote" data-action="promote-item" data-code="${esc(item.code)}" title="Promover a Ticket o Requerimiento">⬆ Promover</button>
        <button class="btn-discard-idea" data-action="discard-idea" data-code="${esc(item.code)}" title="Descartar esta idea">✕ Descartar</button>
       </div>`
    : '';
  // R-202605-010: status chip inline clickeable — solo para ítems pendientes (no P, no done, no descartado)
  const _statusChipHtml = (!isDone && !isDiscarded && !isIdea)
    ? `<button class="bitem-status-chip bitem-status-chip--${esc(item.status || 'pendiente')}" data-action="open-status-popover" data-code="${esc(item.code)}" title="Cambiar status" type="button">${statusLabel(item.status || 'pendiente')}</button>`
    : '';
  // Cerradas: DISC promovida muestra badge en lugar de quick actions o ícono descartado
  // TKT-C2: 'promoted' (Gen2). Edge case: datos legacy 'promovida' también matchean.
  const _isPPromovida = isIdea && (item.status === 'promoted' || item.status === 'promovida');
  const _pPromovidaRef = _isPPromovida && item.promovida_a ? item.promovida_a : null;
  const _pPromovidaBadge = _isPPromovida
    ? `<span class="item-p-badge item-p-badge--promovida" title="Idea promovida${_pPromovidaRef ? ' a ' + _pPromovidaRef : ''}">↗ promovida${_pPromovidaRef ? '<span class="item-p-badge-ref"> ' + esc(_pPromovidaRef) + '</span>' : ''}</span>`
    : '';

  const headerRight = _isPPromovida
    ? `<div class="bitem-header-right">${_pPromovidaBadge}</div>`
    : isDiscarded
    ? `<span class="bitem-discarded-icon">🗑</span>`
    : isDone
      ? `<span class="bitem-done-check">✓</span>`
      : isIdea
        ? `<div class="bitem-header-right">${prioBadgeHtml}${_ideaQuickActions}</div>`
        : `<div class="bitem-header-right">${scopeAddedBadge}${noAcBadge}${acReplacedBadge}${blockingBadge}${blockedBadge}${blockedByBadge}${depBlockedBadge}${orphanedBadge}${noSessionBadge}${childBadge}${prioBadgeHtml}${effortDotsHtml}${_statusChipHtml}</div>`;

  // R-202605-098: subline discard reason diferenciado para P
  // P descartado por promoción → chip con ref; P descartado manual → razón libre
  const _discardReasonHtml = (isDiscarded && item.discardReason)
    ? isIdea && item.discardRef
      ? `<span class="idea-promoted-chip" data-action="navigate-discard-ref" data-ref="${esc(item.discardRef)}" title="Ir al ítem promovido">${esc(item.discardRef)}</span>`
      : `<span class="idea-discard-reason">${esc(item.discardReason)}</span>`
    : isDiscarded && !isIdea && item.discardReason
      ? `<span class="bitem-discard-reason">🗑 ${esc(item.discardReason)}${item.discardRef ? ' · ' + esc(item.discardRef) : ''}</span>`
      : '';

  // Subline (code, area, sprint, role, discard reason, missing warning)
  // UX-redesign: código en subline junto con rol/área/sprint — título queda como línea visual dominante
  const subline = `<div class="bitem-subline">
    <span class="bitem-subline-code" data-action="copy-code" data-code="${esc(item.code)}" data-idx="${globalIdx}" title="Click para copiar ID">${item._focusRank ? `<span class="bitem-focus-rank" title="Posición en Focus">#${item._focusRank}</span> ` : ''}${esc(item.code)}</span>
    ${item.role ? `<span class="bitem-subline-sep">·</span><span class="bitem-subline-role" title="Rol responsable">${esc(item.role)}</span>` : ''}
    ${item.area ? `<span class="bitem-subline-sep">·</span><span class="bitem-subline-area" title="${esc(item.area)}">${esc(item.area)}</span>` : ''}
    ${item.sprint ? `<span class="bitem-subline-sep">·</span><span class="bitem-subline-sprint">${esc(_sprintDisplay(item.sprint))}</span>` : ''}
    ${_discardReasonHtml}
    ${missingFields.length ? `<span class="bitem-missing-warn" title="Faltan: ${missingFields.join(', ')}">⚠</span>` : ''}
  </div>`;

  // Type block — the dominant visual element
  const typeBlock = type
    ? `<div class="bitem-type-block bitem-type-${type}">
        <span class="bitem-type-letter">${type}</span>
        <span class="bitem-type-label">${typeLabel}</span>
       </div>`
    : '';

  // R-202605-098: isPromoted — P descartado por promoción (tiene discardRef)
  const isPromoted = isIdea && isDiscarded && !!item.discardRef;
  // Cerradas: P en estado terminal (promovida o descartado)
  const _isPTerminal = isIdea && (_isPPromovida || isDiscarded);
  const isBloqueado = item.status === 'bloqueado';
  // R-202605-165: .blf-hidden colapsa ítems fuera del Top-10 con transición 150ms ease-out
  const _blfHiddenClass = item._blfHidden ? ' blf-hidden' : '';
  const _blfAriaHidden  = item._blfHidden ? ' aria-hidden="true"' : '';
  return `<div class="item bitem${isDone ? ' is-done' : ''}${isDiscarded ? ' is-discarded' : ''}${isBloqueado ? ' is-bloqueado' : ''}${isActive ? ' bitem--active' : ''}${isIdea ? ' bitem--idea' : ''}${isPromoted ? ' bitem--promoted' : ''}${_isPTerminal ? ' bl-p-terminal' : ''}${_isDepBlocked ? ' bitem--dep-blocked' : ''}${_blfHiddenClass}" data-type="${type}" data-code="${esc(item.code)}"${_blfAriaHidden}>
    <div class="item-header bitem-header" data-action="item-expand" data-idx="${globalIdx}">
      <span class="bitem-collapse-arrow" id="iarrow-${globalIdx}">▸</span>
      ${(!isDone && !isDiscarded && item.sprint) ? `<span class="item-drag-handle" data-action="drag-handle" title="Arrastrar para reordenar en sprint">⠿</span>` : ''}
      ${isActive ? '<span class="bitem-activity-dot" title="Actividad reciente — sesión vinculada en los últimos 7 días"></span>' : ''}
      <button id="copy-item-btn-${esc(item.code)}" class="copy-item-btn" data-action="copy-item" data-code="${esc(item.code)}" aria-label="Copiar ítem" title="Copiar ítem para sesión FS"><svg class="copy-btn-icon copy-btn-icon--clipboard" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect x="5" y="2" width="9" height="12" rx="1.5"/><path d="M5 4H4a1.5 1.5 0 0 0-1.5 1.5v8A1.5 1.5 0 0 0 4 15h7a1.5 1.5 0 0 0 1.5-1.5V13"/></svg><svg class="copy-btn-icon copy-btn-icon--check is-hidden" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M3 8l4 4 6-6"/></svg></button>
      ${typeBlock}
      <div class="bitem-title-col">
        <span class="bitem-title"${(!isDone && !isDiscarded) ? ` data-action="inline-edit-title" data-code="${esc(item.code)}" title="Doble click para editar título"` : ''}>${esc(item.title)}</span>${isDiscarded && (!item.title || item.title.trim() === item.code) ? '<span class="bitem-ghost-note" title="Ítem sin título — posiblemente generado por un CHECKPOINT malformado">⚠ ítem fantasma — generado por CHECKPOINT malformado</span>' : ''}
        ${subline}
      </div>
      ${headerRight}
    </div>
    <div class="item-body bitem-body" id="ibody-${globalIdx}">
      ${item.notes ? `<div class="bitem-notes-block"><span class="bitem-notes-label">Notas</span><span class="bitem-notes-text">${esc(item.notes)}</span></div>` : ''}
      ${_isBlocked(item) ? `<div class="bitem-missing-row"><span class="badge-missing badge-missing--blocked">⛔ bloqueado — sin cambio de status en más de ${_BLOCKED_DAYS} días</span></div>` : ''}
      ${_stalenessData ? `<div class="bitem-missing-row"><span class="staleness-pill staleness--${_stalenessData.modifier}" title="Sin sesión vinculada — ${_stalenessData.days}d desde último cambio de status">${_stalenessData.label} sin sesión</span></div>` : ''}
      ${missingAlert}
      <div class="bitem-meta-grid" data-action="bitem-meta-stop">
        <div class="bitem-meta-cell">
          <span class="bitem-meta-label">Status</span>
          ${isIdea
            ? `<select class="item-status-select bitem-select" data-code="${esc(item.code)}" data-action="bitem-meta-stop"${_isPPromovida ? ' disabled title="No editable — idea ya promovida"' : ''}>
                <option value="discovery"${item.status==='discovery'?' selected':''}>En evaluación</option>
                ${_isPPromovida ? `<option value="${esc(item.status)}" selected>Promovida</option>` : ''}
                <option value="descartado"${item.status==='descartado'?' selected':''}>Descartado</option>
               </select>`
            : `<select class="item-status-select bitem-select" data-code="${esc(item.code)}" data-action="bitem-meta-stop">
                <option value="pendiente"${item.status==='pendiente'?' selected':''}>Pendiente</option>
                <option value="done"${item.status==='done'?' selected':''}>Hecho</option>
                <option value="descartado"${item.status==='descartado'?' selected':''}>Descartado</option>
               </select>`
          }
        </div>
        ${item.status === 'done' ? `<div class="bitem-meta-cell"><span class="bitem-meta-label">Versión</span><span class="bitem-meta-value mono">${esc(item.version || 'futura')}</span></div>` : ''}
        ${!isIdea ? `<div class="bitem-meta-cell">
          <span class="bitem-meta-label">Esfuerzo</span>
          <div class="bitem-effort-display">
            ${(() => { let d=''; for(let i=0;i<3;i++) d+=`<span class="bitem-effort-dot-sm${i<effortN?' on':''}"></span>`; return d; })()}
            <span class="bitem-effort-num">${item.effort ? item.effort+'/3' : '<span class="effort-missing">—</span>'}</span>
          </div>
        </div>` : ''}
        <div class="bitem-meta-cell">
          <span class="bitem-meta-label">Tipo</span>
          <span class="bitem-meta-value">${typeLabel || '—'}</span>
        </div>
        <div class="bitem-meta-cell" data-action="bitem-meta-stop">
          <span class="bitem-meta-label">Rol</span>
          <select class="item-status-select bitem-select bitem-select-role" data-code="${esc(item.code)}" data-select-type="role">
            <option value="">— Sin rol —</option>
            ${_ECOSYSTEM_ROLES.map(r => `<option value="${esc(r)}"${(item.role||'')=== r?' selected':''}>${esc(r)}</option>`).join('')}
          </select>
        </div>
        ${!isIdea ? `<div class="bitem-meta-cell" data-action="bitem-meta-stop">
          <span class="bitem-meta-label">Sprint</span>
          <div id="sprint-select-wrap-${esc(item.code)}">
            ${/* B-202606-083: TKT/INC con parentId — sprint heredado del REQ parent, no editable */
              (item.parentId && (type === 'TKT' || type === 'INC'))
              ? `<select class="item-status-select bitem-select" data-code="${esc(item.code)}" data-select-type="sprint" disabled title="El sprint se hereda del R parent">
                  <option value="${esc(item.sprint||'')}" selected>${esc(_sprintDisplay(item.sprint||''))}</option>
                </select>`
              : `<select class="item-status-select bitem-select" data-code="${esc(item.code)}" data-select-type="sprint">
                  <option value=""${(!item.sprint || item.sprint === '' || item.sprint === 'icebox') ? ' selected' : ''}>Q-Backlog (sin sprint)</option>
                  ${/* TKT3-[pendiente-ID]: _sprintDisplay aplica patrón id · label — antes solo s.label||s.id */''}
                  ${getActiveSprints().filter(s=>s.status!=='closed').map(s=>`<option value="${esc(s.id)}"${item.sprint===s.id?' selected':''}>${esc(_sprintDisplay(s.id))}${s.status==='active'?' ★':''}</option>`).join('')}
                  ${item.sprint && item.sprint !== '' && item.sprint !== 'icebox' && !getActiveSprints().find(s=>s.id===item.sprint) ? `<option value="${esc(item.sprint)}" selected>${esc(item.sprint)}</option>` : ''}
                </select>`
            }
          </div>
        </div>` : ''}
        ${(type === 'TKT' || type === 'INC') ? (() => {
          // T-202604-354: solo REQ pendientes, orden descendente por código, label ID · Título truncado 60 chars
          const rItems = getItems()
            .filter(i => itemKind(i) === 'REQ' && i.status === 'pendiente')
            .sort((a, b) => b.code.localeCompare(a.code));
          const _rLabel = r => { const t = r.title || ''; return r.code + ' · ' + (t.length > 60 ? t.slice(0, 57) + '…' : t); };
          const currentParent = item.parentId ? getItems().find(i => i.code === item.parentId) : null;
          const ghostOption = (currentParent && !rItems.find(r => r.code === item.parentId))
            ? '<option value="' + esc(currentParent.code) + '" selected>' + esc(_rLabel(currentParent)) + ' [' + esc(currentParent.status) + ']</option>'
            : '';
          return '<div class="bitem-meta-cell" data-action="bitem-meta-stop">'
            + '<span class="bitem-meta-label">R padre</span>'
            + '<select class="item-status-select bitem-select" data-code=\'' + esc(item.code) + '\' data-select-type="parent">'
            + '<option value="">— Sin padre</option>'
            + ghostOption
            + rItems.map(r => '<option value="' + esc(r.code) + '"' + (item.parentId === r.code ? ' selected' : '') + '>' + esc(_rLabel(r)) + '</option>').join('')
            + '</select></div>';
        })() : ''}
      </div>
      ${isIdea ? '' : acHtml}
      ${(() => {
        // R-202604-074: AC Vivo — solo en pendientes con sprint; R-202605-098: nunca en P
        if (isIdea || isDone || isDiscarded || !item.sprint) return '';
        // Sin AC definidos — mensaje + CTA
        if (!item.ac || !item.ac.length) {
          const _emptyId = `acv-panel-empty-${globalIdx}`;
          return `<div class="acv-wrap acv-wrap--empty" id="${_emptyId}">
            <button class="acv-toggle" data-action="acv-toggle" data-panel-id="${_emptyId}" title="Revisión de AC">
              <span class="acv-toggle-arrow">▸</span> Revisión de AC
            </button>
            <div class="acv-body acv-body--hidden">
              <p class="acv-empty-msg">Este ítem no tiene AC — agrega criterios antes de implementar.</p>
              <button class="acv-confirm-btn" data-action="acv-open-editor" data-code="${esc(item.code)}" title="Abrir editor de ítem">✎ Ir a Item Editor</button>
            </div>
          </div>`;
        }
        // Revisar si ya fue confirmado recientemente (< 48h)
        const _acRev = item.acReviewed;
        const _reviewed = _acRev && (Date.now() - _acRev) < 48 * 60 * 60 * 1000;
        // Parser heurístico de ambigüedad
        const _ambigTerms = [
          { re: /tiempo real/i,        desc: '"tiempo real" — define frecuencia o evento exacto' },
          { re: /correctamente/i,      desc: '"correctamente" — sin criterio explícito de corrección' },
          { re: /adecuadamente/i,      desc: '"adecuadamente" — ambiguo sin referencia' },
          { re: /\bfunciona\b/i,       desc: '"funciona" — define qué resultado es válido' },
          { re: /visible\b(?!.*\bcon\b.*\bcontraste\b)/i, desc: '"visible" — sin criterio explícito (contraste, posición, tamaño)' },
          { re: /sin regresi[oó]n(?!\s+en\s+\S)/i, desc: '"sin regresión" — scope no definido' },
        ];
        const _classify = (ac) => {
          if (/click|button|tab|badge|color|layout|css|px|rem|visible|muestra|aparece|oculta/i.test(ac)) return { cls: 'visual', label: 'visual' };
          if (/guarda|persiste|localStorage|storage|calcula|retorna|devuelve|valor/i.test(ac)) return { cls: 'datos', label: 'datos' };
          return { cls: 'funcional', label: 'funcional' };
        };
        const _acRows = item.ac.map((c, ci) => {
          const ambig = _ambigTerms.find(t => t.re.test(c));
          const cat   = _classify(c);
          const rowId = `acv-row-${globalIdx}-${ci}`;
          if (ambig) {
            return `<li class="acv-row acv-row--warn" id="${rowId}">
              <span class="acv-badge acv-badge--warn" title="${esc(ambig.desc)}">⚠</span>
              <span class="acv-text">${esc(c)}</span>
              <button class="acv-clarify-btn" data-action="acv-clarify" data-row-id="${rowId}" data-code="${esc(item.code)}" data-ci="${ci}" title="Aclarar este AC">Aclarar</button>
            </li>`;
          }
          return `<li class="acv-row acv-row--ok" id="${rowId}">
            <span class="acv-badge acv-badge--ok acv-badge--${cat.cls}" title="${cat.label}">✓</span>
            <span class="acv-text">${esc(c)}</span>
          </li>`;
        }).join('');
        const _panelId  = `acv-panel-${globalIdx}`;
        const _revClass = _reviewed ? ' acv-reviewed' : '';
        return `<div class="acv-wrap${_revClass}" id="${_panelId}">
          <button class="acv-toggle" data-action="acv-toggle" data-panel-id="${_panelId}" title="Revisión de AC">
            <span class="acv-toggle-arrow">▸</span> Revisión de AC
          </button>
          <div class="acv-body acv-body--hidden">
            <ul class="acv-list">${_acRows}</ul>
            <button class="acv-confirm-btn" data-action="acv-confirm" data-code="${esc(item.code)}" data-panel-id="${_panelId}" title="Marcar revisión como completada">✓ Confirmar y proceder</button>
          </div>
        </div>`;
      })()}
      ${buildItemRefs(item.code)}
      ${(type === 'REQ' && !opts.suppressChildren) ? _buildChildrenBlock(item.code) : ''}
      ${_buildItemTimestamps(item)}
      ${_buildItemOriginBlock(item)}
      ${item.origin ? _buildItemPOriginBlock(item) : ''}
      ${item.triggeredBy ? `<div class="bitem-origin-p-block">
        <span class="bitem-origin-p-label">Originado durante</span>
        <button class="bitem-origin-p-link" data-action="navigate-origin" data-origin="${esc(item.triggeredBy)}" title="Ir al ítem que originó este ítem">${esc(item.triggeredBy)}</button>
      </div>` : ''}
      ${item.migratedFrom ? _buildItemMigratedBlock(item) : ''}
      ${_buildItemMentionedIn(item)}
      <div class="bitem-footer">
        ${isHistorico ? '' : `<button data-action="bitem-edit" data-code="${esc(item.code)}" class="bitem-edit-btn" title="Editar ítem">✎ Editar</button>`}
        ${(!isHistorico && isIdea && !isDone && !isDiscarded && !_isPPromovida) ? `<button data-action="bitem-promote" data-code="${esc(item.code)}" class="bitem-promote-btn" title="Promover esta posibilidad a Ticket o Requerimiento">⬆ Promover</button>` : ''}
        ${(!isHistorico && type === 'TKT' && !isDone && !isDiscarded) ? `<button data-action="bitem-promote-tkt-to-req" data-code="${esc(item.code)}" class="bitem-promote-btn" title="Promover Ticket a Requerimiento">⬆ → R</button>` : ''}
        ${(!isHistorico && !isDone && !isDiscarded) ? `<button data-action="bitem-migrate" data-code="${esc(item.code)}" class="bitem-promote-btn" title="Mover item a otro proyecto">&#x21C4; Mover</button>` : ''}
      </div>
    </div>
  </div>`;
}

// R-[pendiente-ID]: Promover ítem P → T o R con trazabilidad de origen
function _promoteItem(code) {
  const item = getItems().find(i => i.code === code);
  if (!item) return;

  // R-202604-047: shell estático en index.html — inject content + classList
  const overlay = document.getElementById('promote-modal-overlay');
  if (!overlay) return;
  const body = document.getElementById('promote-modal-body');
  if (body) {
    body.innerHTML = `
      <div class="promote-modal-title" id="promote-modal-title-el">⬆ Promover idea</div>
      <div class="promote-modal-sub">${esc(code)} · ${esc(item.title)}</div>
      <div class="promote-modal-desc">¿A qué tipo quieres promover esta idea?</div>
      <div class="promote-type-btns">
        <button class="promote-type-btn" id="promote-btn-TKT" data-action="promote-select-type" data-type="TKT">
          <div class="promote-type-letter">TKT</div>
          <div class="promote-type-name">Ticket</div>
          <div class="promote-type-hint">Tarea técnica concreta</div>
        </button>
        <button class="promote-type-btn" id="promote-btn-REQ" data-action="promote-select-type" data-type="REQ">
          <div class="promote-type-letter">REQ</div>
          <div class="promote-type-name">Requerimiento</div>
          <div class="promote-type-hint">Feature o épica con tickets</div>
        </button>
      </div>
      <div class="promote-modal-actions">
        <button data-action="promote-modal-cancel" class="btn-cancel">Cancelar</button>
        <button id="promote-confirm-btn" data-action="promote-confirm" data-code="${esc(code)}" class="btn-primary" disabled>Promover</button>
      </div>`;
  }
  _promoteTargetType = null;
  overlay.classList.add('open');
  // AC: foco inicial en primer botón de tipo (flujo P)
  requestAnimationFrame(() => {
    const first = overlay.querySelector('.promote-type-btn');
    if (first) first.focus();
  });
}

let _promoteTargetType = null;

function _promoteSelectType(type) {
  _promoteTargetType = type;
  ['TKT', 'REQ'].forEach(t => {
    const btn = document.getElementById('promote-btn-' + t);
    if (btn) btn.classList.toggle('selected', t === type);
  });
  const confirmBtn = document.getElementById('promote-confirm-btn');
  if (confirmBtn) confirmBtn.disabled = false;
}

function _promoteConfirm(originCode) {
  if (!_promoteTargetType || !_GEN2_TYPES.includes(_promoteTargetType)) return;
  const originItem = getItems().find(i => i.code === originCode);
  if (!originItem) return;

  const newCode = _getNextItemCode(_promoteTargetType);
  const nowTs = Date.now();

  // Crear ítem hijo con campos heredados + origin
  // R-202605-098: ítem hijo nace sin esfuerzo — el campo no se hereda del P original
  getItems().push({
    id: 'item-' + nowTs + '-' + Math.random().toString(36).slice(2, 6),
    code: newCode,
    title: originItem.title,
    desc: originItem.desc || '',
    priority: originItem.priority || 'medium',
    area: originItem.area || '',
    effort: null,
    impact: originItem.impact || 'Medio',
    status: 'pendiente',
    version: 'futura',
    sprint: (originItem.sprint && originItem.sprint.trim() !== 'n/a') ? originItem.sprint : '',
    ac: originItem.ac ? [...originItem.ac] : [],
    origin: originCode,
    sessionId: null,
    createdAt: nowTs,
    statusChangedAt: nowTs,
    doneAt: null
  });

  // R-202605-098: P padre → descartado automático con discardReason trazable
  // No requiere acción manual del founder
  originItem.status = 'descartado';
  originItem.statusChangedAt = nowTs;
  originItem.discardReason = 'promovido a ' + _promoteTargetType + ' ' + newCode;
  originItem.discardRef = newCode; // ref al ítem hijo — habilita bitem--promoted chip

  _blogLog('promovido', originCode, originCode + ' → ' + newCode, 'backlog');
  _undoSnapshot();
  saveBacklog();
  _setBacklogModified();

  const _pmo = document.getElementById('promote-modal-overlay');
  if (_pmo) _pmo.classList.remove('open');
  _promoteTargetType = null;

  _markBacklogListDirty(); renderBacklogList(() => navigateToItem(newCode));
  renderStats();
  showToast('success', `⬆ ${originCode} promovido → ${newCode}`);
}

// T-202604-236: Promover Ticket a Requerimiento desde Backlog UI
function _promoteTktToReq(code) {
  const item = getItems().find(i => i.code === code);
  if (!item) return;
  // AC-5: solo en T pendiente o progreso
  if (item.status === 'done' || item.status === 'descartado') return;

  // R-202604-047: shell estático en index.html — inject content + classList
  // DUP-02: usa shell unificado #promote-modal-overlay
  const overlay = document.getElementById('promote-modal-overlay');
  if (!overlay) return;
  const body = document.getElementById('promote-modal-body');
  if (body) {
    body.innerHTML = `
      <div class="promote-modal-title" id="promote-modal-title-el">⬆ Promover Ticket a Requerimiento</div>
      <div class="promote-modal-sub">${esc(code)} · ${esc(item.title)}</div>
      <div class="promote-modal-info">
        Se creará un <strong>R</strong> heredando los campos del T.<br>
        El T origen quedará <strong>descartado</strong> con referencia al R nuevo.
      </div>
      <div class="promote-modal-actions">
        <button data-action="promote-tkt-to-req-cancel"
          class="btn-ghost">Cancelar</button>
        <button data-action="promote-tkt-to-req-confirm" data-code="${esc(code)}" class="btn-primary" id="promote-tkt-to-req-confirm-btn">⬆ Promover</button>
      </div>`;
  }
  overlay.classList.add('open');
  // AC: foco inicial en botón confirmar (flujo T — sin selector de tipo)
  requestAnimationFrame(() => {
    const confirmBtn = overlay.querySelector('#promote-tkt-to-req-confirm-btn');
    if (confirmBtn) confirmBtn.focus();
  });
}

function _promoteTktToReqConfirm(originCode) {
  const originItem = getItems().find(i => i.code === originCode);
  if (!originItem) return;

  const newCode = _getNextItemCode('REQ');
  const nowTs = Date.now();

  // AC-2: R hereda desc · area · sprint · tags del T origen
  // AC-4: origin del R apunta al T
  getItems().push({
    id: 'item-' + nowTs + '-' + Math.random().toString(36).slice(2, 6),
    code: newCode,
    title: originItem.title,
    desc: originItem.desc || '',
    priority: originItem.priority || 'medium',
    area: originItem.area || '',
    effort: originItem.effort || 1,
    impact: originItem.impact || 'Medio',
    status: 'pendiente',
    version: 'futura',
    sprint: (originItem.sprint && originItem.sprint.trim() !== 'n/a') ? originItem.sprint : '',
    tags: originItem.tags ? [...originItem.tags] : [],
    ac: [],
    origin: originCode,
    sessionId: null,
    createdAt: nowTs,
    statusChangedAt: nowTs,
    doneAt: null
  });

  // AC-3: T origen → descartado con reason:reemplazado + ref al R nuevo
  originItem.status = 'descartado';
  originItem.statusChangedAt = nowTs;
  originItem.discardReason = 'reemplazado';
  originItem.discardRef = newCode;

  _blogLog('promovido-a-req', originCode, originCode + ' → ' + newCode, 'backlog');
  _undoSnapshot();
  saveBacklog();
  _setBacklogModified();

  const overlay = document.getElementById('promote-modal-overlay'); // DUP-02: shell unificado
  if (overlay) overlay.classList.remove('open');

  _markBacklogListDirty(); renderBacklogList(() => navigateToItem(newCode));
  renderStats();
  showToast('success', `⬆ ${originCode} promovido → ${newCode}`);
}

function copyItemCode(e, code, idx) {
  e.stopPropagation();
  // e.currentTarget es el listEl cuando se llama desde delegación — usar closest para obtener el badge real
  const btn = e.target.closest('[data-action="copy-code"]');
  const iconClipboard = btn ? btn.querySelector('.copy-btn-icon--clipboard') : null;
  const iconCheck     = btn ? btn.querySelector('.copy-btn-icon--check') : null;

  const _applyFeedback = () => {
    if (btn) btn.classList.add('is-copied');
    if (iconClipboard) iconClipboard.classList.add('is-hidden');
    if (iconCheck)     iconCheck.classList.remove('is-hidden');
    setTimeout(() => {
      if (btn) btn.classList.remove('is-copied');
      if (iconClipboard) iconClipboard.classList.remove('is-hidden');
      if (iconCheck)     iconCheck.classList.add('is-hidden');
    }, 1500);
  };

  navigator.clipboard.writeText(code).then(() => {
    _applyFeedback();
  }).catch(() => {
    // fallback execCommand
    const ta = document.createElement('textarea');
    ta.value = code;
    ta.className = 'clipboard-ghost';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    _applyFeedback();
  });
}

// T-202604-178: copia ítem formateado para sesión FS
function copyItemToClipboard(e, code) {
  e.stopPropagation();
  const item = getItems().find(i => i.code === code);
  if (!item) return;

  const lines = [];

  // Línea 1: código + título
  lines.push(`[${item.code}] ${item.title || ''}`);

  // Línea 2: campos de contexto
  const meta = [`Status: ${item.status || 'pendiente'}`];
  if (item.effort) meta.push(`Effort: ${item.effort}`);
  if (item.area)   meta.push(`Area: ${item.area}`);
  if (item.sprint) meta.push(`Sprint: ${item.sprint}`);
  lines.push(meta.join(' | '));

  // AC
  if (item.ac && item.ac.length) {
    lines.push('');
    lines.push('AC:');
    item.ac.forEach(c => lines.push(`- ${c}`));
  }

  // Notas (desc)
  if (item.desc && item.desc.trim()) {
    lines.push('');
    lines.push(`Notas: ${item.desc.trim()}`);
  }

  // Tags (si el ítem los tiene)
  if (item.tags && item.tags.length) {
    const tagNames = item.tags.map(tid => {
      const t = (getState().tags || []).find(t => t.id === tid); // T-202606-023: window.state → getState()
      return t ? t.name : tid;
    });
    lines.push(`Tags: ${tagNames.join(', ')}`);
  }

  // T-202606-200: sección EXECUTION-PLAN — busca la sesión del ítem en el plan activo
  const _plan = getActivePlan();
  if (_plan) {
    const _sesiones = Array.isArray(_plan.sesiones) ? _plan.sesiones : [];
    const _sesion = _sesiones.find(s => Array.isArray(s.items) && s.items.includes(item.code));
    if (_sesion) {
      lines.push('');
      lines.push('---EXECUTION-PLAN---');
      lines.push('scope: sesion');
      lines.push('sesiones:');
      lines.push('  - id: ' + (_sesion.id || ''));
      lines.push('    rol: ' + (_sesion.rol || ''));
      const _items = Array.isArray(_sesion.items) ? _sesion.items.join(', ') : '';
      lines.push('    items: [' + _items + ']');
      const _archivos = Array.isArray(_sesion.archivos) && _sesion.archivos.length
        ? _sesion.archivos.join(' · ')
        : '';
      lines.push('    archivos: ' + (_archivos ? _archivos : '[]'));
      const _depende = Array.isArray(_sesion.depende_de) && _sesion.depende_de.length
        ? _sesion.depende_de.join(', ')
        : '';
      lines.push('    depende_de: [' + _depende + ']');
      lines.push('---EXECUTION-PLAN-END---');
    }
  }

  const text = lines.join('\n');
  const btnId = `copy-item-btn-${code}`;

  const _feedback = () => {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    const iconClipboard = btn.querySelector('.copy-btn-icon--clipboard');
    const iconCheck     = btn.querySelector('.copy-btn-icon--check');
    btn.classList.add('is-copied');
    if (iconClipboard) iconClipboard.classList.add('is-hidden');
    if (iconCheck)     iconCheck.classList.remove('is-hidden');
    setTimeout(() => {
      btn.classList.remove('is-copied');
      if (iconClipboard) iconClipboard.classList.remove('is-hidden');
      if (iconCheck)     iconCheck.classList.add('is-hidden');
    }, 1500);
  };

  navigator.clipboard.writeText(text).then(_feedback).catch(() => {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.className = 'clipboard-ghost';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    _feedback();
  });
}

function toggleAc(idx) {
  const list = document.getElementById(`ac-list-${idx}`);
  const arrow = document.getElementById(`ac-arrow-${idx}`);
  if (!list) return;
  list.classList.toggle('open');
  arrow.textContent = list.classList.contains('open') ? '▾' : '▸';
}

export function setFilter(f) {
  currentFilter = f;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  const btn = document.querySelector('.f-' + f);
  if (btn) btn.classList.add('active');
  _markBacklogListDirty(); renderBacklogList();
}

function onBacklogSearch() {
  const input = document.getElementById('backlog-search-input');
  // T-202606-099: valor de búsqueda vive en core — el listener de core actualiza backlogSearchQuery
  const clearBtn = document.getElementById('backlog-search-clear');
  if (clearBtn) clearBtn.classList.toggle('visible', !!_getBacklogSearchQuery());
  updateClearFilterBtn();
  _markBacklogListDirty(); renderBacklogList();
  renderStats(); // B-202605-205: actualizar contadores de tipo con búsqueda activa
}

export function clearBacklogSearch() {
  const input = document.getElementById('backlog-search-input');
  if (input) input.value = '';
  const clearBtn = document.getElementById('backlog-search-clear');
  if (clearBtn) clearBtn.classList.remove('visible');
  updateClearFilterBtn();
  _markBacklogListDirty(); renderBacklogList();
  renderStats(); // B-202605-205: restaurar contadores al limpiar búsqueda
}

export function updateBacklogFooter() {
  // T-202604-360: footer fijo colapsable — dos filas: info + filtros accionables
  const footer = document.getElementById('backlog-footer');
  if (!footer) return;

  // Delegation para filter chips del footer — se registra una sola vez
  if (!footer._delegationAttached) {
    footer._delegationAttached = true;
    footer.addEventListener('click', function _blFooterClick(e) {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const act = btn.dataset.action;
      if (act === 'footer-type-filter') {
        toggleTypeFilter(btn.dataset.type);
      } else if (act === 'footer-status-filter') {
        toggleStatusFilter(btn.dataset.status);
      } else if (act === 'footer-effort-filter') {
        toggleEffortFilter(parseInt(btn.dataset.effort, 10));
      } else if (act === 'footer-clear-filters') {
        clearAllFilters();
      }
    });
  }

  // TKT-C2: 'promoted' (Gen2). Edge case: datos legacy 'promovida' también excluidos.
  const _isActive = i => i.status !== 'descartado' && i.status !== 'promoted' && i.status !== 'promovida' && i.status !== 'historico';
  const pend        = getItems().filter(i => _isActive(i) && i.status === 'pendiente').length;
  const enRevision  = getItems().filter(i => _isActive(i) && i.status === 'en-revision').length;
  // B-202606-036: done+icebox no contabiliza — consistente con stats-bar (Capa 3 per BR-Ecosystem §5)
  const done        = getItems().filter(i => _isActive(i) && i.status === 'done' && !(!i.sprint || i.sprint === 'icebox')).length;
  const byType      = { INC: 0, TKT: 0, REQ: 0, DISC: 0 };
  // T-202606-096: byType usa mismo universo activos — status ≠ descartado ≠ promovida ≠ historico
  // + excluye done+icebox (Capa 3 BR-Ecosystem §5) para que INC+TKT+REQ+DISC = Pendiente+EnRevisión+Done
  getItems().forEach(i => {
    if (!_isActive(i)) return;
    if (i.status === 'done' && (!i.sprint || i.sprint === 'icebox')) return;
    const t = itemKind(i); if (t && byType[t] !== undefined) byType[t]++;
  });
  const activeSp = _getActiveSprint();

  const _emitidosF = getItems().length;
  const _doneF = getItems().filter(i => i.status === 'done').length;
  const _descartadosF = getItems().filter(i => i.status === 'descartado').length;
  const _promovidasF = getItems().filter(i => i.status === 'promoted' || i.status === 'promovida').length;
  const _cerradosF = _descartadosF + _promovidasF;

  footer.innerHTML = `
    <div class="bl-footer-row bl-footer-row--single" id="bl-footer-filters">
      <div class="bl-footer-filter-group bl-footer-group--historical">
        <span class="bl-filter-label">Histórico</span>
        <span class="sph-item" title="${_emitidosF} ítems totales">${_emitidosF} emitidos</span><span class="sph-sep">·</span><span class="sph-item">${_doneF} hechos</span><span class="sph-sep">·</span><span class="sph-item sph-cerrados" title="${_descartadosF} descartados · ${_promovidasF} promovidas">${_cerradosF} cerrados sin trabajo</span>
      </div>
      <div class="bl-footer-filter-group">
        <span class="bl-filter-label">Tipo</span>
        ${[['B','Bug'],['T','Ticket'],['R','Req'],['P','Pos.']].map(([t,l]) =>
          `<button class="bl-filter-chip bl-fc-type-${t}${_getActiveTypes().has(t) ? ' active' : ''}" data-action="footer-type-filter" data-type="${t}" title="${l}">${t} <span>${byType[t]}</span></button>`
        ).join('')}
      </div>
      <div class="bl-footer-filter-group">
        <span class="bl-filter-label">Esfuerzo</span>
        ${[1,2,3].map(e => {
          const cnt = getItems().filter(i => _isActive(i) && (parseInt(i.effort)||1) === e).length;
          return `<button class="bl-filter-chip${_getActiveEfforts().has(e) ? ' active' : ''}" data-action="footer-effort-filter" data-effort="${e}" title="Effort ${e}">E${e} <span>${cnt}</span></button>`;
        }).join('')}
      </div>
    </div>
  `;

  // restaurar estado colapsado si aplica
  if (_blFooterCollapsed) {
    const filtersRow = document.getElementById('bl-footer-filters');
    const toggleBtn  = document.getElementById('bl-footer-toggle');
    if (filtersRow) filtersRow.classList.add('bl-footer-row--hidden');
    if (toggleBtn)  toggleBtn.textContent = '▼';
  }
}

// B-202604-198: Helper — detecta si un code es placeholder (nunca matchear contra backlog)
export function _isPlaceholderCode(code) {
  if (!code) return true;
  if (code === '[pendiente-ID]') return true;
  if (/^\[tmp:[a-z0-9_-]+\]$/i.test(code)) return true;
  return false;
}

// B-202604-198: Helper — busca ítem existente cuyo title es similar a un [tmp:slug]
// Retorna { item, score } o null. Solo sugiere — nunca aplica automáticamente.
// T-202605-136: incomingType restringe la búsqueda al mismo type — evita que un T nuevo
// con [tmp:slug] matchee contra una P existente con título similar.
function _findTmpMatch(tmpCode, desc, existingItems, incomingType) {
  if (!desc) return null;
  const needle = desc.trim().toLowerCase();
  let best = null, bestScore = 0;
  existingItems.forEach(item => {
    // T-202605-136: solo matchear contra ítems del mismo type que el entrante
    if (incomingType && item.type && item.type !== incomingType) return;
    const haystack = (item.title || '').trim().toLowerCase();
    if (!haystack) return;
    // Similitud: palabras en común / total palabras
    const needleWords = needle.split(/\s+/);
    const haystackWords = haystack.split(/\s+/);
    const common = needleWords.filter(w => w.length > 3 && haystackWords.includes(w)).length;
    const score = common / Math.max(needleWords.length, haystackWords.length);
    if (score > 0.5 && score > bestScore) { best = item; bestScore = score; }
  });
  return best ? { item: best, score: bestScore } : null;
}

// B-202605-guardar-sesion: _assignPendingIds — convierte [pendiente-ID] en código real.
// Llamado por mergeBacklogFromTG antes de procesar ítems.
// AC-3: ítems sin type válido se dejan con [pendiente-ID] sin modificar.
// AC-4: ítems con código real pasan sin modificación.
// AC-5: [tmp:slug] pasan sin modificación — tienen su propio flujo (_findTmpMatch).
// B-202605-ids: reservedCodes acumula los códigos asignados en esta pasada para que
// _getNextItemCode no repita el mismo número cuando hay múltiples [pendiente-ID] del
// mismo tipo — los ítems nuevos aún no están en getItems() en el momento de la asignación.
// T-202605-140 T2: Paso 1 — asignar IDs reales y construir slugMap.
//   slugMap mapea [tmp:slug] y [pendiente-ID] asignado → código real.
//   Ítems con código real existente se registran como identidad: code → code.
// T-202605-140 T2: Paso 2 — resolver referencias cruzadas (dependsOn, parentId,
//   triggeredBy, origenDisc, promovida_a) usando slugMap. Referencia no resuelta → null/[].
export function _assignPendingIds(tgItems, seedSlugMap) {
  // TKT1 (REQ-[pendiente-ID] · Integridad de generación y persistencia de código de ítems):
  //   validTypes Gen1 (P/T/R/B) reemplazado por _GEN2_TYPES — los 7 tipos canónicos
  //   (REQ/TKT/DISC/INC/PRB/KE/CHG). Causa raíz confirmada: con el set Gen1, todo ítem
  //   Gen2 entrante con [pendiente-ID] o [tmp:slug] quedaba sin asignar silenciosamente.
  const validTypes = new Set(_GEN2_TYPES);
  const reservedCodes = new Set();

  // T-202605-140 T2 · Paso 1: construir slugMap mientras se asignan IDs
  const slugMap = new Map();

  // TKT2 (REQ-[pendiente-ID] · Ingesta batch de CHECKPOINTs): seedSlugMap ausente/undefined →
  //   comportamiento idéntico al actual, slugMap se construye desde cero. Si está presente
  //   (slugMap acumulado de un bloque previo del mismo batch), sus entradas se copian primero
  //   y tienen precedencia como identidad ya resuelta — ver guard en sub-paso 1a, que evita
  //   reasignar código nuevo a un [tmp:slug] ya resuelto en el seed.
  if (seedSlugMap instanceof Map) {
    seedSlugMap.forEach((v, k) => slugMap.set(k, v));
  }

  // Pre-poblar slugMap con códigos reales ya existentes (identidad: code → code)
  tgItems.forEach(item => {
    if (item.code && !_isPlaceholderCode(item.code)) {
      slugMap.set(item.code, item.code);
    }
  });

  // T-202605-137: Paso 1 separado en dos sub-pasos para garantizar que slugMap esté completo
  // antes de resolver referencias. Esto cubre el caso donde un patch con promovida_a:[pendiente-ID]
  // aparece antes del ítem nuevo en el array — el orden en el CHECKPOINT no debe importar.

  // Sub-paso 1a: asignar IDs reales a todos los [pendiente-ID] y [tmp:slug] con type válido,
  // y construir slugMap completo ANTES de resolver cualquier referencia cruzada.
  const paso1 = tgItems.map(item => {
    // T-202606-005: [tmp:slug] con type válido — asignar código real y registrar en slugMap
    // para que las referencias cruzadas (parent, depends_on, triggered_by, origen_disc, promovida_a)
    // dentro del mismo bloque resuelvan correctamente.
    // [tmp:slug] sin type válido: conservar literal — siguen flujo _findTmpMatch existente.
    if (item.code && /^\[tmp:[a-z0-9_-]+\]$/i.test(item.code)) {
      if (!item.type || !validTypes.has(item.type)) return item; // sin type — conservar literal
      // TKT2: slug ya resuelto en el seed (bloque previo del mismo batch) — identidad ya
      // resuelta tiene precedencia, no reasignar código nuevo.
      if (slugMap.has(item.code)) {
        return { ...item, code: slugMap.get(item.code), _wasAssigned: true };
      }
      const newCode = _getNextItemCode(item.type, reservedCodes);
      reservedCodes.add(newCode);
      slugMap.set(item.code, newCode); // tmp:slug → código real asignado
      slugMap.set(newCode, newCode);   // identidad del código asignado
      return { ...item, code: newCode, _wasAssigned: true };
    }
    if (item.code !== '[pendiente-ID]') return item; // AC-4: código real — sin modificación
    if (!item.type || !validTypes.has(item.type)) return item; // AC-3: type inválido — no asignar
    const newCode = _getNextItemCode(item.type, reservedCodes);
    reservedCodes.add(newCode);
    // T-202605-137: registrar con clave única por item (usando índice implícito en el código asignado)
    // para que múltiples [pendiente-ID] no se sobreescriban. El slugMap usa el código asignado
    // como clave de identidad; la clave '[pendiente-ID]' es solo el último asignado (compat legacy).
    slugMap.set('[pendiente-ID]', newCode); // identidad de la última asignación — compat legacy bloques de un ítem
    slugMap.set(newCode, newCode);          // identidad del código asignado — para resolución directa
    return { ...item, code: newCode, _wasAssigned: true };
  });

  // Sub-paso 1b: construir índice invertido de códigos asignados para resolver referencias
  // cross-item. Para cada item que fue asignado, su código real ya está en slugMap.
  // Si hay exactamente un [pendiente-ID] en el batch original, slugMap['[pendiente-ID]'] lo resuelve.
  // Si hay múltiples, la resolución es ambigua — conservar literal (comportamiento previo).
  const assignedCount = paso1.filter(i => i._wasAssigned).length;
  // Si hay más de un [pendiente-ID] asignado, la clave '[pendiente-ID]' apunta solo al último.
  // En ese caso, references que usen [pendiente-ID] como valor quedan sin resolver (conservar literal).
  if (assignedCount > 1) {
    // Eliminar la clave genérica para forzar conservar-literal en Paso 2
    slugMap.delete('[pendiente-ID]');
  }

  // T-202605-140 T2 · Paso 2: resolver referencias cruzadas usando slugMap
  // Campos de referencia: dependsOn, parentId, triggeredBy, origenDisc, promovida_a
  // Referencia presente en slugMap → reemplazar con código real.
  // [pendiente-ID] no resuelta → conservar literal — puede resolverse en pasada posterior.
  // [tmp:slug] no resuelta → null/[] + _blogLog('tmp-slug-no-resoluble') — slug sin type
  //   que no aparece como ítem en el bloque: no tiene sentido conservar la referencia.
  // Referencia con formato de código real (no placeholder) no existente en backlog →
  //   null/[] + _blogLog('ref-no-resuelta') — el código debería existir y no existe.
  const _refFields = ['parentId', 'triggeredBy', 'origenDisc', 'promovida_a'];
  const _listFields = ['dependsOn'];

  const resolvedItems = paso1.map(item => {
    let changed = false;
    const patch = {};

    // Campos escalares de referencia
    _refFields.forEach(field => {
      const val = item[field];
      if (!val) return;
      if (_isPlaceholderCode(val)) {
        // Placeholder: intentar resolver via slugMap
        const resolved = slugMap.get(val);
        if (resolved) {
          patch[field] = resolved;
          changed = true;
        } else if (field === 'promovida_a') {
          // T-202605-137: AC error — promovida_a con pendiente-ID sin ítem nuevo correspondiente
          // Conservar literal para pasadas posteriores, pero registrar advertencia en DocLog
          _blogLog('promovida-a-no-resuelta', item.code || '[sin-código]',
            'promovida_a: ' + val + ' no pudo resolverse — no hay ítem nuevo con ese pendiente-ID en este CHECKPOINT',
            'backlog');
        } else if (/^\[tmp:[a-z0-9_-]+\]$/i.test(val)) {
          // T-202606-005: [tmp:slug] sin type valido no resoluble — null + log
          // No tiene sentido conservar la referencia: el slug no tiene item correspondiente en el bloque.
          _blogLog('tmp-slug-no-resoluble', item.code || '[sin-codigo]',
            field + ': ' + val + ' no pudo resolverse — [tmp:slug] sin type valido en este bloque',
            'backlog');
          patch[field] = null;
          changed = true;
        }
        // [pendiente-ID] sin resolucion — conservar literal para pasadas posteriores
      } else {
        // Código con formato real: si no existe en backlog → null + log
        const existsInBacklog = getItems() && getItems().find(i => i.code === val);
        if (!existsInBacklog) {
          _blogLog('ref-no-resuelta', item.code || '[sin-código]', field + ': ' + val + ' no existe en el backlog', 'backlog');
          patch[field] = null;
          changed = true;
        }
      }
    });

    // Campos de lista de referencias (dependsOn)
    _listFields.forEach(field => {
      const arr = item[field];
      if (!Array.isArray(arr) || !arr.length) return;
      let listChanged = false;
      const resolved = arr.map(val => {
        if (!val) return val;
        if (_isPlaceholderCode(val)) {
          // Placeholder: intentar resolver via slugMap
          const mapped = slugMap.get(val);
          if (mapped) { listChanged = true; return mapped; }
          // T-202606-005: [tmp:slug] sin resolucion — null + log (se filtra del array)
          if (/^\[tmp:[a-z0-9_-]+\]$/i.test(val)) {
            _blogLog('tmp-slug-no-resoluble', item.code || '[sin-codigo]',
              field + '[]: ' + val + ' no pudo resolverse — [tmp:slug] sin type valido en este bloque',
              'backlog');
            listChanged = true;
            return null;
          }
          // [pendiente-ID] sin resolucion — conservar literal para pasadas posteriores
          return val;
        } else {
          // Código con formato real: si no existe en backlog → null + log
          const existsInBacklog = getItems() && getItems().find(i => i.code === val);
          if (!existsInBacklog) {
            _blogLog('ref-no-resuelta', item.code || '[sin-código]', field + '[]: ' + val + ' no existe en el backlog', 'backlog');
            listChanged = true;
            return null;
          }
          return val;
        }
      }).filter(v => v !== null);
      if (listChanged) { patch[field] = resolved; changed = true; }
    });

    return changed ? { ...item, ...patch } : item;
  });
  // B-202606-022: exponer slugMap para que mergeBacklogFromTG lo propague hasta applyPatchesFromTG
  return { items: resolvedItems, slugMap };
}

// TKT-PARSER-2a (REQ-[pendiente-ID]): tabla de pares válidos de transición ITIL.
// Clave: incidentStatus origen. Valor: Set de incidentStatus destino permitidos desde ese origen.
// Distinto de _VALID_INCIDENT_STATUS (locus-session-parse.js) — ese set valida pertenencia
// del valor al vocabulario ITIL; esta tabla valida que el PAR origen→destino sea una
// transición real del ciclo de vida (BR-Core §6), no solo que ambos valores existan.
const _VALID_INCIDENT_TRANSITIONS = {
  detected:    new Set(['assigned']),
  assigned:    new Set(['in_progress']),
  in_progress: new Set(['resolved', 'escalated_to_prb', 'escalated_to_chg']),
  resolved:    new Set(['closed'])
  // closed, escalated_to_prb, escalated_to_chg, descartado: sin transiciones salientes declaradas —
  // estados terminales del ciclo dentro de este merge. Reabrir un INC closed no es un caso cubierto
  // por este AC — fuera de scope de TKT-PARSER-2a.
};

// TKT-PARSER-2a (REQ-[pendiente-ID]): valida un par (oldIncidentStatus, newIncidentStatus).
// No usa VALID_TRANSITIONS (locus-session-save.js) — esa tabla es de status Scrum por tipo,
// no de transiciones ITIL por par origen→destino. Devuelve {valid:true} o {valid:false, reason}.
function validateIncidentTransitions(oldIncidentStatus, newIncidentStatus) {
  if (!_VALID_INCIDENT_STATUS.has(oldIncidentStatus) || !_VALID_INCIDENT_STATUS.has(newIncidentStatus)) {
    // Valor fuera del vocabulario ITIL — ya debió rechazarse en _buildItilItem (locus-session-parse.js).
    // Defensivo: no es una transición ITIL inválida en sí, es un valor inválido — no bloquear aquí.
    return { valid: true };
  }
  const _allowed = _VALID_INCIDENT_TRANSITIONS[oldIncidentStatus];
  if (!_allowed || !_allowed.has(newIncidentStatus)) {
    return { valid: false, reason: `transición ITIL inválida: ${oldIncidentStatus} → ${newIncidentStatus}` };
  }
  return { valid: true };
}

// ── T-098: Merge TRACKER-GLOBAL → getItems() en memoria ──
// Llamado desde saveSession(). Acumula múltiples sesiones sin exportar.
// T-202604-121: retorna {created, updated, ignored} para super toast
export function mergeBacklogFromTG(tgItems, sessionId, opts) {
  // TKT2 (REQ-[pendiente-ID] · Ingesta batch de CHECKPOINTs): slugMap: new Map() agregado al
  // resultado de items vacíos — sin esto, el orquestador de batch (_applyCheckpointBatch,
  // locus-session-save.js) pierde la cadena de seedSlugMap si un bloque del batch no trae ítems.
  if (!tgItems || !tgItems.length) return { created:[], advanced:[], retroceso:[], discarded:[], updated:[], ignored:[], createdAndClosed:[], tmpSuggestions:[], invalidTransition:[], slugMap: (opts && opts.seedSlugMap instanceof Map) ? opts.seedSlugMap : new Map() };
  const _dryRun   = !!(opts && opts.dryRun);
  const _ckptRol  = (opts && opts.ckptRol) || '';

  // B-202604-198: Separar placeholders ANTES de _assignPendingIds para preservar su naturaleza.
  // Los placeholders siempre son ítems nuevos — nunca matchean contra el backlog.
  // _assignPendingIds se aplica solo a los que tienen type char válido (P/T/R/B) y código real.
  // B-202606-022: _assignPendingIds retorna { items, slugMap } — slugMap se propaga hasta applyPatchesFromTG
  // TKT2: opts.seedSlugMap propagado — encadena la identidad de [tmp:slug] resuelta en bloques
  // previos del mismo batch (ver _applyCheckpointBatch, locus-session-save.js).
  const { items: _assignedItems, slugMap: _slugMap } = _assignPendingIds(tgItems, opts && opts.seedSlugMap);
  tgItems = _assignedItems;

  // B-202605-016: normalizar campo parent (schema CHECKPOINT) → parentId (campo interno)
  // El schema declara "parent" pero el código usa parentId — mapear antes del loop
  // T-202606-009: normalizar depends_on (schema) → dependsOn (campo interno) — mismo patrón.
  // Sin esta normalización los slugs en depends_on nunca llegan a _listFields de _assignPendingIds
  // y se pierden silenciosamente: el campo queda undefined en lugar de [] con slugs resueltos.
  // T-[pendiente-ID] (REQ-unify-parent TKT2): tras normalizar a parentId, eliminar item.parent del
  // objeto en memoria — parentId es el único campo canónico en JS desde aquí en adelante. Sin esto,
  // ítems recién ingresados arrastraban .parent como campo legacy durante toda su vida en memoria.
  tgItems = tgItems.map(item => {
    if (item.parent) { if (!item.parentId) item.parentId = item.parent; delete item.parent; }
    if (Array.isArray(item.depends_on) && !item.dependsOn) { item.dependsOn = item.depends_on; }
    return item;
  });

  let changed = false;
  const created = [], advanced = [], retroceso = [], discarded = [], updated = [], ignored = [], invalidTransition = []; // invalidTransition: T-[pendiente-ID]
  // B-202604-198: grupo propio para ítems que nacen y cierran en el mismo CHECKPOINT
  const createdAndClosed = [];
  // B-202604-198: sugerencias de match [tmp:slug] → ID real existente (para confirmación del usuario)
  const tmpSuggestions = [];

  // Orden de avance: pendiente < done < descartado (descartado solo vía confirmación)
  const _statusRank = { pendiente: 0, discovery: 0, 'en-revision': 0.5, promoted: 0.8, promovida: 0.8, done: 1, descartado: 2 }; // T-202606-032 / B-202606-016: rank 0.8 · TKT-C2: 'promoted' Gen2 + 'promovida' legacy · TKT-202606-008: 'discovery' mismo rank que 'pendiente' — ítem activo sin avance de ciclo

  // B-202606-047: ordenar batch — REQ primero, luego TKT/INC, luego el resto.
  // Sin este orden, cuando REQ y sus TKT llegan en el mismo CHECKPOINT el find de parentId
  // no encuentra al REQ padre (aún no pusheado a getItems()) → parentId: null en todos los TKT.
  const _typeOrder = { REQ: 0, TKT: 1, INC: 1, DISC: 2 };
  tgItems.sort((a, b) => {
    const tA = itemKind(a) || 'DISC';
    const tB = itemKind(b) || 'DISC';
    return (_typeOrder[tA] ?? 3) - (_typeOrder[tB] ?? 3);
  });

  // B-202605-007: snapshot antes de cualquier mutación — incluye cierre automático de P padre
  if (!_dryRun) _undoSnapshot();

  tgItems.forEach(item => {
    if (!item.code) return;
    if (item._invalidType) { ignored.push({ code: item.code || '[sin-código]', reason: 'tipo-invalido', desc: item.title }); return; }
    if (item._duplicate) {
      // B-202605-XXX: ítem duplicado (título matchea existente via _assignPendingIds) —
      // aunque se ignore para status/creación, si trae AC se mergean sobre el existente.
      if (item.ac && item.ac.length && item._existingCode && !_dryRun) {
        const dupExisting = getItems().find(i => i.code === item._existingCode);
        if (dupExisting) {
          dupExisting.ac = item.ac;
          _acReplacedSet.add(dupExisting.id);
          if (sessionId && dupExisting.sessionId !== sessionId) dupExisting.sessionId = sessionId;
          if (!dupExisting.history) dupExisting.history = [];
          dupExisting.history.push({ type: 'field', ts: Date.now(), origin: 'checkpoint', sessionId: sessionId || null, data: { field: 'ac', from: null, to: item.ac } });
          changed = true;
        }
      }
      ignored.push({ code: '[pendiente-ID]', reason: 'duplicado', desc: item.title, existingCode: item._existingCode || '' });
      return;
    }

    // B-202604-198: REGLA DE PLACEHOLDER — forzar rama "nuevo" sin intentar match
    // Un [tmp:slug] o [pendiente-ID] NUNCA matchea contra getItems() existentes.
    // Nota: _assignPendingIds ya habrá convertido [pendiente-ID] con type char real si tiene
    // suficiente info; si no pudo (sin type), sigue siendo placeholder.
    const isPlaceholder = _isPlaceholderCode(item.code);

    // B-202604-198: REGLA DE TMP — detectar si [tmp:slug] corresponde a un ID real existente
    // por similitud de título. Si hay match potencial, registrar sugerencia y NO crear duplicado.
    if (isPlaceholder && /^\[tmp:[a-z0-9_-]+\]$/i.test(item.code)) {
      const tmpMatch = _findTmpMatch(item.code, item.title, getItems(), item.type);
      if (tmpMatch) {
        tmpSuggestions.push({
          tmpCode: item.code,
          desc: item.title,
          suggestedCode: tmpMatch.item.code,
          suggestedTitle: tmpMatch.item.title,
          score: tmpMatch.score
        });
        // No crear duplicado — el usuario confirma el match en el panel
        return;
      }
    }

    // B-202604-198: si es placeholder, saltar directamente a rama "nuevo"
    const existing = isPlaceholder ? null : getItems().find(i => i.code === item.code);
    if (existing) {
      const newStatus = item.status; // T-202606-034: item.status ya canónico desde T1 — _tgStatusToBacklog eliminada
      const oldStatus = existing.status || 'pendiente';
      const changes = [];

      // T-[pendiente-ID] · AC-1: filtro pre-clasificación — transición inválida interceptada antes de _statusRank
      // AC-2: type desconocido → no interceptar. AC-3: sin status → no interceptar.
      // TKT0c-gen2: itemKind(existing) reemplaza la inferencia local por prefijo (eliminada) y la tabla inline.
      // TKT-PARSER-2b (REQ-[pendiente-ID]): INC/PRB/KE ahora llegan con item.status poblado
      // (mirror de incidentStatus, ver locus-session-parse.js _buildItilItem) — sin esta
      // exclusión, validateLifecycleTransitions (Scrum, vocabulario TKT/REQ/DISC) interceptaría
      // transiciones ITIL válidas (ej. detected→assigned) como inválidas por desconocer ese
      // vocabulario. La validación real de estos 3 tipos vive en el bloque ITIL dedicado de abajo
      // (validateIncidentTransitions). CHG no se excluye — su vocabulario es Scrum-compatible
      // (pendiente/en-revision/done/descartado) y este bloque lo valida correctamente.
      const _skipScrumGate = ['INC', 'PRB', 'KE'].includes(itemKind(existing));
      if (!_skipScrumGate && newStatus && newStatus !== oldStatus && !item._noStatus) {
        const _existingKind = itemKind(existing);
        if (_existingKind !== null) {
          // Importar VALID_TRANSITIONS directamente para verificación inline (evita llamada costosa al array completo)
          const _vtResult = validateLifecycleTransitions([{ code: item.code, type: _existingKind, status: newStatus }]);
          if (_vtResult.length > 0) {
            // Transición inválida — registrar y saltar toda la lógica de status para este ítem
            invalidTransition.push(_vtResult[0]);
            // Continuar con campos no-status (title, effort, area, etc.) — solo status queda excluido
            // Marcar item._noStatus para que el bloque de lógica de status no lo procese
            item._noStatus = true;
          }

          // T-202606-031 · TKT0c-gen2: validación de rol autorizado para REQ → bloqueado
          // AC-1/AC-4: solo 'QA · Finn' puede mover un REQ a status 'bloqueado'.
          // Si el rol no es el autorizado — registrar en invalidTransition y excluir el cambio de status.
          // AC-3: si no hay status entrante o no es 'bloqueado' — no interceptar.
          if (!item._noStatus && _existingKind === 'REQ' && newStatus === 'bloqueado' && _ckptRol !== 'QA · Finn') {
            invalidTransition.push({
              code: item.code,
              type: 'REQ',
              status: 'bloqueado',
              reason: `rol no autorizado: solo QA · Finn puede mover un REQ a bloqueado (recibido: ${_ckptRol || '(sin rol)'})`
            });
            item._noStatus = true;
          }
        }
      }

      // TKT-PARSER-2a (REQ-[pendiente-ID]): validación de transición ITIL — paralela al bloque
      // Scrum de arriba. TKT-PARSER-2b: INC/PRB/KE quedan excluidos del bloque Scrum vía
      // _skipScrumGate — su único camino de validación de status es esta rama
      // (validateIncidentTransitions). CHG sí pasa por el bloque Scrum (vocabulario compatible)
      // y no entra a esta rama de incidentStatus porque no lo declara.
      const _existingKindItil = itemKind(existing);
      const _isItilExisting = ['INC', 'PRB', 'KE', 'CHG'].includes(_existingKindItil);
      let _noIncidentStatus = false;
      if (_isItilExisting && item.incidentStatus && item.incidentStatus !== existing.incidentStatus) {
        const _itResult = validateIncidentTransitions(existing.incidentStatus, item.incidentStatus);
        if (!_itResult.valid) {
          invalidTransition.push({ code: item.code, type: _existingKindItil, reason: _itResult.reason });
          _noIncidentStatus = true; // excluye solo incidentStatus — el resto de campos ITIL sí mergea
        }
      }

      // --- Lógica de status ---
      if (!item._noStatus && newStatus && newStatus !== oldStatus) {
        const oldRank = _statusRank[oldStatus] ?? 0;
        const newRank = _statusRank[newStatus] ?? 0;

        if (newStatus === 'descartado') {
          // Descarte: encolar para confirmación — no persistir todavía
          discarded.push({ code: item.code, desc: existing.title, from: oldStatus, reason: item.discardReason || existing.discardReason || '', ref: item.discardRef || existing.discardRef || '' });
          // No tocar existing todavía — se aplica en _confirmDiscard()
        } else if (newRank > oldRank) {
          // Avance: aplicar directo (no en dryRun)
          changes.push({ field: 'status', from: oldStatus, to: newStatus }); // T-202604-414
          if (!_dryRun) {
            existing.status = newStatus;
            existing.statusChangedAt = Date.now();
            if (newStatus === 'done' && !existing.doneAt) existing.doneAt = Date.now();
            if (!existing.history) existing.history = [];
            existing.history.push({ type: 'status', ts: Date.now(), origin: 'checkpoint', aiId: _getActiveSessionAiId() || null, data: { from: oldStatus, to: newStatus } }); // B-202606-012
            _blogLog('ckpt-avance', item.code, oldStatus + ' → ' + newStatus, 'backlog');
            changed = true;
            // B-202606-017 AC-1+AC-2: transición automática del R padre tras avance de T/B via CHECKPOINT
            _checkAndAdvanceParentR(item.code, Date.now());
          }
          advanced.push({ code: item.code, desc: existing.title, from: oldStatus, to: newStatus });
        } else if (newRank < oldRank) {
          // Retroceso: encolar para confirmación — no persistir todavía
          retroceso.push({ code: item.code, desc: existing.title, from: oldStatus, to: newStatus });
          // No tocar existing todavía — se aplica en _confirmRetroceso()
        }
        // newRank === oldRank: status idéntico al existente — ignorar silenciosamente (B-202605-086)
      }

      // --- Resto de campos: entrante gana si trae valor (vacíos no degradan) ---
      // T-202604-414: changes es array de {field, from, to} para diff inline en panel
      if (item.title && item.title !== existing.title) { changes.push({ field: 'title', from: existing.title || '—', to: item.title }); if (!_dryRun) { existing.title = item.title; changed = true; } }
      if (item.desc && item.desc !== existing.desc) { changes.push({ field: 'desc', from: existing.desc || '—', to: item.desc }); if (!_dryRun) { existing.desc = item.desc; changed = true; } }
      if (item.effort && item.effort !== existing.effort) { changes.push({ field: 'effort', from: existing.effort || '—', to: item.effort }); if (!_dryRun) { existing.effort = item.effort; changed = true; } }
      if (item.area && item.area !== existing.area) { changes.push({ field: 'area', from: existing.area || '—', to: item.area }); if (!_dryRun) { existing.area = item.area; changed = true; } }
      // TKT-PARSER-2a (REQ-[pendiente-ID]): campos ITIL — mismo patrón entrante-gana-si-trae-valor.
      // incidentStatus respeta _noIncidentStatus (transición rechazada arriba) — el resto de campos
      // ITIL del mismo CHECKPOINT sí mergea aunque la transición de estado se haya excluido (AC-5).
      if (_isItilExisting) {
        if (!_noIncidentStatus && item.incidentStatus && item.incidentStatus !== existing.incidentStatus) {
          changes.push({ field: 'incidentStatus', from: existing.incidentStatus || '—', to: item.incidentStatus });
          // INC-[pendiente-ID] (sin camino de reparación para status corrupto en ítems ITIL):
          // _skipScrumGate (arriba) excluye a INC/PRB/KE del bloque de avance/retroceso Scrum —
          // ese bloque era el único que escribía existing.status. Sin este mirror, existing.status
          // queda congelado en el valor con el que el ítem nació (ej. 'pendiente' pre-TKT-PARSER-2b)
          // para siempre — ni merge ni patch lo corrigen, y chk_status_by_type de Supabase rechaza
          // el upsert indefinidamente. existing.status espeja existing.incidentStatus para tipos ITIL.
          if (!_dryRun) { existing.incidentStatus = item.incidentStatus; existing.status = item.incidentStatus; changed = true; }
        }
        // TKT1 (REQ-inc-historico): al cerrar un incidente vía patch/merge, se fija archivedInSprint
        // al sprint 'active' actual — primer valor gana, nunca se recalcula si ya existía (AC fuera
        // de scope). Sin sprint 'active' → queda sin asignar, no bloquea el resto del merge.
        if (!_noIncidentStatus && item.incidentStatus === 'closed' && !existing.archivedInSprint) {
          const _openSprint = getActiveSprints().find(s => s.status === 'active');
          if (_openSprint) {
            changes.push({ field: 'archivedInSprint', from: existing.archivedInSprint || '—', to: _openSprint.id });
            if (!_dryRun) { existing.archivedInSprint = _openSprint.id; changed = true; }
          }
        }
        if (item.slaPriority && item.slaPriority !== existing.slaPriority) { changes.push({ field: 'slaPriority', from: existing.slaPriority || '—', to: item.slaPriority }); if (!_dryRun) { existing.slaPriority = item.slaPriority; changed = true; } }
        if (item.slaDeadline != null && item.slaDeadline !== existing.slaDeadline) { changes.push({ field: 'slaDeadline', from: existing.slaDeadline || '—', to: item.slaDeadline }); if (!_dryRun) { existing.slaDeadline = item.slaDeadline; changed = true; } }
        if (item.resolutionType && item.resolutionType !== existing.resolutionType) { changes.push({ field: 'resolutionType', from: existing.resolutionType || '—', to: item.resolutionType }); if (!_dryRun) { existing.resolutionType = item.resolutionType; changed = true; } }
        if (item.comportamientoActual && item.comportamientoActual !== existing.comportamientoActual) { changes.push({ field: 'comportamientoActual', from: existing.comportamientoActual || '—', to: item.comportamientoActual }); if (!_dryRun) { existing.comportamientoActual = item.comportamientoActual; changed = true; } }
        if (item.originModule && item.originModule !== existing.originModule) { changes.push({ field: 'originModule', from: existing.originModule || '—', to: item.originModule }); if (!_dryRun) { existing.originModule = item.originModule; changed = true; } }
        if (item.derivedItems && item.derivedItems.length) { changes.push({ field: 'derivedItems', from: existing.derivedItems || [], to: item.derivedItems }); if (!_dryRun) { existing.derivedItems = item.derivedItems; changed = true; } }
      }
      // B-202605-233: sprint vacío explícito ('' ) mueve ítem a Ideas — antes se ignoraba por falsy
      if (item.sprint !== undefined && item.sprint !== existing.sprint) { changes.push({ field: 'sprint', from: existing.sprint || '—', to: item.sprint }); if (!_dryRun) { existing.sprint = item.sprint; changed = true; } }
      // B-202604-179: ac: reemplaza si entrante trae contenido — no acumula entre CHECKPOINTs
      if (item.ac && item.ac.length) {
        changes.push({ field: 'ac', from: existing.ac || [], to: item.ac });
        if (!_dryRun) { existing.ac = item.ac; _acReplacedSet.add(existing.id); changed = true; }
      }
      // AC-4: role entrante gana si trae valor; si vacío no degrada el existente
      if (item.role && item.role !== existing.role) { changes.push({ field: 'role', from: existing.role || '—', to: item.role }); if (!_dryRun) { existing.role = item.role; changed = true; } }
      // parentId: entrante gana si trae valor; si vacío no degrada el existente
      if (item.parentId && item.parentId !== existing.parentId) { changes.push({ field: 'parentId', from: existing.parentId || '—', to: item.parentId }); if (!_dryRun) { existing.parentId = item.parentId; changed = true; } }
      // B-202606-004 AC-2: advertencia cuando TKT/INC existente con parentId recibe merge sin parent declarado
      if (!item.parentId && existing.parentId && ['TKT','INC'].includes(itemKind(existing)) && !_dryRun) {
        _blogLog('parent-ausente-en-merge', existing.code, existing.code + ' tiene parentId ' + existing.parentId + ' — merge entrante no declara parent. parentId conservado.', 'backlog');
      }
      // origin: entrante gana si trae valor; si vacío no degrada el existente
      if (item.origin && item.origin !== existing.origin) { changes.push({ field: 'origin', from: existing.origin || '—', to: item.origin }); if (!_dryRun) { existing.origin = item.origin; changed = true; } }
      // notes: entrante gana si trae valor; si vacío no degrada el existente
      if (item.notes && item.notes !== existing.notes) { changes.push({ field: 'notes', from: existing.notes || '—', to: item.notes }); if (!_dryRun) { existing.notes = item.notes; changed = true; } }
      // discardReason / discardRef
      if (item.discardReason && item.discardReason !== existing.discardReason) { changes.push({ field: 'discardReason', from: existing.discardReason || '—', to: item.discardReason }); if (!_dryRun) { existing.discardReason = item.discardReason; changed = true; } }
      if (item.discardRef    && item.discardRef    !== existing.discardRef)    { changes.push({ field: 'discardRef',    from: existing.discardRef    || '—', to: item.discardRef    }); if (!_dryRun) { existing.discardRef    = item.discardRef;    changed = true; } }
      // T-202604-288: blockedBy — append con dedup
      if (item.blockedBy && item.blockedBy.length) {
        const existingBB = existing.blockedBy || [];
        const newBB = item.blockedBy.filter(c => !existingBB.includes(c));
        if (newBB.length) { changes.push({ field: 'blockedBy', from: existingBB.join(', ') || '—', to: [...existingBB, ...newBB].join(', ') }); if (!_dryRun) { existing.blockedBy = [...existingBB, ...newBB]; changed = true; } }
      }
      // R-202604-051: blocking
      if (item.blocking === true && !existing.blocking) { changes.push({ field: 'blocking', from: '—', to: 'true' }); if (!_dryRun) { existing.blocking = true; changed = true; } }
      // T-202605-137: promovida_a — actualizar en la P y escribir origenDisc en el ítem destino
      if (item.promovida_a && item.promovida_a !== existing.promovida_a) {
        changes.push({ field: 'promovida_a', from: existing.promovida_a || '—', to: item.promovida_a });
        if (!_dryRun) {
          existing.promovida_a = item.promovida_a;
          changed = true;
          // AC edge case: si promovida_a apunta a código real existente, escribir origenDisc en el destino
          if (!_isPlaceholderCode(item.promovida_a)) {
            const destItem = getItems().find(i => i.code === item.promovida_a);
            if (destItem && !destItem.origenDisc) {
              destItem.origenDisc = existing.code;
              _blogLog('origen-disc-escrito', existing.code, existing.code + ' → origenDisc en ' + item.promovida_a, 'backlog');
            }
          }
        }
      }
      // origenDisc: entrante gana si trae valor; si vacío no degrada el existente
      if (item.origenDisc && item.origenDisc !== existing.origenDisc) { changes.push({ field: 'origenDisc', from: existing.origenDisc || '—', to: item.origenDisc }); if (!_dryRun) { existing.origenDisc = item.origenDisc; changed = true; } }
      // Estampar sessionId siempre que venga uno (CHECKPOINT más reciente gana)
      if (!_dryRun && sessionId && existing.sessionId !== sessionId) { existing.sessionId = sessionId; changed = true; }

      // T-202604-423: registrar cambios de merge en history[] con origin 'checkpoint'
      // B-202605-241: origin era 'import' — corregido a 'checkpoint' para display correcto en timeline
      if (!_dryRun && changes.length) {
        if (!existing.history) existing.history = [];
        const importTs = Date.now();
        changes.forEach(ch => {
          // status ya se registra en setItemStatus — aquí solo los demás campos
          if (ch.field === 'status') return;
          existing.history.push({
            type: 'field',
            ts: importTs,
            origin: 'checkpoint',
            sessionId: sessionId || null,
            data: { field: ch.field, from: ch.from !== '—' ? ch.from : null, to: ch.to || null }
          });
        });
      }

      if (changes.length) {
        if (!advanced.find(a => a.code === item.code)) {
          // T-202604-414: emitir changes array estructurado + change string para backward compat
          // T-202606-018: changes[] en el objeto updated contiene solo campos auditados por AC-2:
          //   status · priority · effort · sprint · title · area · role
          //   from: null cuando el campo no existía en el backlog (era undefined o '—' placeholder)
          //   El array interno `changes` sin filtrar se conserva para history[] (ya aplicado arriba)
          const _AUDITED_FIELDS = new Set(['status', 'priority', 'effort', 'sprint', 'title', 'area', 'role']);
          const changesForPanel = changes
            .filter(c => _AUDITED_FIELDS.has(c.field))
            .map(c => ({
              field: c.field,
              from: (c.from === '—' || c.from === undefined || c.from === null) ? null : c.from,
              to: c.to
            }));
          updated.push({ code: item.code, desc: existing.title, changes: changesForPanel, change: changes.map(c => c.field).join(' · '), parent: item.parentId || null });
        }
      } else if (!advanced.find(a => a.code === item.code) && !retroceso.find(r => r.code === item.code) && !discarded.find(d => d.code === item.code)) {
        // Distinguir: ya tenía ese status (ok) vs no hubo cambio de status porque no llegó uno válido
        const noStatusIncoming = !item.status || item.status === 'pendiente'; // T-202606-034: item.status ya canónico — comparación directa
        const alreadyInStatus = newStatus === oldStatus;
        if (alreadyInStatus && !noStatusIncoming) {
          ignored.push({ code: item.code, reason: 'ya-en-status', desc: existing.title, status: oldStatus });
        } else if (noStatusIncoming) {
          ignored.push({ code: item.code, reason: 'sin-status', desc: existing.title });
        } else {
          ignored.push({ code: item.code, reason: 'sin-cambios', desc: existing.title });
        }
      }
    } else {
      // AC-9: ítem nuevo — marcar si no tenía código real
      const isNew = item._wasAssigned;
      const nowTs = Date.now();
      const initialStatus = item.status || 'pendiente'; // T-202606-034: item.status ya canónico desde T1

      // TKT-202606-013 (REQ-202606-003 · AC1/AC2): gate de parser — REQ nuevo sin TKT hijo no se
      // crea en el backlog. Reemplaza la degradación suspendida orphaned:true (T-202606-010) —
      // implementa el bloqueo que ese comentario dejaba pendiente. __BR-Core §4 Gate de parser.
      const _incomingTypePreCheck = itemKind(item) || '';
      if (_incomingTypePreCheck === 'REQ') {
        const _rCode = item.code;
        const _hasChildInBatch = tgItems.some(i => {
          const iType = itemKind(i) || '';
          const iParent = i.parentId || null;
          return iType === 'TKT' && iParent === _rCode && i.status !== 'descartado' && i.status !== 'discarded';
        });
        const _hasChildInBacklog = getItems() && getItems().some(i =>
          i.parentId === _rCode && itemKind(i) === 'TKT' && i.status !== 'descartado'
        );
        if (!_hasChildInBatch && !_hasChildInBacklog) {
          // AC2 edge: aplica solo a REQ nuevos — este bloque ya vive dentro de la rama "!existing".
          const _reqIdentifier = item.title || _rCode;
          const _msg = `CHECKPOINT bloqueado: REQ ${_reqIdentifier} emitido sin TKTs hijos. Un REQ debe nacer con al menos TKT1 declarado. Adjuntar CHECKPOINT corregido.`;
          ignored.push({ code: _rCode, reason: 'req-sin-tkt', desc: item.title || '' });
          // AC4: bloqueo es por ítem — no return de todo mergeBacklogFromTG, solo de este forEach.
          // Toast solo en la corrida real — la corrida dry-run (preview del DIFF) ya refleja
          // la exclusión vía diff.ignored, sin duplicar el aviso.
          if (!_dryRun) showToast('error', 'CHECKPOINT bloqueado', _msg);
          _blogLog('req-sin-tkt', _rCode, _msg, 'backlog');
          return; // AC2: no se crea en el backlog
        }
      }

      // R-202605-021: resolver parentId para ítems nuevos
      // AC: solo TKT o INC pueden tener parentId — REQ con parentId → ignorar + DocLog
      // AC: si parentId apunta a TKT o INC existente → ignorar + DocLog
      // AC: si parentId no existe en backlog → ignorar + DocLog
      let _resolvedParentId = null;
      const _incomingType = itemKind(item) || 'TKT';
      if (item.parentId) {
        if (_incomingType === 'REQ') {
                      _blogLog('parentId-ignorado', item.code || '', 'parentId ignorado: ítems tipo REQ no pueden tener padre. parentId recibido: ' + item.parentId, 'backlog');
        } else {
          const _parentCandidate = getItems().find(p => p.code === item.parentId);
          if (!_parentCandidate) {
                          _blogLog('parentId-ignorado', item.code || '', 'parentId ignorado: código ' + item.parentId + ' no existe en el backlog', 'backlog');
          } else if (itemKind(_parentCandidate) !== 'REQ') {
                          _blogLog('parentId-ignorado', item.code || '', 'parentId ignorado: ' + item.parentId + ' es de tipo ' + (itemKind(_parentCandidate) || 'desconocido') + ' — solo REQ puede ser padre', 'backlog');
          } else {
            _resolvedParentId = item.parentId;
          }
        }
      }

      // B-202604-015: heredar sprint del padre si el ítem no trae sprint propio
      const _parentSprint = (!item.sprint && _resolvedParentId)
        ? (getItems().find(p => p.code === _resolvedParentId) || {}).sprint || ''
        : '';
      if (!_dryRun) {
        getItems().push({
          id: 'item-' + nowTs + '-' + Math.random().toString(36).slice(2,6),
          code: item.code,
          type: _incomingType,
          title: item.title || item.code,
          desc: '',
          priority: item.priority || 'medium',  // T-202606-032 / B-202606-015: tomar priority del ítem entrante — no hardcodear 'medium'
          area: item.area || '',
          effort: item.effort != null ? item.effort : 1, // B-202606-023: preservar effort declarado — null || 1 pisaba el valor con default
          impact: 'Medio',
          status: initialStatus,
          version: 'futura',
          sprint: item.sprint || _parentSprint,
          ac: item.ac || [],
          role: item.role || '',
          origin: item.origin || null,
          parentId: _resolvedParentId,
          dependsOn: item.dependsOn || [],
          triggeredBy: item.triggeredBy || null,
          origenDisc: item.origenDisc || null,
          promovida_a: item.promovida_a || null,
          // TKT-PARSER-2b (REQ-[pendiente-ID]): campos ITIL en creación — antes solo la rama de
          // merge-sobre-existente los persistía; un INC/PRB/KE/CHG nuevo nacía sin incidentStatus,
          // slaPriority, slaDeadline, comportamientoActual, originModule, queue, derivedItems ni
          // resolutionType. INC/PRB/KE usan incidentStatus (mirror de status, ver parse.js); CHG
          // no declara incidentStatus (vocabulario Scrum) pero sí vive en Q-INC → queue.
          ...((['INC', 'PRB', 'KE', 'CHG'].includes(_incomingType)) ? {
            queue: item.queue || null,
            ...(['INC', 'PRB', 'KE'].includes(_incomingType) ? { incidentStatus: item.incidentStatus || initialStatus } : {}),
            slaPriority: item.slaPriority || null,
            slaDeadline: item.slaDeadline || null,
            comportamientoActual: item.comportamientoActual || '',
            originModule: item.originModule || null,
            derivedItems: item.derivedItems || [],
            resolutionType: item.resolutionType || null,
          } : {}),
          // T-202606-025: persistir discard_reason en cualquier tipo con status descartado
          ...(initialStatus === 'descartado' && item.discard_reason !== undefined
            ? (() => {
                const _VALID_DISCARD_REASONS = new Set(['duplicado', 'fuera de alcance', 'reemplazado', 'obsoleto']);
                if (!_VALID_DISCARD_REASONS.has(item.discard_reason)) {
                  _blogLog('discard-reason-no-canonico', item.code, 'discard_reason con valor no canónico: ' + item.discard_reason, 'backlog');
                }
                return { discard_reason: item.discard_reason };
              })()
            : {}),
          blockedBy: item.blockedBy || [],
          blocking: item.blocking || false,
          sessionId: sessionId || null,
          createdAt: nowTs,
          statusChangedAt: nowTs,
          doneAt: initialStatus === 'done' ? nowTs : null
        });
        _blogLog('ckpt-creado', item.code, item.title || '', 'backlog');
        changed = true;

        // B-202606-017 AC-1+AC-2: transición automática del R padre si el nuevo T/B nace con status != pendiente
        if (initialStatus !== 'pendiente') {
          _checkAndAdvanceParentR(item.code, nowTs);
        }

        // R-[pendiente-ID]: si el nuevo ítem tiene origin → cerrar automáticamente el P padre
        if (item.origin) {
          const pParent = getItems().find(p => p.code === item.origin);
          if (pParent && pParent.status !== 'done') {
            pParent.status = 'done';
            pParent.doneAt = pParent.doneAt || nowTs;
            pParent.statusChangedAt = nowTs;
            pParent.discardRef = item.code;
            _blogLog('ckpt-promovido', item.origin, item.origin + ' → ' + item.code, 'backlog');
          }
        }
      }
      // B-202604-198: si el ítem nace con status done en el mismo CHECKPOINT → grupo propio
      const initialStatusForGroup = item.status || 'pendiente'; // T-202606-034: item.status ya canónico desde T1
      if (initialStatusForGroup === 'done') {
        createdAndClosed.push({ code: item.code, desc: item.title, _wasAssigned: isNew });
      } else {
        created.push({ code: item.code, desc: item.title, _wasAssigned: isNew });
      }
    }
    // Actualizar contadores en backlog-meta (no en dryRun)
    if (!_dryRun) {
      const typeKey = itemKind(item);
      if (typeKey && ['REQ','TKT','DISC','INC'].includes(typeKey)) {
        const numMatch = item.code.match(/(?:REQ|TKT|DISC|INC)-\d{6}-(\d{3})/);
        if (numMatch) {
          const num = parseInt(numMatch[1]);
          const meta = JSON.parse(localStorage.getItem(_tplKey('backlog-meta')) || '{}');
          if (!meta.counters) meta.counters = { DISC:0, TKT:0, REQ:0, INC:0 };
          if (num > (meta.counters[typeKey] || 0)) {
            meta.counters[typeKey] = num;
            localStorage.setItem(_tplKey('backlog-meta'), JSON.stringify(meta));
          }
        }
      }
    }
  });

  if (!_dryRun && changed) {
    saveBacklog(); // B-202605-007: _undoSnapshot() movido antes del forEach
    _setBacklogModified();
    renderStats(); // siempre actualizar stat bar aunque no estemos en tab Backlog
    // T-202606-093 AC-3: badges de Icebox/Hotfix/Histórico se actualizan sin importar
    // el tab activo — independiente del guard getCurrentTab() === 'backlog' de abajo
    _updateSubtabBadges();
    if (getCurrentTab() === 'backlog') { _markBacklogListDirty(); renderBacklogList(); updateBacklogBanner(); }
  }
  return { created, advanced, retroceso, discarded, updated, ignored, createdAndClosed, tmpSuggestions, invalidTransition, slugMap: _slugMap }; // T-[pendiente-ID]: invalidTransition poblado pre-clasificación · B-202606-022: slugMap para resolución de [tmp:slug] en applyPatchesFromTG
}




// T-202606-034: _tgStatusToBacklog y _normalizeStatus eliminadas — item.status llega canónico desde locus-session-parse.js (_canonicalStatus)

// T-202605-083: _staleness — punto único de cálculo de días de estancamiento para staleness-pill
// Retorna objeto { days, modifier, label } si el pill debe renderizar, null si no aplica.
// Gate: _hasRecentSession debe retornar false (ítem sin sesión reciente).
// Modificadores: fresh (≤3d) · warn (4–7d) · stale (>7d).
// Si statusChangedAt y createdAt son ambos null/undefined → retorna null (sin crash, sin valor inventado).
function _staleness(item) {
  if (!item || item.status !== 'pendiente') return null;
  if (!item.sprint || item.sprint === 'n/a') return null;
  if (!item.createdAt) return null;
  if (_hasRecentSession(item)) return null;
  const _refTs = item.statusChangedAt || item.createdAt;
  if (!_refTs) return null;
  const days = Math.floor((Date.now() - _refTs) / 86400000);
  const modifier = days <= 3 ? 'fresh' : days <= 7 ? 'warn' : 'stale';
  const label = days === 0 ? 'hoy' : days === 1 ? '1d' : days + 'd';
  return { days, modifier, label };
}

// R-202604-091: decorador de actividad — pendiente con sesión vinculada en los últimos 7 días
const _ACTIVE_RECENT_DAYS = 7;
function _isActiveRecently(item) {
  if (!item || item.status !== 'pendiente') return false;

  const allSessions = getAllSessions();
  let lastTs = 0;
  allSessions.forEach(s => {
    if ((s.backlogRefs || s.trackerRefs || []).includes(item.code)) {
      const ts = s.savedAt || s.createdAt || 0;
      // R-202605-041: excluir sesiones anteriores al createdAt del ítem
      // Ítems legacy sin createdAt → comportamiento anterior sin cambio
      if (item.createdAt && ts < item.createdAt) return;
      if (ts > lastTs) lastTs = ts;
    }
  });
  if (!lastTs) return false;
  return (Date.now() - lastTs) / 86400000 <= _ACTIVE_RECENT_DAYS;
}


// B-202606-014: helper de transición automática del R padre tras cambio de status en T/B.
// Implementa las transiciones declaradas en BR-Ecosystem §5 (gestionadas por Locus):
//   - primer T hijo != pendiente  → R: pendiente → en-proceso
//   - último T hijo done          → R: en-proceso → en-revision
//   - T hijo retrocede desde done → R: en-revision → en-proceso (AC-2 simétrico)
// Solo aplica cuando el ítem modificado tiene parentId y su parent es tipo R.
// AC-3: ítems sin parentId → no-op.
// nowTs: timestamp para statusChangedAt del R.
function _checkAndAdvanceParentR(childCode, nowTs) {
  const allItems = typeof getItems() !== 'undefined' ? getItems() : [];
  const child = allItems.find(i => i.code === childCode);
  if (!child || !child.parentId) return; // AC-3: sin parent → no-op

  const parent = allItems.find(i => i.code === child.parentId);
  if (!parent || itemKind(parent) !== 'REQ') return; // parent debe ser REQ

  // Hijos válidos: TKT e INC no descartados del mismo REQ
  const children = allItems.filter(i =>
    i.parentId === parent.code &&
    ['TKT','INC'].includes(itemKind(i)) &&
    i.status !== 'descartado'
  );
  if (!children.length) return;

  const allDone  = children.every(i => i.status === 'done');
  const anyActive = children.some(i => i.status !== 'pendiente');

  const prevStatus = parent.status;

  if (allDone && prevStatus !== 'en-revision' && prevStatus !== 'done' && prevStatus !== 'bloqueado') {
    // Último T done → R avanza a en-revision
    parent.status = 'en-revision';
    parent.statusChangedAt = nowTs;
    _blogLog('r-auto-transition', parent.code,
      parent.code + ' ' + prevStatus + ' → en-revision (todos los Ts done via patch)', 'backlog');
  } else if (!allDone && anyActive && prevStatus === 'pendiente') {
    // Primer T != pendiente → R avanza a en-proceso
    parent.status = 'en-proceso';
    parent.statusChangedAt = nowTs;
    _blogLog('r-auto-transition', parent.code,
      parent.code + ' pendiente → en-proceso (T activo via patch)', 'backlog');
  } else if (!allDone && prevStatus === 'en-revision') {
    // T retrocedió desde done → R retrocede a en-proceso (AC-2)
    parent.status = 'en-proceso';
    parent.statusChangedAt = nowTs;
    _blogLog('r-auto-transition', parent.code,
      parent.code + ' en-revision → en-proceso (T retrocedió via patch)', 'backlog');
  }
}

// T-202606-017: helper de transición a orphaned del R padre cuando todos sus Ts hijos quedan descartados.
// AC-1: invocado tras marcar un T/B hijo como 'descartado' — si todos los hijos (T/B) del R
//   están en 'descartado', el R pasa a status:'orphaned'.
// AC-3: si al menos un T/B hijo no está descartado → no-op, el R conserva su status actual.
// AC-4: al transicionar, registra en _blogLog el mensaje canónico.
// Solo aplica cuando el ítem modificado tiene parentId y su parent es tipo R.
// nowTs: timestamp para statusChangedAt del R.
export function _checkAndOrphanParentR(childCode, nowTs) {
  const allItems = typeof getItems() !== 'undefined' ? getItems() : [];
  const child = allItems.find(i => i.code === childCode);
  if (!child || !child.parentId) return; // sin parent → no-op

  const parent = allItems.find(i => i.code === child.parentId);
  if (!parent || itemKind(parent) !== 'REQ') return; // parent debe ser REQ

  // Hijos del REQ (TKT e INC) — incluye descartados para evaluar si TODOS lo están
  const children = allItems.filter(i =>
    i.parentId === parent.code &&
    ['TKT','INC'].includes(itemKind(i))
  );
  if (!children.length) return; // sin hijos declarados → no-op (gate de parser cubre REQ sin TKT al ingestar)

  const allDiscarded = children.every(i => i.status === 'descartado');
  if (!allDiscarded) return; // AC-3: al menos un hijo no descartado → R conserva status

  if (parent.status === 'orphaned') return; // ya orphaned — no duplicar transición/log

  parent.status = 'orphaned';
  parent.orphaned = true;
  parent.statusChangedAt = nowTs;
  _blogLog('r-orphaned', parent.code,
    'R ' + parent.code + ' en orphaned — todos los Ts descartados. Cael puede re-especificar o descartar', 'backlog');
}

// R-202605-062: applyPatchesFromTG — aplica patches de campo individual sobre ítems existentes
// AC-1: type: "patch" es instrucción de operación — no tipo de ítem
// AC-2: solo requiere code + campos a patchear
// AC-3: campos patcheables: title, status, priority, effort, area, sprint, role, ac, origin
// AC-3b: campos no patcheables (code, type, schema_version) → advertencia DocLog, sin crash
// AC-4: ac presente → reemplaza array completo
// AC-5: código no existe en backlog → advertencia DocLog, sin crash
// AC-6: código placeholder → ignorado (manejado en parsePaste antes de llegar aquí)
// AC-7: status done → mismas reglas de confirmación que done manual (vía setItemStatus)
// AC-8: mezcla ítems + patches en mismo ---getItems()--- → parser separa por type
// AC-9: panel diff muestra solo campos del patch (changes array)
// AC-11: sin regresión en mergeBacklogFromTG
const _PATCH_ALLOWED_FIELDS = new Set(['title', 'status', 'incidentStatus', 'priority', 'effort', 'area', 'sprint', 'role', 'ac', 'origin', 'parentId', 'promovida_a', 'origenDisc', 'discard_reason']); // R-202605-004: origin patcheable · B-202605-016: parentId patcheable · T-202605-137: promovida_a + origenDisc patcheables · T-202606-025: discard_reason patcheable · INC-[pendiente-ID]: incidentStatus patcheable — antes no había campo patcheable que reparara status corrupto en ítems ITIL ya persistidos
const _PATCH_NON_PATCHEABLE = new Set(['code', 'type', 'schema_version']);

export function applyPatchesFromTG(patches, sessionId, opts) {
  if (!patches || !patches.length) return { patched: [], ignored: [] };

  // B-202606-022: slugMap pasado desde mergeBacklogFromTG via llamador — resuelve [tmp:slug] en parentId
  const _slugMap = (opts && opts.slugMap instanceof Map) ? opts.slugMap : null;

  // B-202606-100: role del header del CHECKPOINT — único contexto que autoriza
  // la transición R → done dentro de un patch. Simétrico al guard ya existente
  // para R → bloqueado en locus-session-parse.js (T-202606-080/022).
  const _ckptHeaderRole = (opts && typeof opts.ckptHeaderRole === 'string') ? opts.ckptHeaderRole : '';

  const patched = [];
  const ignoredPatches = [];

  _undoSnapshot();

  patches.forEach(patch => {
    // B-202605-016: normalizar campo parent (schema CHECKPOINT) → parentId (campo interno)
    // T-[pendiente-ID] (REQ-unify-parent TKT2): eliminar patch.parent tras normalizar — no es
    // campo patcheable (_PATCH_ALLOWED_FIELDS solo declara parentId), dejarlo no tenía efecto
    // pero conservarlo en el objeto patch es ruido del campo legacy.
    if (patch.parent) { if (!patch.parentId) patch.parentId = patch.parent; delete patch.parent; }

    // B-202606-022: resolver [tmp:slug] en parentId usando slugMap post-mergeBacklogFromTG
    if (_slugMap && patch.parentId && _isPlaceholderCode(patch.parentId)) {
      const resolved = _slugMap.get(patch.parentId);
      if (resolved && !_isPlaceholderCode(resolved)) {
        patch.parentId = resolved;
      } else if (!resolved) {
        _blogLog('patch-parent-slug-no-resuelto', patch.code || '[sin-código]',
          'parentId: ' + patch.parentId + ' no encontrado en slugMap — campo ignorado', 'backlog');
        delete patch.parentId;
      }
    }

    const code = patch.code;

    // AC-5: código no existe en backlog → advertencia DocLog
    const existing = (typeof getItems() !== 'undefined') ? getItems().find(i => i.code === code) : null;
    if (!existing) {
              _blogLog('patch-ignorado', code, 'Patch ignorado: código no existe en el backlog. code: ' + code, 'backlog');
      ignoredPatches.push({ code, reason: 'no-existe' });
      return;
    }

    // AC-3b: advertir sobre campos no patcheables presentes en el objeto patch
    Object.keys(patch).forEach(k => {
      if (_PATCH_NON_PATCHEABLE.has(k)) {
                  _blogLog('patch-campo-ignorado', code, 'Campo no patcheable ignorado: ' + k, 'backlog');
      }
    });

    const changes = [];
    const nowTs = Date.now();

    // Iterar solo sobre campos patcheables presentes en el objeto patch
    _PATCH_ALLOWED_FIELDS.forEach(field => {
      if (!(field in patch)) return; // campo no incluido en este patch → no tocar
      const incoming = patch[field];
      const current  = existing[field];

      if (field === 'status') {
        const normalized = incoming; // T-202606-034: incoming ya canónico desde parser — _normalizeStatus eliminada
        if (normalized !== existing.status) {
          const _prevStatus = existing.status;
          if (normalized === 'done') {
            // B-202606-100: un REQ nunca puede ir a done excepto vía patch dentro de
            // un CHECKPOINT con role: 'QA · Finn' — la fila en Postgres lo permite
            // (chk_status_by_type actualizado) pero el origen del cambio debe ser
            // siempre una sesión de cierre de Finn, nunca UI manual ni otro rol.
            // Simétrico al guard de REQ → bloqueado (T-202606-080/022).
            if (itemKind(existing) === 'REQ') {
              const _authorizedRole = 'QA · Finn';
              if (_ckptHeaderRole !== _authorizedRole) {
                _blogLog(
                  'rol-no-autorizado-done',
                  code,
                  `Transición done en REQ ${code} rechazada: solo Finn puede cerrar un REQ, vía sesión de cierre. Rol resuelto: "${_ckptHeaderRole}".`,
                  'backlog'
                );
                ignoredPatches.push({ code, reason: 'rol-no-autorizado-done' });
                return;
              }
            }
            // B-202605-XXX: patch programático → _applyDoneStatus directo, sin modal inline
            // setItemStatus dispara _showInlineConfirmDone para ítems en sprint activo,
            // lo que requiere interacción del usuario y cancela el patch silenciosamente.
            // B-202606-100: authorized=true solo aquí — el guard de rol ya corrió arriba
            // para type REQ. Para TKT/INC no aplica restricción de rol, authorized es irrelevante.
            _applyDoneStatus(existing.code, true);
            changes.push({ field: 'status', from: _prevStatus, to: normalized });
            // B-202606-014 AC-1: transición automática del REQ padre tras TKT/INC → done
            _checkAndAdvanceParentR(existing.code, nowTs);
          } else if (normalized && normalized !== existing.status) {
            changes.push({ field: 'status', from: existing.status, to: normalized });
            existing.status = normalized;
            existing.statusChangedAt = nowTs;
            // B-202606-014 AC-2: transición automática del REQ padre tras cambio de status no-done
            // cubre retroceso desde done (en-revision → en-proceso) y avance a en-revision
            _checkAndAdvanceParentR(existing.code, nowTs);
          }
        }
        return;
      }

      if (field === 'incidentStatus') {
        // INC-[pendiente-ID]: incidentStatus solo aplica a tipos ITIL — no-op silencioso en el resto
        if (!['INC', 'PRB', 'KE'].includes(itemKind(existing))) return;
        if (incoming && incoming !== existing.incidentStatus) {
          const _itResult = validateIncidentTransitions(existing.incidentStatus, incoming);
          if (!_itResult.valid) {
            _blogLog('patch-incidentstatus-invalido', code, 'Transición incidentStatus rechazada vía patch: ' + _itResult.reason, 'backlog');
            return;
          }
          changes.push({ field: 'incidentStatus', from: existing.incidentStatus || '—', to: incoming });
          // Mirror a status — mismo motivo que en mergeBacklogFromTG: sin este espejo, existing.status
          // queda congelado en el valor con el que el ítem nació y chk_status_by_type sigue rechazando
          // el upsert indefinidamente, incluso tras patchear incidentStatus correctamente.
          existing.incidentStatus = incoming;
          existing.status = incoming;
          existing.statusChangedAt = nowTs;
        }
        return;
      }

      if (field === 'ac') {
        // AC-4: ac reemplaza array completo
        if (Array.isArray(incoming)) {
          changes.push({ field: 'ac', from: existing.ac || [], to: incoming });
          existing.ac = incoming;
        }
        return;
      }

      if (field === 'sprint') {
        // Sprint: aplicar _normalizeSprint sobre objeto temporal para normalizar centinelas
        const tempItem = { sprint: incoming };
        _normalizeSprint(tempItem);
        const normalizedSprint = tempItem.sprint; // undefined si centinela, valor si válido
        if (normalizedSprint !== current) {
          changes.push({ field: 'sprint', from: current || '—', to: normalizedSprint });
          if (normalizedSprint === undefined) delete existing.sprint;
          else existing.sprint = normalizedSprint;
          // B-202606-025 AC-1: si el ítem patcheado es un REQ, propagar sprint a todos sus hijos TKT e INC
          // Sin restricción de status — todos los hijos heredan el sprint del parent
          if (itemKind(existing) === 'REQ' && normalizedSprint !== undefined) {
            const _targetSprint = normalizedSprint || 'icebox';
            (typeof getItems() !== 'undefined' ? getItems() : []).forEach(child => {
              if (child.parentId === existing.code && ['TKT','INC'].includes(itemKind(child))) {
                if ((child.sprint || 'icebox') !== _targetSprint) {
                  child.sprint = _targetSprint;
                  _blogLog('sprint-heredado', child.code,
                    child.code + ' sprint ajustado al de su parent ' + existing.code + ': ' + _targetSprint, 'backlog');
                }
              }
            });
          }
        }
        return;
      }

      // Resto de campos patcheables: title, priority, effort, area, role, origenDisc
      // T-202605-137: promovida_a — campo especial: al patchear en una P, escribir origenDisc en el destino
      // T-202606-019: si promovida_a es placeholder → intentar resolver contra getItems() (ítems recién ingresados)
      if (field === 'promovida_a') {
        if (incoming !== undefined && incoming !== null && incoming !== current) {
          let resolvedIncoming = incoming;
          // T-202606-019 AC1: resolver placeholder contra ítems ya en getItems()
          // mergeBacklogFromTG corre antes de applyPatchesFromTG — los ítems nuevos ya tienen código real
          if (_isPlaceholderCode(incoming) && typeof getItems() !== 'undefined') {
            // Buscar ítem recién creado cuyo origenDisc apunta a esta P, o cuyo código es real y fue
            // creado en este CHECKPOINT (no tiene origenDisc aún pero puede inferirse si solo hay un candidato)
            const candidates = getItems().filter(i =>
              !_isPlaceholderCode(i.code) &&
              (i.origenDisc === existing.code || (!i.origenDisc && i.code !== existing.code))
            );
            // Preferir candidato con origenDisc ya escrito (resolución determinista)
            const withOrigenDisc = candidates.find(i => i.origenDisc === existing.code);
            if (withOrigenDisc) {
              resolvedIncoming = withOrigenDisc.code;
            } else {
              // No resoluble con certeza — conservar placeholder + advertencia
              _blogLog('promovida-a-placeholder-en-patch', existing.code,
                'promovida_a en patch contiene placeholder ' + incoming + ' — no resoluble en applyPatchesFromTG. Usar código real en el patch.',
                'backlog');
            }
          }
          changes.push({ field, from: current !== undefined ? current : '—', to: resolvedIncoming });
          existing[field] = resolvedIncoming;
          // AC edge case: si promovida_a apunta a código real existente, escribir origenDisc en el destino
          if (!_isPlaceholderCode(resolvedIncoming)) {
            const destItem = (typeof getItems() !== 'undefined') ? getItems().find(i => i.code === resolvedIncoming) : null;
            if (destItem && !destItem.origenDisc) {
              destItem.origenDisc = existing.code;
              _blogLog('origen-disc-escrito', existing.code, existing.code + ' → origenDisc en ' + resolvedIncoming, 'backlog');
            }
          }
        }
        return;
      }
      // T-202606-025: discard_reason — persiste en cualquier tipo con status descartado
      if (field === 'discard_reason') {
        const _targetStatus = existing.status;
        // AC-3: si el ítem no tiene status descartado → ignorar silenciosamente
        if (_targetStatus !== 'descartado') return;
        if (incoming !== undefined && incoming !== null && incoming !== current) {
          const _VALID_DISCARD_REASONS = new Set(['duplicado', 'fuera de alcance', 'reemplazado', 'obsoleto']);
          if (!_VALID_DISCARD_REASONS.has(incoming)) {
            _blogLog('discard-reason-no-canonico', code, 'discard_reason con valor no canónico: ' + incoming, 'backlog');
          }
          changes.push({ field, from: current !== undefined ? current : '—', to: incoming });
          existing[field] = incoming;
        }
        return;
      }
      if (incoming !== undefined && incoming !== null && incoming !== current) {
        changes.push({ field, from: current !== undefined ? current : '—', to: incoming });
        existing[field] = incoming;
      }
    });

    if (changes.length) {
      // Registrar en history del ítem
      if (!existing.history) existing.history = [];
      changes.forEach(ch => {
        if (ch.field === 'status') return; // status lo registra setItemStatus
        existing.history.push({
          type: 'field',
          ts: nowTs,
          origin: 'patch',
          sessionId: sessionId || null,
          data: { field: ch.field, from: ch.from !== '—' ? ch.from : null, to: ch.to || null }
        });
      });
      if (sessionId && existing.sessionId !== sessionId) existing.sessionId = sessionId;

      patched.push({
        code,
        desc: existing.title,
        changes,
        change: changes.map(c => c.field).join(' · ')
      });

      saveBacklog();
    } else {
      ignoredPatches.push({ code, reason: 'sin-cambios' });
    }
  });

  _markBacklogListDirty(); renderBacklogList();
  renderStats();

  return { patched, ignored: ignoredPatches };
}



// ---------------------------------------------------------------------------
// TKT-B2a: buildQIncItem() — builder de card propio para Q-INC
// No reutiliza buildBacklogItem: modelo de datos ITIL es distinto (incidentStatus,
// slaPriority, slaDeadline, comportamientoActual vs status/sprint/parentId).
// Exportada para consumo en locus-backlog-render.js (renderQIncPanel).
// AC: sin referencias a item.status, item.sprint, item.parentId dentro de la función.
// ---------------------------------------------------------------------------

export function buildQIncItem(item) {
  const type      = itemKind(item) || '';
  const typeLabel = TYPE_LABELS[type] || type || '—';
  const code      = item.code || item.id || '';

  // Badge de tipo con color BR (colores canónicos de __BR-Ecosystem §4)
  const typeColorMap = { INC: '#e85555', PRB: '#f59e0b', KE: '#eab308', CHG: '#64748b' };
  const typeColor    = typeColorMap[type] || 'var(--hint)';

  // Badge incidentStatus — '—' si ausente, sin crash
  const incStatus    = item.incidentStatus || item.incident_status || '';
  const incStatusBadge = incStatus
    ? `<span class="qinc-badge qinc-badge--status">${esc(incStatus)}</span>`
    : `<span class="qinc-badge qinc-badge--status qinc-badge--empty">—</span>`;

  // Badge slaPriority — '—' si ausente, sin crash
  const slaPrio      = item.slaPriority || item.sla_priority || '';
  const slaPrioBadge = slaPrio
    ? `<span class="qinc-badge qinc-badge--sla qinc-badge--sla-${slaPrio}">${esc(slaPrio)}</span>`
    : `<span class="qinc-badge qinc-badge--sla qinc-badge--empty">—</span>`;

  // Countdown slaDeadline — solo si presente
  const slaDeadline  = item.slaDeadline || item.sla_deadline || null;
  let slaCountdownHtml = '';
  if (slaDeadline) {
    const remaining = slaDeadline - Date.now();
    if (remaining < 0) {
      slaCountdownHtml = `<span class="qinc-sla-countdown qinc-sla-countdown--vencido">VENCIDO</span>`;
    } else {
      const hrs = Math.floor(remaining / 3600000);
      const min = Math.floor((remaining % 3600000) / 60000);
      slaCountdownHtml = `<span class="qinc-sla-countdown">${hrs}h ${min}m</span>`;
    }
  }

  // Clases SLA — mutuamente excluyentes (AC TKT-B2a AC4)
  let slaClass = '';
  if (slaDeadline) {
    if (slaPrio === 'high' && slaDeadline < Date.now()) {
      slaClass = 'qinc-item--sla-vencido';
    } else if (slaDeadline >= Date.now() && slaDeadline < Date.now() + 21600000) {
      slaClass = 'qinc-item--sla-riesgo';
    }
  }

  // comportamientoActual expandible — togglable vía data-qi-action (AC TKT-B2a AC5)
  const comportamiento = item.comportamientoActual || item.comportamiento_actual || '';
  const comportamientoHtml = comportamiento
    ? `<div class="qinc-item-comportamiento" data-qi-action="qi-toggle-comportamiento">${esc(comportamiento)}</div>`
    : '';

  // Copy-code badge — patrón idéntico al Backlog principal (AC TKT-B2a AC2)
  const copyCodeHtml = `<span class="bitem-subline-code" data-action="copy-code" data-code="${esc(code)}" data-idx="-1" title="Click para copiar ID">${esc(code)}</span>`;

  return `
<div class="qinc-item ${slaClass}" data-code="${esc(code)}" data-type="${esc(type)}">
  <div class="qinc-item-header">
    <span class="qinc-type-badge qinc-type-badge--${type.toLowerCase()}" style="--qinc-type-color:${typeColor}" title="${esc(typeLabel)}">${esc(type)}</span>
    ${copyCodeHtml}
    <span class="qinc-item-title">${esc(item.title || '(sin título)')}</span>
  </div>
  <div class="qinc-item-meta">
    ${incStatusBadge}
    ${slaPrioBadge}
    ${slaCountdownHtml}
  </div>
  ${comportamientoHtml}
</div>`.trim();
}

// T-202606-072: listeners shell:* — desacoplamiento de módulos consumidores
// locus-backlog-core.js despacha shell:backlog-footer-update en lugar de llamar directamente
window.addEventListener('shell:backlog-footer-update', () => { updateBacklogFooter(); });
