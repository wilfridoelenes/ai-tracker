window.__ENV = {
  SUPABASE_URL: 'https://funougdamryzihjntpfu.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_4jXT7iJXmJpRdTshO9qE6Q_bOZoYcjV'
};