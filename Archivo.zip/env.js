// [PP] v1.0.0 · sprint:PP-S-01 · mod:2 · autor:Rune · 2026-06-11 08:00 UTC-6
window.__ENV = {
  SUPABASE_URL: 'https://funougdamryzihjntpfu.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_4jXT7iJXmJpRdTshO9qE6Q_bOZoYcjV'
};