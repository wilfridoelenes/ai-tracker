# _Locus-ui-Inventory.md
<!-- mod:4 | Última actualización: 2026-06-26 | UI Inventory — Locus — mantenido por Nova -->
<!-- infra_version: 5 | BR-Core v1.3 · BR-Ecosystem v1.2 · BR-Execution v1.1 · OB-Strategy v1.4 -->

## Contexto

**Cambios v0.5.1 (mod:4) — coherencia con BR Gen 2 (infra_version: 5):**
- Encabezado actualizado: `infra_version: 19` → `5` · versiones BR actualizadas a Gen 2. Nombre del archivo sin versión (patrón Doc Ref correcto per `__OB-Strategy §5`).
- Sin cambios de contenido — el inventario documenta IDs del DOM, no nomenclatura BR.

Inventario actualizado post-PP-S-08 y auditoría de index.html — 2026-05-25.

Cambios vs V2.0:
- §2 Panels/Overlays: +1 (`#arranque-overlay`)
- §3 Toggles/Vistas: +1 (`#theme-toggle-btn`)
- §6 Navegación: +3 (`#cmd-k-pill`, `#ckpt-reopen-btn`, `#user-chip`) · `#breadcrumb-item` documentado
- §7 Tab Sprint: sección nueva — 9 elementos (tab completo implementado en PP-S-07/S-08)

Cambios vs V2.1.0 (mod:1):
- §5 Búsquedas: `#search-global` marcado como ausente del DOM — reemplazado por Command Palette. Documentado en UX-ref §F-01.

**Cambios v0.5.0 (mod:3) — auditoría contra index.html real + 50 módulos JS + 17 CSS reales, 2026-06-21:**

14 de 92 IDs catalogados como `limpio` no existen en el DOM real. Reclasificados en tres categorías según evidencia en JS:

| Categoría | Criterio | IDs afectados |
|---|---|---|
| `regresión` | JS lo referencia y cita un T/R como `done`, pero el elemento no está en el DOM — feature inerte, sin crash por guard `if(el)` | `#theme-toggle-btn` (cita T-202606-006) · `#breadcrumb-sprint` + `#breadcrumb-item` (cita R-202605-167) · `#user-chip` |
| `wip` | JS ya registra el handler vía delegation con comentario explícito de que el HTML se añadirá después | `#reset-sessions-overlay` · `#reset-backlog-overlay` · `#purge-modal-overlay` · `#tmpl-trigger-wrap` |
| `ausente` (muerto) | Cero referencias en los 50 módulos JS ni en `index.html` | `#quick-note-modal` · `#migrate-fb-overlay` · `#tracker-view-toggle` · `#header-active-worker` · `#header-sprint-row` · `#cmd-k-pill` |

`#breadcrumb-proj` confirmado como único segmento real del breadcrumb — el patrón de 3 segmentos documentado en V2.1.0 no es el estado actual.

Bug HTML real encontrado durante la auditoría (no es un ítem de este inventario — registrado en CHECKPOINT como hallazgo para Cael/Rune): `<button>` con dos atributos `id` (`btn-migrate-fb-sb` + `mm-btn-migrate`) en el mismo tag — el navegador resuelve solo el primero, por lo que `mm-btn-migrate` nunca responde a clicks.

**Estados de auditoría:**
- `limpio` — sin problemas identificados
- `auditar` — requiere revisión de flujo, comportamiento o consistencia
- `ausente` — catalogado pero no existe en el DOM real (sin distinguir causa)
- `ausente · wip` — no existe en el DOM aún, pero el JS que lo consume ya está implementado a la espera del HTML
- `ausente · regresión` — existió o se dio por implementado (T/R citado como done) y dejó de estar en el DOM — feature inerte hoy

---

## 1. Modales — 27 instancias

| # | ID | Nombre | En DOM | Estado | CSS canónico | Notas |
|---|---|---|---|---|---|---|
| 01 | `#quick-note-modal` | Quick Note | ✗ | `ausente` | `locus-modals.css` | No existe en `index.html` ni se referencia en los 50 módulos JS auditados. No es WIP — sin rastro de implementación. |
| 02 | `#item-editor-overlay` | Item Editor | ✓ | `limpio` | `locus-modals.css` | `item.title` canónico — R-202605-007 done. |
| 03 | `#tpl-picker-overlay` | Template Picker | ✓ | `limpio` | `locus-modals.css` | Sub-modal del Item Editor. |
| 04 | `#avatar-modal` | Avatar Selector | ✓ | `limpio` | `locus-modals.css` | Grid de avatares. `.avatar-modal.open` consolidado. |
| 05 | `#add-modal` | Nuevo Worker | ✓ | `limpio` | `locus-modals.css` | Un campo, Enter confirma. |
| 06 | `#tag-modal` | Tag Picker | ✓ | `limpio` | `locus-modals.css` | Selector + creación inline. |
| 07 | `#qc-modal-overlay` | Quick Capture (unificado) | ✓ | `limpio` | `locus-modals.css` | R-202605-009 done — skip Paso 1 con worker único. |
| 08 | `#standalone-ckpt-overlay` | Standalone CHECKPOINT | ✓ | `limpio` | `locus-modals.css` | Actualiza solo ítems, sin Worker. |
| 09 | `#export-confirm-overlay` | Export Confirm | ✓ | `limpio` | `locus-proyectos.css` | Visibilidad via `.open`. |
| 10 | `#merge-diff-overlay` | Merge Diff | ✓ | `limpio` | `locus-proyectos.css` | Two-column bien estructurado. |
| 11 | `#import-diff-overlay` | Import Diff (Backup) | ✓ | `limpio` | `locus-modals.css` | T emitido — auditoría de paridad entre puntos de entrada pendiente de Finn. |
| 12 | `#sprint-close-overlay` | Sprint Close (3 pasos) | ✓ | `limpio` | `locus-sprint-close.css` | Fix aplicado: botón final accesible con `skipStep2=true` — B-202605-007 + T-202605-015 done. |
| 13 | `#auth-modal-overlay` | Auth / Connect | ✓ | `limpio` | `locus-modals.css` | Google OAuth + magic link. Supabase activo. |
| 14 | `#proj-mismatch-overlay` | Proyecto diferente | ✓ | `limpio` | `locus-modals.css` | Guardia de proyecto. Visibilidad via `.open`. |
| 15 | `#sprint-retro-overlay` | Sprint Retro | ✓ | `limpio` | `locus-modals.css` | — |
| 16 | `#promote-modal-overlay` | Promote P→R/T/R unificado | ✓ | `limpio` | `locus-backlog.css` | `role="dialog"` + `aria-modal`. |
| 17 | `#migrate-item-overlay` | Migrate Item | ✓ | `limpio` | `locus-backlog.css` | T emitido — auditoría de flujo completo pendiente de Finn. |
| 18 | `#changelog-overlay` | Changelog | ✓ | `limpio` | `locus-proyectos.css` | Acceso vía menú ⋯. Visibilidad via `.open`. |
| 19 | `#notif-config-overlay` | Notif Config | ✓ | `limpio` | `locus-modals.css` | Persistencia de estado resuelta — B-202605-009 + B-202605-010 + B-202605-011 done. |
| 20 | `#proj-modal-overlay` | Crear / Editar Proyecto | ✓ | `limpio` | `locus-modals.css` | Formulario completo. Visibilidad via click-outside. |
| 21 | `#gconfirm-overlay` | Global Confirm | ✓ | `limpio` | `locus-modals.css` | Flows destructivos auditados y normalizados — T-202605-008 done. |
| 22 | `#reset-sessions-overlay` | Reset Sesiones | ✗ | `ausente · wip` | `locus-modals.css` | No existe en `index.html`. `main.js` registra el handler vía delegation con comentario explícito: HTML pendiente de añadir. Validación `_validateResetSessionsInput()` ya implementada. |
| 23 | `#reset-backlog-overlay` | Reset Backlog | ✗ | `ausente · wip` | `locus-modals.css` | No existe en `index.html`. Mismo patrón que fila 22 — `_validateResetBacklogInput()` implementada, esperando HTML. |
| 24 | `#purge-modal-overlay` | Purge Sesiones Antiguas | ✗ | `ausente · wip` | `locus-modals.css` | No existe en `index.html`. Handler por delegation ya registrado en `main.js`. |
| 25 | `#migrate-fb-overlay` | Migrate Firebase→Supabase | ✗ | `ausente` | `locus-modals.css` | No existe en `index.html`. Cero referencias en los 50 módulos JS — sin rastro de implementación, a diferencia de filas 22–24. |
| 26 | `#mg-overlay` | Document Generator | ✓ | `limpio` | `locus-document-generator.css` | Stepper 3 pasos. `role="dialog"` + `aria-modal`. |
| 27 | `#weekly-summary-modal` | Weekly Summary | ✓ | `limpio` | `locus-sesiones.css` | Modal automático los lunes. `role="dialog"` + `aria-modal`. |

---

## 2. Panels y Overlays no-modales — 10 instancias

| # | ID | Nombre | En DOM | Estado | CSS canónico | Notas |
|---|---|---|---|---|---|---|
| 01 | `#ckpt-panel` | CHECKPOINT Panel | ✓ | `limpio` | `locus-modals.css` | Slide-in tras CHECKPOINT. Barra de progreso. |
| 02 | `#pulso-overlay` | Pulso del Ecosistema | ✓ | `limpio` | `locus-backlog.css` | Punto de entrada canónico `#gf-pulso`. `role="dialog"` + `aria-modal`. |
| 03 | `#arranque-overlay` | Sesión de Arranque | ✓ | `limpio` | `locus-backlog.css` | Morning brief. `role="dialog"` + `aria-modal`. Botón CTA `#arranque-cta-btn`. |
| 04 | `#item-viz-overlay` | Item Visualizer | ✓ | `limpio` | `locus-modals.css` | `aria-live="polite"` + `role="region"`. |
| 05 | `#pend-overlay` | Pendientes Panel | ✓ | `limpio` | `locus-modals.css` | Drawer lateral derecho. Patrón canónico para futuros drawers. |
| 06 | `#doc-log-drawer` | Doc Log Drawer | ✓ | `limpio` | `locus-sesiones.css` | Historial de acciones. Header con clear+close. Overlay: `#doc-log-overlay`. |
| 07 | `#proj-panel-overlay` | Panel Proyectos | ✓ | `limpio` | `locus-analytics.css` | Lateral. Cierra con overlay-click. |
| 08 | `#cp-overlay` | Command Palette | ✓ | `limpio` | `locus-modals.css` | `role="dialog"` + `aria-modal`. Visibilidad via `.is-hidden`. Descubribilidad via `#hdr-search-trigger` + `#cmd-k-pill`. |
| 09 | `#shortcuts-overlay` | Shortcuts | ✓ | `limpio` | `locus-modals.css` | `role="dialog"` + `aria-modal`. |
| 10 | `#sprint-panel-header` | Sprint Header Panel | ✓ | `limpio` | `locus-sprint.css` | Header sticky del tab Sprint — nombre, versión, burndown, botón cierre. `is-hidden` sin sprint activo. |

---

## 3. Toggles y vistas — 11 instancias

| # | ID / Selector | Nombre | En DOM | Estado | CSS canónico | Notas |
|---|---|---|---|---|---|---|
| 01 | `#tracker-view-toggle` | Tracker: Checkpoint / Historial | ✗ | `ausente` | `locus-sesiones.css` | No existe en `index.html`. Cero referencias en los 50 módulos JS auditados. |
| 02 | `#tab-backlog .bl-toolbar-views` | Backlog: vistas | ✓ | `limpio` | `locus-backlog.css` | `role="tablist"` + `role="tab"` + `aria-selected`. |
| 03 | `#rsb-pin-btn` + `#radar-sidebar-toggle` | Radar Sidebar pin/collapse | ✓ | `limpio` | `locus-radar.css` | Dos controles, comportamientos distintos. |
| 04 | `#bl-collapse-all-btn` | Backlog: Collapse all | ✓ | `limpio` | `locus-backlog.css` | Label cambia dinámicamente. |
| 05 | `#tmpl-trigger-wrap` | Template trigger sub-panel | ✗ | `ausente · wip` | `locus-layout.css` | No existe en `index.html`. Patrón de colapso animado (T-202605-019) sigue documentado en CSS-Reference y consumido por JS — pendiente el HTML del wrapper y sus variantes `+body/session/sprint`. |
| 06 | `#tpl-sidebar-danger` | Sidebar danger zone | ✓ | `limpio` | `locus-radar.css` | Requiere clic en "Opciones avanzadas". |
| 07 | `#tracker-col-tabs` | Tracker col tabs (mobile) | ✓ | `limpio` | `locus-sesiones.css` | Visible <900px. |
| 08 | `more-menu + applyTheme()` | Tema light/dark | ✓ | `limpio` | `locus-layout.css` | T-202605-021 done — entrada duplicada en menú ⋯ eliminada. **Único punto de entrada funcional del theme toggle hoy** — ver fila 11 y `_Locus-ux-ref` D-06. |
| 09 | `#header-active-worker` | Worker activo chip | ✗ | `ausente` | `locus-sesiones.css` | No existe en `index.html`. Cero referencias en los 50 módulos JS — duplicado también en §6 fila 07 con el mismo hallazgo. |
| 10 | `#header-pend-btn` | Header pendientes trigger | ✓ | `limpio` | `locus-layout.css` | Visibilidad via `.is-hidden`. Badge de conteo `#header-pend-count`. Abre `#pend-overlay`. |
| 11 | `#theme-toggle-btn` | Theme toggle (header) | ✗ | `ausente · regresión` | `locus-layout.css` | No existe en `index.html`. `main.js`/`locus-ui-shell.js` referencian el ID citando T-202606-006 como `done` — la feature standalone quedó inerte sin crash (guard `if(el)`). El toggle funcional real es vía fila 08. |

---

## 4. Toast y Feedback — 4 instancias

| # | ID | Nombre | En DOM | Estado | CSS canónico | Notas |
|---|---|---|---|---|---|---|
| 01 | `#toast-stack` | Toast Stack | ✓ | `limpio` | `locus-modals.css` | `aria-live="polite"` + `aria-atomic="false"`. 8 tipos semánticos. |
| 02 | `#status-confirm-overlay` | Status Confirm | ✓ | `limpio` | `locus-backlog.css` | T emitido — verificar referencias JS antes de retirar del DOM. |
| 03 | `#storage-warn` | Storage Warning Banner | ✓ | `limpio` | `locus-layout.css` | Usa `.is-hidden`. |
| 04 | `#setup-checklist-banner` | Setup Checklist Banner | ✓ | `limpio` | `locus-layout.css` | T-202605-016 done — migrado a `.is-hidden`. `role="status"` + `aria-expanded`. |

---

## 5. Búsquedas — 6 instancias

| # | ID | Scope | En DOM | Estado | CSS canónico | Notas |
|---|---|---|---|---|---|---|
| 01 | `#hdr-search-trigger` | Trigger Command Palette — global | ✓ | `limpio` | `locus-layout.css` | Chip fantasma en header, visible desde todos los tabs. Abre Command Palette al hacer clic. |
| 02 | `#search-global` | Workers, sesiones, notas | ✗ | `ausente` | `locus-layout.css` | Eliminado del DOM. Reemplazado por Command Palette (`#cp-input`). Documentado en UX-ref §F-01. |
| 03 | `#backlog-search-input` | Ítems del backlog | ✓ | `limpio` | `locus-backlog.css` | Filtro local. Clear button `#backlog-search-clear`. |
| 04 | `#rsb-search-input` | Workers en Radar sidebar | ✓ | `limpio` | `locus-radar.css` | Filtro local. Clear button `#rsb-search-clear`. |
| 05 | `#ctx-search-input` | Secciones del CONTEXT | ✓ | `limpio` | `locus-proyectos.css` | Filtro de secciones. Clear button `#ctx-search-clear`. |
| 06 | `#cp-input` | Command Palette — global | ✓ | `limpio` | `locus-modals.css` | Descubribilidad resuelta via `#hdr-search-trigger` + `#cmd-k-pill`. |

---

## 6. Navegación principal — 12 instancias

| # | ID / Selector | Nombre | En DOM | Estado | CSS canónico | Notas |
|---|---|---|---|---|---|---|
| 01 | `.tabs` | Tabs principales | ✓ | `limpio` | `locus-layout.css` | Sesiones / Proyectos / Backlog / Sprint / Analytics. 5 tabs — Sprint agregado. |
| 02 | `.tpl-sidebar-nav` | Sub-tabs Backlog | ✓ | `limpio` | `locus-backlog.css` | 5 sub-tabs con icono. |
| 03 | `#breadcrumb-proj` | Breadcrumb header | ✓ | `limpio` | `locus-layout.css` | Único segmento real en el DOM. `#breadcrumb-sprint` y `#breadcrumb-item` (documentados en V2.1.0 como 2do/3er segmento) no existen — ver `ausente · regresión` abajo. |
| 03b | `#breadcrumb-sprint` + `#breadcrumb-item` | Breadcrumb — segmentos 2 y 3 | ✗ | `ausente · regresión` | `locus-layout.css` | No existen en `index.html`. `main.js` los referencia citando R-202605-167 como `done` — inertes sin crash (guard `if(el)`). El breadcrumb real opera con 1 solo segmento. |
| 04 | `#global-footer` | Global footer bar | ✓ | `limpio` | `locus-proyectos.css` | 6 elementos. Visibilidad via `.gf-hidden` / `.is-hidden`. |
| 05 | `#more-menu` | Menú ⋯ | ✓ | `limpio` | `locus-layout.css` | T emitido — verificación de corrección de borde en 1920×1080 y 2560×1080 pendiente de Finn. |
| 06 | `#shortcuts-overlay` | Shortcuts | ✓ | `limpio` | `locus-modals.css` | Unifica configuración y referencia. |
| 07 | `#header-active-worker` | Worker activo chip | ✗ | `ausente` | `locus-sesiones.css` | Duplicado de §3 fila 09 — mismo ID catalogado dos veces en el inventario. No existe en `index.html`, cero referencias en JS. Consolidar a una sola entrada en el próximo ciclo de mantenimiento. |
| 08 | `#header-sprint-row` | Sprint progress row | ✗ | `ausente` | `locus-layout.css` | No existe en `index.html`. Cero referencias en los 50 módulos JS. |
| 09 | `#cmd-k-pill` | Cmd-K pill (header) | ✗ | `ausente` | `locus-layout.css` | No existe en `index.html`. Cero referencias en JS — `#hdr-search-trigger` (fila 01 §5) es el único trigger real del Command Palette hoy. |
| 10 | `#ckpt-reopen-btn` | CKPT Reopen button | ✓ | `limpio` | `locus-layout.css` | Nuevo. `is-hidden` por defecto. Reabre último CHECKPOINT via `showCheckpointPanel(_lastCheckpointResult)`. |
| 11 | `#user-chip` | User chip (Supabase) | ✗ | `ausente · regresión` | `locus-layout.css` | No existe en `index.html` (incluye `#user-chip-dot` + `#user-chip-name`). `locus-ui-shell.js` lo referencia citando feature de auth como implementada — inerte sin crash (guard `if(el)`). `handleSyncPillClick()` no es alcanzable por este punto de entrada. |

---

## 7. Tab Sprint — 9 instancias

*Sección nueva — tab completo implementado. Todo pendiente de auditoría de Finn en sesión dedicada.*

| # | ID | Nombre | En DOM | Estado | CSS canónico | Notas |
|---|---|---|---|---|---|---|
| 01 | `#spt-nav` | Subtab nav Sprint | ✓ | `limpio` | `locus-sprint.css` | `role="tablist"`. Subtabs: Ítems / Planificar / Plan. `is-hidden` sin sprint activo. |
| 02 | `#sprint-panel-items` | Panel Ítems | ✓ | `limpio` | `locus-sprint.css` | `role="tabpanel"`. Contiene workers, lista de ítems, health, scope added. |
| 03 | `#sprint-workers` | Workers vinculados | ✓ | `limpio` | `locus-sprint.css` | `is-hidden` sin sprint activo. Body: `#spw-body`. |
| 04 | `#sprint-items-list` | Lista de ítems del sprint | ✓ | `limpio` | `locus-sprint.css` | 3 secciones: `#spi-section-pendiente` / `#spi-section-bloqueado` / `#spi-section-done`. `is-hidden` sin sprint activo. |
| 05 | `#sprint-health-panel` | Sprint Health | ✓ | `limpio` | `locus-sprint.css` | `is-hidden` sin sprint activo. Contenido inyectado por JS. |
| 06 | `#sprint-scope-added` | Scope añadido | ✓ | `limpio` | `locus-sprint.css` | `is-hidden` sin sprint activo. Count `#sca-count`. Body `#sca-body`. |
| 07 | `#sprint-panel-planificar` | Panel Planificar | ✓ | `limpio` | `locus-sprint-ui.css` | `role="tabpanel"`. Drag & drop backlog → sprint. Container `#sprint-planificar-container`. |
| 08 | `#sprint-panel-plan` | Panel Plan | ✓ | `limpio` | `locus-sprint-plan.css` | `role="tabpanel"`. Container `#sprint-plan-container`. |
| 09 | `#tab-sprint-empty` | Empty state Sprint | ✓ | `limpio` | `locus-sprint.css` | Visible cuando no hay sprint activo. CTA → `openNewSprintInline()`. |

---

## Resumen

| Categoría | Total | Limpio | Ausente | Auditar |
|---|---|---|---|---|
| Modales | 27 | 22 | 5 | 0 |
| Panels/Overlays | 10 | 10 | 0 | 0 |
| Toggles/Vistas | 11 | 7 | 4 | 0 |
| Toast/Feedback | 4 | 4 | 0 | 0 |
| Búsquedas | 6 | 5 | 1 | 0 |
| Navegación | 12 | 7 | 5 | 0 |
| Tab Sprint | 9 | 9 | 0 | 0 |
| **Total** | **79** | **64** | **15** | **0** |

**Desglose de "Ausente" (15) por causa:**

| Causa | Conteo | IDs |
|---|---|---|
| Muerto — sin rastro en JS ni HTML | 7 | `#quick-note-modal` · `#migrate-fb-overlay` · `#tracker-view-toggle` · `#header-active-worker` (×2 filas — §3/§6) · `#header-sprint-row` · `#cmd-k-pill` |
| WIP — JS listo, HTML pendiente declarado | 4 | `#reset-sessions-overlay` · `#reset-backlog-overlay` · `#purge-modal-overlay` · `#tmpl-trigger-wrap` |
| Regresión — citado como `done` en JS, inerte hoy | 3 instancias (4 IDs) | `#theme-toggle-btn` · `#breadcrumb-sprint`+`#breadcrumb-item` (1 instancia) · `#user-chip` |
| Pre-existente (V2.1.0) | 1 | `#search-global` |

**Nota de mantenimiento:** `#header-active-worker` está duplicado como entrada en §3 fila 09 y §6 fila 07 — mismo ID, mismo hallazgo. Consolidar a una sola fila en el próximo ciclo de auditoría.
