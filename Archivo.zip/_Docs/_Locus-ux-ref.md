# _Locus-ux-ref.md
<!-- mod:6 | Última actualización: 2026-06-26 | UX Reference — Locus — mantenido por Nova -->
<!-- infra_version: 5 | BR-Core v1.3 · BR-Ecosystem v1.2 · BR-Execution v1.1 · OB-Strategy v1.4 -->

---

## Cambios v0.5.2 (mod:6) — coherencia con BR Gen 2 (infra_version: 5)

- **Encabezado actualizado:** `infra_version: 19` → `5` · versiones BR actualizadas a Gen 2. Nombre del archivo sin versión (patrón Doc Ref correcto per `__OB-Strategy §5`).
- **Selectores `hoy-mini-*`:** Documentados como selectores CSS reales vivos en `locus-sesiones.css` — son naming interno del componente, no terminología BR. Sin cambio de descripción.
- Sin cambios de contenido UX — las reglas y patrones documentados no tienen dependencia de nomenclatura Gen 1.

---

## Cambios v0.5.1 (mod:5) — tensión A-04 resuelta, sesión T-202606-033/034

- **A-04** — fila "high" renombrada de `Naranja` a `Naranja (sin token c-* asociado)`. Detectado por Rune durante implementación de T-202606-034: `_Locus-css-ref` ya usa la familia de tokens `c-high-*` para el status `en-revision` (azul) — colisión de nombre entre nivel de severidad UX y token de status. La severidad "high/naranja" descrita aquí no tiene tokens `c-*` propios — no se ha implementado bajo ese nombre en ningún componente real. Resuelto manteniendo `c-high-*` = `en-revision` (uso real con instancias activas) y aclarando que el nivel de severidad "high" de esta tabla queda sin token semántico dedicado hasta que se implemente un componente que lo requiera.
- Sin cambio de comportamiento visual — ningún componente vivo usaba la severidad "high" de A-04 con un token `c-high-*`. La fila T-202606-033 usó `--red` + `color-mix` (patrón de `context-conflict-banner`), no esta familia.

---

## Cambios v0.5.0 (mod:4) — auditoría contra index.html real + 50 módulos JS + 17 CSS reales, 2026-06-21

- **E-05** corregido — escala real de z-index es 31 tokens, no 30 (ver `_Locus-css-ref`, mismo gap presente ahí hasta esta auditoría).
- **D-06** degradado de `confirmado` a `tensión` — `#theme-toggle-btn` standalone no existe en el DOM real. El punto de entrada funcional hoy es vía `#more-menu` (`_Locus-ui-Inventory` §3 fila 08). Ver detalle en D-06.
- Verificación de tokens A/B/C/G contra los 17 CSS reales — sin discrepancia adicional encontrada.
- Secciones I/J (flujos Tab Sesiones, AI Card) verificadas contra módulos JS reales — sin discrepancia encontrada.

## Propósito

Documento de referencia de experiencia e interfaz del proyecto Locus. Se carga en toda sesión donde Nova interviene sobre Locus — junto al rol transversal `__Role-Nova_UX.md`.

No reemplaza el rol transversal — lo complementa con el conocimiento específico del sistema implementado.

**Audiencia:** Nova (sesión de diseño y especificación) · Rune (consulta cuando CSS-Reference no es suficiente)

---

## Protocolo de uso

Al iniciar sesión sobre Locus, Nova:

1. Carga este documento junto al rol base y `_Locus-css-ref-v*.md`.
2. Verifica que las reglas aquí declaradas no contradigan un R activo — si hay conflicto, señalarlo antes de actuar.
3. Referencia el código de regla (ej: `A-03`) en sus entregables cuando aplica una decisión de diseño.
4. Propone actualización de este documento al cerrar sprint donde intervino — nuevos patrones, reglas que cambian.

---

## A — Tokens y tema

### A-01 · Toda variable de color vive en `:root[data-theme]` — nunca hardcodeada `confirmado`

Los dos temas (dark/light) están completamente declarados en `locus-base.css`. Ningún componente usa colores hex directos — siempre consume tokens semánticos.

**Regla:** Cualquier color nuevo que Nova introduzca debe declararse primero en `:root[data-theme="dark"]` y `:root[data-theme="light"]` antes de usarse en un componente.

---

### A-02 · Tema aplicado antes del primer paint — sin flash `confirmado`

Script inline en `<head>` lee `localStorage` y aplica `data-theme` en `<html>` antes de renderizar. El CSS usa `:root[data-theme]` — no `body` ni `.dark-mode`.

**Regla:** Nova no introduce selectores de tema que dependan de `body` o clases en `body`. Solo `:root[data-theme]`.

---

### A-03 · Acento único: verde lima como color de acción e identidad `confirmado`

El accent se usa para: foco visible, tab activo (underline), breadcrumb hover, bordes de acción primaria, indicadores de estado positivo.

| Tema | Valor | Hover |
|---|---|---|
| Dark | `#a6e22e` (`--accent`) | `#b8f03a` (`--accent-hover`) |
| Light | `#6db821` (`--accent`) | `#7ec828` (`--accent-hover`) |

**Regla:** No se introduce un segundo color de acción. El accent no se mezcla con colores de severidad para acciones primarias.

---

### A-04 · Severidad codificada en 7 niveles de tokens semánticos `confirmado`

| Nivel | Color | Uso | Token `c-*` dedicado |
|---|---|---|---|
| `critical` | Rojo | Errores bloqueantes, acciones destructivas | No — usar `--red` directo o `--c-critical-border` (`.sps-card--hotfix`) |
| `high` | Naranja | Warnings con impacto | **No** — sin implementación bajo este nombre. Ver nota de colisión abajo |
| `medium` | Amber | Atención sin bloqueo | No — `--amber` directo (`--c-medium-*` no existe, ver `_Locus-css-ref`) |
| `pulido` | Azul | Información complementaria | No — `--blue` directo |
| `low` | Verde | Éxito, confirmación | No — `--green` directo |
| `won` | Gris medio | Estados inactivos | Sí — `--c-won-*` (mapeado a status `descartado`/agotado) |
| `done` | Gris oscuro | Estados completados | Sí — `--c-done-*` (mapeado a status `done`) |

**Nota de colisión (mod:5):** La familia de tokens `--c-high-bg/text/border` existe en `locus-base.css` pero está atada al **status de ítem** `en-revision` (azul) — no a este nivel de severidad UX "high/naranja". Son dos taxonomías distintas que comparten el nombre "high" por coincidencia. Si un componente nuevo necesita severidad "high/naranja", no usar `--c-high-*` — usar `--orange` directo o proponer un token nuevo (`--c-severity-high-*`) antes de implementar.

Cada nivel de status (`won`, `done`, y los de la familia `c-*` documentada en `_Locus-css-ref §Tokens semánticos de status`) tiene tres tokens: `--c-[nivel]-bg` / `--c-[nivel]-border` / `--c-[nivel]-text`. Los niveles de severidad UX (`critical`, `high`, `medium`, `pulido`, `low`) consumen los tokens de color base (`--red`, `--orange`, `--amber`, `--blue`, `--green`) directamente — no tienen familia `c-*` propia salvo que se implemente un componente que la requiera.

Tokens `--purple` / `--purple-dim` / `--purple-border` — exclusivos de estado `insession`. No son nivel de severidad.

**Regla:** Nova no usa colores de severidad para otros fines. El purple es exclusivo de estado insession. Antes de introducir un token `c-[nivel]-*` nuevo, verificar contra `_Locus-css-ref §Tokens semánticos de status` que el nombre no colisiona con un status de ítem ya mapeado.

---

### A-05 · Escala tipográfica de 15 pasos — sin valores libres `confirmado`

| Token | Valor | Uso |
|---|---|---|
| `--text-3xs` | 8px | Badge ultra-compacto |
| `--text-2xs` | 9px | Labels de metadatos compactos |
| `--text-2xs-plus` | 10px | Componentes compactos en modales |
| `--text-xs` | 11px | Labels secundarios, breadcrumb |
| `--text-sm` | 12px | Texto UI estándar compacto |
| `--text-base` | 13px | Tamaño base del documento |
| `--text-md` | 14px | Texto UI estándar |
| `--text-lg` | 16px | Títulos de sección compactos |
| `--text-xl` | 18px | Subtítulos |
| `--text-2xl` | 22px | Títulos principales |
| `--text-display-sm` | 17px | Heading de sección compacto |
| `--text-display-md` | 26px | Stat numbers |
| `--text-display-lg` | 28px | Stat values prominentes |
| `--text-display-xl` | 32px | Stat / ícono grande |
| `--text-display-2xl` | 40px | Empty state icons |

**Regla:** Nova usa exclusivamente los tokens de la escala. Si ninguno encaja — proponer nuevo token antes de hardcodear.

---

### A-06 · Tokens de texto sobre fondos de color — T-202605-033 `confirmado`

| Token | Dark | Light | Uso |
|---|---|---|---|
| `--text-on-accent` | `#000` | `#000` | Texto sobre `var(--accent)` lime-green — contraste ~8:1 |
| `--text-on-danger` | `#fff` | `#fff` | Texto sobre `var(--red)` y fondos destructivos |

**Regla:** Nunca usar `#000` o `#fff` directamente sobre fondos de color. Usar estos tokens — si el valor del accent o del red cambia en el futuro, el contraste se corrige en un solo lugar.

---

### A-07 · Colores de tag extendidos — T-202605-033 `confirmado`

| Token | Dark | Light | Clase de tag |
|---|---|---|---|
| `--pink` | `#f472b6` | `#d6509e` | `.tc-5` |
| `--lime` | `#a3e635` | `#6a9e1a` | `.tc-6` |
| `--orange` | `#fb923c` | `#d4691a` | `.tc-7` |

**Excepción documentada — `tag-color-fixed`:** Los `border-color` de `.tc-0` a `.tc-7` en `locus-modals.css` son paleta fija de instancia de componente. No varían por tema. No se tokenizan. Identificados con comentario `/* tag-color-fixed */` inline. No replicar este patrón fuera del componente de tags sin aprobación de Nova.

---

## B — Elevación y superficie

### B-01 · Jerarquía de 4 superficies `confirmado`

| Token | Rol |
|---|---|
| `--bg` | Fondo base de la aplicación |
| `--surface` | Cards principales, modales, panels |
| `--surface2` | Sub-elementos, toolbars, inputs, tabs container |
| `--surface3` | Dropdowns, hover states, estados activos elevados |

Aliases activos: `--bg2`, `--card-bg` → `--surface`, `--surface-2` → `--surface2`. Usar siempre el canónico en componentes nuevos.

---

### B-02 · Sombras solo en cards y modales — nunca decorativas `confirmado`

Dos estados: reposo (`--card-shadow`) y hover/elevado (`--card-shadow-hover`).

**Regla:** Nova no introduce sombras fuera de estos dos tokens. Si un componente necesita parecer elevado, sube en la escala de superficies (B-01) antes de agregar sombra.

---

### B-03 · Radios semánticos por nivel de componente `confirmado`

| Token | Valor | Uso |
|---|---|---|
| `--radius-sm` | 4px | Badges, pills internas, indicadores |
| `--radius-xs` | 6px | Tooltips, variante intermedia |
| `--radius-md` | 8px | Botones, inputs, tooltips |
| `--radius-md-plus` | 10px | Cards secundarias, secciones |
| `--radius-lg` | 12px | Cards, panels secundarios |
| `--radius-lg-plus` | 14px | Popups, modales compactos |
| `--radius-xl` | 16px | Cards principales, modales |
| `--radius-2xl` | 20px | Modales y superficies grandes |
| `--radius-pill` | 999px | Chips de estado, tags |

**Excepciones documentadas:** `border-radius: 0` (indicadores de barra), `border-radius: 2px` (barras de progreso micro), `border-radius: 50%` (avatares circulares). No crear tokens para estos casos.

---

## C — Movimiento y transiciones

### C-01 · 6 curvas de easing declaradas `confirmado`

| Token | Curva | Uso |
|---|---|---|
| `--ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` | Salidas naturales, la mayoría de transiciones |
| `--ease-in-out` | `cubic-bezier(0.45, 0, 0.55, 1)` | Transiciones simétricas |
| `--ease-bounce` | `cubic-bezier(0.34, 1.56, 0.64, 1)` | Acciones positivas, confirmaciones |
| `--ease-standard` | `cubic-bezier(0.4, 0, 0.2, 1)` | Material-style, fade panels |
| `--ease-decel` | `cubic-bezier(0.22, 1, 0.36, 1)` | Entradas de contenido |
| `--ease-spring` | `cubic-bezier(0.34, 1.4, 0.64, 1)` | Modales, elementos con rebote sutil |

**Tensión activa:** Algunos componentes usan `ease` o `ease-out` literal — migrar a `var(--ease-out)` al tocar el componente.

**Regla:** Nova usa exclusivamente los 6 tokens. Si ninguno encaja — proponer nuevo token antes de hardcodear.

---

### C-02 · Escala de velocidades: 5 tokens `confirmado`

| Token | Duración | Uso |
|---|---|---|
| `--trans-fast` | `all 0.12s var(--ease-out)` | Micro-interacciones, hover, color |
| `--trans-medium` | `all 0.20s var(--ease-out)` | Transiciones de estado, expansión |
| `--trans-slow` | `all 0.32s var(--ease-out)` | Entradas de panel, reveals |
| `--trans-color` | `color/bg/border/opacity 0.15s var(--ease-out)` | Transición selectiva de color |
| `--transition-base` | `150ms ease` | Microinteracciones de componentes migrados |

Patrón de salida: la salida de un elemento es siempre más rápida que su entrada. Excepción documentada: 600ms solo para splash/pantalla completa.

---

### C-03 · `prefers-reduced-motion` — cobertura completa `confirmado`

Todo componente nuevo con animación incluye su bloque `@media (prefers-reduced-motion: reduce)` que la desactiva o reduce a `opacity` sin `transform`.

---

## D — Interactividad y estados

### D-01 · 4 estados obligatorios en elementos interactivos `confirmado`

| Estado | Implementación |
|---|---|
| Normal | Estilo base |
| Hover | `background` o `color` con `--trans-fast` |
| Active | `transform: scale(0.93–0.97)` |
| Focus-visible | `outline: 2px solid var(--accent); outline-offset: 2px` |

Focus-visible global declarado en `locus-layout.css`. Componentes que lo necesiten diferente lo sobreescriben.

**Tensión activa:** Componentes secundarios (ítems del menú ⋯, algunas labels clickeables) solo tienen hover.

---

### D-02 · Foco visible nunca suprimido `confirmado`

El sistema no usa `outline: none` global. Se usa `:focus-visible` — nunca `:focus` a secas.

---

### D-03 · Acciones destructivas: doble confirmación inline — no modal nuevo `confirmado`

Las acciones irreversibles usan confirmación inline dentro del mismo contenedor. La zona de peligro requiere un toggle previo para revelar los botones destructivos. Para acciones de mayor alcance (reset completo): overlay con campo de texto `RESET`.

---

### D-04 · Estado deshabilitado: 3 propiedades obligatorias `confirmado`

```css
opacity: 0.35;
cursor: not-allowed;
pointer-events: none;
```

El atributo HTML `disabled` es complementario — no reemplaza la clase CSS.

---

### D-05 · Feedback de copia: el objeto copiado cambia de estado — no toast `confirmado`

El elemento copiado cambia visualmente con `.code-badge--copied` (fondo verde, texto invertido). El toast se reserva para operaciones de mayor peso.

---

### D-06 · Theme toggle — `#theme-toggle-btn` `tensión`

**Estado revisado v0.5.0:** Degradado de `confirmado` a `tensión`. `#theme-toggle-btn` no existe en `index.html` real. `main.js` / `locus-ui-shell.js` referencian el ID citando T-202606-006 como `done` — el botón standalone quedó inerte (guard `if(el)` evita crash, no restaura la feature). El patrón descrito abajo es el diseño original, no el estado implementado hoy.

**Punto de entrada funcional real:** Toggle de tema dentro de `#more-menu` (`more-menu + applyTheme()`) — ver `_Locus-ui-Inventory` §3 fila 08. Sin entrada duplicada — T-202605-021 resolvió esa duplicación dentro del menú ⋯.

Diseño original (no implementado en el DOM actual):

| Selector | Rol |
|---|---|
| `.theme-toggle-btn` | Botón contenedor — 4 estados: normal, hover, active, focus-visible |
| `.theme-icon-dark` | Ícono SVG inline — visible en tema light |
| `.theme-icon-light` | Ícono SVG inline — visible en tema dark |

**Patrón de visibilidad (diseño original):** Los dos íconos coexisten en el DOM. `applyTheme()` alterna su visibilidad via `aria-label` dinámico y clases. No se genera ni destruye el botón — siempre presente en header.

**Decisión pendiente del founder/Cael:** (a) restaurar `#theme-toggle-btn` en el header y mantener dos puntos de entrada, o (b) deprecar formalmente el patrón standalone y declarar `#more-menu` como único punto de entrada canónico. Hasta esa decisión, Nova no diseña nuevas referencias a `#theme-toggle-btn` como vía funcional.

**Regla (vigente hasta resolución):** Nova no introduce un tercer control de tema. Los dos candidatos a único punto de entrada canónico son `#theme-toggle-btn` (no operativo hoy) y `#more-menu` (operativo).

---

## E — Layout y estructura

### E-01 · Estructura estática en HTML — contenido dinámico en JS `confirmado`

Todos los modales, sidebars y panels viven en el DOM como shells vacíos. JS inyecta solo el contenido variable. La visibilidad se controla con clases — nunca con `display` inline.

---

### E-02 · Un punto de verdad por estructura `confirmado`

Gap DUP-06 cerrado — `item.desc` migrado a `item.title` (R-202605-007 done).

**Regla:** Nova no agrega nuevas instancias duplicadas. Al intervenir en estructuras existentes, verificar que no haya shells huérfanos.

---

### E-03 · Breakpoints del sistema `confirmado`

| Breakpoint | Valor | Comportamiento |
|---|---|---|
| mobile | ≤600px | Breadcrumb reducido, sprint-row oculta, col-tabs de tracker |
| tablet | 601–1024px | Radar sidebar colapsado por defecto |
| desktop | ≥1025px | Layout completo |
| ultrawide | ≥2560px | Contenedores con max-width (`var(--bp-ultrawide)`) |

**Breakpoint interno — `≥900px`:** Usado en `locus-sesiones.css` y `locus-backlog.css` para historial en grid cuando el viewport lo permite. No es un breakpoint de layout general — es un ajuste de densidad de contenido en tabs específicos.

Locus es desktop-only (1920×1080 · 2560×1080). Los breakpoints menores existen pero no son viewport objetivo.

---

### E-04 · Header height como token — nunca hardcodeada `confirmado`

`--header-h: 53px` (header-inner 52px + border-bottom 1px). Usada para calcular `height: calc(100vh - var(--header-h))` en múltiples tabs.

---

### E-05 · Z-index en escala declarada de 31 tokens `confirmado`

**Regla:** Nova usa exclusivamente los tokens. Si hay conflicto de z-index — reportarlo como B antes de introducir un valor nuevo. Valores canónicos en `_Locus-css-ref`.

---

### E-06 · Drawer lateral de consulta rápida — patrón `.pend-overlay` `confirmado`

Patrón canónico para drawers laterales. No bloquea el flujo principal.

| Selector | Rol |
|---|---|
| `.pend-overlay` | Overlay base — visibilidad controlada por `.open` |
| `.pend-panel` | Contenedor del drawer — `max-width: 360px` |
| `.pend-panel-header` | Cabecera fija |
| `.pend-panel-body` | Cuerpo scrolleable |

Convenciones: visibilidad via `.open`. `z-index: var(--z-panel)` (1100). Overlay: `rgb(0 0 0 / 40%)`. Sin animación de entrada.

---

### E-07 · Tab scroll containment — cada tab en su propio contexto `confirmado`

```css
.tab-panel.active:not(#tab-tracker) {
  height: calc(100vh - var(--header-h, 54px));
  overflow: hidden auto;
}
```

`#tab-tracker` tiene su propio scroll management. Evita que el scroll de un tab persista al cambiar.

---

## F — Búsqueda y navegación

### F-01 · Búsquedas: scope local por contexto `confirmado`

| Campo | Scope |
|---|---|
| `#hdr-search-trigger` | Trigger visual en header — abre Command Palette al hacer clic. Complementa `#cmd-k-pill`. |
| `#backlog-search-input` | Ítems del backlog |
| `#rsb-search-input` | Workers en Radar sidebar |
| `#ctx-search-input` | Secciones del CONTEXT importado |
| `#ctr-search-input` | Módulos y funciones en panel Contratos (`locus-sprint-plan.css`) |
| `#cp-input` | Comandos, ítems, Workers, sesiones (global) — acceso via ⌘K |

**Nota:** `#search-global` eliminado del DOM — era búsqueda en tab Tracker. Reemplazado funcionalmente por Command Palette.

**Regla:** Nova no agrega nuevos campos de búsqueda aislados sin evaluar conexión a los existentes.

---

### F-02 · Todo campo de búsqueda tiene botón de clear explícito `confirmado`

Los 6 campos tienen su botón ✕, visible solo cuando hay contenido.

---

## G — Feedback al usuario

### G-01 · Toast system: 8 tipos semánticos `confirmado`

| Tipo | Uso |
|---|---|
| `t-success` | Operación completada con éxito — solo cuando el resultado no es visible en pantalla |
| `t-download` | Descarga iniciada |
| `t-error` | Error — requiere acción del usuario |
| `t-warning` | Advertencia — no bloquea |
| `t-info` | Información neutral |
| `t-confirm` | Confirmación de acción de alto peso que cierra o abandona el contexto activo |
| `t-copy` | Copia al portapapeles |
| `t-neutral` | Mensajes sin semántica de estado |

**Regla de uso:** El toast es para acciones cuyo resultado no es visible en pantalla, o acciones que cierran el contexto activo. Si el resultado es visible en el mismo contexto donde ocurrió la acción → usar feedback inline o silencio. Ver G-04.

---

### G-02 · `aria-live` en contenedores de feedback dinámico `confirmado`

Todo componente nuevo que inyecte contenido dinámico incluye `aria-live="polite"`.

---

### G-03 · Estados de carga internos — patrón definido `confirmado`

- Operaciones < 300ms: sin indicador
- Operaciones 300ms–2s: spinner inline en el botón que la disparó
- Operaciones > 2s: barra de progreso indeterminada en el área afectada (patrón `#pepe-progress-bar`)

---

### G-04 · Jerarquía de feedback: silencio → inline → toast `confirmado`

Tres niveles en orden de preferencia. Usar el nivel más bajo que comunique el resultado con claridad.

| Nivel | Cuándo aplica | Ejemplos |
|---|---|---|
| **Silencio** | El estado del sistema ya comunica el resultado — el cambio es visible sin feedback adicional | Panel DIFF renderizado tras parse exitoso · Status de ítem cambiado con micro-flash |
| **Inline** | La acción ocurre dentro de un panel o contexto abierto y el resultado es visible en ese mismo espacio | Confirmación de merge en panel DIFF · `.item-inline-confirm` en backlog · micro-flash `.item-status-confirmed` |
| **Toast** | La acción cierra el contexto activo, es irreversible sin feedback visible, o el resultado ocurre fuera de pantalla | Guardar sesión completa · Exportar archivo · Error de parse (panel no abre) |

**Reglas duras:**
- No apilar toast sobre inline — si ya hay confirmación inline, el toast es ruido.
- No usar toast para comunicar que un panel se abrió — el panel es la confirmación.
- `t-error` es la excepción: siempre va como toast, incluso si hay contexto abierto. El error requiere atención activa del usuario.

**Aplicación al flujo de CHECKPOINT:**

| Acción | Mecanismo correcto |
|---|---|
| Parse exitoso | Silencio — el panel DIFF es la confirmación |
| Parse fallido | Toast `t-error` — el panel no abre, el error no es visible |
| Apply DIFF (ítems mergeados) | Inline — micro-flash en header del panel antes de cerrar |
| Guardar sesión completa | Toast `t-confirm` — contexto se cierra |
| Standalone CHECKPOINT guardado | Toast `t-confirm` — ídem |
| Status de ítem sin impacto sprint | Micro-flash `.item-status-confirmed` — sin toast |
| Status de ítem con impacto sprint | `.item-inline-confirm` — sin toast posterior |

---

## H — CSS purity

### H-01 · Todo estilo de presentación vive en CSS `confirmado`

Nova entrega clases CSS para cualquier estado visual — no instrucciones de `style.color` o `style.display`. Regla completa en `__BR-Execution §3`.

---

### H-02 · Clase canónica de ocultamiento: `.is-hidden` `confirmado`

**Regla canónica:** `.is-hidden { display: none !important; }` — declarada en `locus-base.css`.

**Alias legacy activos en `locus-base.css`:**
- `.hidden` — alias directo, misma declaración que `.is-hidden`

**Alias de scope en módulos específicos (no migrar sin T explícito):**
- `.gf-hidden` — footer elements (`locus-backlog-item.css`)
- `.breadcrumb-seg--hidden` — segmentos del breadcrumb (`locus-layout.css`)
- `.force-hidden` — override de máxima especificidad (varios módulos)
- `.scb-hidden` — `#setup-checklist-banner` (migración pendiente en backlog)

**Excepción documentada:** `.tmpl-trigger-body.is-hidden` usa `.is-hidden` para colapso animado (max-height/opacity) — no es `display:none`. Intencional.

**Regla:** Nova usa exclusivamente `.is-hidden` en componentes nuevos.

---

## I — Tab Sesiones · Patrones de layout y panel

### I-01 · Proporción canónica del split de columnas del Tab Sesiones `confirmado`

El Tab Sesiones usa un layout de dos columnas horizontales.

| Estado | Proporción | Descripción |
|---|---|---|
| Reposo | `40 / 60` | Columna izquierda (lista de sesiones) · columna derecha (área de trabajo) |

Sin variantes declaradas — no existe estado de columna única ni colapso horizontal en desktop.

**Regla:** Nova usa `40/60` como proporción canónica en reposo. Si una sesión de trabajo requiere ajuste de densidad, proponer nuevo estado con proporción declarada — no asumir libre.

---

### I-02 · Patrón `#ckpt-panel` — flujo canónico post-parse del Tab Sesiones `confirmado`

`#ckpt-panel` es el panel de resultado de parseo de CHECKPOINT. Slide-in lateral — no modal. Definido en `locus-modals.css`.

**Estados y transiciones:**

| Estado | Condición de activación | Comportamiento |
|---|---|---|
| Oculto | Sin CHECKPOINT parseado en sesión activa | `.is-hidden` — fuera del flujo visual |
| Visible — en proceso | Parse en curso | Slide-in visible con barra de progreso activa |
| Visible — resultado | Parse completo (éxito o error parcial) | Muestra DIFF generado — founder puede revisar antes de confirmar |
| Visible — post-apply | Founder confirmó apply | Panel cierra con transición de salida — toast `t-confirm` si la sesión se guarda completa |
| Reabierto | Founder usa `#ckpt-reopen-btn` | Panel vuelve al estado `resultado` con el último DIFF en memoria |

**Criterio de visibilidad:** La apertura del panel es la confirmación de parse exitoso — no se acompaña de toast. El cierre puede ir con toast si el contexto cambia (sesión guardada). Ver G-04.

**Regla:** Nova no introduce un segundo panel de resultado de parse. `#ckpt-panel` es el único punto de llegada del flujo de CHECKPOINT.

---

### I-03 · Triggers automáticos — criterio de interrupción no solicitada `confirmado`

Un trigger automático interrumpe al usuario cuando se activa sin acción directa de su parte (timers, eventos del sistema, llegada de datos).

**Criterio de interrupción válida:**

| Condición | Permitido | Ejemplo válido |
|---|---|---|
| El evento es irreversible o tiene ventana corta de acción | Sí | Alerta de sprint próximo a vencer · notificación de sync fallido |
| El evento afecta el trabajo activo del usuario en ese momento | Sí | Conflicto de CHECKPOINT en sesión en curso |
| El evento es informativo sin urgencia | No | Estadísticas de uso · actualizaciones de fondo resueltas |
| El evento ocurre en flujo que el usuario ya está ejecutando | No | Toast de "guardado" cuando el usuario ya ve el resultado en pantalla |

**Mecanismo preferido por urgencia:**

| Urgencia | Mecanismo |
|---|---|
| Alta — requiere acción inmediata | Modal o panel bloqueante |
| Media — requiere atención pero no bloquea | Toast `t-warning` o `t-info` |
| Baja — informativa, descartable | Banner no bloqueante o silencio |

**Regla:** Un trigger automático que no cumple la condición de interrupción válida no se implementa como toast ni modal. Se registra en estado del sistema y se expone solo si el usuario lo consulta.

---

## J — AI Card · Estados

### J-01 · 5 estados reales de AI Card `confirmado`

La AI Card es el componente central del Tab Tracker. Implementada en `buildHoyCard()` — `locus-sesiones.js`.

| Estado | Clases en el elemento card | Condición de activación | Comportamiento visual |
|---|---|---|---|
| `available` | `hoy-mini-card available` | Worker sin sesión activa, sin restricción, sin interrupción | Estado neutro — sin indicador especial |
| `insession` | `hoy-mini-card available in-session-state` | Worker con sesión en curso (`_isInSession` = true) | Badge `hoy-mini-badge--insession` + dot activo |
| `interrupted` | `hoy-mini-card available interrupted-state` | Sesión interrumpida sin cierre formal (`ai.interrupted = true`) | Banner "⚡ Checkpoint en curso" + CTA "Continuar →" |
| `exhausted-con-hora` | `hoy-mini-card exhausted` | `ai.status === 'exhausted'` con `ai.resetTime` declarado | Countdown dramático + hora reset. Badge `sc-badge--exhausted` |
| `exhausted-sin-hora` | `hoy-mini-card exhausted` | `ai.status === 'exhausted'` sin `ai.resetTime` | "Sin hora de desbloqueo" + CTA asignar. Badge `sc-badge--exhausted` |

**Nota de implementación:** `interrupted-state` e `in-session-state` son clases adicionales sobre `available` — no reemplazan la clase base. Un worker puede ser `available in-session-state` simultáneamente.

**Tokens de color para `in-session-state`:** `--purple`, `--purple-dim`, `--purple-border` — exclusivos de este estado (ver A-04).

**Badges de estado (sc-badge):** El badge en el header de la card usa modificadores de `locus-sesiones-card.css`: `.sc-badge--avail` para estados `available`/`interrupted`, `.sc-badge--exhausted` para estado `exhausted`. Ver CSS-ref `§AI Card rediseño`.

**Regla:** Nova no introduce estados intermedios entre los 5 declarados. Si un caso de uso no encaja en ninguno → proponer nuevo estado con nombre, condición y clases antes de implementar.

---

## K — Tracker · Proporciones de grid

### K-01 · Proporciones canónicas del grid `tracker-3col` `confirmado`

El layout principal del Tab Tracker usa un grid de 3 columnas.

| Estado | Proporción | Condición |
|---|---|---|
| Reposo | `40 / 60` (2 columnas efectivas) | Sin preview activo — la tercera columna colapsada a `0fr` |
| Con preview activo | `30 / 40 / 30` | Panel de preview expandido — tracker-preview visible |

**Nota:** En reposo el grid es técnicamente de 3 columnas pero opera como 2 — la columna de preview está en `0fr`. Ver K-02 para el patrón de expansión.

**Regla:** Nova declara proporciones explícitas cuando propone variantes de layout del tracker. No asumir que `auto` o `1fr` equivale a las proporciones canónicas.

---

### K-02 · Patrón `0fr → Nfr` — paneles expandibles `confirmado`

Patrón canónico para paneles que aparecen y desaparecen sin reflow brusco. Implementación de referencia: `tracker-preview` en el Tab Tracker.

**Mecanismo:**

```css
/* Estado colapsado */
.tracker-preview {
  width: 0fr; /* o grid-template-columns equivalente */
  overflow: hidden;
  transition: width var(--trans-medium);
}

/* Estado expandido — clase aplicada por JS */
.tracker-preview.is-expanded {
  width: Nfr; /* valor canónico del estado expandido */
}
```

**Comportamiento:**
- Colapsado: el panel no ocupa espacio visual — `0fr` en el grid-template
- Expansión: transición suave con `var(--trans-medium)` — sin salto de layout
- Contenido interno: visible solo en estado expandido (`overflow: hidden` en colapsado)

**Criterio de uso:**

| Condición | Usar este patrón | Alternativa |
|---|---|---|
| El panel aparece/desaparece en respuesta a acción del usuario | Sí | — |
| El panel necesita preservar estado interno al colapsar | Sí — el DOM no se destruye | `display: none` / `.is-hidden` si el estado no importa |
| El panel es modal o requiere overlay | No | Shell en HTML + `.open` / `.is-hidden` |

**Regla:** Nova usa este patrón para todo panel expandible inline que requiera transición sin reflow. Si el panel es modal → patrón de shell estático (E-01).

---

## Notas operativas

- Este documento se actualiza al cerrar cada sprint donde Nova interviene sobre Locus.
- `_Locus-css-ref` es la interfaz formal entre Nova y Rune — tiene precedencia sobre este documento en convenciones de implementación.
- El inventario completo de componentes vivos → `_Locus-ui-Inventory`.
- **Tensión activa (v0.5.1):** D-06 — pendiente decisión del founder/Cael sobre punto de entrada canónico del theme toggle. No cerrar como `confirmado` hasta esa decisión. (A-04 resuelta en mod:5 — ver Cambios v0.5.1.)
