# _Locus-css-ref.md
<!-- mod:169 | Última actualización: 2026-08-05 | CSS Reference — Locus — mantenida por Nova, consumido por Rune -->

## Cambios (mod:169) — Fix inline (triggered_by: análisis visual Q-INC): discrepancia de `letter-spacing` en `.qinc-section-header` cerrada — `locus-incidents.css` mod:12 corrige `0.04em → 0.06em`, alineado a la tabla de unificación general. Doc actualizado para reflejar el valor real vigente, sin nota de discrepancia abierta.

## Cambios (mod:168) — Análisis visual Q-INC (Nova, sin REQ/TKT — DOC-UPDATE post-entrega): tres cambios documentados sobre el panel Q-INC — `.qinc-stats-bar` gana identidad de header propia + wrapper `.qinc-stats-bar-inner` (`locus-incidents.css` mod:11); `.qinc-section-header` reemplaza color base único por modificadores `--activos`/`--terminados` + `.qinc-section-count` (`locus-incidents.css` mod:11, `locus-incidents-render.js` mod:21); `.qinc-item-copy-btn` — primera documentación real (huérfana desde TKT-B/REQ CAEL-0722-01) — pasa a icon-only, markup actualizado en `locus-incidents-item.js` mod:10. Discrepancia detectada y declarada, no corregida en este movimiento: `letter-spacing` de `.qinc-section-header` entregado en `0.04em`, doc previo declaraba `0.06em` como valor unificado — ver nota en la sección correspondiente.

## Cambios (mod:167) — REQ-202608-098 (Estandarizar mecanismo visual de pills de filtro)

Mecanismo unificado en `.filter-btn`/`.filter-type-btn`/`.filter-status-btn`/`.filter-done-chip`/`.bl-strip-btn`/`.htmlmap-filter-btn`: `border-radius: var(--radius-xs)`, padding `3px 8px` (normal y activo), `border-width: 1.5px` en `.active` — mismo token de color por variante, solo cambia el grosor. `.hmfilter-pill` migra solo el `border-radius` — su padding queda excluido explícitamente (excepción confirmada por el founder, ver `§HTML-MAP viewer`). `.bl-strip-btn.active.s-bloqueado` corregido de tokens crudos (`--red`) a semánticos (`--red-border`/`--red-dim`/`--red-text`) — ver `§Filter strip de status`. TKTs: TKT-202608-248 (`locus-backlog.css`), TKT-202608-249 (`locus-docs.css`).

## Cambios (mod:166) — Ad-hoc (propuesta de Nova aprobada por founder en sesión — sin REQ/TKT, mismo tratamiento que cambios ad-hoc ya registrados en `index.html` mod:146/172): `.qdisc-limit-indicator` se integra a `.bl-panel-identity`, deja de vivir en línea propia

**Origen:** founder pidió más protagonismo para el indicador "N / 15" de Q-DISC — vivía en su propia línea, fuera del header, con una barra de 34px×4px casi ilegible. Dos opciones comparadas (A: integrado a la derecha de `.bl-panel-identity` · B: franja de capacidad de ancho completo, componente nuevo) — A aprobada, reusa el patrón `.bl-panel-identity` ya vigente (`design_intent: qbacklog_qdisc_panel_identity`) en vez de introducir una familia nueva.

**Cambios en `locus-backlog.css` (mod:139, autor:Nova):**

| Selector | Antes | Ahora |
|---|---|---|
| `.qdisc-limit-indicator` | `margin: 8px 0 0 12px` (línea propia, fuera de `.bl-panel-identity`) — `font-size: var(--text-2xs)` — `gap: 3px` — `padding: 1px 8px` | `margin-left: auto; align-self: center` (tercer hijo de `.bl-panel-identity`, empujado al extremo derecho de la fila) — `font-size: var(--text-xs)` — `gap: 6px` — `padding: 3px 10px` |
| `.qdisc-limit-bar` | `34px × 4px` | `90px × 8px` |

`.qdisc-limit-indicator.qdisc-limit--warn` y `.qdisc-limit-bar-fill` sin cambio — mismo token `--amber`, mismo mecanismo `currentColor`.

**Cambio estructural en `index.html` (mod:178, autor:Rune):** `#qdisc-limit-indicator` se mueve dentro de `.bl-panel-identity` de `#qdisc-header-unified`, como tercer hijo tras `.bl-panel-identity-caption`. Mismo id, mismo `aria-live="polite"`, sin cambio de JS — `_renderQDiscLimitIndicator()` (`locus-backlog-qdisc.js`) sigue resolviendo el nodo por id, agnóstico de dónde vive en el árbol.

**No incluye:** no toca `.qdisc-grooming-banner` ni `.qdisc-area-chips` — siguen en línea propia debajo de `.bl-header-unified`, fuera de scope de este cambio (el founder pidió específicamente el indicador de límite).

---

## Cambios (mod:165) — TKT-202608-240 (REQ Merge Diff Panel — distinguir bloque vacío de referencia sin resolver, ref_id CAEL-0804-01, origen DISC-202608-098): `.mdiff-ckpt-category--vacio`/`--sin-resolver` — separan la categoría `lite` fusionada

**Origen:** `lite` clasificaba dos causas distintas bajo el mismo badge — bloque de CHECKPOINT genuinamente vacío (sin `items`) y bloque con una referencia (`code`/`ref_id`) que no matcheó contra el diff. El founder no podía distinguir ambos sin leer código. Este TKT solo agrega los dos selectores CSS nuevos — la reclasificación en `_ckptCategoryFor`/`_CKPT_CATEGORY_LABELS` y el retiro del badge de bloque `no leído` duplicado los ejecuta TKT2 (Rune, `locus-backlog-merge.js`), `depends_on` de este TKT.

**Cero tokens nuevos — ambos selectores reusan valores ya verificados WCAG AA en este mismo archivo:**

| Selector | Reuso |
|---|---|
| `.mdiff-ckpt-category--vacio` | Misma base neutra que `.mdiff-ckpt-category--borrador` — `var(--surface2)`/`var(--text2)`, `border-style: dashed`, `var(--border)`. Sin acento de alerta — es un estado esperado, no un problema |
| `.mdiff-ckpt-category--sin-resolver` | Misma variable de acento ámbar que `.mdiff-block-badge--flag` — `color-mix(in srgb, var(--amber) 10%, transparent)` / `var(--amber-text)` / `color-mix(in srgb, var(--amber) 28%, transparent)`. Mismo nivel `medium` de `_Locus-ux-ref §A-04` ("atención sin bloqueo") |

**No incluye:** `.mdiff-ckpt-category--lite` se conserva sin cambio en este TKT — el `no_incluye` del TKT excluye explícitamente su retiro; queda huérfana hasta que TKT2 deje de emitirla desde JS, momento en que un TKT o fix inline posterior la retira como CSS muerto (mismo patrón ya usado en este archivo, ver mod:82/85/91).

**Ubicación:** dentro de la familia `.mdiff-ckpt-category` existente, `locus-backlog-item.css` mod:92 — dos reglas nuevas insertadas después de `--lite`, antes del comentario `Borde de card reforzado`.

## Cambios (mod:164) — DOC-UPDATE emitido por Nova en TKT-202608-237: prefijo `du-resolved-` documentado + gap histórico de `du-` (T-202606-033, nunca documentado) cerrado en el mismo movimiento

- **Origen:** `doc_updates` emitido por Nova al entregar TKT-202608-237 (REQ-202608-090, sprint PP-S-26) — pendiente de aplicación hasta esta sesión, sin `_Locus-css-ref.md` adjunto anteriormente.
- **`§Arquitectura de módulos CSS`, fila 20 (`locus-docs.css`):** `925` → `1060` líneas, `mod:4` → `mod:6` · autor Nova — verificado contra archivo real de esta sesión (`wc -l`). Scope extendido: `htmlmap-* · mm-* · context-* · du-* · du-resolved-*`.
- **`§Prefijos de módulo`:** 2 filas nuevas — `du-` (Pendientes, T-202606-033 — nunca tuvo entrada pese a estar en producción desde esa fecha) y `du-resolved-` (Sub-tab Resueltos, TKT-202608-237). Ambas `locus-docs.css`.

## Cambios (mod:163) — TKT-202608-235 (REQ-202608-089, design_intent: ingest_block_preview_mockup): `.ingest-block-preview*` — preview de bloques detectados antes de 'Procesar batch'

**Origen:** Founder señaló que el panel de ingesta no distingue, antes de pegar, si el CHECKPOINT trae cambios reales de backlog o es solo trazabilidad de archivo — el mensaje final ("Sin ítems para procesar") sonaba a error incluso siendo válido (TKT-202608-234, mismo REQ, ya cerrado). Este TKT resuelve la mitad visual: una fila por bloque detectado, visible antes del botón "Procesar batch".

**Reuso deliberado, no invención:** misma gramática visual que `.validation-result-item*` (`§Modal de ingesta — panel de validación`, CAEL-19/CAEL-23) — icono + texto truncado en fila, contenedor con scroll interno tras cierto alto. Distinto de esa familia porque vive en un momento distinto del flujo (antes de procesar, no en el resultado post-proceso) y no tiene badge de tipo ni columna de status a la derecha — es una lista de confirmación visual, no un resultado clasificado. Nombre de clase independiente (`.ingest-block-preview-*`, no `.validation-result-*`) para no mezclar semánticas de "ya procesado" con "detectado, aún sin procesar".

**Elemento 100% dinámico — sin shell estático (`BR-Execution §5`):** a diferencia de `.ingest-validation-panel` (shell fijo en `index.html`, tres sub-vistas togleadas con `is-hidden`), `.ingest-block-preview` no tiene contraparte estática — el contenedor completo solo existe en el DOM cuando hay 1+ bloques válidos detectados en el textarea. Con 0 bloques, no se inserta el nodo — nunca `display:none` sobre un shell vacío.

**Selectores nuevos (`locus-modals-base.css` — mod real pendiente de confirmar contra archivo adjunto, ver `Acción sugerida` en el CHECKPOINT de entrega):**

| Selector | Rol |
|---|---|
| `.ingest-block-preview` | Contenedor raíz — mismo chrome que `.ingest-validation-panel`: `var(--surface2)`/`var(--border2)`, `--radius-lg`, `padding:12px 14px`, inset `margin-left/right: var(--subtab-gutter)` (12px, mismo criterio REQ CAEL-0717-02), `margin-top:10px` |
| `.ingest-block-preview-label` | Eyebrow "preview de bloques detectados" — `--text-xs`/`var(--text3)`, `text-transform:lowercase` (mismo tratamiento que `.validation-result-next-step-label`), `margin-bottom:8px` |
| `.ingest-block-preview-list` | Lista de filas — `display:flex; flex-direction:column`, `max-height:130px` + `overflow-y:auto`, mismo AC de overflow que `.validation-result-items` (no crece el panel con muchos bloques) |
| `.ingest-block-preview-item` | Fila individual — JS-generada, existe solo si hay bloque (`BR-Execution §5`, mismo criterio que `.validation-result-item`). `display:flex; align-items:flex-start; gap:6px`, `padding:8px 0`, `border-bottom:1px solid var(--border2)`, sin borde en `:last-child` |
| `.ingest-block-preview-icon` | Ícono `ti-file-text` — `flex-shrink:0`, `color:var(--text3)`, `font-size:var(--text-base)`, `margin-top:1px` (alineación óptica con la primera línea de texto) |
| `.ingest-block-preview-text` | Wrapper de título+subtítulo — `display:flex; flex-direction:column; min-width:0; gap:2px` (`min-width:0` es lo que habilita el `text-overflow:ellipsis` de los hijos dentro de un flex item) |
| `.ingest-block-preview-title` | Título del bloque, truncado a una línea — `--text-base`/`500`/`var(--text)`, `white-space:nowrap; overflow:hidden; text-overflow:ellipsis`. JS trunca el string a 60 caracteres antes de poblar (AC del TKT) — el CSS trunca visualmente como red de seguridad si el string es más largo de lo esperado, no reemplaza el truncado en JS |
| `.ingest-block-preview-meta` | Subtítulo condicional "archivo · mod:N" — solo presente si el bloque declara `files`. `--text-xs`/`var(--text3)`, mismo tratamiento de ellipsis que `.ingest-block-preview-title`. Nodo omitido del DOM (no vacío ni oculto) cuando el bloque no declara `files` |

**Accesibilidad:** `.ingest-block-preview-title` lleva `title="[texto completo sin truncar]"` como atributo nativo — mismo criterio que el sistema ya aplica en truncados equivalentes (ej. atribución de tarjetas en batch, `_Locus-ux-ref` — tarjetas atribuidas). El ícono es decorativo (sin texto alternativo) — la información que transmite (fila = un bloque de CHECKPOINT) ya está en el texto adyacente.

**Sin tokens nuevos** — reuso exclusivo de `--subtab-gutter`, `--surface2`, `--border2`, `--radius-lg`, `--text-xs`, `--text-base`, `--text3`, `--text`.

**No incluye:** no reemplaza ni modifica `.ingest-validation-panel`/`.validation-result-*` (panel posterior a "Procesar batch", TKT distinto según AC del REQ). No agrega interacción — la fila no es clickeable ni seleccionable, es lectura pasiva antes de procesar.

## Cambios (mod:162) — INC-202608-083 cerrado: familia `.mdiff-zone*`/`.mdiff-bucket*` — nunca tuvo CSS propio desde TKT-202607-205 (`locus-backlog-item.css` mod:88→89)

**Origen:** Founder reportó vía screenshot que "Revisar antes de guardar" y "Cambios en el backlog / Se aplican solos" se veían como texto plano en el panel de revisión del ingest modal. Grep contra `locus-backlog-merge.js` (mod:84, sin cambio) confirmó que el markup de las "6 zonas cognitivas" (TKT-202607-205, REQ-202607-079) usa `.mdiff-zone`, `.mdiff-zone-label`, `.mdiff-bucket`, `.mdiff-bucket--auto`/`--revisar`/`--info` y `.mdiff-bucket-label` — ninguna de las seis tenía regla declarada en ningún archivo CSS del proyecto ni entrada en este doc. Gap de entrega desde el TKT original, no regresión. Afecta las 4 zonas del body (`resultado`/`narrativa`/`cambios-backlog`/`impacto-ecosistema`), no solo la zona reportada — `.mdiff-zone`/`.mdiff-zone-label` son compartidas por las 4.

| Selector | Descripción |
|---|---|
| `.mdiff-zone` | Contenedor de cada una de las 4 zonas del body — solo `margin-bottom: 1rem` (`0` en `:last-child`), sin framing propio |
| `.mdiff-zone-label` | Eyebrow uppercase que abre una zona ("Cambios en el backlog", "Impacto en el ecosistema") — reusa 1:1 la receta tipográfica ya establecida por `.mdiff-narrative-header` (mismo rol semántico, sin token nuevo) |
| `.mdiff-bucket` | Cubeta dentro de la zona `cambios-backlog` (auto/revisar/info) — `margin-bottom: 0.75rem` (`0` en `:last-child`) |
| `.mdiff-bucket-label` | Eyebrow un nivel debajo de `.mdiff-zone-label` — mismo patrón, tamaño menor (`--text-xs` vs `--text-sm`), sin `border-bottom` para no competir con el label de zona que lo contiene |
| `.mdiff-bucket--revisar .mdiff-bucket-label` | Gana `color: var(--amber-text)` — mismo token semántico "acción pendiente" ya usado en `.mdiff-right-banner--warn`/`.mdiff-pending-item` en este mismo panel, no un color nuevo |

**No incluye:** `.mdiff-bucket--auto`/`--info` no ganan color propio — quedan con la base neutra de `.mdiff-bucket-label`, sin justificación semántica para diferenciarlos visualmente (a diferencia de `--revisar`, que sí mapea a "acción pendiente" ya establecido en el panel).

**Fix aplicado por:** Nova, `locus-backlog-item.css` mod:89. INC cerrado — `incident_status: closed`, `resolution_type: permanent_fix`.

## Cambios (mod:161) — Variantes `--pink` — severidad informativa/no-bloqueante en Panel de Revisión (`locus-backlog-item.css` mod:87→88)

**Origen:** Hallazgo del founder — el panel de resolución de "referencias sin resolver" del merge diff usaba el mismo estilo `warn` para casos que bloquean guardar y casos que no (valores sin forma de código, ej. `triggeredBy: "n/a — alta manual de prueba"`, tratados igual que un typo de código real). `source: 'formato_invalido'` nuevo en `_assignPendingIds()` (`locus-backlog-item.js`, ver `_Locus-module-contracts §2`) distingue el caso; esta entrada documenta el CSS de esa distinción.

**Token reusado, no creado:** `--pink`/`--pink-text` ya existían (`§Tokens de color`, línea 1757/1775 — dominio: tag `.tc-5` / toast `t-copy`, ninguno de tipo de ítem del backlog). Sin colisión semántica — mismo criterio de "compromiso aceptable" ya aplicado en `mod:116`. `--blue` quedó descartado por colisión con DISC (ya asignado); `--pink` es el color libre elegido como estándar de severidad informativa/no-bloqueante para toda la UI de Locus, no solo este panel.

**Selectores nuevos (`locus-backlog-item.css` mod:87→88):**

| Selector | Rol |
|---|---|
| `.mdiff-section-header.mdiff-section-header--pink` | Header de sección — mismo patrón que `--warn`/`--red`/`--muted` (color + background `color-mix`), con `:hover` propio |
| `.mdiff-pill--pink` | Badge "no bloquea guardar" — mismo patrón que `--retroceso`/`--warn` |
| `.mdiff-unresolved-row.mdiff-unresolved-row--pink` | Extiende `.mdiff-unresolved-row` (no la reemplaza) — solo ajusta `border-top-color` |
| `.mdiff-unresolved-invalid-wrap` | Contenedor flex de la fila informativa (valor + botón) |
| `.mdiff-unresolved-invalid-value` | Valor crudo del campo inválido, `font-mono` |
| `.mdiff-unresolved-invalid-btn` | Botón "Quitar referencia" — affordance explícita con label, a diferencia de `.mdiff-unresolved-chip-remove` (ícono-solo) |
| `.mdiff-unresolved-removed` | Estado post-click — confirmación breve (`opacity: 0.6`) antes de que el render retire la fila |

**Atribución de bloque:** reusa `.mdiff-block-badge` sin variante nueva — la sección `--pink` no requirió badge propio de origen, mismo mecanismo que ya usan retrocesos/descartes vía `item.idx`.

**Corrección de contrato incluida (mod:88):** la primera entrega (mod:87) declaraba `.mdiff-unresolved-invalid-remove-btn` y `.mdiff-unresolved-invalid-label` — no coincidían con el markup real de `locus-backlog-merge.js` (JS escrito antes de que este CSS existiera). Corregido a `.mdiff-unresolved-invalid-btn` (sin sufijo `-remove`); `-label` retirado — sin consumidor, el label del campo ya usa `.mdiff-unresolved-label` reusado fuera del branch de `formato_invalido`. Los selectores de esta entrada son los finales, verificados 1:1 contra el JS real.

**No incluye:** no crea variante nueva de `.mdiff-block-badge`. No toca `.mdiff-unresolved-chip`/`.mdiff-unresolved-search-wrap` (flujo de búsqueda existente, sin cambio).

---

## Cambios (mod:160) — TKT1 (REQ CAEL-0803-03, design_intent: qbacklog_activos_group_mockup): `.bl-active-*` — grupo colapsable de ítems activos en Q-Backlog

**Origen:** Founder señaló que Q-Backlog tenía "Terminados" y "Borradores" como bloques colapsables (header + chevron + contador), pero la lista de ítems activos quedaba suelta directamente en `.bl-zone-body`, sin el mismo tratamiento — inconsistencia entre las tres agrupaciones del mismo panel. Consistente con **E-17** (`_Locus-ux-ref`) — criterio transversal de header clickeable + chevron para todo grupo de ítems por categoría, ya vigente en `.qdisc-status-group`/`.qbacklog-draft-group`/`.qinc-section-header`.

**Selector nuevo (`locus-backlog.css` mod:136):**

| Selector | Rol |
|---|---|
| `.bl-active-group` | Contenedor raíz — dinámico (se recrea en cada render de `_renderZonePanel`, a diferencia de `.bl-done-group` que es shell estático en `index.html`) |
| `.bl-active-header` | Header clickeable — mismos tokens que `.bl-done-header` (`--surface2`/`--border`/`--text2`), cromática neutra sin tinte de estado |
| `.bl-active-arrow` | Chevron — mismo mecanismo de rotación que `.bl-done-arrow` |
| `.bl-active-label` | Label "Activos" |
| `.bl-active-count` | Contador — mono, tabular-nums, siempre visible incluyendo "0" (a diferencia de `.qbacklog-draft-group`, que se omite del DOM en 0 ítems — aquí el header nunca desaparece, mismo criterio que `.qdisc-status-header`) |
| `.bl-active-body` | Cuerpo colapsable — `display:none` bajo `.is-collapsed` |

**Mecanismo de colapso:** unificado con `.bl-done-group`/`.qdisc-status-group`/`.qbacklog-draft-group` — una sola clase `.is-collapsed` en el wrapper, sin clases sueltas togleadas por separado.

**No reutiliza `.bl-done-*` directamente** — clases independientes pese a estilo idéntico, mismo criterio de independencia semántica ya usado entre `.bl-done-*` y `.qbacklog-draft-*` (grupos visualmente equivalentes, significado distinto).

**No incluye:** no toca `.bl-header-unified`/`.bl-zone-body`/`.qbacklog-draft-*`/`.bl-done-*` — el grupo nuevo es un tercer bloque, no reemplaza ninguno de los dos existentes. No se aplica a Q-DISC en este TKT (fuera de scope — Q-DISC ya resuelve sus 3 grupos con `.qdisc-status-group`).

---

## Cambios (mod:159) — TKT1/TKT2 (REQ CAEL-0803-01, design_intent: qbacklog_qdisc_panel_identity): `.bl-panel-identity` — tira de identidad de panel en Q-Backlog y Q-DISC

**Origen:** entregado en la misma tanda de `REQ CAEL-0803-01` que `§Cambios (mod:158)` — `doc_relevance_confirmada.css_ref` no se declaró `"sí"` al entregar TKT1/TKT2, dejando `.bl-panel-identity`/-label/-caption sin entrada pese a estar presentes en `locus-backlog.css` desde mod:135. Gap detectado por Rune al auditar la fusión de dos entregas paralelas de `index.html` (mod:173) — sin este doc adjunto en esa sesión, el markup no podía confirmarse contra CSS real.

**Selector nuevo (`locus-backlog.css` mod:135):**

| Selector | Rol |
|---|---|
| `.bl-panel-identity` | Contenedor de la tira de identidad — primera fila de `.bl-header-unified` en Q-Backlog y Q-DISC, antes de `.stats-bar`. `display:flex; align-items:baseline; gap:var(--space-sm); padding:var(--space-xs) var(--space-md) var(--space-2xs); flex-wrap:wrap` |
| `.bl-panel-identity-label` | Label de sección (ej. "Q-Backlog", "Discoveries") — `font-size:var(--text-sm); font-weight:700; color:var(--text); flex-shrink:0` |
| `.bl-panel-identity-caption` | Caption de alcance (ej. "Product Backlog · sin sprint asignado") — reusa el mismo tratamiento tipográfico que `.qdisc-stats-caption` (`--text-2xs`, uppercase, `--text3` sobre `--surface`) — mismo par de tokens ya en producción sobre el mismo fondo, sin nueva verificación de contraste |

**Separador:** `.bl-header-sep` entre `.bl-panel-identity` y `.stats-bar` — mismo mecanismo ya usado entre `.stats-bar` y `.bl-toolbar` (`§Cambios mod:100`), sin clase nueva.

**No es wrapper sticky propio:** vive dentro de `.bl-header-unified`, que ya es sticky como unidad completa — identidad + stats + toolbar en un solo header sticky, secciones/listas debajo (fuera del sticky), confirmado por founder.

**Consumidores (`index.html` mod:173):** `#qbacklog-header-unified` (TKT1, label "Q-Backlog") y `#qdisc-header-unified` (TKT2, label "Discoveries").

**No incluye:** no toca `.bl-header-unified`/`.stats-bar`/`.bl-toolbar` — el resto de `§Cambios (mod:100)` y anteriores sigue vigente sin modificación.

---

## Cambios (mod:158) — TKT CAEL-0803-02 (REQ CAEL-0803-01): `.mss-content--ingest-wide` — el Panel de Ingesta se expande cuando el Panel de Revisión está vacío

**Origen:** `_Locus-css-ref` no reflejaba la clase nueva sobre `.mss-content` — `§Cambios (mod:134)` documenta `.mss-col--ingest` en su proporción base (`flex:0 0 33.3333%`) pero no el modificador que la expande. `doc_relevance_confirmada.css_ref: "sí"` declarado por Nova al entregar el TKT.

**Selector nuevo (`locus-modals-base.css` mod:23):**

| Selector | Rol |
|---|---|
| `.mss-content--ingest-wide` | Modificador sobre `.mss-content` (no sobre `.mss-col--ingest` directamente) — activo cuando `#merge-diff-overlay` está en `mdiff-overlay--empty` (sin diff que revisar). `.mss-content.mss-content--ingest-wide .mss-col--ingest { flex-basis: 55%; }` — sobreescribe el `33.3333%` base de `§Cambios (mod:134)` mientras el modificador está presente |

**Estado machine — inversa exacta con `.mdiff-overlay--filled`:** las dos clases nunca coexisten sobre sus respectivos nodos — `--ingest-wide` se retira exactamente en los mismos 4 puntos conceptuales donde `#merge-diff-overlay` gana `--filled` (apertura inicial, apertura tras batch, cierre-aplicar, cierre-cancelar/Escape), y se re-agrega en la inversa. Documentado en comentario inline `locus-modals-base.css` L436-443 (Nova) — implementado en `locus-backlog-merge.js` (Rune, mod:83, 3 puntos de código cubriendo los 4 conceptuales, el cierre-cancelar/Escape comparte `teardownMergeDiffPanel()`) y `locus-sesiones.js` (mod:59, apertura inicial vía `_openIngestModal`).

**Consumidor JS:** `shell.querySelector('.mss-content')` — confirmado contra `index.html` que `.mss-content` es hijo único sin `id` de `.mss-box`, no aplica sobre `#modal-split-shell` directamente.

**No incluye:** no toca `.mss-box`/`.mss-col`/`#merge-diff-overlay`/`#merge-diff-header` — el resto de `§Cambios (mod:134)` sigue vigente sin modificación.

---

## Cambios (mod:157) — INC-202608-082 cerrado: `--spacing-xl` inexistente reemplazado por `--space-xl`

**Fix:** `locus-modals-misc.css` L2238, `.clean-project-panel{padding}` — `var(--spacing-xl, 1.5rem)` (fallback silencioso, `--spacing-xl` nunca declarado, computaba 19.5px real con `html{font-size:13px}`) reemplazado por `var(--space-xl)` (24px, ya declarado en `:root` desde mod:16 — ver tabla `§B`). Sin fallback: el token real existe, no lo necesita (`§E` anti-pattern). Mismo fix propuesto en `§Cambios (mod:156)` punto 3 — Fast Track, un solo archivo, sin lógica de negocio.

**mod de archivos reales:** `locus-modals-misc.css` mod:7→8 (Nova).

---

## Cambios (mod:156) — Auditoría de proximidad/separación de módulos: 3 gaps cerrados contra código real

**Origen:** Sesión de auditoría de spacing solicitada por el founder (separación visual entre contenedores/módulos). Antes de auditar superficies nuevas, verificación de que `§Estándar de Spacing & Layout · F. Fase 3` refleja el código real (`Archivo_2.zip`, 2026-08-01) — encontró 3 gaps. Resuelto en sesión bajo Excepción de resolución directa (`__BR-Core` — NO DEJAR DEUDA EN SILENCIO): dueña (Nova) presente en sesión Execution · nivel Patch, sin cambio de comportamiento CSS · sin bifurcación de founder.

1. **Gap de log — Fase 3 no registraba `locus-backlog-item.css` (TKT-202607-220):** El propio archivo (mod:86, comentario de header) documenta que TKT-202607-220 (REQ-202607-086, TKT3) migró 26 valores de padding/gap/margin del bloque IDP (L967-1545) a `--space-*` — pero `§F. Fase 3 — progreso por archivo` solo listaba `locus-layout.css` y `locus-backlog.css`. Fila nueva agregada abajo con las excepciones ya documentadas en el propio comentario de código (10px en 4 pares mixtos, 1px, 5px, 3px, ceros).
2. **Hallazgo fuera de scope — `role` mal declarado en 3 TKTs (destino: Cael):** El comentario de `locus-backlog-item.css` mod:86 señala que TKT-202607-218/219/220 tienen `Role: FS · Rune` en el backlog pese a que los tres son migración pura de tokens CSS (implementados como Nova, `__BR-Execution §3`). No corregible por Nova — el campo `role` del ítem es de Cael. `Acción sugerida: Cael corrige role → "UX · Nova" en los tres TKTs vía type:patch.`
3. **Hallazgo nuevo — `--spacing-xl` referenciado sin declarar (`locus-modals-misc.css` L2238):** `.clean-project-panel{padding: var(--spacing-xl, 1.5rem)}` — `--spacing-xl` no existe en `:root` (solo `--spacing-sm`/`--spacing-md` están declaradas, ver `§A3`). El navegador cae siempre al fallback `1.5rem`, que con `html{font-size:13px}` (A5) computa **19.5px real** — no un valor de escala reconocible, y nadie lo verificó porque visualmente "funciona" (fallback silencioso). Mismo anti-pattern que `§E`: "declarar fallback de `var()` con valor distinto al del token real" — agravado porque el token ni siquiera existe. No es Patch de Nova sin ticket — registrar como candidato a INC Fast Track (`sla_priority: low`, un solo archivo, sin lógica de negocio, role: Nova) con fix propuesto: `var(--spacing-xl, 1.5rem)` → `var(--space-xl)` (24px, ya declarado, coherente con `§B Regla de consolidación`).

**Verificado sin gap — no listado como hallazgo:** `--space-*` en `:root` (`locus-base.css` L62-69, mod:16) coincide exactamente con la tabla `§B`. `html{font-size:var(--text-base)}` = 13px (`§A5`) confirmado. `.header-inner`/`.header-zone`/`#search-global` (TKT-202607-218) y `.stats-row` (TKT-202607-219) coinciden línea por línea con lo documentado en `§F`.

**`mod` de archivos reales:** ninguno — este mod es solo documental, sin tocar `.css`.

---

## Cambios (mod:155) — INC-202608-081: .proy2-panel-wrap sin prefers-reduced-motion

**Fix:** `.proy2-panel-wrap` (transición `grid-template-rows` 0fr→1fr, K-02 panel embebido) no tenía cobertura de `prefers-reduced-motion` — único selector de la familia `proy2-panel-*` con transición sin ese bloque. Agregado `@media (prefers-reduced-motion: reduce) { .proy2-panel-wrap { transition: none; } }` inmediatamente después de la declaración base — mismo patrón ya usado por `.sprint-health-bar` en este archivo.

**mod de archivos reales:** `locus-proyectos.css` mod:20→21 (Nova).

---

## Cambios (mod:154) — INC de causa raíz: escala --space-* nunca declarada en :root · TKT-202607-219 (A7 cerrado)

**INC — bloqueante, detectado por Nova al iniciar TKT-202607-219:** `locus-base.css` solo declaraba `--spacing-sm`/`--spacing-md` — la escala `--space-3xs`…`--space-2xl` de `§Estándar de Spacing & Layout` era únicamente estándar propuesto (Fase 2, papel), nunca custom property real. **TKT-202607-218 (ya liberado a producción) usó `var(--space-md)`/`var(--space-sm)`/`var(--space-2xs)`/`var(--space-3xs)` sin que existieran — declaraciones inválidas, spacing real roto en header/tabs.** Fix de causa raíz aplicado en `locus-base.css` (mod:16): las 8 custom properties de la tabla `§B` declaradas con los valores exactos ya documentados — coexisten con `--spacing-sm`/`--spacing-md`/`--subtab-gutter`/`--gutter-shell` sin reemplazarlos (`Regla de consolidación`, sin cambio). **Efecto retroactivo verificado:** `.bl-toolbar-divider` (`locus-backlog.css`, `T-202606-100`, anterior a esta sesión) también consumía `var(--space-sm)` sin que existiera — mismo bug, origen distinto, reparado por el mismo fix sin tocar ese selector.

TKT-202607-218 queda retroactivamente válido — sin cambio de código en `locus-layout.css`/`locus-sesiones.css`, el fix vive enteramente en `locus-base.css`.

**A7 cerrado (TKT-202607-219, `locus-backlog.css` mod:134):** `.stats-row{gap}` `6px` → `var(--space-sm)` (8px). `.stats-row--compact` (`locus-backlog.css` L5566) y `.sps-stats-block` (`locus-sprint.css` L3339) ya estaban en `8px` hardcoded — quedan como fuente canónica documentada, sin cambio de código (no forman parte del AC de este TKT).

| Token | Valor | Estado |
|---|---|---|
| `--space-3xs` | 2px | declarado, sin consumidor nuevo en este TKT |
| `--space-2xs` | 4px | consumido por `locus-layout.css` (TKT-202607-218) |
| `--space-xs` | 6px | declarado, sin consumidor activo — ningún selector migrado usa este peldaño todavía |
| `--space-sm` | 8px | consumido por `locus-layout.css` (TKT-202607-218) + `locus-backlog.css` `.stats-row` (TKT-202607-219) + `.bl-toolbar-divider` (retroactivo) |
| `--space-md` | 12px | consumido por `locus-layout.css` (TKT-202607-218) |
| `--space-lg` | 16px | declarado, sin consumidor nuevo en este TKT |
| `--space-xl` | 24px | declarado, sin consumidor nuevo en este TKT |
| `--space-2xl` | 32px | declarado — pendiente de la DISC de A5 antes de asignarle consumidor |

## Cambios (mod:153) — Hallazgo de CSS Purity en TKT-202607-218, resuelto en sesión

`locus-layout.css` (mod:27) y `locus-sesiones.css` (mod:46) fueron entregados con `autor:Rune` — viola `__BR-Execution §3` (Nova es la única rol que escribe `.css`, sin excepción). Detectado por Finn en auditoría del TKT antes de avalar `done`. A diferencia del hallazgo histórico ya registrado para 3 archivos (`§Cambios` L1371, sin resolver en su momento), este se resuelve en la misma sesión bajo Excepción de resolución directa (`__BR-Core` — NO DEJAR DEUDA EN SILENCIO): dueño (Nova) presente en sesión Execution · nivel Patch, sin cambio de comportamiento CSS · sin bifurcación de founder. Nova revisó el contenido verificado por Finn (AC1/AC2/AC3 de TKT-202607-218) y re-entregó ambos archivos: `locus-layout.css` mod:27→28, `locus-sesiones.css` mod:46→47, `autor:Nova` en ambos. Sin cambios de contenido CSS — solo re-atribución tras revisión real.

## Cambios (mod:152) — TKT-202607-218 (Fase 3 · primera aplicación real del Estándar de Spacing & Layout)
Primer TKT de Fase 3 sobre `locus-layout.css`/`locus-sesiones.css`. Ver entrada nueva `§Estándar de Spacing & Layout · F. Fase 3 — progreso por archivo` para el detalle de qué migró y qué quedó como excepción documentada. Cierra A6 (fallback `--header-h` corregido). No cierra A5 — sigue pendiente de la DISC de diseño.

## Cambios (mod:151) — TKT1/TKT2 (REQ CAEL-0731-01): familia `.badge-status-*` documentada por primera vez + `.badge-status-orphaned` unificado a ámbar

**Reaplicado sobre la base correcta (mod:150 — corrección de A5):** este mod se había aplicado antes sobre una copia obsoleta que no incluía la corrección de A5 de arriba; esa copia quedó descartada. El contenido de fondo (badge-status-*) es el mismo, ahora reaplicado sin pisar la corrección de A5.

- **Origen:** Gap de especificación — `statusClass()`/`statusLabel()` (`locus-backlog-core.js`) no tenían case para `status: 'orphaned'` (DISC-202607-089, promovida). Al implementar, se detectó que `.badge-status-orphaned` **ya existía** en `locus-backlog.css` (B-202606-095) con tratamiento gris neutro (`--surface2`/`--border2`/`--text3`) — sin caller en JS, CSS muerto desde su alta. Kill_criteria del REQ evaluado: la mitad "en-revision usa color distinto al ámbar documentado" se cumple (`.badge-status-en-revision` usa `--c-high-*`, no `--amber`); la mitad "rompe jerarquía visual vigente en producción" no aplica en sentido estricto (el selector no se renderizaba en ningún flujo activo). Founder confirmó Opción A — unificar a ámbar.
- **`.badge-status-orphaned` (`locus-backlog.css`):** reemplaza el bloque gris por el mismo par que `.spi-item-status--orphaned`/`.staleness-pill.staleness--orphaned` — `background: color-mix(in srgb, var(--amber) 10%, transparent)`, `border-color: color-mix(in srgb, var(--amber) 28%, transparent)`, `color: var(--amber-text)`.
- **`statusClass()`/`statusLabel()` (`locus-backlog-core.js`):** agregan entrada `'orphaned'` → `'badge-status-orphaned'` / `'Huérfano'`. Resto de entradas sin cambio.
- **Gap de documentación cerrado:** la familia `.badge-status-*` (Vista Lista/Kanban de Backlog — consumida por `statusClass()`) nunca estuvo documentada en este doc, a diferencia de `.spi-item-status` (Tab Sprint, documentada en `§Cambios mod:106`). Sección nueva agregada — ver `§Badges de status de ítem — familia .badge-status-* (Vista Lista / Kanban)`.
- **Hallazgo fuera de scope (no resuelto en este mod):** `.badge-status-en-progreso` y `.badge-status-bloqueado` también están declaradas en `locus-backlog.css` sin ningún caller en JS confirmado por grep — mismo patrón de dead code que `.badge-status-orphaned` tenía antes de este mod. Registrado como DISC en `Q-DISC` — no bloquea este REQ.
- **`_Locus-ui-Inventory` — verificado contra el archivo real (mod:46), adjunto en esta sesión:** `.badge-status-*` es una familia de clases dinámicas sin ID propio — el inventario indexa IDs (`#qdisc-search-input`, `#tab-btn-proyectos`, etc.), no familias de clase por status. Mismo criterio ya establecido para `.spi-item-status`, tampoco presente ahí. La declaración inicial de `doc_relevance.ui_inventory: sí` en Fase 2 fue un gap de especificación de Cael — confirmado sin entrada, sin `doc_update` sobre ese archivo.
- **`mod` de archivos reales:** `locus-backlog.css` mod:132→133 (Nova) · `locus-backlog-core.js` mod:139→140 (Rune).

---

## Cambios (mod:150) — Corrección de A5 antes de especificación: `2rem` computa 26px, no 32px

Al especificar los TKTs de Fase 3, Cael detectó que `html { font-size: var(--text-base) }` (`locus-base.css` L451) = 13px — no el default de 16px del navegador. El hallazgo A5 original (mod:149) asumía que `2rem` de los shells equivalía a 32px y proponía unificarlo a `--space-2xl`. Corregido: `2rem` computa **26px real**. Forzar `--space-2xl` habría sido una regresión visual de +23%, no un fix. La unificación de A5 se baja a DISC para decisión de diseño explícita — no entra como TKT en el REQ de Fase 3. Ver tabla A5 y tabla C actualizadas abajo.

---

## Cambios (mod:149) — Auditoría de spacing/gutters/alineación (Fase 1) + Estándar propuesto (Fase 2)

**Origen:** Founder solicita auditoría total de márgenes, separaciones, alineados y gutters de Locus para establecer criterios documentados y aplicarlos. Esta entrada cubre Fase 1 (auditoría, sin tocar código) y Fase 2 (estándar documentado, ver sección nueva `§Estándar de Spacing & Layout`). Fase 3 (aplicación al codebase) requiere Protocolo de Especificación de Cael — no se ejecuta en esta sesión, ver `Hallazgo fuera de scope` en el CHECKPOINT de esta sesión.

**Método:** grep cuantitativo contra los 22 archivos `.css` reales del repo (`Archivo.zip`, sesión 2026-07-31) — no solo lectura de este doc. Hallazgos completos en la sección nueva más abajo.

**Resumen del hallazgo central:** El sistema de tokens de spacing existe (`--spacing-sm`/`--spacing-md` en `locus-base.css`) pero está prácticamente sin adoptar — 2 usos reales contra 2.465 declaraciones de `padding`/`margin`/`gap` en px, la gran mayoría con valores sueltos sin relación a una escala. Esto es distinto del sistema de radios y tipografía, que sí tienen escala completa y adoptada. Ver detalle en `§Estándar de Spacing & Layout`.

---

## Cambios (mod:148) — TKT-202607-213 (REQ-202607-083): AC4 cerrado — retiro completo de clases proj-panel/proj-modal

**Cierra el pendiente declarado en `§Cambios (mod:147)`.** Con `locus-analytics.css`, `locus-layout.css`, `locus-modals-base.css` y `locus-sesiones.css` adjuntos en esta sesión, se retiraron las clases exclusivas restantes del overlay proj-panel/proj-modal:

| Archivo | Retirado | mod resultante |
|---|---|---|
| `locus-analytics.css` | Bloque exclusivo `.proj-panel-overlay`/`.proj-panel-overlay.open`/`.proj-panel`/`.proj-panel-header`(+`button`/`:hover`/`:focus-visible`)/`.proj-panel-title`/`.proj-panel-body`/`.proj-panel-hint`/`.proj-panel-actions` + familia `.proj-row`/`.proj-row:hover`/`.proj-row.active`/`.proj-row-dot`/`.proj-row-icon`/`.proj-row-name`/`.proj-row-notes`/`.proj-row-count`/`.proj-row-edit`(+`:hover`) — confirmado exclusivo por grep en los 21 archivos CSS del repo antes de retirar (`.proj-all-row`, inmediatamente después en el archivo, NO se tocó — nombre distinto, sin verificar como parte de este overlay) | mod:19 |
| `locus-layout.css` | `.proj-modal-overlay` retirado del comma-list compartido de light-theme backdrop-blur (Fix #1 macOS) — resto de la lista (`.modal-overlay`, `.gconfirm-overlay`, `.popup-overlay`, `.item-viz-overlay`, etc.) intacto | mod:26 |
| `locus-modals-base.css` | Selector `.proj-modal-*` retirado de 11 comma-lists compartidos: `.overlay.closing` (normal + reduced-motion), `.overlay.closing .modal` (normal + reduced-motion), `.modal-actions`/`button`/`button:active`/`.btn-ghost`/`.btn-ghost:hover`/`.btn-primary`/`.btn-primary:hover`/`.btn-primary:focus-visible`/`.btn-ghost:focus-visible`, y `.modal`/reduced-motion. En cada caso donde `.proj-modal-footer`/`.proj-modal` era el último ítem de la lista (con la llave de apertura en la misma línea), la llave se reubicó al ítem anterior — sin este cuidado, un `sed` de borrado directo de línea rompe la sintaxis (detectado y corregido en la misma sesión antes de entregar). `#proj-modal-close-btn` no aplica — ya migrado a `.modal-close` genérico, no tenía entrada propia que retirar aquí | mod:22 |
| `locus-sesiones.css` | Bloque exclusivo `.proj-modal-overlay`/`.proj-modal-overlay.open`/`.proj-modal`/`.proj-modal-header`/`.proj-modal-title`/`.proj-modal-body`/`.proj-modal-footer` retirado. `.proj-form*` (línea siguiente en el archivo) **NO se tocó** — confirmado compartido con el form inline "Nuevo proyecto" de Tab Proyectos (`.proj-form-actions`/`.proj-form-btn-sm`/`.proj-form-existing-label`/`.proj-form-label-hint` viven también en `locus-proyectos.css`, activos fuera del modal retirado) | mod:45 |
| `locus-proyectos.css` | Sin retiro de código nuevo — comentario de cabecera (mod:17) actualizado para reflejar que AC4 ya no tiene pendiente | mod:18 |

**Regla de verificación aplicada — no confundir namespace compartido con exclusivo:** antes de retirar cualquier bloque, se corrió `grep` de cada clase candidata contra los 21 archivos CSS reales del proyecto. Dos casos evitaron un retiro incorrecto: `.proj-form*` (compartido con Tab Proyectos, no se tocó) y la verificación de que `.proj-row` (clase exacta) no colisiona con `.hoy-mini-proj-row`/`.sess-proj-row` (substring match falso positivo en `locus-sesiones.css`, clases no relacionadas).

**AC4 cerrado.** Sin selectores `proj-panel`/`proj-modal` remanentes en ningún `.css` del proyecto (verificado por grep post-edición) — excepto una mención en comentario de documentación en `locus-modals-misc.css:1548` (no es selector, no bloquea el AC, no se tocó — fuera de scope de este TKT).

---

## Cambios (mod:147) — TKT-202607-213 (REQ-202607-083): retiro parcial de clases proj-panel — locus-proyectos.css

**Origen:** REQ-202607-083 retira el proj-panel/proj-modal overlay (Rune migró los 3 call sites JS a `es-switch-tab` en sesión previa, ver `locus-sesiones.js`/`locus-backlog-render.js`/`locus-sesiones-capture.js`). AC4 exige retirar las clases CSS exclusivas del overlay.

**Cerrado en esta sesión — `locus-proyectos.css` mod:17:** `.proj-panel-empty` y `.proj-panel-btn-sm` retirados — únicos selectores exclusivos del overlay que vivían en este archivo (confirmado por grep, sin otro consumidor).

**Abierto — AC4 no está completo.** Vía `_Locus-ui-Inventory` (filas 22-24, 60-62, 601), el resto de las clases exclusivas vive en archivos no adjuntos en esta sesión:

| Selector | Archivo(s) declarados en ui-Inventory |
|---|---|
| `#proj-panel-overlay` / `#proj-panel-body` / `#proj-panel-close-btn` (+ `.proj-panel-header button` agregado en TKT-[tmp:proj-panel-close-fix]) | `locus-analytics.css` |
| `.proj-modal-overlay` (`#proj-modal-overlay`) | `locus-layout.css`, `locus-modals-base.css`, `locus-sesiones.css` |
| `#proj-modal-close-btn` | `locus-modals-base.css` — ya migrado a `.modal-close` genérico (shell compartido), **no retirar** — lo consumen otros modales |

**Regla de retiro — no confundir clase exclusiva con clase de shell compartido:** `.modal-close`/`.modal-overlay`/`.modal-actions` (shell genérico de `locus-modals-base.css`) no se tocan aunque `#proj-modal-*` los use — los comparten `gconfirm-overlay`, `pend-overlay`, `mg-overlay`, `qc-overlay`, etc. Solo se retira lo que es exclusivo del namespace `proj-panel`/`proj-modal` (ej. `.proj-modal-overlay` como clase propia declarada en `locus-layout.css`/`locus-sesiones.css`, no el shell que consume).

**Pendiente:** adjuntar `locus-analytics.css`, `locus-layout.css`, `locus-modals-base.css`, `locus-sesiones.css` (+ `index.html` para confirmar si el markup `#proj-panel-overlay`/`#proj-modal-overlay` ya fue retirado o sigue vivo) antes de cerrar AC4 completo.

---

## Cambios (mod:146) — DOC-UPDATE: familia `mdiff-status-chip*` / `mdiff-transition*` / `mdiff-field-patch*` / `mdiff-zone-*` documentada (Zona Identidad, DISC cerrada)

**Origen:** `locus-backlog-item.css` mod:85 (TKT-202607-204, REQ-202607-079) introdujo estas clases sin entrada correspondiente en este Doc Ref — gap detectado cuando Rune requirió el contrato exacto para implementar `TKT1+TKT2` (REQ ref_id CAEL-0731-01, wiring de Zona Identidad en `locus-backlog-merge.js` mod:82). DISC abierta en esa sesión, cerrada aquí.

**Tokens y clases — resumen de contrato (fuente: `locus-backlog-item.css` mod:85):**

| Clase | Uso |
|---|---|
| `.mdiff-status-chip--avalado` | Chip de estado sobre un `type:patch` cuando `changes` incluye `field:"draft"` con `to===false` — icono `ti-shield-check` |
| `.mdiff-status-chip--borrador` | Mismo chip, cuando `draft` no llega en `false` (incluye ausencia del campo) — sin icono de aval |
| `.mdiff-transition` | Pill-flecha-pill para `field==='status'` dentro de un patch — reemplaza el chip genérico de campo cuando el cambio es de status |
| `.mdiff-field-patch` | Ícono lápiz + texto plano, para cualquier campo de un patch que no sea `status` ni `draft` |
| `.mdiff-zone-card` / `.mdiff-zone-card--retroceso` | Contenedor de card en la Zona Identidad — el modificador `--retroceso` usa tokens `--c-high-*`, **distinto** de `.mdiff-card--retroceso` (family ámbar, ya existente para `diff.retroceso`/`_retrocedoRow` — casos de origen distinto: diff normal vs `type:patch`, coexisten sin sustitución) |
| `.mdiff-zone-chevron` | Botón 20×20, `aria-expanded`, foco visible — alterna visibilidad del drawer asociado vía `classList` (`is-hidden`), sin regenerar HTML |
| `.mdiff-zone-detail` | Contenedor del drawer — oculto por default (`is-hidden`), revela el detalle ya computado por `_transitionOrFieldPatchHtml` |
| `.mdiff-retroceso-flag` / `.mdiff-retroceso-context` | Etiqueta + contexto (`from → to`) cuando se detecta retroceso de status dentro de un patch |

**Consumidor confirmado:** `locus-backlog-merge.js` mod:82 (`_statusChipHtml`, `_transitionOrFieldPatchHtml`, `_buildPatchCard`, `_mdiffToggleZone`) — implementación verificada contra este contrato en sesión de Rune.

**`mod` de archivos reales:** `locus-backlog-item.css` mod:85 (origen, ya entregado — sin cambio en esta sesión) · `locus-backlog-merge.js` mod:82 (consumidor, ya entregado).

---

## Cambios (mod:145) — TKT1 (REQ ref_id CAEL-0731-04): `#tab-proyectos-inner` se une a `.session-subpanel` — sin CSS nueva

**Origen:** REQ acotado por el founder a Dashboard+Map+Context de Tab Proyectos — antes `#tab-proyectos-inner` se renderizaba siempre, fuera del mecanismo de visibilidad-por-clase que ya cubre htmlmap/context/docupdates/contratos.

**Decisión de Nova (sesión de diseño del TKT):** reusar la regla ya extendida a `#tab-proyectos .session-subpanel` / `.session-subpanel.active` (`locus-proyectos.css`, TKT-202607-208) en vez de introducir CSS nueva o un mecanismo de visibilidad ad-hoc — mismo patrón arquitectónico ya vigente para el resto de sub-tabs de `#tab-proyectos`. `#tab-proyectos-inner` conserva su clase original `.tab-proyectos-content` además de ganar `session-subpanel active` — ambas clases coexisten en el mismo elemento.

**`locus-proyectos.css` — sin modificación.** No estuvo adjunto en la sesión de diseño de este TKT; la decisión se apoya en el hallazgo de Nova de una sesión anterior de esta misma tanda (confirmó la regla contra el archivo real antes de emitir el entregable). Este doc no cita línea exacta de `locus-proyectos.css` para esta regla — pendiente de que una sesión con el archivo adjunto la referencie con precisión si se audita este doc a futuro.

**`mod` de archivos reales:** `index.html` mod:168 · `locus-ui-shell.js` mod:65. `locus-proyectos.css` sin cambio.

---

## Cambios (mod:144) — Cierre de `Hallazgo 2` (`§Cambios mod:142`): `.idp-tl-label--success` migrado a `--green-text` (`DISC-202607-068` promovida y cerrada)

**Origen:** `DISC-202607-068` — la DISC que `§Cambios mod:142` registró para este hallazgo — promovida a `TKT-202607-194` (parent `REQ-202607-072`) y resuelta en la misma sesión. `locus-backlog-item.css` mod:84: `.idp-tl-label--success` pasa de `color: var(--green)` a `color: var(--green-text)` — mismo token ya verificado WCAG AA en `§Cambios (mod:95)` y reutilizado sin cambio en 33+ consumidores de este mismo archivo, sin necesidad de nueva medición. `.idp-tl-dot--success` (elemento gráfico, umbral 3:1, override `#16914c` en light) sin cambio — el gap era exclusivo de texto. Grep de cierre confirma 0 ocurrencias de `color: var(--green)` fuera de elementos gráficos en el archivo.

**Cambio en este doc:** nota de `§Item Detail Panel — familia idp-*` ("Gap de contraste — `.idp-tl-label--success` en light theme") actualizada de "pendiente de verificación" a resuelto — ver entrada corregida abajo, cerca de la tabla `--_type-color`.

**`mod` de archivos reales:** `locus-backlog-item.css` mod:84 (Nova).

---

## Cambios (mod:143) — Cierre de `Hallazgo 1` (`§Cambios mod:142`): `.idp-type-chip.idp-type-KE`/`.idp-ac-dot.idp-type-KE` retirados (`DISC-202607-067` promovida y cerrada)

**Origen:** `DISC-202607-067` — la DISC que `§Cambios mod:142` registró para este hallazgo — promovida a TKT (`ref_id CAEL-0730-01`) y resuelta en la misma sesión. `locus-backlog-item.css` mod:82 (retiro de las 3 reglas huérfanas de la familia `KE`) + mod:83 (limpieza de terminología residual "INC/PRB/KE/CHG"→"INC/PRB/CHG" en 3 comentarios no relacionados con estos selectores). Grep de cierre confirma cero reglas CSS con `KE` en el archivo — solo permanece en el header, como registro histórico del propio retiro.

**Cambio en este doc:** fila `KE` retirada de `§Colores por tipo` (tabla de `--_type-color` para `.idp-type-chip`/`.idp-ac-dot`, `§Item Detail Panel — familia idp-*`) — el selector que documentaba ya no existe. Sin cambio en el resto de la tabla (`INC`/`TKT`/`REQ`/`DISC`/`PRB`/`CHG` sin tocar).

**No confundir con `.qinc-type-badge--ke`** (`§Panel Q-INC — familia qinc-*`, `§Cambios mod:127/128`) — familia distinta, no retirada, sigue alcanzable por el bug de clasificación documentado ahí. Este mod no la toca.

**`mod` de archivos reales:** `locus-backlog-item.css` mod:83 (Nova).

---

## Cambios (mod:142) — DOC-UPDATE: sección `Item Detail Panel — familia idp-*` agregada (`DISC-202607-064` cerrado)

**Origen:** `locus-backlog-item.css` real (mod:81) adjuntado por el founder para desbloquear `DISC-202607-064` — el componente con más `mod` acumulado del sistema no tenía sección propia en este doc, solo la fila 12 de `§Arquitectura de módulos CSS`. Ver sección nueva `§Item Detail Panel — familia idp-*` (abajo, antes de `§Deprecated`).

**Grounding:** 79 selectores `.idp-*` únicos extraídos por grep contra el archivo real — agrupados por zona funcional (header/type chip, meta grid, sections, AC, timeline, actions bar, origin chips), no transcritos regla por regla. Origen de cada bloque referenciado (`R-202604-015`, `R-202604-015 Sesión 2`, `T-202604-307`, `R-202605-004`, fix directo mod:55 de `locus-backlog-item.css`).

**Dos hallazgos fuera de scope de `DISC-202607-064` detectados al leer el archivo — registrados, no corregidos en esta entrada:**
1. `.idp-type-chip.idp-type-KE` / `.idp-ac-dot.idp-type-KE` — código muerto. `KE` fue fusionado a `PRB.root_cause_confirmed` desde `infra_version 51` (`__BR-Core §6`) y ya no es un tipo alcanzable en ningún generador de UI real (`locus-session-parse.js` mod:136, `locus-incidents-item.js` mod:3 ya limpiados en `REQ CAEL-0724-01` — `_pp-context §7`). Esta regla CSS no fue tocada en esa limpieza.
2. `.idp-tl-label--success` sin override de contraste en light theme — `var(--green)` crudo como color de **texto** (umbral 4.5:1); el override `#16914c` existente en `.idp-tl-dot--success` es para elemento gráfico (umbral 3:1) y el propio archivo real lo declara explícitamente como gap no corregido (`locus-backlog-item.css` L1347-1350, comentario de Nova). Mismo patrón de familia ya registrado para `.ct-pill-req/tkt/disc/inc` (`§Colores declarados — .ct-pill-*`).

Ambos registrados como DISC en `Q-DISC` en el CHECKPOINT de esta sesión — no se resuelven aquí (fuera del alcance de `DISC-202607-064`, que era exclusivamente el gap de documentación).

**`mod` de archivos reales:** ninguno — sección puramente documental, sin cambio de código.

---

## Cambios (mod:141) — DOC-UPDATE: dos hallazgos de la auditoría Doc Refs UX vs código real (`DISC-202607-062`, `DISC-202607-065`) cerrados

**Origen:** Auditoría de Rune (grep estructural de clases documentadas vs. código real de los 22 `.css` + `index.html`) detectó dos desalineaciones entre este doc y el código real, registradas como DISC y confirmadas con código real en `_PP-backlog-v1.16.0.md`.

**1 — `DISC-202607-062` · `.qdisc-stats-block`/`.qdisc-stat-*` retirado, este doc lo documentaba como vigente:** Ver marca de retiro agregada en `§Panel Q-DISC — Bloque de estadísticas` (abajo). Código real: `.qdisc-stats-block`/`.qdisc-proportion-bar` retirados de `locus-backlog.css` bajo comentario `/* REQ homologación visual Q-Backlog/Q-DISC — RETIRADO: .qdisc-stats-block/.qdisc-stat-cell... */` (`REQ-202607-059`, `PP-S-18`, cierre 2026-07-28) — reemplazados por `.bl-header-unified`/`.stats-row--compact`, mismo patrón ya vigente en Backlog list e Histórico. `_renderQDiscProportionBar()` (JS) queda comentada, no borrada — `_pp-context §5`.

**2 — `DISC-202607-065` · `.cmd-palette-*` huérfano en `locus-modals-misc.css`, sin marcar en este doc:** 9 reglas sin consumidor desde que Command Palette fue retirado del JS (`locus-ui-shell.js` mod:44, 2026-07-13 — `_pp-context §5`). `_Locus-ux-ref` (mod:19) y `_Locus-ui-Inventory` (mod:25) ya documentaban correctamente la baja a nivel de HTML/JS/ID — este doc nunca reflejó la baja a nivel de CSS, mismo patrón de doc-lag ya visto en `§Cambios mod:94/mod:102/mod:103/mod:140`. Fila 19 de `§Arquitectura de módulos CSS` corregida (abajo). Regla CSS no eliminada en esta entrada — marcada huérfana, retiro físico queda para TKT de limpieza si Cael lo prioriza (mismo criterio que `.qinc-type-badge--ke`, `§Cambios mod:128`).

**`mod` de archivos reales:** ninguno — ambos hallazgos son de documentación, sin cambio de código en esta entrada.

---

## Cambios (mod:140) — DOC-UPDATE: entrada retroactiva — `.stat-compact-item--primary`/`.stat-compact-n--primary` ya implementadas (TKT-202607-180 cerrado sin cambio de código)

**Origen:** TKT-202607-180 (Effort 1, sprint PP-S-19) pedía agregar CSS para `.stat-compact-item--primary`/`.stat-compact-n--primary` — verificado contra `locus-backlog.css` real (mod:131) adjunto en esta sesión: ambos selectores **ya existen** (L5593-5601), agregados bajo el comentario `TKT1 REQ-058-fix (DISC-202607-058)`. Este doc nunca registró esa entrada — mismo patrón de doc-lag ya visto en `§Cambios mod:94/mod:102/mod:103` (fix aplicado directamente sobre el archivo real sin changelog correspondiente en este Doc Ref).

**AC de TKT-202607-180 verificados contra código existente — sin gap:**
- `.stat-compact-item--primary .stat-compact-l` → `color: var(--accent-text); font-weight: 600` — tratamiento diferenciado sobre la etiqueta del chip.
- `.stat-compact-n--primary` → `color: var(--accent-text); font-weight: 700` — mismo tratamiento sobre el número.
- Contraste: `--accent-text` ya verificado WCAG AA en `§Cambios mod:96` — dark alias de `--accent` (11:1) · light `#45700f` (5.53:1 vs `--surface2`, 5.11:1 vs `--surface`). El contenedor real (`.bl-header-unified`, fondo `background: var(--surface)`) cae dentro de los fondos ya verificados — ambas variantes superan 4.5:1 sin necesidad de nueva medición.

**Resolución:** Ningún archivo `.css` se modifica — el TKT se cierra por verificación, no por implementación. `Excepción de resolución directa` (`__BR-Core` NO DEJAR DEUDA EN SILENCIO): dueña de doc (Nova) presente, nivel Patch, sin bifurcación de founder.

**`mod` de archivos reales:** ninguno — `locus-backlog.css` permanece en mod:131, sin cambio.

## Cambios (mod:138) — Patrón colapsable `.qinc-section-*` documentado (TKT-202607-158) + corrección de token `:focus-visible`

**Origen:** DOC-UPDATE de Nova emitido en el CHECKPOINT de entrega de TKT-202607-158 (estados collapsed/expanded de `.qinc-section` en `locus-incidents.css`), aplicado ahora que `_Locus-css-ref` está disponible en sesión. Ver entrada completa en `§Panel Q-INC — familia qinc-*`, nueva subsección "Secciones colapsables".

**Resumen del cambio:** (1) primera documentación del patrón `.qinc-section-header--collapsed`/`.qinc-section-chevron`/`.qinc-section-body--collapsed`, mismo mecanismo que `.qdisc-status-group`/`.qbacklog-draft-group` ya documentados; (2) corrección de `:focus-visible` — el archivo entregado usa `var(--border)` (supuesto declarado por Nova sin este doc adjunto), el token real del sistema es `var(--accent)` — Rune corrige antes de que Finn audite; (3) nota de no-conflicto con E-13 (`_Locus-ux-ref`), que documenta un elemento distinto (`.qinc-item-header`, header de card, no de sección).

## Cambios (mod:137) — `.breadcrumb-seg--proj` escalado a tratamiento de header-title, aplicado inline por instrucción directa del founder

**Origen:** El founder revisó el resultado de mod:135/136 en producción (screenshot) y pidió explícitamente tratamiento de "header title principal" + ícono de carpeta — fuera del alcance original de `TKT-202607-149` (que deliberadamente mantenía `.breadcrumb-seg--proj` en Nivel 3/14px, sin escalar a A-08). Instrucción: "Aplícalo inline" — máxima autoridad en la jerarquía (`__BR-Core §3`), aplicado sin pasar por Fase 1-4 de Cael ni Fase 5 de Finn.

**Discrepancia declarada — Protocolo de Especificación no ejecutado:** Este cambio se aplica directamente sobre `locus-layout.css` (mod:24 → mod:25) sin REQ/TKT formal, por instrucción explícita del founder que prioriza velocidad sobre el ciclo completo de especificación. `__BR-Core` HARD RULE "PROTOCOLO DE ESPECIFICACIÓN OBLIGATORIO" normalmente exige que todo cambio pase por Cael antes de Rune/Nova — la jerarquía de autoridad (`§3`) coloca la instrucción directa del founder por encima de las HARD RULES. Sin ítem de backlog abierto para este cambio — trazabilidad vive únicamente en este DOC-UPDATE y en el header de identidad del archivo.

**Fix aplicado (`locus-layout.css` mod:25):**

| Selector | Cambio | Motivo |
|---|---|---|
| `.breadcrumb-seg--proj` | `font-size: var(--text-md)` (14px) → `var(--text-lg)` (16px) — Nivel 2 A-08 (Modal-section title) | Tratamiento de header-title pedido por el founder |
| `.breadcrumb-seg--proj` | `font-weight: 500` → `600` | Mismo motivo — techo de peso ya no es 500 en este selector, se aparta del límite documentado en mod:135 (esa restricción de "solo 400/500" aplicaba al AC original de `TKT-202607-149`, ya superado por esta instrucción) |
| `.breadcrumb-seg--proj` | `color: var(--text2)` → `var(--text)` | Texto primario, consistente con mayor prominencia |
| `.breadcrumb-seg--proj` | `max-width: 140px` → `160px` · `padding-left: 18px` agregado | Espacio para el ícono nuevo sin comprimir más el texto truncado |
| `.breadcrumb-seg--proj::before` (nuevo) | `content: '📁'` — mismo patrón que `::after` (chevron `⌄`) ya existente: glifo Unicode vía `content`, sin SVG nuevo, sin tocar HTML/JS | Ícono de carpeta pedido por el founder — se resuelve 100% en CSS, no requiere `<svg>` inline como el resto de íconos del sistema porque el elemento ya usa el patrón `content: '⌄'` para el chevron |

**Sin cambio:** `:hover` (`--accent-text`/`--accent-dim`, WCAG-safe) y `:focus-visible` (regla global) se conservan — no estaban en el pedido del founder. Estado `:disabled` hereda el ícono nuevo (sin proyecto activo sigue mostrando la carpeta) — solo pierde chevron y `padding-right`, sin cambio en esta sesión.

**Contraste:** `--text` sobre `--surface`/`--surface2`/`--surface3` ya está validado WCAG AA en todo el sistema — sin verificación nueva necesaria. El glifo `📁` no es texto renderizado por el navegador via color CSS (emoji con paleta propia), por lo que no aplica verificación de contraste de color de texto.

**Pendiente:** El founder verifica en app antes de considerar esto cerrado — sin sesión de QA de Finn. Si el founder decide que el resultado visual no es el esperado, es una iteración directa sobre este mismo mod, no una devolución de gap de especificación (no hubo especificación formal que auditar).

## Cambios (mod:136) — Corrección de mod:135: `#breadcrumb-proj` no existe — selector real `.breadcrumb-seg--proj`, ya implementado

**Origen:** `locus-layout.css` real (no adjunto cuando se emitió mod:135) confirma que el proyecto en el header es `.breadcrumb-seg--proj` (clase, `L452-494`) — sin `id="breadcrumb-proj"` en ninguna regla CSS existente. La afirmación de mod:135 ("Selector confirmado contra `index.html` real, línea 294") no se pudo verificar contra `locus-layout.css` en esa sesión y resultó incompatible con el archivo real una vez adjunto.

**Riesgo evitado — anti-pattern de contraste que el propio doc ya prohíbe:** mod:135 proponía `#breadcrumb-proj:hover { color: var(--accent) }` como regla nueva. De existir el id en el HTML, un selector de id (especificidad 1,0,0) habría ganado sobre `.breadcrumb-seg--proj:not(:disabled):hover` (clase, especificidad 0,2,0 aprox.) ya existente — que usa `color: var(--accent-text)` + `background: var(--accent-dim)`, el par WCAG-safe documentado en `§Tokens de color utilitarios`. El resultado habría sido texto `--accent` crudo sobre fondo `--accent-dim` — 2.32:1 en light, el mismo gap que motivó crear `--accent-text` (ver entrada de `--accent-text` en `§Tokens de color utilitarios`). Se descarta la regla de id — el hover/foco ya existentes en `.breadcrumb-seg--proj` se conservan sin cambio.

**Fix real aplicado (Rune integra, mismo turno, `locus-layout.css` mod:24):**

| Selector | Cambio | AC que cierra |
|---|---|---|
| `.breadcrumb-seg--proj` | `font-size: 13px` (hardcoded) → `font-size: var(--text-md)` (14px) | AC-1 — prominencia. `font-weight: 500` ya estaba en el tope permitido (400/500), sin cambio |
| `.breadcrumb-seg` (base compartida por los 3 segmentos) | `transition: color 0.15s var(--ease-out)` (hardcoded) → `transition: var(--trans-color)` | AC-2 — mismo valor efectivo, ahora vía token de `§Velocidades` en vez de literal |

**Sin cambio — ya satisfechos por código existente, no requieren CSS nueva:**
- **AC-2 (hover):** `.breadcrumb-seg--proj:not(:disabled):hover` ya declara `color: var(--accent-text)` + `background: var(--accent-dim)` — sin tocar.
- **AC-3 (foco visible):** la regla global `:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; border-radius: var(--radius-sm); }` (`locus-layout.css` ~L744) ya cubre el botón sin override — mismo tratamiento que el resto de controles del header.
- **AC-4 (contraste, sin `--blue`/`--red`):** `color: var(--text2)` en reposo — no toca ninguno de los dos tokens señalados por el AC como gap conocido.

**Corrección de la entrada de patrón (`#### #breadcrumb-proj`, más abajo en este doc):** reemplazada por `.breadcrumb-seg--proj` — ver entrada actualizada.

**Alcance:** el cambio de `transition` en `.breadcrumb-seg` es compartido por `.breadcrumb-seg--sprint`/`--item` — mismo valor computado, sin cambio visual para esos dos segmentos. No se declara `no_incluye` violado — es limpieza de token sin efecto observable fuera del segmento proyecto.

## Cambios (mod:135) — TKT-202607-149 (REQ-202607-048): `#breadcrumb-proj` — jerarquía visual prominente como único punto de entrada a Documentos/Context

**Origen:** El nombre de proyecto en el header (`#breadcrumb-proj`, dentro de `.logo-project-label`/`#header-project-label`) pasa a ser el único punto de entrada visible a la vista Documentos/Context — `#tab-btn-proyectos` se retira en TKT-202607-150 (mismo REQ). Antes de este TKT, `.breadcrumb-seg` solo tenía documentado `.breadcrumb-seg--hidden` (`display:none!important`) — sin tratamiento de prominencia ni estados de interacción propios.

**Selector confirmado contra `index.html` real (línea 294):** `#breadcrumb-proj` — `<button class="breadcrumb-seg breadcrumb-seg--proj" id="breadcrumb-proj">`. El candidato alternativo `.logo-project-label` del AC original es el contenedor padre (envuelve también `#header-sprint-pill-wrap`), no el elemento de texto — se descarta.

**Archivo candidato:** `locus-layout.css` — mismo archivo donde ya vive el resto del patrón de breadcrumb (`R-202605-167 Breadcrumb interactivo en logo area`, `T-202605-002 Sprint pill wrap`, ambos en `.logo-project-label`). No verificado contra el archivo real en esta sesión — `locus-layout.css` no estaba adjunto. Rune confirma mod/línea exacta al integrar.

**Reglas nuevas:**

| Selector | Declaración | Justificación |
|---|---|---|
| `#breadcrumb-proj` | `font-size: var(--text-md)` (14px, sube desde `--text-xs`/11px — línea base documentada en A-05 de `_Locus-ux-ref` para breadcrumb) · `font-weight: 500` · `color: var(--text)` · `transition: var(--trans-color)` | AC exige solo los dos pesos del sistema (400/500) — `500` es el más alto permitido, entrega prominencia real frente a `.tab-btn` sin escalar a un Nivel de A-08 (esto no es un Tab/Modal/Card title ni un Eyebrow label — es un elemento de navegación persistente, fuera del catálogo de 4 niveles). `--text` es el token de texto primario ya validado WCAG AA contra `--surface`/`--surface2`/`--surface3` en todo el sistema — sin verificación nueva de contraste necesaria |
| `#breadcrumb-proj:hover` | `color: var(--accent)` | Reusa el uso de accent ya declarado como "confirmado" en `_Locus-ux-ref §A-03` ("breadcrumb hover") — no es una decisión nueva de color, es la aplicación del patrón ya vigente al elemento que ahora es interactivo con más peso. Sin token nuevo |
| `#breadcrumb-proj:focus-visible` | `outline: 2px solid var(--accent); outline-offset: 2px` | Mismo patrón ya usado en `.tab-btn`, `.rsb-card-quick`, `.sps-btn-menu` y el resto de controles interactivos del header — sin variable nueva |

**Anti-pattern evitado:** no se usó `--blue`/`--red` directos para ningún estado — el AC señala explícitamente el gap de contraste ya registrado en `§Tokens de color utilitarios` (`--blue`/`--red` fallan 4.5:1 como texto en light); ninguno de los dos aplica aquí, la prominencia se logra por tamaño/peso/color primario, no por color semántico.

**Gap declarado — sin verificación cruzada de duplicado:** `_Locus-ux-ref §A-03` documenta "breadcrumb hover" como comportamiento ya confirmado del sistema — no se pudo verificar si ya existe una regla `.breadcrumb-seg:hover` genérica en `locus-layout.css` real (archivo no adjunto) que haga esta declaración redundante. Rune verifica contra el archivo real antes de integrar — si ya existe una regla equivalente a nivel de `.breadcrumb-seg`, `#breadcrumb-proj:hover` de esta entrada es redundante y se omite, dejando solo `font-size`/`font-weight`/`color`/`transition`/`:focus-visible`.

## Cambios (mod:134) — Hallazgo fuera de scope de Nova (auditoría del Split View de Sesión contra `index.html`/`locus-sesiones.js`/`locus-modals-base.css` reales, adjuntos por primera vez desde mod:132): corrige la fila `.modal-split__header`/`.modal-split__header--empty`/`.msh-empty` de `§Cambios (mod:132)` — ninguno de los tres está retirado

**Origen:** verificación cruzada contra los tres archivos reales, pendiente desde que mod:132 la declaró como gap explícito ("Selectores exactos... quedan pendientes de verificación cruzada por Nova en la próxima sesión con esos tres archivos adjuntos"). Esta es esa sesión — dueña (Nova) presente, corrección de nivel Patch sin bifurcación de founder, resuelta en sesión (`__BR-Core` Excepción de resolución directa).

**Corregido:** la fila de la tabla de `§Cambios (mod:132)` listaba `.modal-split__header` / `.modal-split__header--empty` / `.msh-empty` bajo "Retirado → Consolidadas en el header único del shell". Incorrecto para los tres selectores:

- **`.modal-split__header` no se retiró** — es la clase real del header compartido (`#ingest-split-header`, `locus-modals-base.css` L403-414). Se reescribió para flujo (`display:flex`, `height:60px` fijo) en vez de `position:absolute` sobre el ancho combinado de ambas columnas (arquitectura pre-mod:132), pero el nombre del selector persiste sin cambio.
- **`.modal-split__header--empty` / `.msh-empty` tampoco se retiraron** — siguen siendo el mecanismo activo del estado "Sin worker activo" del header compartido. `_populateIngestModalHeader(null)` (`locus-sesiones.js`) inyecta `header.className = 'modal-split__header modal-split__header--empty'` + `<span class="msh-empty">Sin worker activo</span>` vía JS — contenido dinámico, no shell estático (`BR-Execution §5`, por eso `.msh-empty` no vive en `index.html`). `locus-modals-base.css` L416-423 conserva sus dos reglas sin cambio.

La fila se retira de la tabla de retiro/reemplazo de `§Cambios (mod:132)` — no describía un retiro real, era la única fila de esa tabla sin verificación contra código, y quedó desactualizada respecto al criterio del resto de la entrada. Ver corrección aplicada en esa misma sección, abajo.

**Selectores documentados — `.modal-split__header` / `.modal-split__header--empty` / `.msh-empty` (nueva entrada, `locus-modals-base.css`):**

| Selector | Rol |
|---|---|
| `.modal-split__header` | Header compartido del shell — `display:flex; align-items:center; justify-content:space-between; height:60px`, `border-bottom`. Contiene identidad del worker (`.sc-header-left`/`.sc-header-right`, ver `§2073` para el resto de la familia `.sc-*`) + único botón de cierre del shell (`#ingest-modal-close-btn`, movido desde el nodo interno de ingesta en mod:132) |
| `.modal-split__header--empty` | Modificador — aplicado junto a `.modal-split__header` cuando `_populateIngestModalHeader()` recibe `ai: null`. Solo `color:var(--text3)` — no cambia layout |
| `.msh-empty` | Texto del estado vacío ("Sin worker activo") — `--text-xs`/`var(--text3)`. Único hijo del header en ese estado; JS restaura el markup completo (`.sc-header-left`/`.sc-header-right` + sus 3 nodos) en la siguiente apertura con worker real antes de repoblar |

**Gap adicional cerrado — familia `.mss-*` nunca tuvo entrada propia en este doc, pese a existir desde mod:132:** mismo gap declarado explícitamente en `§Cambios (mod:132)` ("Selectores exactos de `#modal-split-shell`... quedan pendientes de verificación cruzada"). Cerrado en esta sesión contra `locus-modals-base.css` real (L385-456):

| Selector | Rol |
|---|---|
| `.mss-box` | Dialog real del shell — `width: min(1600px, calc(100vw - 48px))`, `height: 90vh`, `display:flex; flex-direction:column`, `var(--surface)`/`var(--border2)`, `--radius-xl`, `box-shadow` de dos capas (24px/50% + 4px/30%), `overflow:hidden`. Tamaño fijo centrado contra el viewport completo — no reactivo a `body.radar-sb-open`/`-collapsed` (AC3) |
| `.mss-content` | Body del shell — `flex:1 1 auto; min-height:0; display:flex`. Contenedor directo de las dos regiones (`.mss-col--ingest` + `#merge-diff-overlay`) |
| `.mss-col` | Base compartida de región — `min-width:0; min-height:0; overflow:hidden`. Sin uso standalone, siempre con modificador |
| `.mss-col--ingest` | Región izquierda (Panel de Ingesta) — `flex:0 0 33.3333%`, `display:flex; flex-direction:column`, `border-right:1px solid var(--border2)`. Proporción 1/3 · 2/3 vía `flex-basis`, reemplaza el `calc()` contra `--split-total-w` de la arquitectura anterior |
| `#merge-diff-overlay` (región derecha, Panel de Revisión) | Sin clase `.mss-col` propia — ocupa el 2/3 restante vía `flex:1 1 auto` implícito, layout declarado directamente en `locus-backlog-item.css` (no en este archivo) |
| `#merge-diff-header` | `display:none` — header interno de `#merge-diff-overlay` oculto del layout visual (AC2, un solo header por shell). El contenido que Rune puebla ahí no se toca, solo el nodo contenedor (`BR-Execution §5`) |

## Cambios (mod:133) — TKT-202607-146 (REQ-202607-046, depends_on: TKT-202607-144): retira `#merge-diff-overlay.has-diff` — nunca tuvo consumidor JS, contradecía la fila 18 de `§Cambios (mod:132)` (ya declaraba `.mdiff-overlay--empty`/`--filled` como mecanismo real)

**Origen:** Gap de contrato detectado por Rune al leer `locus-backlog-merge.js` (mod:69) contra el AC de Cael para TKT-202607-146 — `.has-diff` (declarado por Nova en TKT-202607-144, `locus-backlog-item.css` mod:77, `§Cambios mod:132` fila 18) nunca fue escrito ni leído por JS; el toggle real que popula/limpia `#merge-diff-body` alterna `mdiff-overlay--empty`/`--filled` en 4 puntos (apertura, cierre-aplicar, cierre-cancelar, cierre-Escape). Cael resolvió la bifurcación (Opción A — CSS se alinea al toggle ya emitido por JS, vs. Opción B — JS agrega `.has-diff` como segunda fuente de verdad) a favor de Opción A por mantenibilidad y consistencia con el patrón `--modificador` ya vigente. Founder confirmó Opción A.

**Cambio en `locus-backlog-item.css` (mod:78, Nova):**

| Retirado | Reemplazado por |
|---|---|
| `#merge-diff-overlay.has-diff .msc-diff-empty { display: none; }` | `#merge-diff-overlay.mdiff-overlay--filled .msc-diff-empty { display: none; }` |
| `#merge-diff-overlay.has-diff .mdiff-dialog { display: flex; }` | `#merge-diff-overlay.mdiff-overlay--filled .mdiff-dialog { display: flex; }` |

Sin cambio de JS — `locus-backlog-merge.js` ya emitía `mdiff-overlay--filled`/`--empty` antes de este TKT; solo se reutiliza. `.msc-diff-empty`/`.mdiff-dialog` (estructura, defaults) sin cambio.

**No incluye:** no toca `#modal-split-shell`, `.mss-*`, ni ningún otro selector de `§Cambios (mod:132)` — el resto de esa entrada sigue vigente sin modificación.

---

## Cambios (mod:132) — REQ-202607-046 (TKT-202607-144/145, ambos `done`): merge completo del split view — retira `.modal-split*`/`.mdiff-overlay--docked` (familia mod:79→129), nace `#modal-split-shell`

**Origen:** doc_update pendiente declarado por Nova (mod:34 de `_Locus-ux-ref`, tras aplicar el doc_update de Rune de TKT-202607-145). Founder confirmó Opción A (merge completo) sobre Opción B (shell contenedor) — prioriza eliminar la causa raíz de la superposición Col1/Col2 sobre conservar la independencia de DOM de `#merge-diff-overlay` que la familia `.modal-split*` protegía desde mod:79.

**Qué retira esta entrada — toda la cadena mod:79→83→86→87/88→129 queda superada, no solo el fix más reciente:**

| Retirado | Reemplazado por |
|---|---|
| `.modal-split__shell` (wrapper vacío sin CSS propio, mod:129) | `#modal-split-shell` — nodo real con `position:fixed`, backdrop y `z-index` propios, `max-width:1600px` / `height:90vh`, centrado contra el viewport completo |
| `.modal-overlay.modal-split` (en `#ingest-modal-overlay`) | Retirada — `#ingest-modal-overlay` pasa a región interna (`position:relative`/estática), sin backdrop ni `position:fixed` propio |
| `#merge-diff-overlay.mdiff-overlay--docked` + su `padding-left` calculado | Retirada — `#merge-diff-overlay` pasa a región interna, sin `.mdiff-overlay--docked` (0 asignaciones en el codebase, verificado por Rune vía grep en TKT-202607-145) |
| `--split-total-w/-h/-gap/-header-h` reactivas a `body.radar-sb-open`/`.radar-sb-collapsed` (mod:86) | Retiradas — `#modal-split-shell` **no** reacciona al estado del radar-sidebar (AC3 de TKT-202607-144: mismo ancho/posición con sidebar abierto o colapsado, centrado contra el viewport completo, no el área libre) — cambio de comportamiento explícito respecto a la arquitectura anterior |
| `.modal-split__dialog` / `.modal-split__col--ingest` / `.modal-split__col--diff` / `.modal-split__divider` | Retiradas junto con el layout de columnas ancladas independientes — TKT-202607-144 declara layout de dos columnas dentro del shell único (AC5), sin socket decorativo separado |
| `.msc-diff-empty*` + selector de hermano general (`#merge-diff-overlay.mdiff-overlay--docked ~ #ingest-modal-overlay .msc-diff-empty`, mod:87/129) | Estado vacío pasa a alternar dentro de la región `#merge-diff-overlay` vía `.mdiff-overlay--empty`/`--filled` (ver `locus-sesiones.js` mod:56, comentario inline de Rune) — ya no depende de adyacencia de hermanos entre dos overlays independientes |
| `--gutter-shell` como consumidor de `.modal-overlay.modal-split` (mod:88) | Sin efecto sobre el shell nuevo — `--gutter-shell` conserva su uso en el resto del sistema (`#tab-analytics`/`#tab-backlog`), solo pierde este consumidor específico |

**Corrección mod:134 — `.modal-split__header`/`.modal-split__header--empty`/`.msh-empty` retirados de esta tabla:** esta entrada los listaba como retirados/consolidados. Verificado contra código real (mod:134): ninguno se retiró — `.modal-split__header` es el selector real del header compartido, `--empty`/`.msh-empty` siguen siendo el estado activo "sin worker activo". Ver `§Cambios (mod:134)` para el detalle y la tabla de selectores documentada ahí.

**Gap declarado — cerrado en mod:134:** esta entrada documentó originalmente el criterio y la tabla de retiro/reemplazo según los AC de TKT-202607-144/145 y comentarios inline, sin lectura directa de `locus-modals-base.css`/`index.html` reales (ninguno adjunto en esa sesión). Verificación cruzada completada en `§Cambios (mod:134)` — selectores exactos de `.mss-box`/`.mss-content`/`.mss-col`/`.mss-col--ingest`/`#merge-diff-header` documentados ahí, junto con la corrección de la fila `.modal-split__header`. `locus-backlog-item.css` (layout de `#merge-diff-overlay` dentro del shell) sigue sin verificar — no adjunto en mod:134 tampoco.

**Consumo desde JS:** `showMergeDiffPanel()` y `_openIngestModal(aiId)` agregan/remueven `'open'` sobre `#modal-split-shell` — mismo mecanismo para ambos call sites, sin cascada entre nodos (ver `_Locus-ux-ref` mod:34 para el criterio de UX).

---

## Cambios (mod:131) — TKT-202607-126 (REQ-202607-039): cierre de Hallazgo fuera de scope de Finn — documenta `.sps-stat-cell--en-revision`/`--bloqueado` y la familia `.spt-content-empty*`/`.spt-identity*`, entregadas por Nova en mod:67 de `locus-sprint.css` sin entrada propia en este doc

- **Origen:** `Hallazgo fuera de scope` de Finn en el CHECKPOINT de cierre de `TKT-202607-126` — patrones nuevos y reusables entregados en la misma sesión que corrigió el mismatch de prefijo `.spi-*`→`.sps-*`/`.spt-*` (ver `locus-sprint.css` mod:67), sin `doc_updates` declarado en ese momento.
- **`.sps-stat-cell--en-revision`/`--bloqueado`:** agregadas a la tabla de `§Bloque de métricas — .sps-stats-block / .sps-stat-cell` — mismo componente ya documentado en mod:107, dos modificadores de color nuevos reusados también en sub-tab Ítems vía `#spi-stats-block` (mismas clases, contenedor con `id` propio para lectura JS).
- **Familia `.spt-content-empty*` (nueva, documentada por primera vez):** empty-state de las sub-tabs Ítems/Planificar del Tab Sprint — mismo lenguaje visual que `.msc-diff-empty*` (`locus-backlog-item.css`) y `.sps-empty` (L1680), nunca área en blanco (`BR-Execution §5`).
- **Familia `.spt-identity*` (nueva, documentada por primera vez):** chip de sprint + label, instancia única compartida entre Ítems y Planificar — no tenía entrada pese a existir sin cambios desde antes de mod:66.
- **`_Locus-ui-Inventory` — pendiente, no resuelto en esta sesión:** los IDs reales que portan estos patrones (`#spi-content-empty`, posible equivalente propio en Planificar) requieren `index.html` para confirmar `En DOM`/`CSS canónico` antes de agregar fila a Categoría 9 — no adjunto en esta sesión. La cita textual de `locus-sprint.css` mod:67 (`#spi-content-empty`, `index.html L888-892`) ya fue verificada por Rune en su propia sesión de fix — se toma como fuente confiable para el nombre de clase, no reemplaza la verificación de `En DOM` que exige el formato de Categoría 9.

## Cambios (mod:130) — TKT-202607-132/133 (REQ-202607-042): worker-header — avatar sin ring, dot en `currentColor`, rayo de sesión rápida + countdown fusionado a fila principal

- **Origen:** `design_intent: worker_header_tres_estados_v2` — REQ derivado de sesión de diseño con el founder. Cierra la recurrencia de `§Cambios mod:69/71/72` (worker-header cerrado sin `doc_update` tres veces consecutivas) — esta sesión aplica el update en el mismo ciclo de entrega, dueña presente (Nova), sin cola.
- **Avatar sin ring dentro de `#worker-header`:** `box-shadow` anulado, acotado a los 4 modificadores de estado del avatar — el acento ya vive en `border-left` (header) + `.sc-badge`/`.sc-badge-dot`, el ring lo triplicaba. Fuera de `#worker-header` (AI Card, tab Por IA) sin cambio.
- **`.sc-badge-dot` a `currentColor`:** antes `var(--c-low-text)` fijo, desalineado del color de texto del badge. Un solo selector cubre los 4 modificadores — sin regla por estado.
- **Familia nueva — `.worker-header-quick` / `.worker-header-cd-inline`:** ambos hermanos estáticos dentro de `#worker-header`, `is-hidden` por default — reemplazan el patrón de inserción/remoción dinámica de `.worker-header-unlock` (mod:73/74). El rayo reutiliza el delegador global `data-action="open-quick-capture"` ya existente, sin `addEventListener` propio. El countdown fusionado iguala la altura de fila entre los 4 estados — el motivo original de `.worker-header-unlock` (bloque de ancho completo como hermano de `#worker-header`, ver patrón documentado en mod:74) queda superado, no ese patrón general de inserción como hermano en sí.
- **`.worker-header-unlock` no se retira:** sin consumidor JS activo tras esta sesión — deuda intencional, retiro es TKT de limpieza aparte.
- **Ver tabla completa actualizada:** `#### Worker-header — modificadores de estado`.
- **`mod` de archivos reales:** `locus-sesiones.css` mod:44 (Nova, TKT-202607-132) · `locus-sesiones-card.css` mod:13 (Nova, TKT-202607-132) · `index.html` mod:159 (Nova, TKT-202607-132) · `locus-sesiones.js` mod:55 (Rune, TKT-202607-133).

## Cambios (mod:129) — TKT-202607-128 (REQ-202607-038): `.modal-split__shell` nueva + fix de raíz del padding-left docked (desalineación horizontal del split view)

- **Origen:** REQ-202607-038 — desalineación horizontal del split view de sesión (Col 2 `#merge-diff-overlay` docked vs Col 1 `#ingest-modal-overlay`) + `.msc-diff-empty` sin ocultarse tras procesar batch. Dos causas raíz: fórmula CSS con puntos de referencia distintos, y dependencia de una adyacencia DOM que la arquitectura original (`§Cambios mod:79`) declaraba explícitamente que **no** iba a restructurar — ver corrección abajo, en esa misma entrada.
- **`.modal-split__shell` — clase nueva, `index.html`:** wrapper sin reglas CSS propias en ninguno de los 22 archivos de `§Arquitectura de módulos CSS` — deliberado. `#merge-diff-overlay` y `#ingest-modal-overlay` pasan de hijos directos de `<body>` a hijos directos de este wrapper. No declara `position`/`transform`/`filter`/`will-change` — no crea containing block nuevo para los dos overlays `position: fixed` que envuelve. Si un TKT futuro necesita estilar `.modal-split__shell` directamente, verificar primero que la nueva regla no introduce una de esas cuatro propiedades — rompería el posicionamiento fixed de ambos hijos contra el viewport.
- **Fix de raíz — `padding-left` de `#merge-diff-overlay.mdiff-overlay--docked` (`locus-backlog-item.css`):** faltaba sumar `var(--gutter-shell)` — el borde izquierdo real de la columna de ingesta (`#ingest-modal-overlay.modal-split`, `locus-modals-base.css` L423) arranca en `var(--gutter-shell)`, no en `left:0`. `padding-left` pasa de `calc(var(--split-total-w) * 0.333 + var(--split-gap) / 2)` a `calc(var(--gutter-shell) + var(--split-total-w) * 0.333 + var(--split-gap) / 2)`. Identidad algebraica — sostiene el alineamiento en los 3 estados de `--split-total-w` (`:root`/`body.radar-sb-open`/`body.radar-sb-collapsed`) sin declaración adicional por estado.
- **`§Arquitectura de módulos CSS`, filas 5 y 15:** corregidas — `mod`/líneas de tabla estaban desalineadas de los archivos reales antes de esta sesión (`locus-backlog-item.css` tabla declaraba `mod:62`, real `mod:75` al abrir esta sesión; `locus-modals-base.css` tabla declaraba `mod:12`/1210 líneas, real `mod:19`/1244 líneas). Ver `Hallazgo fuera de scope` abajo.
- **No incluye:** no toca contenido interno de `.modal-split__col--ingest` ni de `.mdiff-dialog` (fuera de scope del TKT) — el selector de hermano general `#merge-diff-overlay.mdiff-overlay--docked ~ #ingest-modal-overlay .msc-diff-empty` no cambió de forma, solo la adyacencia DOM que consume.

**Hallazgo fuera de scope:** Las filas 5 y 15 de `§Arquitectura de módulos CSS` no reflejaban el `mod` real de `locus-backlog-item.css` (tabla: 62, real al inicio de esta sesión: 75 — 13 entregas de diferencia) ni de `locus-modals-base.css` (tabla: 12/1210, real: 19/1244). Se corrigen solo esas dos filas en esta entrada porque son las que grounding directo contra archivo real permitió verificar — el resto de la tabla no fue reauditado, mismo criterio ya declarado en la nota de cabecera de `§Arquitectura de módulos CSS` ("resto de la tabla sin reverificar en esta sesión"). Acción sugerida: Cael evalúa si amerita una sesión de re-auditoría completa de la tabla, dado que este es al menos el segundo desfase de este tipo detectado (ver `§Cambios mod:126` sobre `locus-incidents.css`).

## Cambios (mod:128) — Cierre del hallazgo `qinc-type-badge--ke` (`§Cambios mod:127`): NO es huérfana — reachable, y revela un bug de clasificación aguas arriba

- **Grounding:** `locus-incidents-item.js` (`buildQIncItem`, línea `type = itemKind(item) || ''` → `qinc-type-badge--${type.toLowerCase()}`), `locus-incidents-render.js` (`_qincEffectiveStatus`/`_isQIncTerminal`), `locus-incidents-generator.js` (comentario mod:8, AC de error verificado).
- **Conclusión — revierte la hipótesis de "huérfana" de `§Cambios mod:127`:** `itemKind()` **sí** puede devolver `'KE'` para un ítem histórico persistido en Supabase con `type:'KE'` sin migrar (confirmado explícitamente por el propio comentario de `locus-incidents-generator.js` mod:8 — "ítem histórico con type:'KE' persistido en Supabase — itemKind(i) devuelve 'KE'"). El comentario de `locus-incidents-item.js` línea 84 ("type:'KE' ya no alcanza este archivo") es incorrecto — contradicho por el propio código del generador.
- **Bug real revelado (no es solo un cabo documental):** `_isQIncTerminal()` (`locus-incidents-render.js`) perdió la rama `k === 'KE'` en la fusión a `infra_version 51` — para cualquier tipo que no es `CHG`, evalúa `s === 'closed'` (criterio INC/PRB). Un KE histórico real terminaba en `resolved`, nunca en `closed` (documentado en el propio comentario de la función: "resolved (KE, único terminal — KE no tiene status closed propio)"). Resultado: un KE histórico con status `resolved` se clasifica como **no terminal** → cae en `_activeItems` → se renderiza en la grilla de 3 columnas como si fuera un incidente activo sin resolver, con badge `qinc-type-badge--ke` (que sigue existiendo en CSS exactamente porque este camino lo sigue necesitando).
- **`.qinc-type-badge--ke` no se retira** — retirarlo dejaría a esos ítems históricos (mal clasificados, pero de todas formas mostrados) con un badge sin estilo, peor que el estado actual. Se mantiene documentado en la tabla de 4 variantes (`§Panel Q-INC — familia qinc-*`), corrigiendo el encabezado que decía "corregido mod:124 — listaba KE como cuarto tipo, fusionado" — esa afirmación era prematura/incorrecta para esta familia específica: `.stat-type-chip.tc-KE`/`.item-type-pill.KE` sí se retiraron en mod:124; `.qinc-type-badge--ke` nunca se retiró y, con este hallazgo, no debe retirarse hasta que el bug de clasificación se resuelva.
- **No es competencia de Nova resolver el bug de `_isQIncTerminal`** — es lógica JS de clasificación, no CSS. Se escala como hallazgo funcional, no como limpieza de estilos.
- **`mod` de archivos reales:** ninguno — auditoría pura, sin cambio de código (los 4 archivos JS solo se consultaron como fuente de verdad).

## Cambios (mod:127) — Auditoría de `locus-incidents.css` real (mod:1→2): discrepancia de tamaño resuelta, atribución stale corregida, KE vivo detectado

- **Discrepancia de tamaño (declarada como abierta en `§Cambios mod:126`) — resuelta:** `locus-incidents.css` real tiene **480 líneas** — coincide exactamente con lo ya declarado en la fila 4 de `§Arquitectura de módulos CSS`. La cifra de "504 líneas movidas" en el header ad-hoc de `locus-backlog.css` (mod:128) era una estimación imprecisa del founder/rol que hizo la extracción, no un valor verificado — se descarta como fuente, la tabla queda como estaba (480), sin la marca ⚠️.
- **Atribución stale corregida (`locus-incidents.css` mod:1→2, Patch, sin cambio de comportamiento):** `.qinc-item--sla-vencido`/`.qinc-item--sla-riesgo` citaban `TKT2 (REQ CAEL-0724-14, ref_id CAEL-0724-16)` — atribución que el propio `locus-backlog.css` (comentario del TKT de `.qinc-columns`, previo a la extracción) ya había corregido a `TKT2 (TKT-202607-089, parent REQ-202607-026)` por ser la primera "sin código real" (`ref_id` nunca resuelto a código real de Locus). La extracción mecánica (mod:1) copió el comentario viejo sin aplicar esa corrección — dejaba una referencia sin código real viviendo en un archivo real (mismo riesgo que `__BR-Execution §9` — Referencias a ítems embebidas en código). Resuelto en esta sesión — dueña presente (Nova), nivel Patch, sin bifurcación de founder.
- **Hallazgo fuera de scope — `.qinc-type-badge--ke` sigue vivo:** la familia `.qinc-type-badge` (badge de tipo ITIL sobre la card de Q-INC — distinta de `.stat-type-chip`/`.item-type-pill`, ya auditadas y retiradas en `§Cambios mod:124`) **conserva `--ke` y su variante dark** sin retirar. `KE` está fusionado a `PRB.root_cause_confirmed` desde `infra_version 51` — este selector nunca fue evaluado en esa fusión ni en el retiro de mod:124, que solo cubrió `tc-KE`/`item-type-pill.KE`. No tengo el JS de render de esta card (`locus-incidents-render.js` u otro) adjunto en esta sesión para confirmar si `t==='KE'` todavía puede llegar a generar esta clase o si es huérfana — no la retiro sin ese grounding. **Acción sugerida:** Rune confirma vía grep si algún caller todavía puede emitir `qinc-type-badge--ke`; si no hay caller, es alta prioritaria para un TKT de limpieza (mismo patrón que `tc-KE`/`item-type-pill.KE`) — si lo hay, es un INC de vocabulario (fuente sigue produciendo `KE` post-infra_version 51).
- **`mod` de archivos reales:** `locus-incidents.css` mod:1→2 (Nova).

## Cambios (mod:126) — Ad-hoc: extracción de la rama Reactiva (Q-INC) a `locus-incidents.css` — alta de archivo nuevo

- **Origen:** instrucción directa del founder, sin REQ/TKT vía Cael (`locus-backlog.css` mod:128, header: "Ad-hoc (sin REQ/TKT vía Cael, ítem directo de founder)"). **Corrige la atribución anterior de este mismo hallazgo:** la fila 3/fila 4 de `§Arquitectura de módulos CSS` ya declaraba esta extracción como documentada en "mod:124" — incorrecto, esa entrada es el retiro de KE (ver `§Cambios mod:124`, reconstruida en esta misma sesión), un cambio distinto y anterior. La extracción real es de hoy (2026-07-25), posterior incluso a `§Cambios mod:125` (spnp-*) — no cabía en mod:124 cronológicamente.
- **Movimiento mecánico, sin cambio de una sola declaración** (según header de `locus-backlog.css` mod:128): `#tab-incidentes` (antes L352-367) + bloque `TKT-D3` de badges de tipo ITIL/señales SLA/comportamiento/stats-bar Q-INC (antes L5660-5871) + `.tpl-nav-badge.is-urgent` + card/sección/badge/countdown/columnas Q-INC (antes L6383-6658) → `locus-incidents.css` (alta, mod:1).
- **Excepción intencional — NO se movieron:** variantes ITIL de componentes compartidos con la rama Planeada — `.stat-type-chip.tc-PRB`/`.tc-CHG`, `.item-type-pill.PRB`/`.CHG`, `.filter-type-btn.active-INC`. Partirlas habría fragmentado un componente único (chip/pill de filtro por tipo) en dos archivos en vez de separar por rama.
- **Pendiente fuera de este doc (declarado en el header de `locus-backlog.css`, no resuelto aquí):** `<link>` a `locus-incidents.css` en `index.html` (Rune) + declaración de orden de carga en `_pp-context §6` — sin dependencia de cascada real entre ambos archivos, el orden no es bloqueante.
- **Discrepancia sin resolver — tamaño de archivo:** el header de `locus-backlog.css` declara "504 líneas movidas"; la fila 4 de `§Arquitectura de módulos CSS` (actualizada en esta misma corrección) declara `locus-incidents.css` con 480 líneas. No tengo `locus-incidents.css` real adjunto en esta sesión para verificar cuál cifra es correcta — se deja la tabla con el valor ya existente (480) y se registra la discrepancia en vez de elegir una cifra sin grounding.
- **`mod` de archivos reales:** `locus-backlog.css` mod:127→128 (Nova, founder directo) · `locus-incidents.css` alta en mod:1 (Nova).

## Cambios (mod:125) — Familia `spnp-*` ("+ Sprint nuevo") documentada por primera vez — gap completo, código activo desde antes de mod:107

- **Origen:** auditoría solicitada por el founder sobre el botón `+ Sprint nuevo` (`#sprint-panel-sprints`) tras señal previa de Nova en sesión — el botón se había marcado como posible contradicción de `.sps-empty-hint`/`__BR-Ecosystem §5` ("solo Cael propone apertura de sprint") por no tener entrada en este doc. **Corrección de la señal anterior, no del código:** verificado contra `locus-sprint.js` (mod:113) + `index.html` (mod:156) que el panel **no crea sprints libremente** — es la ruta de paste + Aprobar/Rechazar del `sprint_proposal` que Cael ya emite (`_spnpHandleParseClick` exige un CHECKPOINT válido con `sprint_proposal` vía `parseCheckpoint`, mismo parser y mismo gate de exclusividad de `__BR-Ecosystem §8`/`§12` — sin `sprint_proposal` detectado, error inline). El texto de `.sps-empty-hint` ("no hay creación manual") sigue siendo correcto — lo que faltaba era documentar el vehículo (`spnp-*`) que lo implementa.
- **Alcance del gap:** familia completa activa desde TKT2/TKT4 (`REQ-[pendiente-ID]`, migración Step 0 DIFF → panel Sprint subtab) — nunca tuvo entrada en este doc pese a `design_intent: sprint-nuevo-panel-v1` (paste + aprobar/rechazar) y `design_intent: spnp-gate-inline-v1` (gate de ítems Q-Backlog tras crear sprint) declarados en comentario de código.
- **Nueva sección:** `### Panel "+ Sprint nuevo" — familia spnp-*` (ver abajo, junto a `§Sprint activo — familia sps-*`).
- **Sin selectores ni tokens nuevos de color** — composición íntegra sobre tokens ya validados (`--surface`/`--surface2`/`--surface3`, `--border`, `--text`/`--text2`/`--text3`, `--accent`/`--accent-dim`/`--accent-text`, `--red`, `--radius-sm/md/lg`). `.spnp-badge` reusa el par `--accent-dim`/`--accent-text` sin variante nueva.
- **`mod` de archivos reales:** ninguno — este DOC-UPDATE es puramente de auditoría/documentación, sin cambio de código (`locus-sprint.css` mod:64, `locus-sprint.js` mod:113, `index.html` mod:156 — todos solo consultados como fuente de verdad, sin modificar).

---

## Cambios (mod:124) — TKT2 (REQ CAEL-0724-11, `ref_id` CAEL-0724-13): retiro final de `KE` — fusión `KE→PRB.root_cause_confirmed` (infra_version 51)

- **Origen:** reconstrucción de esta entrada — el header existía como hueco (`## Cambios (mod:124)` ausente pese a 8+ referencias cruzadas en el cuerpo del doc citando "corregido mod:124"). Reconstruida contra `locus-backlog.css` real (comentario "TKT2 (REQ CAEL-0724-11, ref_id CAEL-0724-13): retiro final de 'KE'").
- **Reglas CSS retiradas:** `.stat-type-chip.tc-KE`, `.stat-type-chip.active.tc-KE`, `.item-type-pill.KE` — ninguna tenía consumidor JS activo tras TKT1 de este mismo REQ (`locus-incidents-render.js` mod:10 dejó de emitir la clase `tc-KE`; `.item-type-pill.KE` ya estaba huérfana antes de este TKT, sin caller confirmado por grep). `.tc-PRB`/`.tc-CHG`/`.item-type-pill.PRB`/`.item-type-pill.CHG` sin cambio.
- **Correcciones de contenido de este mismo doc, ya reflejadas en sus secciones respectivas (no se repiten aquí, solo se listan como índice):** `§Cambios mod:101` (nota inline sobre `.tc-KE` histórico) · `ct-type-cols` (columna de 3 filas→2 filas) · `staleness--itil-incompleto` · `.mdiff-queue-badge--qinc` · `.validation-result-item-type`. **Nota (mod:128): esta lista incluía originalmente `§Tabla de prefijos (.qinc-type-badge, "INC/PRB/KE/CHG"→"INC/PRB/CHG")` — esa corrección era incorrecta y fue revertida en `§Cambios mod:128`: `.qinc-type-badge--ke` nunca se retiró y sigue siendo alcanzable.**
- **`mod` de archivos reales:** `locus-backlog.css` — mod exacto de este TKT2 no verificable con certeza contra el archivo real (el comentario de este TKT no lleva su propio header `[PP] mod:N` en el archivo, queda entre los headers explícitos mod:126 y mod:123 — gap del archivo real, no de este doc; ver `Hallazgo fuera de scope` en el CHECKPOINT de esta sesión). `locus-incidents-render.js` mod:10 (Rune, TKT1 del mismo REQ).

## Cambios (mod:123) — Fila 2 de header de sprint: split label/valor (REQ CAEL-0724-01, TKT1 `ref_id` CAEL-0724-02) + retiro de `.hsr-velocity`

- **Cierra el gap de `§Cambios (mod:121)`:** esa entrada dejaba Fila 2 sin split label/valor porque `_sprintVelocityLabel`/`_metaText` (`locus-backlog-render.js`) devolvían un string compuesto por función, no datos separables. TKT3 (`ref_id` CAEL-0724-03, Rune) refactorizó ambas funciones a `{label, valor}` — `locus-backlog-render.js` mod:106. Este doc-update es su contraparte de estilos.
- **Clases nuevas (`locus-backlog.css` mod:127):** `.bl-vl-sprint-header-meta-label` (Nivel 4 — `--text-xs`, `uppercase`) y `.bl-vl-sprint-header-meta-value` (`--text-sm`) — ambas hijas de `.bl-vl-sprint-header-meta`, color heredado del contenedor, sin override de color propio.
- **`.hsr-velocity` retirada** — huérfana desde el refactor de TKT3: `_sprintVelocityLabel()` ya no retorna HTML con esa clase, retorna `{label, valor}` consumido directamente por `renderSprintGroup()`.
- **Sin tokens nuevos** — `--text-xs`/`--text-sm` ya declarados en `§1 Tokens de color utilitarios`.
- **`mod` de archivos reales:** `locus-backlog.css` mod:126→127 (Nova) · `locus-backlog-render.js` mod:105→106 (Rune, vía TKT3).

## Cambios (mod:122) — `.bl-plan-card--child` (REQ `ref_id` CAEL-0724-01, TKT1 `ref_id` CAEL-0724-02): sangría de TKT bajo su REQ en Vista Planificación

- **Clase nueva (mod:14 de `locus-sprint-ui.css`):** `.bl-plan-card--child` — `margin-left: 20px` + guía vertical vía `::before` absoluto (aprovecha `position: relative` ya declarado en `.bl-plan-card`), en vez de reutilizar `border-left` — ese borde ya codifica `--item-type-color` (semántica de tipo de ítem) y un segundo borde-izquierdo simultáneo habría colisionado visualmente. Sin token nuevo — `--border2` y `--radius-3xs` ya estaban en uso en el archivo.
- **Desviación menor del borrador aprobado por el founder:** el wireframe mostraba guía vertical + `padding-left`; la implementación usa `margin-left` + pseudo-elemento — resultado visual equivalente (indentación + línea guía), sin línea conectora entre cards (fuera de scope declarado en `no_incluye` del TKT).
- **CSS dependencies:** `--border2`, `--radius-3xs` (ambos ya declarados, sin alta nueva).

## Cambios (mod:121) — REQ CAEL-0724-01 (TKT1/TKT2): headers de sprint — tipografía, tinte Planificado, resumen en Cerrado

- **Nota de secuencia:** esta entrada se reaplica sobre la versión real del doc (que ya había avanzado a mod:120 con un cambio no relacionado, TKT-202607-086) — la primera aplicación había ocurrido sobre un adjunto obsoleto (mod:119) sin este cambio. Contenido idéntico al intentado antes, solo se corrige el número de mod y el punto de inserción.
- **`.sprint-name-label` → Nivel 3** (`--text-md`/`500`, antes `--text-sm`/`400`, `locus-backlog.css` mod:126). `.version-tag` sin cambio — ya correcto (`--text-xs` mono), confirmado por grounding.
- **`.sprint-badge-active` — gap de notación cerrado, sin cambio de código:** la tabla de abajo decía `Color: --amber` sin distinguir texto/acento. Verificado contra `locus-backlog.css` real: ya usa `color: var(--amber-text)` desde antes de esta sesión (consistente con la migración masiva mod:99/100). Tabla corregida.
- **Header Planificado — tinte de fondo nuevo:** `.sprint-group-planned .bl-vl-sprint-header` agrega `background: rgb(2 136 209 / 8%)` — mismo patrón que Activo. Antes sin fondo, solo `border-left`.
- **Header Cerrado — Fila 3 ya no es progress bar:** clase nueva `.bl-vl-sprint-header-summary` (`locus-backlog.css` mod:126) reemplaza `.bl-vl-sprint-header-progress` exclusivamente en estado Cerrado — texto `X/X ítems · vX.Y.Z` reutilizando `.bl-vl-progress-label`. Activo y Planificado sin cambio — siguen con la barra. Implementado en `renderSprintGroup()` (`locus-backlog-render.js` mod:105, Rune) — `_emptySprintHeaderHtml()` no se toca, nunca cubre sprints cerrados.
- **AC de Fila 2 (label/valor Nivel 4) — no implementado, gap devuelto a Cael:** `_velLabel`/`_metaText` son strings compuestos por función, no datos separables en label/valor sin refactor.
- **`mod` de archivos reales:** `locus-backlog.css` mod:125→126 (Nova) · `locus-backlog-render.js` mod:104→105 (Rune).

## Cambios (mod:120) — TKT-202607-086: toggle collapse en tarjetas atribuidas del Panel de Revisión — reuso de `.mdiff-section-header`/`.mdiff-section-body`, selector roto corregido

- **Origen:** Rune señaló conflicto CSS antes de implementar TKT-202607-086 (`_buildAttributedCardsBlock`, `locus-backlog-merge.js`) — el AC pide envolver `_attrRow` en un `<button data-action="mdiff-toggle-section">` (mismo mecanismo que `_section()`), pero el selector `.mdiff-narrative-section:not(:only-of-type) > .mdiff-narrative-row:first-child .mdiff-narrative-value` (TKT5/REQ CAEL-0718-01, truncado a 1 línea del título) depende de que `.mdiff-narrative-row` sea hijo directo de `.mdiff-narrative-section` — dejaría de matchear con el nuevo nivel de anidación.
- **Decisión — reuso funcional sin wireframe nuevo:** el botón reutiliza la clase base `.mdiff-section-header` (sin modificador de acento — no hay semántica de color de tipo-de-diff aplicable a una tarjeta atribuida) y `.mdiff-section-body` tal cual, mismo mecanismo de toggle (`is-collapsed`/`is-hidden` vía `_mdiffToggleSection`, sin JS nuevo). Mismo criterio que `§Cambios mod:103` ("Wrapper aplicado — reuso sin CSS nuevo") — no requiere wireframe de founder por ser reuso de un patrón de disclosure ya aprobado, sin diseño visual nuevo.
- **Ajuste de framing — `.mdiff-narrative-section:not(:only-of-type)` gana `border`/`border-radius`:** la clase base `.mdiff-section-header` trae esquinas superiores redondeadas + fondo propio (`var(--surface2)`) pensadas para vivir dentro de un contenedor tipo `.mdiff-section` con borde — sin ese marco, el header quedaría con esquinas redondeadas flotando sin borde que las contenga. Se agrega `border: 1px solid var(--border); border-radius: var(--radius-md-plus);` al selector `:not(:only-of-type)` ya existente (caso de 2+ tarjetas — el único donde el toggle aplica, AC1 del TKT) — el caso de una sola tarjeta (`:only-of-type`) no lleva header colapsable y no se toca. `padding-bottom: 0.75rem` de la regla base se conserva sin cambio — dobla como respiro interno inferior contra el nuevo borde.
- **Selector corregido:** `.mdiff-narrative-section:not(:only-of-type) > .mdiff-narrative-row:first-child .mdiff-narrative-value` → `.mdiff-narrative-section:not(:only-of-type) > .mdiff-section-header .mdiff-narrative-row .mdiff-narrative-value`. Ya no usa `:first-child` — con `_attrRow` como único `.mdiff-narrative-row` dentro del `<button>`, el descendiente ya es inequívoco sin necesitar la pseudo-clase; evita que el selector vuelva a matchear por accidente la primera fila narrativa dentro de `.mdiff-section-body` (que sí sería `:first-child` de su propio padre) si alguna vez comparten el mismo nivel de anidación.
- **Sin clases nuevas, sin tokens nuevos.** CSS dependencies para Rune: `.mdiff-section-header` (base, sin variante `--accent`) en el `<button>` que envuelve `_attrRow`; `.mdiff-section-body` en el `<div>` que envuelve `_releaseInfo`/`_narrativeHtml`/`_itemsBlockHtml`. El botón debe ser el hijo inmediato de `.mdiff-narrative-section` seguido directamente por el `<div class="mdiff-section-body">` como siguiente hermano — `_mdiffToggleSection` usa `btn.nextElementSibling` para localizar el body, mismo contrato que `_section()`.
- **`mod` de archivos reales:** `locus-backlog-item.css` mod:74→75 (Nova).

## Cambios (mod:119) — `.bl-plan-dest-programado-badge` + `.bl-plan-dest-sprint--programado` (REQ CAEL-0724-02, TKT1) + tabla `bl-plan-*` completada con familia dest-sprint

- **Clases nuevas (mod:13 de `locus-sprint-ui.css`):** `.bl-plan-dest-programado-badge` y `.bl-plan-dest-sprint--programado` — mismo componente/tratamiento que `--current`/`.bl-plan-dest-current-badge`, tono `--blue`/`--blue-text` en vez de `--accent`. Reusa la semántica ya establecida en `.sprint-badge-programado` (`§Sprint groups y badges`) — sin token nuevo.
- **Desviación del wireframe aprobado por el founder:** el borrador mostraba "Activos"/"Planificados" como dos bloques separados. La implementación real reutiliza la lista plana ya vigente desde T-202605-028 (`.bl-plan-dest-list` / `.bl-plan-dest-sprint`, un card por sprint destino con dropzone individual) — distinguir programado con badge/borde evita introducir una estructura de agrupación DOM nueva. Justificación completa en el CHECKPOINT de la sesión (Cael/Finn/Nova, 2026-07-24).
- **Gap de completitud cerrado en la misma sesión (dueño Nova co-presente, nivel Patch, sin bifurcación — `__BR-Core` Excepción de dueño co-presente):** la tabla `### Vista Planificación — familia bl-plan-*` no listaba la sub-familia `bl-plan-dest-*` (T-202605-028, ya vigente antes de esta sesión) — corregido junto con las clases nuevas para que la tabla no quede desactualizada apenas se toca por primera vez.


## Cambios (mod:118) — Badge de tipo en `#ingest-result-items` (REQ CAEL-0724-02/TKT1, promueve DISC-202607-029)

- **Clases nuevas:** `.validation-result-item-left` (wrapper de estructura, sin equivalente previo) y `.validation-result-item-type(--REQ|TKT|DISC|INC|PRB|CHG|unknown)` — ver `§Modal de ingesta — panel de validación`, tabla viva extendida.
- **Conflicto CSS resuelto en sesión (dueño Nova co-presente, nivel Patch, sin bifurcación — `__BR-Core` Excepción de dueño co-presente):** las restricciones de Fase 1 originales asignaban REQ→azul/DISC→púrpura, mapeo de `BR-Ecosystem §4` sin el swap DISC↔REQ ya vigente en Locus desde `mod:55`/`mod:51` (`locus-backlog-item.css`, TKT1 CAEL-11, decisión del founder). Corregido antes de implementar — REQ→`--purple-text`, DISC→`--blue-text`, coherente con `.item-type-pill.DISC`/`.tc-REQ`/`.qdisc-stat-cell--discovery`. Resto de tipos sin cambio de mapeo respecto al borrador original de Nova.
- **Sin tokens nuevos** — reuso exclusivo de `--purple`/`--purple-text`, `--green`/`--green-text`, `--blue`/`--blue-text`, `--red`/`--red-text`, `--amber`/`--amber-text`, `--slate`/`--slate-text`, `--surface3`, `--text3`, todos ya definidos y verificados WCAG en entradas previas de este doc.
- **Fallback `--unknown`:** activado cuando `item.type` no matchea `_GEN2_TYPES` (`locus-backlog-core.js`) — fuente única de tipos válidos, ya importada en `locus-session-parse.js`, reusada en vez de duplicar el array de 6 tipos.

## Cambios (mod:116) — Cierre del gap de `t-copy` declarado en mod:115: TKT correctivo reemplaza `--purple` por `--pink`

- **Origen:** `Acción sugerida` de `mod:115` — TKT correctivo Effort 1 ejecutado sobre `locus-modals-toast.css`. Dos rondas de QA (Finn): primera ronda (mod:5 del archivo) encontró el fix incompleto — `background`/`border-color`/`color` de `.toast-item.t-copy` ya usaban `--pink`, pero `.toast-item.t-copy::before` seguía en `--purple`. Corregido en mod:6 del archivo — las 4 declaraciones usan `--pink` de forma consistente. Segunda ronda de QA: aprobado.
- **`t-copy` real, actualizado:** `color-mix(in srgb, var(--pink) 12%/35%, transparent)` (background/border) + `color: var(--pink)` + `::before background: var(--pink)`. Ya no reutiliza `--purple` (dominio REQ) — gap de `mod:115` cerrado.
- **`--pink` no es un token nuevo, ni 100% dedicado a `t-copy`:** ya existía (`§Tokens de color utilitarios`) para texto de tag `.tc-5`. Mismo criterio de "compromiso aceptable" que `mod:115` aplicó a `--blue`/`t-confirm`: `--pink` no tiene una semántica de dominio fuerte y conflictiva como `--purple` (tipo de ítem REQ) — es un color utilitario sin tipo de backlog asociado, por lo que reusarlo para `t-copy` no reproduce el anti-pattern de `mod:75`/`mod:114` (préstamo de un token con significado de dominio ajeno). No es lo que el AC original de "tokens dedicados, no heredados" pedía en sentido estricto, pero cierra el gap de riesgo real (colisión semántica con REQ) que `mod:115` señaló como bloqueante.
- **Estado del REQ CAEL-0724-02:** con este fix, `t-confirm` (`--blue-*`, mod:115) y `t-copy` (`--pink`, aquí) quedan resueltos bajo el mismo criterio de compromiso — ninguno reutiliza un token de dominio de tipo de ítem del backlog (`--purple`=REQ, etc.). Pendiente fuera de este doc: confirmar con Cael/founder si el REQ cierra con este criterio o si en algún momento se justifica crear tokens 100% dedicados (`--indigo`/`--teal` u otros) — no se decide unilateralmente aquí.

## Cambios (mod:115) — Corrección de mod:114: tokens reales de `t-confirm`/`t-copy` distintos a lo documentado — `t-copy` no resuelve el anti-pattern de mod:75

- **Origen:** `locus-modals-toast.css`/`locus-toast.js` recuperados y adjuntados en esta sesión (el `mod:114` se escribió sin los archivos reales, como especificación pendiente de re-entrega — ver nota de esa misma entrada). Verificado contra código real: la implementación **no coincide** con los tokens `--indigo`/`--teal` documentados en `mod:114`. Se corrige aquí — `mod:114` queda como registro histórico de una spec que no se implementó así; no se reescribe.
- **`t-confirm` real:** `var(--blue-dim/-border/-text)` — no `--indigo`. Distinto de `t-info` (que es neutro — `--surface`/`--border2`/`--text`, sin tinte), por lo que sí quedan visualmente diferenciados entre sí. Sigue siendo un token compartido con la semántica "informativo" general del resto del ecosistema (DISC, etc.) — no es un token dedicado como pedía el AC original, pero no reproduce el anti-pattern de mod:75 (no es un préstamo de dominio no relacionado, `--blue` ya es "informativo" genérico y `confirm` es informativo-de-cierre). Compromiso aceptable, no lo que se especificó.
- **`t-copy` real — anti-pattern NO resuelto:** `color-mix(in srgb, var(--purple) 12%, transparent)` / borde `color-mix(..35%..)` / texto `var(--purple-text)`. `--purple` es el token de dominio **Requerimiento — tipo REQ** en backlog/archive/sprint (ver `§Tokens de color utilitarios`). Reusar `--purple` para `t-copy` es la misma categoría de error que `t-confirm`/`t-copy` reusando `--c-won`/`--c-pulido` (kanban) antes de este REQ, y la misma que ya se corrigió en `.sc-badge--avail`/`--exhausted` en `mod:75` — un token con significado propio en otro dominio (aquí: tipo de ítem REQ) prestado para un estado no relacionado. El AC de "tokens dedicados, no heredados" del REQ CAEL-0724-02 no se cumple para `t-copy` tal como está implementado.
- **`.toast-icon` — chip resuelto correctamente, mejor que la spec de mod:114:** `background: color-mix(in srgb, currentColor 15%, transparent)` — chip único que hereda automáticamente el color de `.toast-item.t-*` vía `currentColor`, sin necesitar una regla por tipo. Cumple el objetivo de TKT2 sin la necesidad de tokens de chip dedicados que `mod:114` daba por sentada.
- **`.toast-progress` real:** `height: 3px` confirmado — `opacity` no verificada línea por línea en esta pasada (comentario de header del archivo declara `.20→.36`, no `.20→.4` como decía `mod:114`; no se re-grepeó el valor exacto de `opacity` en esta sesión). Corregir el número exacto en la próxima sesión que toque este archivo si no coincide.
- **Tokens `--indigo`/`--teal` de mod:114 — retirados de este doc:** no existen en código, no hay otro consumidor. Ver fila retirada en `§Tokens de color utilitarios`, abajo.
- **Acción sugerida:** `t-copy` queda como gap abierto — Cael declara un TKT correctivo (Effort 1) para reemplazar `--purple` por un token genuinamente dedicado (o justificar explícitamente el reuso, cosa que el AC actual no permite) antes de cerrar REQ CAEL-0724-02.

## Cambios (mod:114) — Sistema de Toast: tokens dedicados para `t-confirm`/`t-copy` (corrige anti-pattern de mod:75) + polish de render — documentado por primera vez

- **Origen:** auditoría visual de Nova sobre `locus-modals-toast.css`/`locus-toast.js` (sesión 2026-07-24) — `t-confirm` reutilizaba `--c-won-*` (semántica kanban "descartado/agotado") y `t-copy` reutilizaba `--c-pulido-*` (semántica kanban "en-curso") — exactamente el anti-pattern que este mismo doc ya advertía en `§Cambios (mod:75)`: *"`c-pulido`/`c-won` son tokens de semántica kanban... no usar para nuevos estados"*. En light theme `t-confirm` colapsaba a neutro total (mismo `surface`/`border2` que `t-info`/`t-neutral`), perdiendo toda distinción. Gap adicional: `_TOAST_ICONS` solo mapea 5 de 8 tipos — `confirm`/`copy`/`neutral` caían al mismo ℹ genérico.
- **Toast — 8 tipos, sin entrada previa en este doc:** `success` (`--green-*`) · `download` · `info` (`--blue-*`) · `warning` (`--amber-*`) · `error` (`--red-*`) · `confirm` (nuevo, ver abajo) · `copy` (nuevo, ver abajo) · `neutral`. Primera documentación de la familia `.t-*` en `_Locus-css-ref` — no tenía entrada de patrón, solo aparecía en la tabla de módulos (`§L.904`, `locus-modals-toast.css`).
- **Tokens nuevos — dedicados, no heredados de otro dominio:** ver `--indigo`/`--teal` en `§Tokens de color adicionales`, abajo. `t-confirm` → `var(--indigo-dim/indigo/indigo-border)` + texto `var(--indigo-text)`. `t-copy` → `var(--teal-dim/teal/teal-border)` + texto `var(--teal-text)`. Ninguno de los dos reutiliza un token de otro dominio semántico — mismo criterio que ya corrigió `.sc-badge--avail`/`--exhausted` en mod:75.
- **Íconos — 1:1 tipo→ícono, sin fallback compartido:** `_TOAST_ICONS` (locus-toast.js) debe declarar entrada propia para los 8 tipos — `confirm`→`ti-circle-check`, `copy`→`ti-copy`, `neutral`→`ti-info-circle` (fallback explícito, no implícito). Ningún tipo cae al glifo de otro por ausencia de entrada.
- **Polish de render (mismo ciclo):** ícono envuelto en chip con `background` tintado del token del tipo (`border-radius: 50%`, mismo principio que `.sc-avatar`/badges de estado ya usan en el resto del sistema) · botón dismiss migrado de glifo de texto "×" a `<i class="ti ti-x">` (Tabler Icons ya cargado vía CDN para el resto de la UI, ver `§Arquitectura de módulos CSS` — Iconografía del sistema) · barra de progreso de auto-dismiss `height: 2px→3px` / `opacity: 0.20→0.4` (visibilidad, sin competir con contenido).
- **Fuera de scope, por diseño:** tamaño del stack (máx 3), animación de entrada/salida, comportamiento de pausa on-hover/touch — sin cambio, ya resuelto correctamente.
- **`mod` de archivos reales — pendiente de re-entrega:** `locus-modals-toast.css` y `locus-toast.js` fueron editados en la sesión anterior de este mismo hilo, pero el contenedor de esa sesión no persiste entre sesiones — los archivos ya no están disponibles para verificar header/`mod` real ni para confirmar que la implementación coincide exactamente con esta especificación. Esta entrada documenta el diseño acordado con el founder (tokens + polish, aprobado en sesión) como fuente de verdad para la re-entrega — no como registro de un `mod` ya verificado en código. Rune/Nova confirman `mod` real al reattachar los archivos y entregar.
- **`_Locus-ui-Inventory`:** pendiente — alta de `t-confirm`/`t-copy` como variantes documentadas del componente Toast (Cat. de componentes flotantes). No aplicado en esta sesión — mismo motivo que el punto anterior.

## Cambios (mod:113) — REQ-202607-019 (grupo de drafts en Q-Backlog): `.qbacklog-draft-*` — alta, documentado por primera vez

- **Origen:** TKT-202607-071 (Nova, entregable CSS) + TKT-202607-072 (Rune, `locus-backlog-zone-engine.js` mod:10 / `locus-backlog-qbacklog.js` mod:5) — cierre de REQ-202607-019 confirmado `done` por Finn. Los REQ/TKT en `draft: true` (pendientes de aval Fase 5 de Finn) eran invisibles en Q-Backlog sin señal de que existían.
- **Patrón:** mismo mecanismo de colapso que `.qdisc-status-group` (chevron + `is-collapsed`) — grupo colapsable inyectado en los tres puntos de salida de `_renderZonePanel()`, debajo del bloque "Terminados" (`bl-done-*`). Solo activo en Q-Backlog (`opts.showDraftGroup`) — Q-DISC no lo declara, sin regresión. Ver sección nueva `§Panel Backlog — grupo de drafts qbacklog-draft-*`, debajo de `§Panel Q-DISC`.
- **Fuera de scope visual, por diseño:** sin badge de prioridad ni área (cola de espera de proceso, no ítem priorizable), sin hover/drag — tarjetas planas no accionables.
- **`mod` de archivos reales:** `locus-backlog-zone-engine.js` mod:10 · `locus-backlog-qbacklog.js` mod:5 · `locus-backlog.css` (clases nuevas, ver sección) — entregado por Nova/Rune en TKT-202607-071/072.
- **`_Locus-ui-Inventory`:** altas correspondientes en Cat. 2 (Paneles) y Cat. 9 (Contenedores dinámicos) — ver ese doc, mismo ciclo.

## Cambios (mod:112) — Corrección V4 (auditoría #ingest-validation-panel): `--amber` crudo → `--amber-text` en toda la familia `.validation-*`/`.blocker-row--warning`

- **Origen:** hallazgo de Finn (auditoría del modal de ingesta) — este doc declaraba `.validation-warnings`, `.validation-force-btn`, `.validation-badge--warning` y `.blocker-row--warning` usando `var(--amber)` crudo como `color:` de texto, con nota explícita "sin `-text` dedicado". Verificado contra código real (`locus-modals-base.css` líneas 742/756/809/915): las cuatro reglas **ya usan `var(--amber-text)`** — el código está correcto, la desactualización era de este doc.
- **Causa probable:** la sección `§Modal de ingesta — panel de validación` (mod:66/68, CAEL-19/23/30) se escribió antes de la migración masiva de `mod:99/100` (296 instancias `--amber`→`--amber-text` por WCAG AA, `§Cambios mod:99`) y nunca se barrió junto con esa migración — mismo patrón de doc-lag ya visto en `§Cambios mod:91` para `.rsb-hdr-session`.
- **Corregido:** tabla viva de `§Modal de ingesta — panel de validación` (fila `.validation-warnings`, `.validation-force-btn`, `.validation-badge--warning`, `.blocker-row--warning`) y el bloque "Mapeo de tokens del wireframe" — los cinco puntos que declaraban `var(--amber)`/`--text-warning` sin `-text` ahora declaran `var(--amber-text)`, consistente con el anti-pattern ya documentado en `§Cambios mod:99` y con `.spi-item-status--orphaned` (línea ~1503, mismo criterio).
- **`mod` de archivos reales:** ninguno — DOC-UPDATE puramente de auditoría/documentación, `locus-modals-base.css` ya estaba correcto, sin cambio de código.
- **Nota — entradas históricas mod:66/mod:68 no reescritas:** se dejan como registro de la decisión original (remapeo de tokens del wireframe); la tabla viva de la subsección es la fuente de verdad operativa y es la que queda corregida.

## Cambios (mod:111) — REQ CAEL-0723-01 (checkbox de WIP): `.quick-wip-check` / `.correct-hora-wip-check` — dos altas

Nuevo patrón de checkbox activo — reutiliza `var(--purple)`/`var(--purple-text)` vía `color-mix()`, mismo token que ya colorea el estado `interrupted` en badge/avatar/worker-header (`§J-01`, ux-ref mod:25) y mismo mecanismo que `.item-type-pill.REQ`. El wireframe original aprobado por el founder usaba una escala `--purple-50/200/600/800` que no existe en este doc — corregido en sesión (Criterio de Resolución de Raíz, Opción A) antes de implementar, sin reabrir el diseño aprobado (layout/label/posición sin cambio).

- **`.quick-wip-check`** (`locus-sesiones.css` mod:41) — checkbox "Este worker tiene un WIP", Quick Capture paso 2, debajo de `#quick-hora`. Sin marcar: `background: var(--surface3)`, `color: var(--text3)` (tratamiento pasivo, mismo criterio que `.mg-output-check`). Marcado: `background: color-mix(in srgb, var(--purple) 12%, transparent)`, `border-color: color-mix(in srgb, var(--purple) 35%, transparent)`, `color: var(--purple-text)` (nunca `var(--purple)` crudo en `color:` — anti-pattern mod:99). `<label for>` + `:focus-visible`.
- **`.correct-hora-wip-check`** (`locus-backlog-item.css` mod:72) — mismo patrón visual, modal "⏰ Editar worker agotado" (`#gconfirm-overlay`, contenido inyectado en `msg.innerHTML` por `openCorrectHora()`), entre el bloque de hora y los botones Cancelar/Guardar. Precargado con `ai.interrupted` — ver `_Locus-ux-ref §Cambios (mod:32)`.

Ver `_Locus-ui-Inventory §6 Formularios` — altas `#quick-wip` / `#correct-hora-wip`.

## Cambios (mod:110) — DOC-UPDATE: corrección de indexación — badges `tpl-badge-backlog/qbacklog/qdisc` son `.spt-tab-badge`, no familia `tpl-`

- **Origen:** hallazgo de Rune durante implementación de TKT1 (REQ CAEL-0723-01, badge Discoveries) — al auditar la clase real contra `index.html`/`locus-sprint.css`, los tres badges de sub-tab de Tab Backlog resultaron ser `.spt-tab-badge` (`locus-sprint.css`, T-202606-098), no la familia `tpl-` (Templates sidebar) donde este doc los tenía indexados. El naming del `id` (`tpl-badge-*`) es legado y coincide por accidente con el prefijo `tpl-` — no hay relación de arquitectura real.
- **Corregido:** fila `tpl-` (nota aclaratoria, sin retirar los 3 IDs de la tabla — siguen siendo IDs válidos, solo se corrige su clase/archivo real) + fila `spt-` (agregada `.spt-tab-badge` con los 3 call sites reales).
- **`_Locus-ui-Inventory` fila 51 (`#tpl-badge-qdisc`) tiene la misma corrección — aplicada en el mismo ciclo por Nova, ver ese doc.**
- **`mod` de archivos reales:** ninguno — este DOC-UPDATE es puramente de auditoría/documentación, sin cambio de código (`locus-sprint.css` sin modificar, solo consultado como fuente de verdad).

## Cambios (mod:109) — DOC-UPDATE: auditoría de la stats bar de Q-INC (gap abierto desde mod:108) + Hallazgo fuera de scope (case mismatch JS/CSS)

- **Origen:** founder pide "Auditemos" — cierre explícito del gap dejado abierto en mod:108 ("Stats bar del panel — sin auditar, gap registrado"). Auditado contra `Archivo.zip` real: `locus-backlog.css` (`.qinc-stats-bar`/`.qinc-search-input`/`.qinc-stats-types`/`.qinc-stats-priority`, ~L5857-6506) y `locus-incidents-render.js` (`renderQIncStats()`).
- **CSS auditado, sin gaps propios:** layout del contenedor y del input documentados por primera vez en `§Panel Q-INC — familia qinc-*`. Chips de tipo/prioridad reutilizan `.stat-type-chip`/`.stat-pri-chip` ya documentados — sin duplicar.
- **Hallazgo fuera de scope detectado durante la auditoría — destino Rune, no corregido en este DOC-UPDATE (es `.js`, no `.css`):** `renderQIncStats()` (`locus-incidents-render.js:118`) y la función de stats bar reusada de Q-Backlog (`locus-backlog-zone-engine.js:300`) generan la clase de tipo con `t.toLowerCase()` (`tc-inc`, `tc-req`, etc.) — el CSS solo define el selector en mayúsculas (`.tc-INC`, `.tc-REQ`, etc.). Selector CSS es case-sensitive → nunca matchea → los chips de tipo de Q-INC y de Q-Backlog pierden el color por tipo, quedan en el estilo base genérico. Ver detalle completo en `§Panel Q-INC — familia qinc-*`.
- **`mod` de archivos reales:** ninguno — este DOC-UPDATE es puramente de auditoría/documentación. El bug de JS encontrado no se corrige aquí — Nova no modifica `.js`.

## Cambios (mod:108) — DOC-UPDATE: cierre del Hallazgo fuera de scope registrado en mod:107 — `§Panel Q-INC` referenciaba `#sps-qinc`, contenedor real es `#tab-incidentes`

- **Origen:** `Hallazgo fuera de scope` declarado por Nova al cierre de mod:107 — la sección `§Panel Q-INC` seguía nombrando `#sps-qinc` como contenedor pese a que ese ID fue retirado del sub-tab Sprints en la misma corrección de mod:107. Auditado ahora contra `Archivo.zip` real (`locus-backlog.css` mod:121) — founder lo priorizó explícitamente sobre otras verificaciones pendientes.
- **Hallazgo confirmado — más profundo de lo esperado:** no era solo un rename. Q-INC fue promovido de sub-panel a **tab de primer nivel** (`#tab-incidentes`) en un REQ ajeno a este ciclo (CAEL-0720-05, "Shell persistente Q-INC") — anterior y sin relación con el rediseño de `locus-sprint.css`/`.js` de mod:107. `#tab-incidentes` envuelve `#qinc-toolbar` (estático) + `.qinc-stats-bar` + `#qinc-panel-body` (dinámico, `renderQIncPanel()`).
- **Corregido:** heading de `§Panel Q-INC`, tabla de prefijos (`§Tabla de prefijos`, fila `sps-`) y nota de comportamiento de `§Encabezado de contexto vista-principal` — las tres referenciaban `#sps-qinc` como si siguiera viviendo en el sub-tab Sprints.
- **No corregido — fuera de este DOC-UPDATE:** "Stats bar del panel — sin auditar, gap registrado" (línea previa a `§Panel Q-DISC`) sigue abierta. `Archivo.zip` sí trae el CSS real de `.qinc-stats-bar`/`.qinc-search-input` — auditoría completa no ejecutada en este ciclo, sin instrucción del founder para ampliar el scope más allá del hallazgo de `#sps-qinc`.
- **`mod` de archivos reales:** ninguno — este DOC-UPDATE es puramente correctivo sobre este doc, sin cambio de código (`locus-backlog.css` mod:121 sin modificar, solo consultado como fuente de verdad).

## Cambios (mod:107) — DOC-UPDATE: rediseño sub-tab Sprints documentado (ad-hoc, instrucción directa del founder — sin REQ/TKT, `design_intent: sprint_subtab_redesign`)

- **Origen:** CSS entregado por Nova (`locus-sprint.css` mod:64) e implementado por Rune en dos sesiones (`locus-sprint.js` mod:111 — 4 status-groups + fila `.sps-closed-row`; `locus-sprint.js` mod:112 / `index.html` mod:151 — bloque de métricas `#sps-stats-block`, bloqueado en mod:111 por falta de `index.html` en esa sesión). Doc no actualizado en el momento de cada entrega — gap cerrado ahora, en sesión con Nova co-presente (Excepción de dueño co-presente, `__BR-Core`).
- **`.sps-section-label` / `.sps-section-count` — retiradas de la referencia viva (tachadas, no borradas):** reemplazadas por `.sps-status-group` / `.sps-status-header` / `.sps-status-body` en las 4 secciones (Activo/Programados/Pausados/Cerrados). Mismo mecanismo de colapso que `.qdisc-status-group` (chevron + `is-collapsed`), documentado por primera vez — ver tabla nueva abajo.
- **`.sps-stats-block` / `.sps-stat-cell` documentadas por primera vez:** shell estático en `index.html` (mod:151), 4 celdas fijas — mismo patrón que `.qdisc-stats-block`. A diferencia de qdisc, sin `.sps-stat-icon` (no existe en `locus-sprint.css`) y solo 2 de las 4 celdas llevan modificador de color (`--activo`/`--programados`) — Pausados/Cerrados neutros a propósito, mismo criterio que Descartado en `.qdisc-stat-cell`.
- **`.sps-closed-row` documentada por primera vez — reemplaza `.sps-cerrados-row`/`.sps-cerrados-header`/`.sps-cerrados-retro` (nunca tuvieron entrada de tabla propia en este doc, solo mención en prosa en la fila `#sps-cerrados` de la tabla de estructura — corregida abajo):** fila plana con acento lateral, mismo lenguaje visual que las cards PROMOTED de Q-DISC. El menú `···` (Ver retro completa / Exportar .md) se retira — ambas acciones invocaban `openSprintRetroView()`, ya redundantes entre sí. La fila completa es ahora el control.
- **Corrección de hecho — tabla "Estructura real del sub-tab Sprints" (línea `§Sprint activo — familia sps-*`):** declaraba 5 secciones incluyendo `#sps-qinc`. Verificado contra `index.html` real (mod:151): `#sps-qinc` no existe — Q-INC vive en su propio tab (`locus-sprint.js` mod:111, comentario de header: "Q-INC excluido — tiene tab propio, por instrucción del founder"). La remoción es anterior a esta sesión — este doc nunca la reflejó. Tabla corregida a 4 secciones.
- **`mod` de archivos reales:** `locus-sprint.css` mod:64 (Nova, sin cambio en esta sesión — ya entregado) · `locus-sprint.js` mod:110→112 (Rune) · `index.html` mod:150→151 (Rune).

## Cambios (mod:106) — TKT-202607-048 (REQ CAEL-0721-01/CAEL-0721-05): badge Huérfano corregido + familia `.spi-item`/`.spi-item-status` documentada por primera vez

- **Origen:** auditoría de Finn sobre TKT-202607-048 — AC original ("badge muestra 'huérfano' vía `.spi-item-status--pendiente`") era ambiguo y no declaraba clase nueva en el CSS dependencies block. Finn devolvió a Cael; Cael reescribió el AC con clase propia `.spi-item-status--orphaned`, coordinado con Nova.
- **Bug cerrado (`locus-sprint.js`):** `statusCls` en `_sprintItemHtml()` no tenía rama `isOrphaned` pese a que la variable ya existía — REQ orphaned caía en el default `'spi-item-status--pendiente'`, badge mostraba texto "Huérfano" con color de pendiente. Rama agregada al ternario.
- **Conflicto CSS resuelto en sesión (dueño Nova co-presente, nivel Patch, sin bifurcación — `__BR-Core` Excepción de dueño co-presente):** el snippet inicial de Nova para `.spi-item-status--orphaned` usaba `color: var(--amber)` crudo — anti-pattern ya documentado y migrado en `§Cambios mod:99/100` (296 instancias/19 archivos, `--amber`→`--amber-text` por WCAG AA). Corregido antes de entregar — usa `--amber-text`, mismo patrón que `.spi-item-status--en-revision` ya vigente en el mismo archivo.
- **Gap de documentación cerrado:** la familia `.spi-item`/`.spi-item-status` (4 modificadores de fila + 5 de badge, activos desde antes de este mod) nunca estuvo documentada en este doc pese a que el prefijo `spi-` ya figuraba en `§Prefijos y convenciones de naming`. Sección nueva agregada — ver `§Sprint items list`.
- **`mod` de archivos reales:** `locus-sprint.js` mod:109→110 (Rune) · `locus-sprint.css` mod:62→63 (Nova).

## Cambios (mod:105) — TKT-202607-044 (REQ CAEL-0721-01, ref_id CAEL-0721-04): badges Activo/Pausado del Tab Sprint reusan `.sprint-badge-*` — eliminada familia `.sml-badge*` no documentada

- **Origen:** auditoría de render del Tab Sprint (sesión founder 2026-07-21) — `_renderSpsActivo()`/`_renderSpsPausados()` en `locus-sprint.js` usaban una familia `.sml-badge`/`.sml-badge--active/--closed/--scheduled/--current` que **nunca estuvo documentada en este doc** y que, salvo la clase base `.sml-badge` (sin color), no tenía ningún call site propio — el badge Activo ya se renderizaba en la práctica mezclando `.sml-badge` (base) con `.sprint-badge-active` (de esta familia, `§Sprint groups y badges` arriba), y el badge Pausado con `.sml-badge--paused`, clase inexistente en CSS.
- **Resolución (opción B, founder confirmó por mantenibilidad — sin tocar Nova para clase nueva):** `_renderSpsActivo()` y `_renderSpsPausados()` migrados a usar exclusivamente `.sprint-badge-active` / `.sprint-badge-paused` — mismas clases y mismo tratamiento visual que ya usa `§Sprint groups y badges` (Vista Lista de Backlog). **Este doc no documentaba ese segundo consumidor hasta ahora** — actualizado abajo.
- **Eliminado — `locus-sprint.css` (mod:60→61):** familia completa `.sml-badge` / `.sml-badge--active` / `.sml-badge--closed` / `.sml-badge--scheduled` / `.sml-badge--current`, más `.sml-retro-btn` y `.sml-current-btn` (con pseudo-clases y referencias en `@media prefers-reduced-motion`) — subsistema huérfano "sprint en curso" (`setSprintCurrent()`, ver `_Locus-module-contracts.md`), sin consumidor en JS confirmado por grep contra los 52 módulos del proyecto.
- **Sin selector ni token nuevo** — reuso exclusivo de clases ya existentes y documentadas en `§Sprint groups y badges`.
- **Gap de origen cerrado:** la causa raíz de la deuda (badge Activo funcionando "por accidente" al mezclar `.sml-badge` con `.sprint-badge-active` de una familia distinta) era justamente que esta familia tenía un solo consumidor documentado — ahora tiene dos, declarado explícitamente para prevenir el mismo mismatch de nomenclatura en el futuro.
- **`mod` de archivos reales:** `locus-sprint.css` mod:60→61 (Nova).

## Cambios (mod:104) — Limpieza CSS muerto post-unificación `renderSprintGroup()` (Hallazgo fuera de scope registrado en `_Locus-module-contracts.md` §4, mod:94)

- **Origen:** anti-pattern detectado por Finn/Rune durante auditoría de REQ CAEL-0720-01 — `renderSprintGroup()` se unificó a un nuevo patrón de render (consumido hoy vía `.bl-vl-sprint-body`/`.version-header-arrow`, este último sigue vivo — usado por `toggleCollapseAll()`) sin auditar los consumidores del patrón anterior (`.version-group-body`). El selector quedó huérfano en dos archivos, sin ningún handler o wiring que lo aplicara desde entonces — `toggleCollapseAll()` se volvió no-op silencioso hasta el fix de TKT-CAEL-0721-02 (ver `_Locus-module-contracts.md`).
- **Verificado antes de eliminar:** grep exhaustivo sobre los 21 `.css` reales del proyecto (`Archivo_2.zip`) — exactamente 6 ocurrencias de `version-group-body`/`version-collapse-arrow`, las mismas 6 ya registradas en `_Locus-module-contracts.md` §4, ninguna adicional. No verificado contra `.js`/`.html` en esta sesión (no adjuntos) — la ausencia de consumidor JS se hereda de la auditoría ya cerrada por Rune/Finn en la sesión del REQ, no se repite aquí.
- **Eliminado — `locus-backlog.css` (mod:117→118):**
  - `.version-group-body` / `.version-group-body.collapsed` (declaración base + estado colapsado, ~L1084-1091) — superseded por `.bl-vl-sprint-body`.
  - `.sprint-group-active .version-group-body .item:hover` / `.sprint-group-active .version-group-body .item.is-done` (~L1192-1200) — selectores compuestos: el ancestro `.sprint-group-active` sigue vivo y documentado (`§Cambios` histórico, `.sprint-group-active/closed`), pero el descendiente `.version-group-body` nunca se aplica desde la unificación — la regla completa era inalcanzable.
- **Eliminado — `locus-analytics.css` (mod:16→17):** `.version-collapse-arrow` + `.version-group-body.collapsed` (~L781-790) — duplicado suelto sin relación con el resto del archivo (Tab Analytics), origen no reconstruible más allá de copy-paste histórico. Sin selectores `.version-*` restantes en este archivo tras la limpieza.
- **Sin cambio de comportamiento visual** — ninguno de los selectores eliminados podía matchear ningún elemento real desde la unificación de `renderSprintGroup()`; esta limpieza no altera lo que el usuario ve, solo retira CSS inalcanzable.
- **Gap declarado, no resuelto en este mod:** el origen exacto de por qué `.version-collapse-arrow`/`.version-group-body.collapsed` vivían específicamente en `locus-analytics.css` (archivo sin relación funcional con sprint groups de Backlog) no se reconstruye — copy-paste histórico sospechado, sin evidencia que lo confirme o descarte.
- **`mod` de archivos reales:** `locus-backlog.css` mod:117→118 (Nova) · `locus-analytics.css` mod:16→17 (Nova).

## Cambios (mod:103) — Homologación visual Histórico con Backlog (REQ CAEL-0720-01, ref_id CAEL-0720-02/03)

- **Origen:** auditoría solicitada por founder — `#historico-stats-bar` usaba patrón previo a la migración de Backlog (`.stat-card` en 3 filas apiladas, sin wrapper `.bl-header-unified`, sin fila de esfuerzo). Boceto aprobado por founder ancla la homologación completa.
- **Wrapper aplicado — reuso sin CSS nuevo:** `#historico-header-unified` consume `.bl-header-unified` tal cual — mismo criterio que el patrón `### Barras sticky de contenedor (toolbar/stats)` ya documentado (`§Cambios mod:30`) preveía como "equivalentes futuros en otros subtabs". Sin selector nuevo.
- **Fila de conteos:** migrada a `.stats-row--compact` + `.stat-compact-sep`, mismo mecanismo que Backlog. Chip "Total" migrado de `.stat-card` a `.stat-compact-item--primary`.
- **`.stat-effort-card--static` — único selector nuevo:** modificador estático agregado a la familia `.stat-type-chip--static`/`.stat-pri-chip--static` — faltaba porque la fila de esfuerzo no existía en Histórico hasta este REQ. Cursor default, sin hover de borde — mismo criterio que `.stat-area-chip--static` (`§L.1645`).
- **Toolbar reducido — sin selectores nuevos:** `#historico-toolbar` reusa `.bl-toolbar`/`.bl-collapse-btn`/`.bl-search-input` existentes, sin el grupo de filtros de status ni Deps/Hijos/Sin AC — ver justificación de scope en `_Locus-ux-ref.md`.
- **Sin tokens nuevos.**
- **`mod` de archivos reales:** `locus-backlog.css` mod:116→117 (Rune — header no reflejaba el cambio hasta corrección de Finn en sesión de cierre).
- **Hallazgo fuera de scope: el header de este doc declaraba `mod:102` sin sección `## Cambios (mod:102)` correspondiente — Resuelto en sesión (dueña Nova presente, nivel Patch, sin bifurcación de founder):** verificado contra el header real de `locus-backlog.css` (líneas 27-34) — el mod:102 corresponde al rediseño ad-hoc de la fila DISC en Q-DISC, entrada retroactiva documentada abajo. Mismo patrón de gap ya cerrado en `§Cambios mod:94`.

## Cambios (mod:102) — Ad-hoc: rediseño fila DISC en Q-DISC — card boxeada → fila flat tipo inbox

- **Origen:** ítem directo de founder, sin pasar por Cael (REQ/TKT) — instrucción explícita en sesión de Nova. Entrada retroactiva: el `mod` del archivo real se incrementó en su momento (2026-07-18) pero el changelog de este doc nunca se escribió — gap detectado y cerrado en sesión de cierre de REQ CAEL-0720-01.
- **Cambio:** `.bitem--idea` (card boxeada — wash 4 caras, borde punteado, glow) reemplazado por fila flat tipo inbox (patrón Linear/Things). Reemplaza el bloque completo de `mod:95` (card base, `::before` muerto sin `content`, type-block duplicado, quick-actions siempre visibles).
- **Separación de responsabilidad:** el acento de tipo (border-left + tint de header) lo resuelve exclusivamente `.item.bitem[data-type="DISC"]` en `locus-backlog-item.css` (mod:52) — esta capa cubre solo lo exclusivo de la fila de idea: hover, acciones bajo hover/foco, badges no aplicables.
- **Sin cambio HTML/JS.**
- **`mod` de archivos reales:** `locus-backlog.css` mod:101→102 (Nova, 2026-07-18).

## Cambios (mod:101) — TKT1 (REQ CAEL-0720-01, ref_id CAEL-0720-02): unificación de estado activo — chips type/priority/effort

- **Origen:** diagnóstico de filtros del Backlog — tres mecanismos de estado activo distintos conviviendo sin razón funcional (`.stat-type-chip`: opacidad + intensificación de color · `.stat-pri-chip`: `box-shadow` anillo genérico, sin reflejar el color semántico de la prioridad · `.stat-effort-card`: border+bg, ya el más cercano al target). SVG aprobado por founder (`unificacion_estado_activo_chips.svg`) ancla el mecanismo objetivo. AC de coherencia: mismo mecanismo en las tres — border 1.5px + fondo con tinte + texto en tono `-text` de su propia familia — sin cambiar color semántico.
- **`.stat-type-chip.active`:** agregado `border-width: 1.5px` (antes heredaba 1px de la base, sin cambio en activo). Mecanismo de color por tipo no cambia — ya usaba intensificación de background/border por `.tc-*`.
- **Fix de coherencia incluido — necesario para que "texto en tono -text" sea cierto en las 7 variantes de tipo:** `.tc-INC` y `.tc-REQ` usaban `color: var(--red)` / `var(--blue)` crudo (mismo anti-pattern ya corregido para `--accent`/`--amber`/`--purple` en `§Cambios mod:99`, no capturado en esa migración porque el regex ancló solo esos tres tokens) — migrados a `--red-text`/`--blue-text`, que ya existían y ya estaban en uso en `.tc-TKT`/`.tc-DISC`. `.tc-KE`/`.tc-CHG` usaban hex crudo (`#eab308`/`#94a3b8`) sin ningún token — migrados a `var(--yellow-text, #eab308)` / `var(--slate-text, #94a3b8)`, mismo patrón que `.tc-PRB` ya usaba (`var(--amber-text, #e8a832)`). Fallback preservado en los tres, mismo criterio que `§Cambios mod:99`. Solo la propiedad `color:` fue tocada — `background`/`border-color` de estas reglas no cambian. **Nota (mod:124):** la regla `.tc-KE` descrita aquí fue retirada por completo en TKT2/REQ CAEL-0724-11 — este párrafo describe el estado del selector mientras existió, no el estado vigente.
- **`.stat-pri-chip.active`:** reemplazado el `box-shadow: 0 0 0 2px var(--accent, var(--purple))` genérico por el mismo patrón ya establecido en `.filter-btn.active.f-high`/`.f-medium` (`§L.957-976`, mismo archivo) — `border-color`/`color` = token `-text` de la prioridad, `background` = token `-bg`. Tres variantes nuevas: `.active.pri-high` (`--c-high-text`/`--c-high-bg`), `.active.pri-medium` (`--c-medium-text`/`--c-medium-bg`), `.active.pri-low` (`--border2`/`--surface3`/`--text` — más oscuro que el reposo `--surface2`/`--text2` para quedar distinguible). Motivo del reemplazo: el anillo no reflejaba el color semántico de la prioridad activa — alto y medio activaban con el mismo anillo genérico.
- **`.stat-effort-card.active`:** agregado `border-width: 1.5px`. **Corrección de mismatch preexistente:** `background: var(--blue-dim)` no coincidía con `border-color: var(--accent)` ya declarado en la misma regla — azul vs. el verde-lima de `--accent`. Corregido a `background: var(--accent-dim)` / `border-color: var(--accent-border)`, mismo par de tokens que `.qinc-export-btn` ya usa para el estado activo de elementos con semántica accent (`§L.2334`). `.eff-label` suma `color: var(--accent-text)` + `font-weight: 500` en activo — antes solo `.sec-count` reaccionaba.
- **Sin tokens nuevos** — reuso exclusivo de `--red-text`/`--blue-text`/`--yellow-text`/`--slate-text`/`--c-high-text`/`--c-high-bg`/`--c-medium-text`/`--c-medium-bg`/`--border2`/`--surface3`/`--text`/`--accent-dim`/`--accent-border`/`--accent-text`, todos ya definidos y verificados WCAG en entradas previas de este doc.
- **`mod` de archivos reales:** `locus-backlog.css` mod:114→115 (Nova).

## Cambios (mod:100) — TKT-202607-041 (REQ CAEL-0720-02): fix gutter duplicado en `.bl-header-unified` / `.active-filter-chips`

- **Origen:** bug reportado por el founder en QA de TKT-202607-041 — el wrapper quedaba separado del borde del panel un gutter extra respecto a `#backlog-list`. Causa raíz: `margin-left: 12px` + `width: calc(100% - 12px)` en ambos selectores compensaba `.tpl-sidebar` (wrapper vertical Gen1), eliminado en `locus-proyectos.css` (REQ CAEL-01, ver `locus-proyectos.css:2060`). `#backlog-list` nunca tuvo ese margen — de ahí el desalineado.
- **Fix:** eliminado el `margin-left` huérfano en `.bl-header-unified` y `.active-filter-chips`, `width: 100%` — flush con `#backlog-two-col-wrap`, igual que el resto del contenido del panel.
- **Patrón corregido:** ver `### Barras sticky de contenedor (toolbar/stats)` — el patrón documentado ahí asumía compensación contra un sidebar que ya no existe. Reemplazado por la versión sin `margin-left`.
- **Alcance de esta entrada — no repite el patrón como anti-pattern retroactivo:** otros consumidores del patrón antiguo (`max-width` + `width:calc(100%-N)` + `margin-left:N` contra un sidebar inexistente) no fueron auditados en esta sesión — si aparecen desalineados, aplican el mismo diagnóstico.
- **`mod` de archivos reales:** `locus-backlog.css` mod:112→114 (Nova) — incluye también el fix de offset sticky (`top: calc(var(--header-h) + 1.95rem + 1px)`) de la misma sesión, no relacionado con este gutter.

## Cambios (mod:99) — REQ CAEL-0720-01: 296 usos crudos de color: var(--accent|--amber|--purple) migrados a -text

- **Origen:** Los tokens `--accent-text`/`--amber-text`/`--pink-text`/`--lime-text`/`--purple-text` ya estaban definidos y verificados con contraste WCAG AA (`§Cambios mod:95-98`) — pero su *uso* en la propiedad `color:` de los componentes seguía apuntando al token crudo en 19 archivos, 296 instancias. Esta entrada cierra ese gap de adopción — no crea tokens nuevos, no repite el trabajo de mod:96/mod:98.
- **Alcance del swap — anclado a la propiedad:** solo líneas que matchean `^\s*color:\s*var\(--(accent|amber|purple)[,)]`. `border-color`/`background`/`outline` con estos tokens no se tocan — siguen siendo válidos ahí, el problema de contraste es exclusivo de texto sobre fondo.
- **Desglose:** `--accent`→`--accent-text` 168 instancias / 17 archivos · `--amber`→`--amber-text` 99 instancias / 16 archivos · `--purple`→`--purple-text` 29 instancias / 10 archivos.
- **Fallbacks preservados:** el swap toca solo el primer argumento de `var()` — ejemplo `locus-historico.css:350`, `color: var(--accent, #38bdf8)` → `color: var(--accent-text, #38bdf8)`, fallback intacto.
- **`mod` de archivos reales:** `locus-analytics.css` mod:15→16 · `locus-backlog-item.css` mod:69→70 · `locus-backlog.css` mod:109→110 · `locus-contracts.css` mod:8→9 · `locus-docs.css` mod:4→5 · `locus-document-generator.css` mod:5→6 · `locus-historico.css` mod:7→8 · `locus-layout.css` mod:22→23 · `locus-modals-base.css` mod:16→17 · `locus-modals-misc.css` mod:6→7 · `locus-modals-toast.css` mod:3→4 · `locus-modals-tracker.css` mod:2→3 · `locus-proyectos.css` mod:13→14 · `locus-radar.css` mod:11→12 · `locus-sesiones-card.css` mod:11→12 · `locus-sesiones.css` mod:38→39 · `locus-sprint-close.css` mod:5→6 · `locus-sprint-ui.css` mod:11→12 · `locus-sprint.css` mod:59→60 (todos Nova).
- **Anti-pattern registrado:** `color: var(--accent|--amber|--purple)` crudo — deprecado. Usar siempre la variante `-text` para color de texto. Los tokens crudos siguen válidos en `border-color`/`background`/`outline` — el anti-pattern aplica exclusivamente a la propiedad `color:`.

## Cambios (mod:98) — REQ CAEL-0719-02 (TKT1+TKT2 done, TKT3+TKT4 bloqueados por datos obsoletos)

- **Origen:** Fix de los hallazgos de la auditoría de color (`PP-audit-color-tokens-Nova.md`, REQ CAEL-0719-01). Antes de ejecutar, re-verifiqué cada AC contra el codebase real adjunto en esta sesión — el codebase avanzó significativamente entre la auditoría original y esta ejecución (REQ CAEL-0720-01 ya corrió, css-ref pasó de mod:94 a mod:97).
- **TKT1 — ajuste de scope, no ejecutado como se especificó:** `--accent-text` **ya existía** (creado en `§Cambios mod:96`, REQ CAEL-0720-01) — la parte de accent del TKT quedó redundante, no se re-crea. Ejecutado solo lo que seguía faltando: `--amber-text`/`--pink-text`/`--lime-text` (alias directo en dark, ya pasaban; override oscurecido en light, medido con la misma fórmula WCAG que `--green-text`) y `--purple-text` (alias directo en light, ya pasaba; override aclarado en dark — patrón inverso, único caso del inventario). `.tc-5`/`.tc-6` (`locus-modals-misc.css`) migrados a los nuevos tokens — únicos 2 consumidores reales de pink/lime como texto.
- **Valores nuevos — contraste medido contra los 4 fondos estándar, ambos temas:** `--amber-text` light `#8b6009` (4.53:1 mínimo) · `--pink-text` light `#af4181` (4.62:1 mínimo) · `--lime-text` light `#4e7413` (4.70:1 mínimo) · `--purple-text` dark `#8b7bf7` (4.70:1 mínimo). Metodología: relative luminance WCAG 2.1, sin estimación.
- **TKT2 — ejecutado sin cambio de scope:** `.copy-item-btn` en `locus-sesiones.css` tenía 3 tokens sin declarar (`--surface-hover`, `--surface-active`, `--c-accent`) — colisión de naming con tokens reales. Corregido a `--surface2` (hover) / `--surface3` (active) / `--accent` (focus-visible), aplicando la regla ya documentada en este doc (`§1088` — "en código nuevo usar `--surface2` para hover, `--surface3` para active"), no una decisión nueva de Nova. `.copy-item-btn` en `locus-backlog-item.css` es un componente distinto (mismo nombre de clase, tamaño y comportamiento diferentes) que ya usaba tokens reales — no tocado, no relacionado.
- **TKT3 y TKT4 — bloqueados, devueltos a Cael. El AC de ambos parte de datos obsoletos:** re-verifiqué uso real de los 16 alias `--color-*`/legacy que el reporte de auditoría marcó como "0 usos" o "concentrados solo en `locus-sesiones.css`". Resultado contra el código real de esta sesión: **de los 16 marcados 0-uso en AC3, los 16 tienen al menos 1 uso real hoy** (rango 1–15 usos, la mayoría vía `var(--token, fallback)` — patrón que el grep original de Nova no capturó o que se agregó después). Ejemplo: `--color-border-tertiary` pasó de "0 usos" a 15, concentrados en `locus-document-generator.css` (un módulo que el reporte original describía como aislado en su propio scope `--mg-*`, y que evidentemente ya no lo es del todo). De los 5 alias que sí figuraban con uso real, el patrón "solo `locus-sesiones.css`" tampoco se sostiene — `--color-text`/`--color-border`/`--color-primary`/`--color-surface` ya se consumen también en `locus-document-generator.css`, `locus-backlog-item.css`, `locus-radar.css` y `locus-sprint-ui.css`. Ejecutar TKT3 (eliminar en bloque) habría roto `locus-document-generator.css` de forma activa — no se ejecuta sobre datos sin re-verificar. TKT4 (migrar solo `locus-sesiones.css`) dejaría el problema real (4+ archivos, no 1) sin resolver.
- **Único par confirmado como genuinamente sin uso, verificado en esta sesión:** `--correct` y `--warning` (capa legacy semántica, sin prefijo `color-`) — 0 usos reales cada uno. `--success`/`--error`/`--danger` (mismo grupo) sí tienen 1 uso real cada uno con fallback — el reporte original solo acertó en `--danger`. No se eliminó nada en esta sesión — devuelto a Cael para decidir si ese par de 2 tokens amerita un TKT de Effort 1 separado o se pliega a un TKT3 re-especificado.
- **`mod` de archivos reales:** `locus-base.css` mod:12→13 · `locus-modals-misc.css` mod:5→6 · `locus-sesiones.css` mod:34→35 (todos Nova).
- **Hallazgo fuera de scope — gap de changelog, mismo patrón que mod:78/mod:94:** el header real de `locus-sesiones.css` declaraba `mod:34` antes de esta sesión, pero la última entrada de este doc que menciona el archivo (`§Cambios mod:95`) documenta `mod:32→33` — 1 incremento sin registrar entre ambos. No investigado en esta sesión (fuera de scope de TKT1/TKT2) — señalado para que Cael o el founder decida si amerita sesión de verificación dedicada, mismo criterio que cerró el gap de mod:78.

## Cambios (mod:97) — Cierre de hallazgos post-REQ CAEL-0720-01

- **Hallazgo #1 (`locus-sprint-plan.css` → `locus-contracts.css` en ui-Inventory) — sin acción sobre este doc:** no aplica, vive en `_Locus-ui-Inventory.md`. Verificado ya resuelto ahí (mod:29) contra el ui-Inventory adjunto en esta sesión.
- **Hallazgo #2 (duplicación `#pepe-splash`) — sin acción sobre este doc:** vive en `locus-layout.css`/`locus-modals-tracker.css`, sin entrada dedicada aquí. Verificado ya resuelto (`locus-layout.css` mod:20) — cero intersección de selectores entre ambos archivos.
- **Hallazgo #3 (`.gconfirm-title`/`.gconfirm-modal` sin documentar, TKT1) — cerrado en este mod:** sección `§Confirmación de status — familia .status-confirm-*` reemplazada por `§gconfirm — shell de confirmación genérico unificado`, documentando la familia completa post-fusión (TKT1-4, REQ CAEL-0720-01) — incluye `.gconfirm-body-html` (nuevo), los 8 call sites conocidos, y la nota de comportamiento nuevo (cierre por click-fuera/Escape heredado, que `.status-confirm-*` no tenía).

## Cambios (mod:96) — REQ CAEL-0720-01 (Incidents export): token `--accent-text` nuevo + `.mg-output-check--incidents` (pasivo) + `.qinc-export-btn` (activo)

- **Origen:** TKT2 (AC6) y TKT3 (AC5) del REQ — checkbox de Incidentes en el Document Generator y botón "Exportar incidents.md" en `qinc-stats-bar`. Fase 5 de Finn corrigió el AC original para exigir tokens reales de este doc — el wireframe aprobado usaba `--bg-accent`/`--text-accent`/`--border-accent`, que no existen (mismo anti-pattern ya corregido dos veces, ver `.pill-project` CAEL-15 y `.blocker-chip` CAEL-30).
- **Tratamiento decidido:** checkbox = pasivo (`var(--surface3)`/`var(--text3)` — toggle entre iguales, no una acción). Botón de exportación = activo (`var(--accent-dim)`/`var(--accent-border)` + texto — acción directa, no toggle).
- **Token nuevo — `--accent-text`:** verificación de contraste antes de entregar detectó que `var(--accent)` directo como color de texto sobre `--accent-dim` da 2.32:1 en light theme — bajo WCAG AA, mismo gap ya resuelto para `--green-text`/`--blue-text`/`--red-text`. Se agregó `--accent-text` en vez de repetir el anti-pattern: dark = alias de `var(--accent)` (11:1 vs `--surface2`, ya AA); light = valor propio `#45700f` (5.53:1 vs `--surface2`, 5.11:1 vs `--surface`). Ver `§Tokens de color utilitarios`.
- **`mod` de archivos reales:** `locus-document-generator.css` mod:3→4 · `locus-backlog.css` mod:105→106 · `locus-base.css` mod:11→12 (todos Nova).
- Ver detalle de selectores en `### Document Generator — checkbox de Incidentes + qinc-stats-bar — botón de exportación (REQ CAEL-0720-01)`, bajo `## Patrones de componentes flotantes`.

## Cambios (mod:95) — Auditoría de contraste `--green` como texto: 71 instancias corregidas a `--green-text` en 12 archivos

- **Origen:** solicitud directa del founder tras cerrar `§Cambios (mod:94)` — verificar si el bug de contraste de `.mdiff-finnrelease-header`/`-check` (mod:94) era caso aislado o patrón repetido. Ejecutado en la misma sesión, no diferido a DISC — mismo criterio de la Excepción de resolución directa (dueño Nova presente, corrección mecánica de un valor de token ya definido y documentado, sin bifurcación de founder), extendido aquí a un batch de instancias en vez de una sola, dado que todas comparten exactamente el mismo diagnóstico ya verificado.
- **Verificación previa al fix — por qué las 71 son el mismo caso:** `--green` declara valores distintos por tema (`locus-base.css`: dark `#39e87c` línea 156, light `#1aab5a` línea 324) — mismo mecanismo de theming vía `data-theme` que ya falla contraste 4.5:1 en light (2.6–2.8:1 medido, documentado junto a la definición de `--green-text`). Se auditaron las 91 ocurrencias totales de la cadena `var(--green)` en los 12 archivos identificados; se aisló mecánicamente (regex ancla de propiedad, no de cadena) la propiedad `color:` de `border-color:`/`background:` — estas últimas no comparten el problema de contraste texto-sobre-fondo y quedaron sin tocar. Resultado: 71 declaraciones `color: var(--green)` en 12 archivos, cero con override de tema propio que las eximiera del gap ya documentado.
- **Fix aplicado — mecánico, sin cambio de fondo/borde:** las 71 instancias pasan de `color: var(--green)` a `color: var(--green-text)`. Ninguna declaración de `background`/`border-color`/`border-left-color` en las mismas reglas fue tocada — el fix es exclusivo de la propiedad de texto, mismo criterio que Cluster B (`--orange-text`/`--yellow-text`/`--slate-text`) y el propio `--green-text` ya establecen.
- **Archivos y conteo de instancias corregidas:** `locus-analytics.css` (1) · `locus-backlog-item.css` (18, incluye las 2 de `mod:94`) · `locus-backlog.css` (9) · `locus-contracts.css` (4) · `locus-modals-misc.css` (3) · `locus-modals-toast.css` (3) · `locus-proyectos.css` (3) · `locus-radar.css` (1) · `locus-sesiones-card.css` (2) · `locus-sesiones.css` (20) · `locus-sprint-close.css` (4) · `locus-sprint.css` (3).
- **Fuera de scope de este fix — sin tocar:** el gap de contraste ya registrado y explícitamente diferido para `--blue`/`--red` crudos en `.item-type-pill`/`.ct-pill-*` (ver `§Colores declarados`, nota "Registrado como DISC por Nova — no se corrige en este TKT, fuera de scope") — ese hallazgo sigue en DISC, no se resolvió como parte de esta auditoría porque no fue el que el founder pidió verificar. No confundir ambos: `--green`→`--green-text` ya resuelto en su totalidad en este mod; `--blue`/`--red` crudo sigue pendiente.
- **`mod` de archivos reales:** `locus-analytics.css` mod:11→12 · `locus-backlog-item.css` mod:65→66 (ya reflejado en mod:94, este mod no vuelve a incrementarlo) · `locus-backlog.css` mod:104→105 · `locus-contracts.css` mod:7→8 · `locus-modals-misc.css` mod:4→5 · `locus-modals-toast.css` mod:2→3 · `locus-proyectos.css` mod:10→11 · `locus-radar.css` mod:8→9 · `locus-sesiones-card.css` mod:10→11 · `locus-sesiones.css` mod:32→33 · `locus-sprint-close.css` mod:3→4 · `locus-sprint.css` mod:57→58 (todos Nova).

## Cambios (mod:94) — Gap de contrato cerrado: `.mdiff-finnrelease-*` nunca se implementó en mod:78 + fix de contraste aplicado en la misma sesión

- **Origen:** Verificación contra código real (`locus-backlog-item.css`) solicitada en sesión — la entrada de `§Cambios (mod:78)` de este doc declaraba `.mdiff-finnrelease-*` como implementado (`mod:56→57`, Nova), pero el archivo real no tenía ninguna de esas 8 clases hasta `mod:65` (2026-07-18) — casi 6 mods después, vía un fix de hallazgo post-cierre de REQ CAEL-0718-01, sin relación con el ciclo original de TKT2. El propio comentario de header de `mod:65` en el archivo lo confirma explícitamente: *"nunca tuvo CSS propio desde su entrega original"*.
- **Naturaleza del gap:** `type: gap_contrato` de facto — un DOC-UPDATE se declaró `aplicado` sobre un cambio de CSS que no llegó al archivo real. Nadie detectó la ausencia en el ciclo de QA de TKT2 original porque el AC verificable de ese TKT era JS (`_ckptMeta.finnRelease` + `_buildFinnReleaseSection()`), no el CSS en sí — el bloque visual simplemente no se veía estilado hasta que un hallazgo posterior lo notó.
- **Discrepancia de token — corregida, no solo documentada:** `mod:78` documentaba `--green-text` como token reusado (línea de "Sin tokens nuevos"). La implementación real de `mod:65` usó `--green` crudo en `.mdiff-finnrelease-header` y `.mdiff-finnrelease-check` — falla contraste 4.5:1 en light theme (`--green` sin corregir mide 2.6–2.8:1 contra `--surface3`/`--surface2`/`--bg2`, mismo gap ya documentado y resuelto para Cluster B — ver `§Colores declarados .ct-pill-*`). **Hallazgo fuera de scope resuelto en la misma sesión** (dueño Nova presente, nivel Patch, sin bifurcación de founder): `mod:66` corrige ambos selectores a `--green-text` — fondo/borde del check (`--green-dim`/`--green-border`) sin cambio, solo el texto necesitaba el override de contraste.
- **Selectores sin cambio respecto a `mod:65`:** `.mdiff-finnrelease-section` (borde), `.mdiff-finnrelease-probado` (layout), `.mdiff-finnrelease-check-icon` (peso de fuente), `.mdiff-finnrelease-docs-wrap/-label/-list` (`--amber` para la etiqueta, coincide con lo documentado en `mod:78`) — ninguno de estos usaba `--green` crudo, sin problema de contraste.
- **Propuesta de mejora — proceso, no CSS (destino Cael):** un DOC-UPDATE no debería declararse `aplicado` sin que Rune confirme `mod` real del archivo tocado en el mismo ciclo — este gap sobrevivió ~40 mods sin detectarse porque nadie cruzó el `mod` declarado en `§Cambios (mod:78)` contra el header real del archivo hasta esta sesión. Registrado para evaluación de Cael — no corregido en esta entrada, es proceso.
- **`mod` de archivos reales:** `locus-backlog-item.css` mod:65→66 (Nova).

## Cambios (mod:93) — revierte mod:92: `.rsb-hdr-session`/`.rsb-hdr-dot` vuelven a ámbar — coherencia total de "en sesión"

- **Origen:** founder revirtió explícitamente la decisión de mod:92 — instrucción directa en sesión de que el pill de conteo "en sesión" y su dot deben seguir ámbar, no púrpura.
- **Hallazgo fuera de scope resuelto en la misma sesión (dueño presente, Patch, sin bifurcación):** al verificar contra código real (`locus-sesiones-card.css` mod:10, `locus-sesiones.css` mod:32) para este TKT, se confirmó que ambos archivos ya tenían aplicado el swap insession→ámbar desde `CAEL-0717-0X` — `.sc-avatar--insession`, `.sc-badge--insession` y `.worker-header--insession` (+ pulso) ya usaban `var(--amber)`. La entrada de mod:91 y anteriores no reflejaba este estado — este doc quedó desactualizado respecto al código real en esos dos archivos, sin relación con el fix de `.rsb-hdr-session` de mod:92. Ningún archivo requirió cambio por este hallazgo — solo se corrige la documentación.
- **Fix aplicado en `locus-radar.css`:** `.rsb-hdr-session` (fondo + texto) vuelve a `var(--amber)` en ambos temas — dark: `background: rgb(245 158 11 / 12%)`, `color: var(--amber)`; light: `background: rgb(212 146 14 / 10%)`, `color: var(--amber)`. El color-mix a `--purple` introducido en mod:92 se retira.
- **`.rsb-hdr-dot` re-acoplado al color del pill** — vuelve a `var(--amber)` en ambos temas, mismo patrón que `.rsb-hdr-available`/`.rsb-hdr-exhausted` (el dot hereda el acento del estado, no un gris neutro). El desacople a `var(--text3)` introducido en mod:92 se retira, junto con el recálculo de `box-shadow` de `rsb-dot-pulse`/`rsb-dot-pulse-light` a RGB de `--text3` — el pulso vuelve al RGB de `--amber`.
- **Sin cambio:** `.rsb-card.in-session-state` y `.rsb-ckpt-direct-btn` — ya estaban en `var(--amber)`, sin tocar. `.rsb-hdr-available`/`.rsb-hdr-exhausted` sin modificación.
- **Resultado:** "en sesión" queda ámbar en los 5 puntos de la app — card, CTA, pill de conteo + dot, avatar, badge, worker-header + pulso.
- **Archivos:** `locus-radar.css` mod:7→8 (Nova).

## Cambios (mod:92) — `.rsb-hdr-session`/`.rsb-hdr-dot` desincronizados entre temas tras el swap de `locus-radar.css` mod:6

- **Origen:** founder señaló (screenshot sidebar Workers, light theme) que el pill de conteo "X en sesión" debía quedar púrpura y su dot gris — pedido puntual, sin REQ formal previo, resuelto vía TKT Effort 1 Fast Track.
- **Gap encontrado en Fase 5 (Finn):** el swap semántico insession↔interrupted (`locus-radar.css` mod:6, CAEL-0717-0X) migró `.rsb-hdr-session`/`.rsb-hdr-dot` a ámbar solo en el bloque dark theme (default) — el override `:root[data-theme="light"] .rsb-hdr-session` quedó con el púrpura hardcoded (`#7c3aed`/`rgb(124 58 237 / …)`) previo al swap, sin migrar. Los dos temas mostraban selectores con intención distinta sin que ningún changelog lo documentara como decisión consciente — inconsistencia no detectada hasta esta sesión.
- **Fix aplicado — no es reversión del swap de mod:6:** `.rsb-hdr-session` (fondo + texto) vuelve a `var(--purple)` en **ambos** temas — dark vía `color-mix(in srgb, var(--purple) 10%, transparent)`, light vía `color-mix(in srgb, var(--purple) 8%, transparent)` (reemplaza el hex hardcoded, mismo valor visual — `--purple` light = `#7c3aed`, coincidencia exacta verificada contra `§Tokens de color`). El hardcode se retira, sin cambio de valor perceptible.
- **`.rsb-hdr-dot` desacoplado del color del pill (decisión nueva, no existía antes del swap):** pasa a `var(--text3)` en ambos temas — gris terciario, no repite el acento del pill (evita doble señal de color redundante dentro de la misma pastilla). Keyframes `rsb-dot-pulse`/`rsb-dot-pulse-light` actualizados — `box-shadow` del pulso recalculado al RGB de `--text3` (`rgb(134 139 184 / …)` dark · `rgb(90 97 146 / …)` light) en vez del RGB previo del acento (ámbar dark / púrpura light).
- **Sin cambio — fuera de scope de este TKT:** `.rsb-card.in-session-state` (card del worker en sesión) y `.rsb-ckpt-direct-btn` (CTA de checkpoint directo) — ambos siguen `var(--amber)`, intactos en sus 3 declaraciones en el archivo. El ajuste es exclusivo del pill de conteo del header — la card y el CTA no comparten selector ni intención de color con `.rsb-hdr-session`.
- **Archivos:** `locus-radar.css` mod:6→7 (Nova).

## Cambios (mod:91) — cierra el `Hallazgo fuera de scope` de mod:85: CSS Purity violado en 3 archivos

- **Origen:** Cael evaluó INC vs DISC sobre el hallazgo de mod:85 (`locus-sprint-ui.css`, `locus-modals-toast.css`, `locus-modals-tracker.css` con `autor:Rune` en header) — clasificado como Rama Planeada (no interrumpe producto en producción), especificado directo como REQ-corregir-css-purity / TKT1+TKT2, sin pasar por Q-DISC.
- **Auditoría de contenido (Nova):** dos naturalezas distintas confirmadas contra código real —
  - `locus-modals-toast.css` / `locus-modals-tracker.css`: split mecánico de `locus-modals.css` mod:7 (TKT1 de REQ split, 2026-07-05) — un único header (`mod:1`), nunca vuelto a tocar, sin decisión de estilo nueva. TKT1: header corregido a `autor:Nova`, contenido adoptado sin cambios.
  - `locus-sprint-ui.css`: violación real y activa — `mod:8`/`mod:9` (2026-07-17, mismo REQ CAEL-0717-01) introdujeron `.bl-plan-card--done`/`.bl-plan-done-group/header/body` con decisiones de estilo propias (`background: var(--surface2)`, `border-top: var(--border2)`) sin Nova. TKT2: founder decidió adoptar tal cual — correcto contra tokens vigentes, sin colisión con el sistema de diseño. Header corregido a `autor:Nova` (`mod:10`), `mod:8`/`mod:9` conservados como registro histórico.
- **Gap de proceso señalado, no resuelto en este mod:** `REQ CAEL-0717-01` avanzó 2 TKTs consecutivos de CSS sin consulta a Nova en Fase 1 (`__BR-Execution §1`) — el REQ tocaba UI y el protocolo de especificación de Cael no lo detectó. Registrado como `Propuesta de mejora` a Cael para revisión del gate de Fase 1, no corregido en esta entrada — es proceso, no CSS.
- **Archivos:** `locus-modals-toast.css` mod:1→2 · `locus-modals-tracker.css` mod:1→2 · `locus-sprint-ui.css` mod:9→10 (todos Nova).

## Cambios (mod:90) — TKT1 (REQ CAEL-0718-01): mismo patrón full-bleed extendido a `#tab-proyectos` — variante asimétrica

- **Origen:** founder confirmó (screenshot + inspector DevTools) que `#tab-proyectos` tiene el mismo problema que `#tab-backlog` — `.spt-nav`/`#proj-doc-actions` (mismos componentes, reutilizados vía migración documentada en `index.html`) no llegan a los bordes.
- **Diferencia clave:** `#tab-proyectos` solo declara `padding-left: var(--subtab-gutter)` (12px) — asimétrico, no `--gutter-shell` (24px, ambos lados) como Backlog. Fix: `margin-left` únicamente, no `margin-inline` — cancelar un lado sin padding real introduciría overflow.
- **Sección `### Full-bleed dentro de contenedor con gutter heredado` extendida** con la variante asimétrica — mismo patrón, regla general añadida: el margin negativo debe reflejar exactamente qué lados tienen padding en el contenedor.
- **Archivos:** `locus-backlog.css` mod:100→101 (Nova).

## Cambios (mod:89) — TKT1 (REQ CAEL-0717-01): `#tab-backlog .tpl-sidebar-actions` / `.spt-nav` full-bleed — patrón nuevo de escape de gutter heredado

- **Origen:** founder señaló que toolbar y `.spt-nav` de `#tab-backlog` debían ir full-bleed como el header; `.tpl-detail` conserva su gutter. AC-1 original de Cael referenciaba `#tpl-toolbar` — ID inexistente en CSS (selector real `.tpl-sidebar-actions`); corregido en sesión (evidencia nueva: archivos reales no estaban adjuntos al especificar/avalar).
- **Fix:** `margin-inline: calc(-1 * var(--gutter-shell))` en ambos selectores (scope `#tab-backlog .selector`) — cancela el padding heredado de `#tab-backlog` sin tocar el padding propio de cada elemento (que ya funcionaba como gutter de contenido) ni el padding del contenedor. `.tpl-detail` sin cambio.
- **Nueva sección `### Full-bleed dentro de contenedor con gutter heredado` en `§Patrones de layout`** — documenta el patrón para reuso. Corrige nota de mod:88 sobre `.tpl-sidebar-actions` y `--gutter-shell` (seguía siendo cierta para padding propio, incompleta tras este TKT).
- **Archivos:** `locus-backlog.css` mod:99→100 (Nova).

## Cambios (mod:88) — TKT1 (REQ CAEL-0717-02): consolidación de gutters horizontales — token `--gutter-shell` (24px) + reuso de `--subtab-gutter` (12px) en modal de ingesta

- **Origen:** auditoría de gutters solicitada por el founder en esta sesión — 4 valores hardcoded (12/18/24/32px) sin escala común, 3 sin token. Opción A aprobada (escala de 2 tiers) sobre Opción B (solo documentar sin tocar CSS).
- **Token nuevo — `--gutter-shell: 24px`** (`:root`, `locus-base.css` mod:11, junto a `--subtab-gutter`). Retira `--split-viewport-gutter` (mod:87, introducido y retirado en el mismo sprint — sin período de gracia, `__BR-Execution §2`): `.modal-overlay.modal-split` (`padding-left`) y `--split-total-w` en sus 3 variantes (`locus-modals-base.css`) pasan a consumir `--gutter-shell` directamente.
- **`#tab-analytics`** (`locus-analytics.css`) — `padding: 2rem` (32px hardcoded) → `padding: 2rem var(--gutter-shell)`. Solo el eje horizontal migra.
- **`#tab-backlog`** (`locus-backlog.css`) — `padding: 0 2rem 2rem` → `padding: 0 var(--gutter-shell) 2rem`. Reemplaza la nota anterior de esta misma sección (mod:87 y previas) que documentaba el 32px como "no requiere el token" — esa nota es anterior a la existencia de `--gutter-shell`, quedó obsoleta con esta entrega.
- **Modal de ingesta (`.modal--ingest`, `locus-modals-base.css`)** — `.ingest-modal-header`, `.ingest-modal-columns`, `.ingest-modal-actions` y el par `.ingest-modal-meta`/`.ingest-validation-panel`: `18px` hardcoded → `var(--subtab-gutter)` (12px) en los 5 selectores. Decisión ampliada en sesión: migrar solo el par original (`.ingest-modal-meta`/`.ingest-validation-panel`) sin tocar `.ingest-modal-columns` habría desalineado el cuerpo del modal contra su propio header/footer (los tres ya compartían 18px) — se migran las 4 secciones juntas para preservar alineación interna del modal.
- **No incluye:** no toca `--split-gap`/`--split-header-h` (`.modal-split*`, familia distinta) ni `.tpl-sidebar-actions` (padding de toolbar, coincidencia de valor 24px casual, no gutter de página).
- **Escala resultante:** 2 tiers — `--subtab-gutter` (12px) y `--gutter-shell` (24px) — ver `§Patrones de layout` → `### Gutter de shell/viewport completo` (nueva sección) y `### Gutter unificado de subtabs` (actualizada).
- **Archivos:** `locus-base.css` mod:10→11 · `locus-modals-base.css` mod:11→12 · `locus-analytics.css` mod:10→11 · `locus-backlog.css` mod:98→99 (todos Nova).
- **`§Arquitectura de módulos CSS`:** filas 1, 3, 13, 14 actualizadas — `mod` + conteo de líneas reverificado con `wc -l` contra los archivos reales de esta sesión.

## Cambios (mod:87) — TKT1 (REQ CAEL-0717-01): `.msc-diff-empty` (empty state del socket de revisión) + `--split-viewport-gutter` — reaplicado sobre la base mod:86

- **Origen:** entrega de Nova sobre `locus-modals-base.css` (mod:11) trabajada en paralelo a la auditoría de arquitectura del founder (mod:85→86, ver abajo) — mismo archivo, sesiones distintas. Reaplicado sobre esta base sin conflicto: la auditoría tocó `§Prefijos de módulo` y `§Patrones de componentes flotantes` de otras familias, no la familia `.modal-split*`.
- **Empty state del socket `.modal-split__col--diff`:** el socket quedaba vacío sin indicación visual mientras `#merge-diff-overlay` no tenía `.mdiff-overlay--docked` (previo a procesar batch o paste único). Clases nuevas — `.msc-diff-empty` / `.msc-diff-empty-icon` / `.msc-diff-empty-title` / `.msc-diff-empty-hint` — mismo patrón dashed-border ya canónico en `.scm-du-empty`/`.qc-empty` (ver `§Sprint close modal` y `§Quick Capture`), sin clase nueva de familia. Ver filas nuevas en la tabla de `§Cambios (mod:79)` — extendida en el mismo lugar donde vive la tabla canónica de `.modal-split*`.
- **Ocultamiento sin JS nuevo:** `#merge-diff-overlay.mdiff-overlay--docked ~ #ingest-modal-overlay .msc-diff-empty { display: none }` — selector de hermano general contra la clase que Rune ya aplica/retira vía `classList` en `showMergeDiffPanel()` (mod:79). No se tocó ninguno de los 4 call sites JS (`locus-session-save.js`, `locus-session-parse.js` ×2, `locus-sesiones.js`, `locus-modals.js`).
- **Token nuevo — `--split-viewport-gutter: 24px`** (`:root`, `locus-modals-base.css`, junto a `--split-total-w/-h/-gap/-header-h`). `.modal-overlay.modal-split` pasa de `padding-left: 0` (borde real, mod:84) a `padding-left: var(--split-viewport-gutter)`. `--split-total-w` resta `var(--split-viewport-gutter) * 2` en sus tres variantes (`:root`, `body.radar-sb-open`, `body.radar-sb-collapsed`) — con sidebar cerrada, el borde derecho de `.modal-split__col--diff` queda a 24px del borde derecho del viewport, simétrico al margen izquierdo.
- **No incluye:** no modifica `--split-gap`/`--split-header-h`, la proporción 1/3-2/3 entre columnas, ni el mecanismo de docking (`mdiff-overlay--docked`) documentado en mod:79/83.
- **Fuente adicional consultada por Finn en Fase 5:** `index.html` real (orden DOM — `#merge-diff-overlay` antes de `#ingest-modal-overlay`, ambos hijos del mismo contenedor raíz, condición necesaria para que el selector de hermano general resuelva) + los 4 call sites JS de `mdiff-overlay--docked` — confirmó que ninguno requería cambio.
- **Archivos:** `index.html` mod:141 (Rune) · `locus-modals-base.css` mod:10→11 (Nova).
- **`§Arquitectura de módulos CSS`, fila 14:** `mod:10` → `mod:11`. Conteo de líneas de esa fila (1151) sin reverificar contra el archivo real en esta sesión — pendiente de confirmar con `wc -l` en la próxima auditoría que toque este archivo.

## Cambios (mod:86) — cierra el `Hallazgo fuera de scope` de mod:85: `§Prefijos de módulo` y `§Patrones` reconciliados contra los 21 archivos reales

- **Origen:** `Propuesta de mejora` de mod:85, aceptada por el founder en la misma sesión — continuación directa de la auditoría de arquitectura.
- **`§Prefijos de módulo` corregido:** filas `plan-`/`acv-`/`ctr-`/`arch-`→`historico-`/`pend-`/`viz-`/`ckpt-`/`promote-`/`ie-` — todas referenciaban `locus-sprint-plan.css`, `locus-archive.css` o `locus-modals.css` (inexistentes post-rename/post-split). Reemplazadas con los archivos reales, verificados con grep contra el zip.
- **Hallazgo mayor — `plan-` no era solo problema de archivo:** la familia original de la Sub-tab Plan (`.plan-*` documentada como "Execution Plan — sesiones y sprints") fue eliminada del codebase en TKT-202607-053/067 (confirmado por comentario en `locus-contracts.css:5`). El prefijo `plan-` que existe hoy es una familia distinta y sin relación — `.plan-scope-*`/`.plan-zone-*`/`.plan-sessions-row` en `locus-sprint-ui.css` (Vista Planificación) y `.plan-file-pill--broken` en `locus-sesiones.css`. Misma corrección aplicada en `§Patrones de componentes flotantes` → `### Execution Plan sessions`.
- **`§Patrones de componentes flotantes` corregido:** tabla de comportamiento compartido de modales (`locus-modals.css` → `locus-modals-base.css`), drawer `.pend-overlay` (`locus-modals.css` → `locus-modals-misc.css`), `tag-color-fixed` de `.tc-0`-`.tc-7` (`locus-modals.css` → `locus-modals-misc.css`).
- **Hallazgo mayor — `### Divisor de zona` documentaba selector inexistente, no solo archivo incorrecto:** `.arch-zone-divider` no existe en el codebase — el rename `arch-*`→`historico-*` (mod:22 de `locus-historico.css`) alcanzó también al selector, no solo al archivo. Selector real: `.historico-zone-divider` (`locus-historico.css:470`). Sección reescrita completa.
- **`§Selectores Gen 1` — 7 filas marcadas como migración completada (no pendiente):** `.arch-row-type--*` (4 filas) y `.spl-type--*` (3 filas) ya están implementadas en su forma Gen 2 en el codebase real — confirmado por grep. La tabla las presentaba como trabajo pendiente de Rune; quedan tachadas y marcadas `✅` para no generar TKT de migración sobre algo ya hecho, conservadas como registro histórico de la migración.
- **Hallazgos nuevos, no resueltos en esta entrada — registrados para sesión de continuación:**
  - `.ctr-layout`/`.ctr-search`/`.ctr-body` (3 reglas) existen tanto en `locus-contracts.css` (canónico) como en `locus-proyectos.css` — sin confirmar si es dead code en `locus-proyectos.css` o duplicado activo.
  - `.ie-body` declarada dos veces — calificada en `locus-sesiones.css:2978` (`#item-editor-overlay .ie-body`) y sin calificar en `locus-modals-misc.css:1975` (`.ie-body`). Sin auditar cuál gana en cascada o si una es dead code.
  - `.promote-modal-info` (`locus-backlog-item.css`) vs familia `.promote-modal*` (`locus-backlog.css`) — mismo patrón, no confirmado si es intencional (variante) o duplicado.
  - `Propuesta de mejora`: TKT de auditoría de las 3 colisiones/duplicados arriba — destino Nova + Rune (verificar consumo real vía grep de call sites JS antes de retirar cualquiera).
- **`mod` de archivo real:** ninguno — esta sesión solo actualiza el Doc Ref.

## Cambios (mod:85) — Auditoría de arquitectura CSS completa: tabla de 17 archivos (desactualizada) reemplazada por los 21 reales

- **Origen:** `Hallazgo fuera de scope` registrado al aplicar el DOC-UPDATE de mod:84 — la tabla de `§Arquitectura de módulos CSS` seguía declarando `locus-modals.css` como archivo único (4264 líneas) pese a que el split a 5 archivos (`locus-modals-base/-toast/-tracker/-editor/-misc`) ya estaba vigente en código desde varias entradas anteriores de este mismo changelog (mod:67, mod:74, mod:78...). Founder aprobó ejecutar la auditoría en esta sesión.
- **Método:** `index.html` real (21 `<link rel="stylesheet">`, L118-138) + los 21 `.css` reales del ZIP — orden de carga, línea por línea (`wc -l`) y header de identidad (`mod`/`autor`) de cada archivo, verificados uno a uno. Tabla reemplazada completa — ver `§Arquitectura de módulos CSS`.
- **Renames confirmados y reflejados:** `locus-sprint-plan.css` → `locus-contracts.css` (pos. 7) · `locus-archive.css` → `locus-historico.css` (pos. 9) · `locus-modals.css` → split en 5 (pos. 14-18).
- **Hallazgo nuevo — CSS Purity violado:** 3 archivos (`locus-sprint-ui.css`, `locus-modals-toast.css`, `locus-modals-tracker.css`) declaran `autor:Rune` en su header de identidad — contradice la regla dura de `__BR-Execution §3`/`__Role-Nova`. Documentado en la tabla y como `Hallazgo fuera de scope` — no resuelto en esta entrada, requiere que Cael evalúe INC vs DISC antes de que Nova audite el contenido real de esos 3 archivos.
- **Fuera de scope de esta auditoría — drift adicional detectado pero no corregido en esta entrada, cerrado en mod:86:** `§Prefijos de módulo` y varias entradas de `§Patrones de componentes flotantes` seguían referenciando `locus-sprint-plan.css`, `locus-archive.css` y `locus-modals.css` sin split. Ver mod:86 para la reconciliación completa.
- **`mod` de archivo real:** ninguno — esta sesión solo actualiza el Doc Ref, no toca `.css` reales.

## Cambios (mod:84) — TKT (REQ CAEL-0716-02): split view full-viewport — sin bandas vacías, reactivo a header/footer/sidebar

- **Origen:** wireframe aprobado por el founder — el split view (`.modal-split`/`.mdiff-overlay--docked`, familia mod:79/83) usaba tamaño fijo centrado (`min(1800px,92vw) × min(960px,88vh)`) dejando espacio del viewport sin usar. Done cuando: el split ocupa el 100% del área real entre header, sidebar derecha y footer — sin JS nuevo.
- **Token nuevo — `--footer-h: 28px`** (`:root`, `locus-base.css`, junto a `--header-h`). Mide `#global-footer` completo — `height:28px` + `border-top:1px` incluido por `box-sizing:border-box` global (`locus-layout.css`), no se suma aparte.
- **`--split-total-w`/`--split-total-h` — de valores fijos a reactivos (`:root`, `locus-modals-base.css`):**
  - `--split-total-h: calc(100vh - var(--header-h) - 1.95rem - 1px - var(--footer-h))` — resta el offset real del header (`--header-h` mide solo `.header-inner`; el `<header>` real suma `1.95rem + 1px` de padding/border encima — mismo cálculo ya usado en `.tab-panel.active`, `locus-layout.css`) y `--footer-h`.
  - `--split-total-w: 100vw` por default; recalculado completo bajo `body.radar-sb-open`/`.radar-sb-collapsed` — mismo mecanismo reactivo que `#global-footer` (`locus-radar.css`), sin JS nuevo: `var(--split-total-w)` se hereda por el árbol DOM y todo `calc()` que lo consume (dialog, header compartido, columna diff, panel docked) recibe el valor nuevo automáticamente.
  - `--split-gap`/`--split-header-h` sin cambio (18px / 60px).
- **`.modal-overlay.modal-split` — de centrado a anclado:** `padding-top`/`padding-left` dejan de centrar contra `(100vh/100vw - total)/2` — ahora `padding-top: calc(var(--header-h) + 1.95rem + 1px + var(--split-header-h))` (arranca justo bajo el header real + header propio del split) y `padding-left: 0` (borde izquierdo real, ya no centrado).
- **Fix de raíz — desfase de `--split-gap/2` en `.mdiff-overlay--docked`:** `padding-left` usaba `+ var(--split-gap)` (gap completo) desde su implementación original (mod:79) — inconsistente con `.modal-split__col--diff`/`.modal-split__divider` (mismo archivo de origen, `locus-modals-base.css`), que ya asumían `+ var(--split-gap)/2`. Con el split fijo el bug era cosmético (9px de más dentro de bandas vacías); con full-viewport el panel real sobrepasaba `--split-total-w` y caía bajo el sidebar cuando estaba abierto. Corregido a `+ var(--split-gap) / 2` — alineado con la decorativa del mismo REQ, sin bifurcación (un solo camino correcto).
- **Archivos:** `locus-base.css` mod:10 · `locus-modals-base.css` mod:10 · `locus-backlog-item.css` mod:62.
- **No incluye:** transición animada al redimensionar por cambio de sidebar — `--split-total-w` se recalcula instantáneo, a diferencia de `margin-right`/`right` (0.35s) que sí anima en `body.radar-sb-open`/`#global-footer`. Registrado como DISC — mejora puntual, no AC de este REQ.

## Cambios (mod:83) — corrige mod:79: `.mdiff-overlay--docked` no ganaba en cascada — selector calificado + z-index real corregido

- **Origen:** Hallazgo de Rune (auditoría de modales de ingesta) — Screenshot mostraba `#merge-diff-overlay` como modal centrado con backdrop propio en vez de dockeado contra `#ingest-modal-overlay`. Causa raíz: `.mdiff-overlay--docked` (especificidad 0,1,0, `locus-backlog-item.css`) y `.modal-overlay` (especificidad 0,1,0, `locus-modals-base.css`, cargado después en `index.html`) empatan en especificidad — gana la regla cargada más tarde en el cascade, sin importar qué clase se agregó después vía JS. `.modal-overlay` sobrescribía `background`/`justify-content`/`align-items` de `.mdiff-overlay--docked`.
- **mod:79 quedaba parcialmente incorrecto — no solo desactualizado:** esa entrada documentó el fix de `z-index` como "resuelto en CSS... fija `z-index: var(--z-modal-plus)` explícitamente" y afirmó que antes del fix `#merge-diff-overlay` "ya computaba 900 por orden de carga". Ambas afirmaciones asumían que el empate de especificidad se resolvía a favor de `.mdiff-overlay`/`.mdiff-overlay--docked` (archivo cargado antes) — es al revés: gana la regla cargada **después** (`.modal-overlay`, `locus-modals-base.css`). El z-index declarado (`var(--z-modal-plus)` = 600) nunca ganaba tampoco — mismo bug de especificidad, no solo las cuatro propiedades visuales. No se detectó antes porque el resultado accidental (backdrop de `.modal-overlay` ganando) coincidía visualmente con "algo se ve", aunque no dockeado.
- **Fix — selector calificado:** `.mdiff-overlay--docked` → `#merge-diff-overlay.mdiff-overlay--docked` (especificidad 1,1,0) — gana sobre `.modal-overlay` (0,1,0) sin depender del orden de `<link>`, mismo criterio ya usado en `.worker-header.worker-header--exhausted` (ver mod:74). Verificado (Rune, grep del codebase completo): `#merge-diff-overlay` es el único consumidor de esta clase — sin pérdida de cobertura al calificar.
- **Fix — z-index real:** `var(--z-modal-plus)` (600) → `calc(var(--z-overlay) + 1)`. `#ingest-modal-overlay` (`.modal-overlay.modal-split`, sin override propio de `z-index`) hereda `var(--z-overlay)` (900) de `.modal-overlay` base — 600 quedaba por debajo, el backdrop full-viewport del ingest pintaría sobre el panel docked una vez corregida la especificidad. No se introduce token nuevo en la escalera de `locus-base.css` — no hay hueco nombrado entre `--z-overlay` (900) y `--z-toast` (1000) para "sobre overlay base", mismo patrón semántico que `--z-modal-plus` ya usa para "sobre modal base".
- **Sin cambio de arquitectura:** `--split-total-w/-h/-gap/-header-h`, la ausencia de backdrop propio en `.mdiff-overlay--docked`, y el consumo desde JS (`classList.add/remove('mdiff-overlay--docked')`, sin cambio) siguen siendo la decisión vigente de mod:79 — esta entrada corrige únicamente el mecanismo de especificidad y el valor de z-index, no el diseño del split.
- **Archivo:** `locus-backlog-item.css` mod:59.

## Cambios (mod:82) — A-08 de `_Locus-ux-ref` (mod:24): 2 colisiones de selector-base cerradas + `letter-spacing` de eyebrow unificado

- **Origen:** auditoría cross-CSS de los 21 archivos reales (fuera de sesión de TKT), documentada en `_Locus-ux-ref` mod:24 junto con la definición de los 4 niveles canónicos de jerarquía (A-08). Esta entrada cubre la parte de implementación — los selectores concretos tocados en `_Locus-css-ref`.
- **Colisión 1 — `.bitem-title`:** declarado en `locus-backlog.css:5528` (`13px` hardcoded / `400`) y en `locus-backlog-item.css:248` (`var(--text-base)` / `500`). Mismo selector base, misma especificidad — el orden de `<link>` en `index.html` (`locus-backlog.css` en línea 120, `locus-backlog-item.css` en línea 121) hace que la segunda declaración gane siempre en cascada. La de `locus-backlog.css` era código muerto invisible. **Retirada** la declaración de `locus-backlog.css:5528` — `.bitem-title` vive únicamente en `locus-backlog-item.css`, valor vigente `var(--text-base)` (13px) / `500`, alineado a Nivel 3 — Card title de A-08 salvo por el peso (A-08 pide `600` para Nivel 3; `.bitem-title` queda documentado como excepción de deuda, ver nota abajo).
- **Colisión 2 — `.mdiff-right-section-title`:** declarado en `locus-backlog-item.css:3790` (`var(--text-xs)` / `700`) y en `locus-modals-misc.css:534` (`var(--text-2xs)` / `600`). `locus-modals-misc.css` carga después (línea 135 vs 121) — gana esa declaración. **Retirada** la declaración de `locus-backlog-item.css:3790` — selector vive únicamente en `locus-modals-misc.css`, valor vigente `var(--text-2xs)` (9px) / `600` / uppercase — alineado a Nivel 4 — Eyebrow label de A-08 salvo por el tamaño (9px en vez de 11px; queda como excepción de deuda, mismo criterio que arriba).
- **`letter-spacing` del eyebrow uppercase unificado a `0.06em`** en los selectores que antes usaban `0.04em`/`0.05em`/`0.07em`/`0.08em` para el mismo rol (label uppercase de header de sección) — lista completa de selectores tocados en la tabla de A-08 abajo. `0.06em` ya era el valor de `.mdiff-right-section-title` (declaración ganadora) y de otros 4 selectores — se generaliza al resto del rol en vez de introducir un sexto valor.
- **No incluido en esta sesión:** migración retroactiva de los ~140 selectores `*-title`/`*-header` a los 4 niveles canónicos de A-08. Ver regla de "consolidación oportunista" en `_Locus-ux-ref` mod:24 — un TKT que toque un selector de título existente lo alinea como parte de ese trabajo, no se abre TKT de migración masiva.
- **Excepciones de deuda declaradas — pesos fuera de A-08 conservados sin cambio en esta sesión:** `.bitem-title` (peso `500`, A-08 pide `600` para Nivel 3) y `.mdiff-right-section-title` (tamaño 9px, A-08 pide 11px para Nivel 4). Ambos casos son la declaración que ya ganaba en cascada antes de esta sesión — se documenta el desvío en vez de forzar un cambio visual no solicitado por ningún TKT.

## Cambios (mod:81) — cierra el `Hallazgo fuera de scope` de mod:80: `.rsb-status-available`/`.rsb-status-session` retiradas

- **Origen:** mod:80 dejó declarado que `.rsb-status-available`/`.rsb-status-session` quedaban sin consumidor en JS tras TKT2 (REQ CAEL-0717-01) — dead CSS, fuera de scope de ese TKT. Excepción de resolución directa (`BR-Core NO DEJAR DEUDA EN SILENCIO`): dueño presente (Nova), nivel Patch — retiro de selectores sin consumidor, sin cambio de comportamiento — sin bifurcación de founder.
- **Retirado de `locus-radar.css`** (mod:5): `.rsb-status-available { color: var(--green); }` y `.rsb-status-session { color: var(--purple); background: rgb(167 139 250 / 10%); }`.
- **Sin cambio:** `.rsb-status-badge` (base) y `.rsb-status-exhausted`/`.rsb-status-interrupted` — `interrupted-state` y `exhausted` no fueron tocados por REQ CAEL-0717-01 y siguen usando el dot/badge de texto.
- **No incluye:** no se tocó la familia `.sc-avatar--*`/`.worker-header--*` (mod:80, líneas 92/94) — vocabulario cromático compartido pero componente distinto, sin relación con este retiro.

## Cambios (mod:80) — TKT1 (REQ CAEL-0717-01): `.rsb-card-quick:focus-visible` — gap de foco cerrado antes de extender el uso de la clase

- **Origen:** `.rsb-card-quick` (Radar Sidebar, `locus-radar.css`) se usaba solo en cards `available` para el botón ⚡ (sesión rápida) y no tenía `:focus-visible` propio. El TKT2 del mismo REQ extiende su uso a un segundo trigger (+ registrar CHKPT) y a un segundo estado (`in-session-state`, morado) — se cierra el gap de accesibilidad en el mismo TKT en vez de propagarlo.
- **Regla:** `.rsb-card-quick:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }` — mismo token que `.tsb-ai-row:focus-visible`, ya declarado en `locus-radar.css`. Sin variable nueva.
- **No incluye:** no se tocó `.rsb-status-available`/`.rsb-status-session` — quedan sin consumidor en JS tras TKT2 (dead CSS), fuera de scope de este TKT. Ver `Hallazgo fuera de scope` en CHECKPOINT.

## Cambios (mod:79) — TKT1/TKT4 (REQ CAEL-0716-01): familia `.modal-split*` + `.mdiff-overlay--docked` nueva; `.standalone-ckpt-*`/`.modal--standalone-ckpt` retiradas — **toda la familia `.modal-split*`/`.mdiff-overlay--docked` (mod:79→83→86→87/88→129) retirada por mod:132 (REQ-202607-046, merge completo) — ver arriba**

- **Origen:** split view coordinado #ingest-modal-overlay (1/3) + #merge-diff-overlay (2/3) bajo un solo backdrop visual, con header compartido de identidad de worker. Reemplaza el flujo standalone-ckpt (modal aislado sin coordinación con el DIFF), retirado en el mismo REQ.
- **Arquitectura — dos nodos DOM, coordinados por CSS, sin restructurar el DOM de `#merge-diff-overlay`:** evita blast radius sobre sus 3 call sites de `showMergeDiffPanel` (`locus-session-save.js`, `locus-session-parse.js` ×2). El backdrop real lo pinta solo `#ingest-modal-overlay` (`.modal-split`) — `#merge-diff-overlay` en modo `.mdiff-overlay--docked` va sin backdrop propio (`background: transparent`), posicionado por `fixed` contra las mismas custom properties que `.modal-split__dialog`. **Corrección posterior (ver `§Cambios (mod:129)`):** esta afirmación ya no es exacta — TKT-202607-128 restructuró el DOM, envolviendo ambos overlays en `.modal-split__shell`, un contenedor padre común nuevo. La restructura no tocó los 3 call sites de `showMergeDiffPanel` (siguen resolviendo por `getElementById`, sin blast radius), pero sí contradice el "sin restructurar" original — se conserva esta entrada como registro histórico de la decisión de arquitectura de ese momento.
- **Custom properties nuevas (`:root`, `locus-modals-base.css`):** `--split-total-w: min(1800px, 92vw)` · `--split-total-h: min(960px, 88vh)` · `--split-gap: 18px` · `--split-header-h: 60px`. Ambos diálogos (`#ingest-modal-overlay` y `#merge-diff-overlay` docked) calculan su posición/tamaño contra las mismas cuatro variables — quedan visualmente contiguos sin acoplar su DOM.
- **Header compartido — reuso de vocabulario, sin clases `.msh-*` nuevas de estructura:** `.modal-split__header` reusa `.sc-header-left`/`.sc-avatar`/`.sc-project`/`.sc-header-right`/`.sc-badge` (ya documentados abajo, familia AI Card) — mismo lenguaje visual del resto del ecosistema para identidad de worker. Única clase nueva de contenido: `.msh-empty` (texto del estado vacío, inyectado por JS — no vive en HTML estático, es empty state dinámico por BR-Execution §5).
- **Fix de z-index — intento original, superado por mod:83:** esta entrada documentó `.mdiff-overlay--docked` fijando `z-index: var(--z-modal-plus)` como solución al riesgo de orden de `<link>`. El diagnóstico del riesgo era correcto; el mecanismo (selector sin calificar) no resolvía el empate de especificidad contra `.modal-overlay` — ver mod:83 para el fix real (selector calificado + `calc(var(--z-overlay) + 1)`).
- **Consumo desde JS (Rune, TKT2/TKT3):** `.mdiff-overlay--docked` se aplica/retira vía `classList` al invocar/cerrar `showMergeDiffPanel()` desde el flujo de ingesta — mismo mecanismo para paste único y batch, sin diferenciar caller en CSS.
- **Retirado — `.standalone-ckpt-*` / `.modal--standalone-ckpt` (TKT4):** 4 reglas en `locus-modals-editor.css` (`.standalone-ckpt-ta`, `:focus`, `-desc`, `-prev`) + 1 en `locus-modals-base.css` (`.modal--standalone-ckpt`, hallazgo de impacto lateral no declarado originalmente en el TKT). Sin consumidor tras retirar el shell HTML (`#standalone-ckpt-overlay`) — la ingesta de CHECKPOINT (single y batch) converge ahora en `.modal-split`/`.mdiff-overlay--docked`.

| Selector | Rol |
|---|---|
| `.modal-split__shell` | Contenedor padre común de `#merge-diff-overlay` + `#ingest-modal-overlay`, `index.html` (mod:129). Sin reglas CSS propias — `<div>` plano, no crea containing block para los dos hijos `position: fixed`. Único propósito: adyacencia DOM explícita para el selector de hermano general de la última fila de esta tabla |
| `.modal-overlay.modal-split` | Aplicada a `#ingest-modal-overlay`. Ancla el diálogo al tercio izquierdo del área total — `justify-content/align-items: flex-start` + padding calculado contra `--split-total-w/-h/-header-h` |
| `.modal-split__dialog` | Diálogo de la columna ingesta — `width: calc(var(--split-total-w) * 0.333 - var(--split-gap)/2)`, `overflow: visible` (no recorta el header absoluto) |
| `.modal-split__header` | Header compartido full-width — `position: absolute`, se extiende sobre ingesta + socket DIFF vía `width: calc(100% + var(--split-total-w)*0.667 + var(--split-gap))` |
| `.modal-split__header--empty` | Estado sin worker activo — `color: var(--text3)` |
| `.msh-empty` | Texto del estado vacío — inyectado por JS dentro de `.modal-split__header--empty`, sin nodo estático en HTML |
| `.modal-split__col--ingest` | Columna izquierda — `flex-direction: column`, `overflow: hidden` |
| `.modal-split__col--diff` | Socket reservado, decorativo — `pointer-events: none`, fija la proporción 2/3 en el DOM sin duplicar contenido (el diálogo real es `#merge-diff-overlay` docked, posicionado independiente) |
| `.modal-split__divider` | Borde central 1px — `background: var(--border2)`, `pointer-events: none` |
| `#merge-diff-overlay.mdiff-overlay--docked` | En `locus-backlog-item.css` (junto a `.mdiff-overlay`, no duplicada aquí) — selector calificado con ID (mod:83, especificidad 1,1,0) para ganar sobre `.modal-overlay` sin depender de orden de `<link>`. `background: transparent`, `z-index: calc(var(--z-overlay) + 1)`, posición calculada contra las mismas 4 custom properties. Único consumidor de `.mdiff-overlay--docked` en el codebase — calificar no reduce cobertura. **`padding-left` corregido en mod:129** — sumaba `--split-total-w`/`--split-gap` pero no `--gutter-shell`, desalineando el borde izquierdo de `.mdiff-dialog` respecto al borde real de la columna de ingesta. Fórmula vigente: `calc(var(--gutter-shell) + var(--split-total-w) * 0.333 + var(--split-gap) / 2)` |
| `#merge-diff-overlay.mdiff-overlay--docked .mdiff-dialog` | Dialog en modo docked — `width: calc(var(--split-total-w)*0.667 - var(--split-gap)/2)`, sin animación de entrada (`animation: none`) |
| `.msc-diff-empty` | Empty state del socket `.modal-split__col--diff` — visible cuando `#merge-diff-overlay` no tiene `.mdiff-overlay--docked` (mod:87). Dashed border `1px var(--border2)`, `border-radius: var(--radius-lg)`, `padding: 28px 16px`, centrado — mismo patrón que `.scm-du-empty`/`.qc-empty` |
| `.msc-diff-empty-icon` | Ícono `ti-git-compare` — `font-size: var(--text-display-2xl)`, `color: var(--text3)` (mod:87) |
| `.msc-diff-empty-title` | "El panel de revisión aparece aquí" — `color: var(--text2)` (mod:87) |
| `.msc-diff-empty-hint` | "Se activa al procesar el batch" — `font-size: var(--text-xs)`, `color: var(--text3)` (mod:87) |
| `#merge-diff-overlay.mdiff-overlay--docked ~ #ingest-modal-overlay .msc-diff-empty` | Oculta el empty state cuando el diff está docked — selector de hermano general, sin JS nuevo (mod:87). Desde mod:129, ambos IDs son hijos directos de `.modal-split__shell` — adyacencia explícita, ya no depende de que ningún otro overlay se intercale entre ellos bajo `<body>` |

**Token de gutter (mod:88):** `--gutter-shell: 24px` (`:root`, `locus-base.css`) — consumido por `.modal-overlay.modal-split` (`padding-left`) y restado ×2 de `--split-total-w` en sus tres variantes. Reemplaza `--split-viewport-gutter` (token propio, mod:87, retirado sin período de gracia — mismo valor, ahora consolidado con `#tab-analytics`/`#tab-backlog`/modal de ingesta en la escala general de gutters). Ver `§Cambios (mod:88)` y `§Patrones de layout` → `### Gutter de shell/viewport completo` para el detalle completo.

## Cambios (mod:78) — TKT2 (REQ CAEL-0717-01): familia `.mdiff-finnrelease-*` — tarjeta de liberación (`finn_release`) en panel DIFF

> **Corrección posterior (ver `§Cambios (mod:94)`):** esta entrega nunca llegó al archivo real. `.mdiff-finnrelease-*` no existió en `locus-backlog-item.css` hasta `mod:65` — implementado con `--green` crudo, no `--green-text` como se documenta abajo. Esta entrada se conserva como registro histórico de la especificación original; no refleja el estado del código entre `mod:57` (declarado aquí) y `mod:65` (implementación real).

- **Origen:** gap #2 del handoff de auditoría de Vera (infra_version 37→40) — `finn_release` se parsea en el CHECKPOINT pero nunca llega a `_ckptMeta` en `locus-session-parse.js` ni se renderiza en `locus-backlog-merge.js`. Confirmado contra código real en esta sesión (grep sin resultados para `finnRelease`/`finn_release` en `locus-backlog-merge.js`) — campo mudo, no hipótesis.
- **Decisión de diseño — reuso, no componente nuevo:** el AC de Cael pedía "tarjeta entre header y lista de ítems". El código real ya resuelve ese hueco con `_buildNarrativeSection()` (T-202606-038, `.mdiff-narrative-*`) insertada al inicio de `body.innerHTML` (línea ~746, antes de `_buildSummaryChipsBlock()` + `sectionsHtml`). `.mdiff-finnrelease-*` reusa esa caja/tipografía tal cual — `.mdiff-narrative-row/-label/-value` cubren `que_hace`/`que_no_hace`/`listo_para` sin selector propio. Solo se declaran 6 selectores genuinamente nuevos: `.mdiff-finnrelease-section`, `-header`, `-probado`, `-check`, `-check-icon`, `-docs-wrap`, `-docs-label`, `-docs-list`.
- **Orden de inserción — finn_release antes de narrative, no después:** `_buildFinnReleaseSection()` se concatena antes de `_buildNarrativeSection()` en `body.innerHTML` — el resultado liberado precede a la narrativa de la sesión que lo produjo, mismo criterio jerárquico que ya separa "qué se entrega" de "cómo fue la sesión" en el resto del DIFF.
- **Docs pendientes — reuso de `.mdiff-pending-item` (amber), sin token nuevo:** semánticamente correcto sin adaptación — un doc pendiente de aplicar es la misma categoría de "acción abierta para el founder" que un ítem pendiente de merge.
- **Probado — accesibilidad (AC-4):** `.mdiff-finnrelease-check` es texto visible junto al símbolo (`✓ AC1`), no símbolo solo con color — cumple el criterio de no depender únicamente de color/ícono para transmitir estado, mismo principio ya aplicado a `.autosave-indicator` (`§Modal de ingesta`).
- **Sin tokens nuevos:** reuso exclusivo de `--text-sm`, `--text2`, `--text`, `--green-text`, `--border`, `--amber` (heredado vía `.mdiff-pending-item`).
- **Pendiente de Rune — no cubierto por este DOC-UPDATE:** `_ckptMeta.finnRelease` en `locus-session-parse.js` (parsing) + `_buildFinnReleaseSection()` en `locus-backlog-merge.js` (render, mismo patrón que `_buildNarrativeSection()`) + inserción en el concat de `body.innerHTML`. Este doc cubre el contrato CSS — la implementación JS es TKT2 de Rune, ya especificado por Cael con AC propios.
- **`mod` de archivos reales:** `locus-backlog-item.css` mod:56→57 (Nova).

## Cambios (mod:76) — `.tpl-sidebar-actions` documentado por primera vez (gap desde REQ CAEL-01/TKT2) + familia `tpl-` corregida tras housekeeping de dead code

- **Origen:** conflicto de cascada detectado por Rune en Momento 1 de TKT2 (ref_id CAEL-03) — `.tpl-sidebar-actions` estaba declarado dos veces en `locus-proyectos.css`: la regla de Nova para TKT2 (línea 2064, fila horizontal) y una regla legacy del sidebar vertical Gen1 (línea 2162, `flex:1`/`overflow-y:auto`) nunca eliminada cuando TKT1/TKT2 removieron el wrapper `.tpl-sidebar` del DOM. La legacy se declaraba después → ganaba por cascada, pisando `flex-shrink:0` con `flex:1` y rompiendo el AC-7 de TKT1 ("hermano directo... mismo patrón que `#proj-doc-actions`"). Nova eliminó la regla legacy (`locus-proyectos.css` mod:8) — nunca documentado como patrón hasta ahora, mismo gap de "componente nuevo sin entrada en css-ref" ya registrado en otras entradas de este changelog.
- **Patrón — `.tpl-sidebar-actions`:** fila horizontal fija, `flex-shrink:0`, `display:flex`, `padding: 8px 24px` — hermana directa de `.spt-nav` en el DOM. Contenedor de la barra de Acciones (`#tpl-toolbar` en tab Backlog, `#proj-doc-actions` en tab Proyectos) — mismo componente reutilizado por ambos tabs desde la unificación de sub-tabs de REQ CAEL-01. No confundir con la familia `.tpl-action-btn`/`.tpl-action-row` (botones individuales dentro de la fila) ni con `.tpl-detail` (panel de detalle) — las tres siguen activas y sin cambio.
- **Housekeeping — familia `tpl-` corregida:** `tpl-sidebar-nav`, `tpl-nav-btn`, `tpl-sidebar-label`, `tpl-sidebar-section` estaban documentadas en la tabla de Prefijos como "familia activa en producción" con nota "no confirmado" desde mod:14 — confirmadas dead code (cero referencias en HTML/JS tras la migración a tablist horizontal) y eliminadas de `locus-proyectos.css` por Nova (mod:9, excepción de resolución directa — dueño presente + nivel Patch + sin bifurcación de founder, ver `__BR-Core §NO DEJAR DEUDA EN SILENCIO`). Fila de la tabla de Prefijos corregida para reflejar solo la familia realmente viva.
- **Hallazgo derivado, no resuelto en este doc:** al limpiar el JS asociado, Rune detectó que `sstab-btn-qbacklog`/`sstab-btn-qdisc` reciben dos listeners de click independientes — el centralizado (`switchSubTab()`) despacha `shell:render-qbacklog`/`shell:render-qdisc` sin listener activo hoy; el render real depende del listener local legacy en `locus-backlog-qbacklog.js`/`locus-backlog-qdisc.js`. Es arquitectura, no CSS — registrado como DISC (`priority: medium`, `triggered_by: TKT2-CAEL01`) para evaluación de Cael, no como entrada de este doc.
- **`mod` de archivos reales:** `locus-proyectos.css` mod:7→9 (Nova — mod:8 fix de cascada, mod:9 housekeeping).

## Cambios (mod:75) — `.sc-badge--avail`/`--exhausted` usaban tokens genéricos, color no coincidía con el estado (hallazgo del founder)

- **Hallazgo:** pill "Disponible" se veía cian/azul, no verde — `.sc-badge--avail` usaba `var(--c-pulido-*)`, token genérico heredado de semántica kanban (`en-curso`, ver `.bl-strip-btn.active.s-en-curso`), reciclado sin verificar el color real contra el estado que representa. Mismo problema en `.sc-badge--exhausted` con `var(--c-won-*)` (ámbar, no rojo).
- **Fix:** ambos badges migrados a tokens semánticos del propio estado — `var(--green-dim/green/green-border)` y `var(--red-dim/red/red-border)`, ya definidos y usados en `locus-sesiones.css` (`.worker-header--available/--exhausted`, `.sc-avatar--available/--exhausted`). Mismo patrón que `.sc-badge--insession`/`--interrupted` ya seguían (color semántico directo, sin token intermedio genérico).
- **`c-pulido-*`/`c-won-*` sin cambio:** siguen usándose en `.bl-strip-btn.active.s-en-curso`/`.s-descartado` (kanban) — no se tocaron, sin riesgo de regresión ahí.
- **Anti-pattern para no repetir:** `c-pulido`/`c-won` son tokens de semántica kanban (`en-curso`/`descartado`), no tokens de color genéricos reutilizables. No usar para nuevos estados — si un estado necesita un tinte, usar el token semántico del color real (`--green-dim`, `--red-dim`, `--amber` + `rgb(.../8%)`, etc.) o crear uno nuevo si no existe. Ver tabla `#### Tokens de color adicionales` para el mapeo completo.
- **Impacto lateral:** `.sc-badge` es compartido entre `#worker-header` y la AI Card (tab Por IA) — el fix aplica en ambos lugares.
- **`mod` de archivos reales:** `locus-sesiones-card.css` mod:8→9 (Nova).

## Cambios (mod:74) — corrige mod:73: `.worker-header-unlock` documentado con estado intermedio, superado por mod:29-31 tras fix de especificidad y ajuste visual del founder en la misma sesión

- **Por qué se corrige:** La entrada mod:73 documentó `.worker-header-unlock` en un estado intermedio (`locus-sesiones.css` mod:28) que cambió tres veces más en la misma sesión — quedó desactualizada antes de que el founder llegara a ver el resultado. Se corrige aquí en vez de dejarlo como gap para la próxima sesión — mismo criterio que cerró la recurrencia mod:69/71/72.
- **`.worker-header--exhausted` — fix de especificidad (root cause, no solo síntoma):** `.sc-header` (`locus-sesiones-card.css`) y `.worker-header--exhausted` (`locus-sesiones.css`) tenían igual especificidad (una clase c/u). `locus-sesiones.css` carga *antes* que `locus-sesiones-card.css` en `index.html` — en la cascada, `.sc-header` ganaba y su `border-bottom` original nunca se anulaba, aunque el selector lo declarara. Resultado visible: separador duplicado (línea sin anular entre fila 1/fila 2 + línea nueva de `.worker-header-unlock`). Fix: selector compuesto `.worker-header.worker-header--exhausted` (especificidad 0,0,2,0) — gana sin depender del orden de `<link>`, sin tocar `index.html`. Alternativa descartada: reordenar los `<link>` en `index.html` — mismo resultado pero con blast radius sobre toda la cascada del proyecto.
- **`.worker-header-unlock` — estado final:** `border-bottom: 0.5px solid var(--border)` (no `border-top` — cierra el bloque completo fila1+fila2 antes de la lista de sesiones, no entre las dos filas) · `border-left: 3px solid var(--red-border)` agregado — continúa el acento de fila 1 sin corte · `justify-content: flex-start` (no `space-between`) — countdown alineado a la izquierda, mismo eje que avatar/nombre de fila 1 · `background: linear-gradient(135deg, var(--red-dim) 0%, var(--surface, transparent) 60%)` — gradiente idéntico al de `.worker-header--exhausted`, mismos stops (60%, no 80% como documentaba mod:73).
- **`mod` de `locus-sesiones.css`:** 28 → 31 en esta sesión (Nova). Ver header de identidad del archivo para el detalle acumulado de cada incremento.

## Cambios (mod:73) — Iconografía del sistema documentada por primera vez (INC Tabler Icons ausente)

- **Origen:** `doc_update` de Rune tras INC de esta sesión — íconos `ti ti-*` en toda la app renderizaban como cuadros grises porque `index.html <head>` nunca cargó el webfont de Tabler Icons. Fix: `<link>` CDN agregado (`index.html` mod:133→134), aprobado por el founder como dependencia externa nueva.
- **Primera documentación — iconografía del sistema:** ver entrada `Iconografía del sistema` en `§Arquitectura de módulos CSS`, abajo.
- **Patrón — inserción de bloques full-width como hermano, no hijo, de contenedores flex:** `.worker-header-unlock` se insertaba inicialmente con `header.appendChild()` dentro de `#worker-header` (`display:flex`, `.sc-header`) — quedaba comprimido como tercer ítem del flex row en vez de renderizar como fila completa debajo. Corregido a `header.after(unlockEl)`, hermano del header — consistente con el patrón ya existente `.sc-header`/`.sc-stats`/`.sc-footer` (`locus-sesiones-card.css:15,306,517`), block-stacked dentro del mismo wrapper. Regla para Rune: un bloque que debe ocupar una fila propia de ancho completo nunca se inyecta como hijo de un contenedor `display:flex` existente — se inserta como hermano.
- **`mod` de archivos reales (estado al cierre de mod:73 — ver mod:74 para el estado final de `.worker-header-unlock`):** `index.html` mod:133→134 (Rune) · `locus-sesiones.js` mod:43→44 (Rune).

## Cambios (mod:72) — REQ CAEL-01 (rediseño worker-header, ciclo 2026-07-14) cerrado sin `doc_updates` — tercera recurrencia del mismo gap (ver mod:69, mod:71)

- **Hallazgo previo a documentar — tercera recurrencia:** el REQ CAEL-01 (TKT/CAEL-02 · TKT/CAEL-03) de este ciclo — distinto de los dos REQ "CAEL-01" anteriores (mod:69 iconos SVG, mod:71 estado unificado avatar/badge/header) — cerró QA y liberó al founder sin que Nova declarara `doc_updates` en el CHECKPOINT de entrega. Mismo patrón exacto ya señalado dos veces en este mismo doc.
- **Pulso trasladado del avatar al header completo:** `.worker-header .sc-avatar--available::after` / `--insession::after` anulados (`animation:none; content:none`) — el pulso ya no vive en el avatar de 28px dentro de `#worker-header` (el resto del ecosistema, AI Card y tab Por IA, conserva el pulso de avatar sin cambio). `.worker-header--available`/`--insession` ganan `::before` con `box-shadow: inset 0 0 22px -4px var(--green|--purple)`, animación `whHeaderPulse` (`@keyframes`, 2.4s ease-in-out infinite, `opacity 0↔0.6`). `prefers-reduced-motion: reduce` desactiva ambos `::before`.
- **`.worker-header .sc-project` — título principal del tab:** `font-size: var(--text-2xl)` (22px), `font-weight: 600`, `letter-spacing: -0.01em`. Selector acotado a `#worker-header` — `.sc-project` de la AI Card sin cambio.
- **`.worker-header .sc-save` / `.worker-header .sc-menu-btn` — contraste propio:** `background: var(--surface2)`, `border-color: var(--border2, var(--border))`, `color: var(--text2)` — independiente del gradiente tenue ambiente del header, en los 4 estados.
- **Familia nueva — `.worker-header-unlock`:** reemplaza el pill compacto `.worker-header-reset-icon` + contador en estado `exhausted` (nota de corrección: el AC original de Cael describía el pill reemplazado como `.sc-badge--exhausted` — verificado contra código real en QA, el contador compacto vivía en `.worker-header-reset-icon`; `.sc-badge--exhausted` solo porta el label de texto, sin contador). Integración de markup vía JS — `_populateWorkerHeader()` en `locus-sesiones.js`, no HTML estático. Ver tabla nueva en `#### Worker-header — modificadores de estado`.
- **Mismo lenguaje tipográfico que `.hoy-exh-countdown`** (`buildHoyCard()`, panel Hoy) — `.worker-header-unlock-value` reutiliza el mismo criterio (JetBrains Mono, 700, `--text-xl`) sin introducir tokens nuevos.
- **`mod` de archivos reales:** `locus-sesiones.css` mod:26→27 (Nova) · `locus-sesiones.js` mod:42→43 (Rune).

## Cambios (mod:71) — familia `.gf-ckpt--alert-*` documentada por primera vez (4 variantes: inc/sprint/backlog/docupdate) — gap abierto desde el REQ original, cerrado junto con la 4ª variante

- **Hallazgo previo a documentar — mismo patrón recurrente de mod:69/mod:70:** el REQ original de la familia (`footer_global_alertas_wireframe` — 3 variantes: `--alert-inc`/`--alert-sprint`/`--alert-backlog`, `locus-backlog-item.css` mod:53→54) cerró QA y liberó al founder sin que Nova declarara `doc_updates` para esta referencia — la familia completa nunca tuvo entrada en este doc hasta ahora. Cerrado en la misma sesión que la 4ª variante (`--alert-docupdate`, mod:55→56), evitando que el gap se acumule una tercera vez.
- **Selector nuevo — familia `.gf-ckpt--alert-*`:** cuatro variantes sobre `#gf-ckpt` (footer global, `locus-backlog-item.css`), mutuamente excluyentes — `_getFooterAlert()` (`locus-sesiones-stats.js`) retorna como máximo un tipo por render, resuelto por prioridad (inc > sprint > backlog > docupdate). Ver tabla nueva en `§Patrones de componentes flotantes` → `Footer global — familia .gf-ckpt--alert-*`.
- **Sin tokens de color nuevos en ninguna de las 4 variantes:** `--red` (inc), `--amber` (sprint), `--purple` (backlog) usados directos — ya validados como texto en este doc. `--alert-docupdate` usa `--blue-text` (no `--blue` directo, que falla 4.5:1 en light — ver `§Tokens de color utilitarios`).

- **Hallazgo previo a documentar:** el REQ CAEL-01 (TKT1/CAEL-02 · TKT2/CAEL-03), distinto del REQ CAEL-01 de mod:69 (iconos SVG), cerró QA y liberó al founder sin que Nova declarara `doc_updates` en ninguno de los CHECKPOINTs del ciclo — mismo patrón de gap ya detectado en el ciclo de mod:69.
- **Modificadores nuevos — `.sc-avatar--*`:** cuatro variantes (`available` · `insession` · `interrupted` · `exhausted`) sobre `.sc-avatar`, mismo vocabulario cromático que `.card-avatar.*` (`locus-sesiones.css`) y `.rsb-card.*` (`locus-radar.css`). `available`/`insession` llevan anillo pulsante vía `::after` (respeta `prefers-reduced-motion`); `interrupted`/`exhausted` sin pulso.
- **Modificadores nuevos — `.sc-badge--insession` / `.sc-badge--interrupted`:** completan la familia junto a `--avail`/`--exhausted` ya documentados — cierran el gap que el comentario `T-202606-074 AC-8` había anticipado sin resolver.
- **Selector nuevo — `.worker-header--*`:** cuatro variantes sobre `#worker-header` (`border-left` + fondo tenue por estado), mismo patrón que `.rsb-card.available`/`.rsb-card.interrupted-state`. Mutuamente excluyentes — un solo modificador aplicado a la vez, resuelto en JS por Rune.
- **Sin tokens de color nuevos:** las cuatro variantes reutilizan `--green`/`--purple`/`--amber`/`--red`/`--red-border` ya existentes en ambos temas (`locus-base.css`) — verificado en Fase 5 por Finn.
- **`mod` de archivos reales:** `locus-sesiones-card.css` mod:7→8 (Nova), `locus-sesiones.css` mod:25→26 (Nova, acento de `#worker-header`), `locus-sesiones.js` mod:40→41 (Rune).

## Cambios (mod:69) — REQ CAEL-01 cerrado: sistema de iconos SVG propio en el header — 18 emojis reemplazados, gap de documentación cerrado en sesión posterior al cierre del REQ

- **Hallazgo previo a documentar:** el REQ CAEL-01 (TKT1/CAEL-02 · TKT2/CAEL-03 · TKT3/CAEL-04) cerró QA y liberó al founder sin que Nova declarara `doc_updates` en ninguno de los CHECKPOINTs del ciclo — gap detectado por Cael en diagnóstico de sesión posterior, no en el cierre mismo.
- **Convención nueva — íconos SVG del header:** primera documentación — ver `§Header global — familia .header-zone-*` (misma subsección, extendida) con nueva entrada `Íconos SVG del header`.
- **Sin tokens de color nuevos:** los 18 `<svg>` usan `stroke="currentColor"` — heredan `--text2`/`--text` según contexto (tab inactivo/activo, ítem de menú), ya validados WCAG AA en el sistema. Cero paleta propia.
- **`mod` de archivos reales:** `index.html` mod:124→125 (Rune, TKT2+TKT3/CAEL-03+CAEL-04). TKT1 (CAEL-02) define el mapeo de iconos consumido por TKT2/TKT3, sin archivo real propio declarado en el ciclo.
- **No afecta:** `#mm-btn-sync` conserva su `.sync-status-dot` sin cambio — excluido explícitamente del reemplazo (`no_incluye` de TKT3) — ni la iconografía fuera del header (sidebar, badges).

## Cambios (mod:68) — TKT6 (CAEL-30): próximo paso + bloqueantes migrados a `#ingest-validation-result` — familia `.validation-result-next-step*` / `.validation-result-blockers*` / `.blocker-row*` / `.blocker-chip`

- **Clases nuevas — `.validation-result-next-step(-label|-text)` / `.validation-result-blockers(-label)` / `.blocker-row(--ok|--ref|--warning)` / `.blocker-chip`:** primera documentación — ver `§Modal de ingesta — panel de validación` (misma subsección, extendida).
- **Corrección de tokens antes de implementar:** el wireframe aprobado por el founder (`wireframe_ingest_validation_result_proximo_paso_bloqueantes.html`) usa `--bg-accent`/`--text-accent` para `.blocker-chip` — ninguno de los dos existe en `locus-base.css`. Mismo caso ya resuelto para `.pill-project` (CAEL-15, mod:65): remapeado a `var(--surface3)`/`var(--text3)`, par ya validado WCAG AA para chips de dato pasivo — sin token nuevo.
- **Estados de `.blocker-row` reusan tokens ya validados en esta misma subsección:** `--ok` usa `var(--green-text)` (mismo par que `.validation-badge--success`) · `--warning` usa `var(--amber)` (mismo par que `.validation-badge--warning`) · `--ref` es texto neutro `var(--text)` con `.blocker-chip` inline para el código referenciado.
- **Archivo:** `locus-modals-base.css` mod:5 → mod:6, autor Nova.
- **Origen:** CAEL-30 (TKT6, REQ CAEL-24) — restricciones UX aprobadas por el founder antes de escribir AC (`design_intent: wireframe_ingest_validation_result_proximo_paso_bloqueantes`).

## Cambios (mod:67) — REQ-1 (CAEL-01) cerrado: TKT1 (guardando/error) + TKT2 (empty state) de Quick Capture, fix de coherencia + corrección de atribución de archivo en tabla de prefijos

- **Corrección de atribución (pendiente desde entrega de Nova en este mismo REQ):** la fila `qc-` de `§Prefijos de módulo` declaraba `locus-modals.css` — nombre pre-split, inexistente en el codebase actual. Corregido a `locus-modals-misc.css`, confirmado contra el zip real.
- **Clases nuevas — primera documentación parcial de la familia `qc-*`:** `.qc-empty`/`.qc-empty-title`/`.qc-empty-hint`/`#qc-empty-cta` (TKT2, empty state) · `#qc-next-btn:disabled`/`#qc-next-btn.is-loading`/`.qc-spinner` (TKT1, guardando) · `.qc-error-banner`/`.qc-error-msg`/`.qc-error-retry-btn` (TKT1, error) — ver `§Quick Capture — estados de guardado/error/vacío` (nueva subsección). El resto de la familia `qc-*` (shell, stepper, worker list) queda sin documentar — gap heredado, señalado como Hallazgo fuera de scope en la nueva subsección.
- **Bug de coherencia detectado y corregido en sesión:** `.qc-error-banner` declaraba `margin: 0 18px 10px` siendo hijo directo de `.qc-panel` (`flex` + `gap:10px` + `padding:16px 18px`) — duplicaba el inset horizontal y el espaciado vertical, dejando el banner desalineado (no flush) respecto a `.qc-worker-chip`/`.quick-field`. Retirado el `margin` completo — condiciones de resolución directa cumplidas (dueña presente, nivel patch, sin bifurcación de founder).
- **`mod` de archivos reales:** `locus-modals-misc.css` mod:2→3 (Nova, TKT1+TKT2+fix de coherencia).
- **No afecta:** `.btn-primary` global (el `:disabled` de `#qc-next-btn` tiene scope acotado, no se declaró clase compartida) · `locus-sesiones.js` · `sessionGroupId`.

## Cambios (mod:66) — TKT (CAEL-19 recuperado + CAEL-23): panel de validación del modal de ingesta — no existía en archivo real pese a status `done` de CAEL-19

- **Hallazgo previo a implementar:** CAEL-19 (estados error/warnings de `#ingest-validation-panel`) figuraba `done` en el backlog, pero ni `index.html` ni `locus-modals-base.css` (zip más reciente confirmado por el founder) contenían el panel — y este mismo doc tampoco tenía entrada. Sin evidencia de entregable real en ningún artefacto verificable. Se registra como Hallazgo fuera de scope a Cael (reconciliación de backlog) — no se investiga la causa aquí, se recupera el shell completo en esta entrega junto con CAEL-23.
- **Clases nuevas — `.ingest-validation-panel` / `.validation-error` / `.validation-warnings` / `.validation-force-btn` / `.validation-result` / `.validation-badge(--success|--warning)` / `.validation-result-title` / `.validation-divider` / `.validation-result-summary` / `.validation-result-file` / `.validation-result-items` / `.validation-result-item(-status)`:** primera documentación — ver `§Modal de ingesta — panel de validación` (nueva subsección).
- **Corrección de tokens antes de implementar:** el wireframe aprobado por el founder (`wireframe_ingest_validation_panel_v2_resultado.html`) usa `--bg-danger`/`--text-danger`/`--bg-warning`/`--text-warning`/`--bg-success`/`--text-success` — ninguno existe en `locus-base.css`. Sustituidos por el patrón `color-mix(in srgb, var(--COLOR) 10%/28%, transparent)` + `var(--COLOR-text)` (red/green) o `var(--amber)` directo (sin `-text` dedicado, ya usado como texto en decenas de componentes del proyecto: `locus-backlog-item.css`, `locus-sesiones.css`, `locus-sprint.css`) — mismo idioma visual que el resto del sistema, no un token de un solo uso. `.validation-error .validation-msg` usa `var(--bg-danger-subtle)` (alias ya existente de `--red-dim`) en vez de recrear el color-mix manualmente.
- **`mod` de archivos reales:** `index.html` mod:123→124 (Nova, CAEL-19+CAEL-23) · `locus-modals-base.css` mod:4→5 (Nova, CAEL-19+CAEL-23).
- **No afecta:** `.pill-project`, `.ingest-modal-meta`, `.autosave-*`, `.char-counter`, `.sc-diff-preview`, `.sc-stepper` — sin cambio de markup ni estilo. Se extendió el selector compartido de `margin-left/right:18px` para incluir `.ingest-validation-panel`.

## Cambios (mod:65) — TKT (CAEL-15): pill de proyecto + fila autosave/contador en modal de ingesta — corrección de tokens sobre el AC original

- **Clases nuevas — `.pill-project` / `.ingest-modal-meta` / `.autosave-indicator` / `.autosave-dot` / `.char-counter` / `.ingest-modal-title-row`:** primera documentación del modal de ingesta en este doc — ver `§Modal de ingesta` (nueva sección). `.modal--ingest` en sí (CAEL-06/07/08) nunca tuvo entrada propia — gap heredado, no corregido en este DOC-UPDATE, señalado como Hallazgo fuera de scope a Cael.
- **Corrección de tokens antes de implementar:** el AC de Cael (CAEL-15) declaraba `--bg-accent`/`--text-accent` para `.pill-project` — ninguno de los dos existe en este doc ni en `locus-base.css`. Sustituido por `var(--surface3)`/`var(--text3)`, el mismo par ya validado WCAG AA en `.sps-section-count` (`§Sprint activo — familia sps-*`) para pills de dato pasivo — sin token nuevo.
- **`.autosave-dot` usa `var(--green)` como fill decorativo, no como texto** — el AC exige que el label "Guardado automático" acompañe siempre al dot (nunca solo color transmite el estado), por lo que el contraste de `--green` como texto no aplica aquí — mismo criterio ya documentado para `--green` como elemento gráfico no-texto (`§Tokens de color utilitarios`).
- **`mod` de archivos reales:** `index.html` mod:122→123 (Nova, CAEL-15) · `locus-modals-base.css` mod:3→4 (Nova, CAEL-15).
- **No afecta:** `.paste-ta-wrap`, `.sc-diff-preview`, `.sc-stepper` — sin cambio de markup ni estilo, solo se agregó `.ingest-modal-meta` al mismo selector compartido de margin-left/right:18px.

---

## Cambios (mod:64) — REQ CAEL-05 cerrado (TKT4/CAEL-01, TKT5/CAEL-02, TKT6): jerarquía visual del sprint activo + contador de secciones — 3 gaps de documentación cerrados en la misma sesión que la implementación

- **`.sph-pct` ampliado — `var(--text-sm)` → `var(--text-lg)`:** el dato de mayor jerarquía de la card (salud del sprint) ahora lidera visualmente — peso/color sin cambio (`600`/`var(--accent)`, ya correctos).
- **Border-left de `#sps-activo .sps-card` reducido — `3px` → `2px` (T-202606-099 modificado):** reemplazo consciente detectado durante implementación — el AC original de Cael no contemplaba que la regla ya existía con 3px, corregido vía patch antes de escribir código. `padding-left: 12px` de los hijos compensatorios conservado sin cambio (delta de 1px evaluado como no perceptible por Nova).
- **Clase nueva — `.sps-section-count`:** pill de conteo hijo de `.sps-section-label`, en `#sps-programados` y `#sps-cerrados` (ambas ramas). No oculta en count=0. Deliberadamente distinto de `.blf-badge`/`.blt-badge` — ver tabla `sps-*` para la comparación completa, verificada contra `locus-backlog.css` mod:96 tras observación de Finn en sesión de cierre del REQ.
- **Elemento nuevo — `#sps-activo::after`:** conector decorativo estático entre la card Activo y la sección Programados. Sin precedente en el sistema — primer uso de este patrón. Vive en `#sps-activo`, no en `.sps-card`, por el `overflow:hidden` de esta última (impacto lateral detectado en implementación, no en especificación — el AC original asumía `.sps-card` como contenedor).
- **Gap cerrado — hallazgo de sesión, resuelto en el mismo turno bajo excepción de resolución directa (`__BR-Core`):** `_renderSpsCerrados()` no renderizaba `.sps-section-label` en su rama de vacío (`closed.length === 0`) — única sección con este gap tras el cierre de mod:63 para Pausados. Agregado con `.sps-section-count` en `'0'`, mismo patrón que las otras 3 secciones.
- **TKT3 del REQ (badge de bloqueados reutilizable, mencionado como pendiente en mod:61) descartado — `discard_reason: obsoleto`:** el comportamiento ya existía en `.sph-alert`/`.sps-blocked-badge`, confirmado por founder. No se construyó una segunda implementación.
- **`mod` de archivos reales:** `locus-sprint.css` mod:53→55 (Nova, CAEL-01 + TKT6) · `locus-sprint.js` mod:101→103 (Rune, CAEL-02 + fix del hallazgo de Cerrados).
- **No afecta:** `#sps-activo` (label, sin contador — fuera de scope) · `#sps-pausados` (sin contador — fuera de scope) · `#sps-qinc` (familia `qinc-*` independiente).

---

## Cambios (mod:63) — INC (variante ligera): `.sps-section-label` faltante en Pausados + gap de documentación del selector cerrado

- **Gap cerrado — comportamiento:** `_renderSpsPausados()` era la única de las 4 secciones visibles del sub-tab Sprints que nunca renderizaba `.sps-section-label` — ni en estado vacío ni con datos. Exclusión deliberada de TKT4 (REQ-202607-100, comentario en código: "agregar label solo en vacío crearía inconsistencia"), quedó sin resolver hasta que el founder lo señaló directamente sobre la captura. Agregado en ambas ramas — mismo patrón textual y de markup que Activo/Programados/Cerrados.
- **Gap cerrado — documentación:** `.sps-section-label` nunca tuvo entrada propia en este doc pese a estar en uso desde antes de este REQ (Activo/Programados/Cerrados). Documentado ahora en `§Sprint activo — familia sps-*`, justo debajo de la tabla de las 5 secciones.
- **`mod` de archivo real:** `locus-sprint.js` mod:100→101 (Rune).
- **No afecta:** `#sps-qinc` — no usa `.sps-section-label`, familia `qinc-*` independiente.

---

## Cambios (mod:62) — INC (variante ligera): `#sprint-panel-sprints` sin gutter izquierdo — migración a `--subtab-gutter` completada

- **Gap cerrado:** `#sprint-panel-sprints` nunca recibió la migración a `--subtab-gutter` que ya tenían sus contenedores hermanos de otros subtabs (`.tpl-detail`, `#tab-proyectos`, `#tab-sesiones`, ver `§Gutter unificado de subtabs`). Sin `padding-left` propio, todo el contenido del sub-tab Sprints (Activo/Programados/Pausados/Cerrados) quedaba pegado al borde izquierdo del viewport — detectado por captura de pantalla del founder, fuera de ejecución de cualquier TKT activo.
- **Fix:** `#sprint-panel-sprints` declara `padding-left: var(--subtab-gutter)` — mismo token, mismo patrón que los tres contenedores ya migrados. Un solo archivo, sin cambio de comportamiento.
- **`mod` de archivo real:** `locus-sprint.css` mod:52→53 (Nova).
- **Verificación:** variante ligera (`__BR-Core §6`) — founder verificó en app, sin sesión de Finn. INC cerrado con `verificado_por: founder`.
- **No afecta:** ningún selector de `#sps-activo`/`#sps-programados`/`#sps-pausados`/`#sps-cerrados` documentado en `§Sprint activo — familia sps-*` — el fix es exclusivamente en el contenedor padre, sin tocar hijos.

---

## Cambios (mod:61) — TKT2 (REQ CAEL-05, code real TKT-202607-099 es TKT1; TKT2 aún sin código real): `.sph-panel` pasa de hermano a hijo de `.sps-card` en `#sps-activo` — fusión visual en un solo bloque bordeado

- **`.sph-panel` pierde border/background/radius propios** — hereda el fondo de `.sps-card`. Gana `border-top: 1px solid var(--border)` como divisor y `margin-top: 4px`.
- **Padding-left compensado** — `.sph-panel` se agrega a la misma regla de compensación de `#sps-activo .sps-card` que ya cubría `.sps-card-header`/`.sps-meta` (border-left 3px → `padding-left: 12px`). **Nota histórica — border-left superado en mod:64 (CAEL-01, REQ CAEL-05):** el valor de 3px reflejado aquí fue correcto hasta esa sesión — reducido a `2px`, `padding-left: 12px` conservado sin cambio. El registro de esta línea se conserva como historia del TKT que lo precedió, no se reescribe.
- **Combinador de estado pausado corregido:** `.sps-card--pausado ~ .sph-panel .sph-bar-fill` (hermano general) → `.sps-card--pausado .sph-panel .sph-bar-fill` (descendiente). El combinador `~` dejó de matchear en cuanto `.sph-panel` pasó a vivir dentro de `.sps-card` — corregido en el mismo TKT, no deuda diferida.
- **`mod` de archivos reales:** `locus-sprint.js` mod:96→97 (Rune, TKT2 — solo mueve el punto de apertura/cierre del `<div class="sph-panel">`, ningún atributo ni AC de contenido interno cambia) · `locus-sprint.css` mod:49→50 (Nova, TKT2).
- **No afecta:** `#sps-programados`/`#sps-pausados`/`#sps-cerrados`, menú `.sps-menu-wrap`/`.sps-dropdown` — badge de bloqueados reutilizable en Programados/Pausados queda para TKT3 del mismo REQ. **Nota histórica — TKT3 descartado en mod:64 (REQ CAEL-05, sesión de cierre):** el comportamiento que TKT3 iba a construir ya existía en `.sph-alert`/`.sps-blocked-badge` — `discard_reason: obsoleto`, confirmado por founder. REQ CAEL-05 cerrado `done` con TKT1/TKT2/TKT4/TKT5/TKT6 done y TKT3 descartado.

---

## Cambios (mod:60) — TKT1 (REQ CAEL-05 — código real pendiente de asignar en Locus): `.sps-progress-wrap`/`.sps-burndown-*` retiradas de la referencia viva, familia `.sph-*` documentada por primera vez como única barra de progreso de `#sps-activo`

- **Selectores retirados de la referencia viva (tachados, no borrados — historial de doc intacto):** `.sps-progress-wrap`, `.sps-burndown-bar`, `.sps-burndown-fill`, `.sps-card--pausado .sps-burndown-fill`, `.sps-burndown-label`. Código muerto desde T-202606-033 (oculto por `display:none`, 0 call sites) — eliminado del markup y del CSS en TKT1. Ver auditoría de hallazgos previa a este REQ.
- **Familia nueva documentada — `.sph-*`:** existía en código desde T-202606-033 pero nunca se documentó en este archivo — gap de documentación cerrado, no selector nuevo. Con la eliminación de `.sps-progress-wrap`, `.sph-panel` pasa de ser un panel paralelo a ser la única fuente de progreso visual de la card Activo.
- **Variable `--sps-burndown-pct` sin cambio de nombre** — sigue siendo el nombre real en `locus-sprint.js`/`locus-sprint.css` pese a que el markup que consume ahora es `.sph-bar-fill`, no `.sps-burndown-fill`. Documentado explícitamente para que no se lea como inconsistencia.
- **`mod` de archivos reales:** `locus-sprint.js` mod:95→96 (Rune, TKT1) · `locus-sprint.css` mod:48→49 (Nova, TKT1).
- **No afecta:** `#sps-programados`/`#sps-pausados`/`#sps-cerrados`, menú `.sps-menu-wrap`/`.sps-dropdown` — fuera de scope de TKT1 (quedan para TKT2 del mismo REQ).

---

## Cambios (mod:59) — `--text3` deja de ser alias de `--hint`: token propio con contraste WCAG AA (REQ separar-rol-texto-hint, `ref_id` CAEL-01, TKT1-3 `ref_id` CAEL-02/03/04 — código real pendiente de asignar en Locus)

- **Causa raíz cerrada — `--hint` mezclaba tres roles semánticos en un solo token:** borde sutil, fill/dot decorativo, y texto terciario/placeholder (alias `--text3`, documentado en `locus-base.css` como "38 usos → texto inactivo/placeholder" — el conteo real era ~534 incluyendo usos directos de `color:var(--hint)` sin pasar por el alias). El rol de texto nunca cumplió 4.5:1 WCAG AA: 1.5–2.3:1 real en ambos temas.
- **Nota histórica — supera lo verificado en TKT-202607-016 (línea ~116, sin modificar):** ese TKT confirmó `--text3` como alias legacy con consumo activo — correcto en su momento. Este REQ cambia el estado: `--text3` deja de ser alias y pasa a token canónico propio. El registro de línea 116 se conserva como historia del TKT que lo precedió, no se reescribe.
- **Valores nuevos:** `--text3: #868bb8` (dark, 5.21:1 vs `--surface2` / 4.79:1 vs `--surface3`) · `--text3: #5a6192` (light, 5.56:1 / 5.18:1). `--hint` sin cambio de valor en ningún tema — queda exclusivo para border/background/fill (~74 usos verificados intactos, incluye `locus-analytics-charts.js:487,507` como fill de chart categórico, uso válido sin cambio).
- **534 call-sites migrados** de `color:var(--hint)` a `color:var(--text3)` en 19 de 21 `.css` del proyecto (2 archivos — `locus-contracts.css`, `locus-document-generator.css` — sin el patrón, sin cambio). Selectores mixtos (mismo selector con `color:` + `border-color:`/`background:` usando `--hint`) verificados uno a uno — solo `color:` migró.
- Ver tabla de tokens de color y sección de aliases de texto actualizadas más abajo.

- **Gap cerrado — `#mdiff-summary-chips` (ui-Inventory fila 48) sin selectores internos documentados:** el badge de conteo por acción (creados/avances/actualizados/retrocesos/descartes) dentro del panel DIFF no tenía family CSS propia registrada en este doc — auditado durante Fase 5 de Finn, ningún selector previo cubría este contenido. Cerrado con la familia `.diff-chip*` — ver `§Diff action chips — familia diff-chip-*`.
- **Patrón nuevo — componente compartido entre dos módulos:** hasta ahora `sc-*` (`locus-sesiones-card.css`) y `mdiff-*` (`locus-backlog-item.css`) no compartían ningún selector visual. `.diff-chip*` se declara en `locus-base.css` (Variables globales/reset — único archivo cargado antes que ambos consumidores) precisamente para evitar duplicar la misma regla en dos archivos con prefijos distintos — mismo criterio que la familia `c-*-bg/text/border` (§Tokens semánticos de status), que ya vive en `locus-base.css` por la misma razón de consumo cruzado.
- **Excepción consciente registrada — `.diff-chip--descarte` usa rojo:** la "Nota de decisión — sin rojo para 'Descartado'" (`§Sección Cerradas`/`.qdisc-stat-cell`) aplica al status stats block de Q-DISC, donde descartar una DISC es decisión deliberada, no fallo. Este chip vive en el resumen general de un CHECKPOINT (mezcla REQ/TKT/DISC/INC) — el rojo aquí distingue visualmente "algo se retiró del alcance" del resto de acciones, no implica error. Mismo criterio de excepción ya usado para `.qdisc-status-header--descartadas` (founder, mod:55).
- **Tokens reusados, ninguno nuevo:** `--c-done-text`/`--green` (creado) · `--blue-text`/`--blue` (avance) · `--text2`/`--surface2`/`--border` (actualizado, neutro) · `--c-high-text/bg/border` (retroceso — mismo family de status, no de severidad) · `--red-text`/`--red` (descarte). Cero hex hardcoded nuevo.
- **Consumidores:** `.sc-diff-preview` (nuevo contenedor en `locus-sesiones-card.css`, dentro de `.sc-preview-block` — ver `§AI Card rediseño`) y `#merge-diff-header .mdiff-header-chips` (nuevo, `locus-backlog-item.css`) + `#mdiff-summary-chips` (ya existente, ui-Inventory fila 48 — Rune aplica `.diff-chip.diff-chip--*` a sus hijos en vez de la clase ad-hoc previa, no identificada por no tener el archivo real adjunto en esta sesión).
- **Gap registrado — markup actual de `#mdiff-summary-chips` no confirmado:** sin `locus-backlog-item.css` real adjunto, Nova no puede confirmar qué clase(s) renderiza hoy ese contenedor. Rune confirma antes de reemplazar — si ya usa una clase equivalente no documentada, migrar a `.diff-chip*` en el mismo TKT en vez de mantener las dos.

## Cambios (mod:57) — Fila DISC rediseñada (card → inbox flat) + tres gaps de documentación cerrados (doc alcanza al código)

- **Ad-hoc (sin REQ/TKT vía Cael, ítem directo de founder):** fila DISC en Q-DISC pasa de card boxeada (wash 4 caras, borde punteado, glow, badge de tipo en caja) a fila flat tipo inbox — patrón Linear/Things. `locus-backlog-item.css` mod:51→52, `locus-backlog.css` mod:95→96. Ver `§Sección Cerradas — DISC terminales` para el detalle de estado activo vs terminal, y `§Colores declarados — item-type-pill Gen2` para la corrección de `--idea-*`.
- **Gap de documentación cerrado — `.bitem-type-DISC` y `.mdiff-queue-badge--qdisc`:** ambos ya declaraban `var(--blue)` desde `locus-backlog-item.css` mod:51 (TKT1 CAEL-11, swap DISC↔REQ) — este doc seguía marcándolos como "desalineados"/`var(--purple)` en mod:56 (línea `§Cambios mod:55` y `§mdiff-queue-badge`). No era un gap de código sin resolver — era el doc sin actualizar tras el fix. Corregido en `§mdiff-queue-badge — badge de cola fija en modal DIFF`.
- **Gap de documentación cerrado — familia `--idea-*`:** deriva de `var(--blue)` desde `locus-backlog.css` mod:95 (TKT1 CAEL-08, mismo swap) — este doc seguía documentándola como derivada de `var(--purple)` (`§Colores declarados — item-type-pill Gen2`, antiguo párrafo "Card completa de DISC"). Corregido — ver párrafo reescrito para el nuevo patrón de fila flat.
- **Fix de comentario en código (Patch, sin cambio de valor):** `locus-backlog-item.css` líneas 128/135 tenían las etiquetas "REQ → azul" / "DISC → púrpura" invertidas respecto al valor real ya correcto (`--purple`/`--blue`) — corregido en mod:52, mismo delta que el rediseño de fila.

## Cambios (mod:56) — Auditoría cerrada: `.qinc-type-badge` (4 variantes documentadas) + código muerto confirmado y eliminado en `locus-backlog-item.css`/`locus-backlog-item.js`

- **Gap cerrado — `.qinc-type-badge` (Patch, sin cambio de comportamiento):** `§Panel Q-INC — familia qinc-*` marcaba este selector "pendiente de auditoría" desde su primera documentación (mod:48). Cerrado con las 4 variantes (`--inc/--prb/--ke/--chg`, light+dark) y su fuente de color confirmada — hex hardcoded por clase, sin token compartido con `.item.bitem` ni `.idp-type-chip`. Ver `§Panel Q-INC — familia qinc-*`.
- **Código muerto confirmado y eliminado — `locus-backlog-item.css` (Nova, TKT1/CAEL-19, mod:50→51):** 8 reglas `.item.bitem[data-type="INC"|"PRB"|"KE"|"CHG"]` (border-left+header + 3 reglas exclusivas de INC en `bitem-effort-dot`/`-sm`/`bitem-ac-dot`) — INC/PRB/KE/CHG nunca renderizan vía `buildBacklogItem()`/`.item.bitem`, usan `buildQIncItem()`/`.qinc-item` (shell separado, `locus-backlog.css`). Nunca estuvieron documentadas en este doc — no hay entrada previa que corregir, solo confirmación de que el archivo no tenía deuda de documentación sobre selectores ya inexistentes. No requiere entrada en tabla de arquitectura — la fila de `locus-backlog-item.css` no listaba estos selectores.
- **Código muerto confirmado y eliminado — `locus-backlog-item.js` (Rune, TKT1/CAEL-21, mod:107→108):** `typeColorMap`/`typeColor` calculados en `buildQIncItem()` e inyectados como `style="--qinc-type-color:..."` inline — variable nunca consumida por CSS. Detalle en `§Panel Q-INC — familia qinc-*`.
- **Contexto de sesión:** ambos hallazgos surgieron de la evaluación de split arquitectónico Q-INC/Backlog (locus-backlog-item.css candidato a módulo crítico) — confirmado que Q-INC ya tiene shell propio (`.qinc-item`) desde su origen, sin mezcla de shell que separar. Split descartado, sin REQ abierto para eso.

- **Reasignación de color:** DISC pasa de `--purple` a `--blue`; REQ pasa de `--blue` a `--purple`. Motivo: DISC se reasigna a azul por decisión del founder — sin swap, DISC y REQ compartirían color (mapeo 1:1 de 7 tipos/7 hues roto). Ver auditoría de color completa en CHECKPOINT del REQ.
- **Superficies actualizadas (TKT1, `locus-backlog.css` mod:95):** `.item-type-pill.DISC`/`.REQ`, familia `--idea-*` (light y dark), `.qdisc-stat-cell--discovery` (bg/border/label/n). Ver tablas actualizadas abajo.
- **Superficies actualizadas (TKT2, `locus-analytics.css` mod:10):** `.ct-pill-req`/`.ct-pill-disc`.
- **La excepción consciente de mod:54 deja de ser excepción:** `.qdisc-status-header--discovery` usaba `--blue-text` como override consciente contra el `--purple` semántico de DISC (ver `§Cambios (mod:54)`, histórico, no editado). Tras este swap, `--blue-text` para Discovery **es la norma** — coincide con el nuevo `--blue` semántico de DISC. Ya no hay override que documentar para Discovery. La excepción de `.qdisc-status-header--descartadas` (rojo) no se toca — sigue vigente, sin relación con este swap.
- **Gap registrado — dos superficies fuera de scope de este REQ, ahora inconsistentes con el nuevo mapeo:** `.bitem-type-DISC` (`locus-backlog-item.css`, archivo no adjunto en la sesión del REQ) y `.mdiff-queue-badge--qdisc` (línea 1610 de este doc, archivo no identificado en la sesión) siguen declarando `var(--purple)` — el REQ las registró explícitamente como gap sin AC, no como parte del swap. Quedan documentadas abajo con nota de inconsistencia pendiente. Ver DISC nueva en backlog para seguimiento.

## Cambios (mod:54) — 3 bloques verticales Q-DISC por status (REQ QDISC-headers-3-bloques-verticales, TKT1 — código real pendiente de asignar en Locus, `ref_id` CAEL-01 de esta sesión, sin relación con el REQ CAEL-01 de mod:53)

- **Gap cerrado — `--blue`/`--red` como texto bajo 4.5:1 en light theme:** hallazgo registrado sin resolver en mod:36 (~3.31–4.11:1 contra `--surface3`/`--bg2`/`--surface2`). Tokens `--blue-text`/`--red-text` agregados en `locus-base.css` mod:8 — mismo método que `--orange-text`/`--yellow-text` (dark: sin override, ya pasaban 7.85–9.55:1/4.68–5.69:1; light: oscurecidos a `#026aa8`/`#b8253f`, 4.96–5.90:1/5.33–5.87:1). Ver `§Tokens de color utilitarios`.
- **Patrón nuevo — `.qdisc-status-group`/`.qdisc-status-header`/`.qdisc-status-body`** (`locus-backlog.css` mod:93): 3 bloques verticales siempre visibles en `#sspanel-qdisc`, uno por status de DISC (Discovery/Promoted/Descartadas). Ver `§Patrones de componentes flotantes` → nueva entrada.
- **Excepción consciente registrada — override de color en Q-DISC status headers:** Discovery usa `--blue-text` (no `--purple`, el token semántico de DISC en `.item-type-pill.DISC`/`.bitem-type-DISC`/`.qdisc-stat-cell--discovery`) y Descartadas usa `--red-text` (contradice la "Nota de decisión — sin rojo para 'Descartado'" de `.qdisc-stats-block`, ver línea de esa nota). Decisión explícita del founder, confirmada en sesión — no es inconsistencia sin resolver ni bug de Rune. Promoted sigue `--green`, sin cambio respecto al patrón ya establecido.

## Cambios (mod:53) — Sprint selector reconciliado: drift JS↔CSS de mod:50/mod:51 resuelto (REQ CAEL-01, TKT1-TKT4)

- **Reconciliación completa de la familia `bl-sprint-trigger-*` / `bl-sprint-option-*` / `bl-sprint-*`** — 7 bugs funcionales (barra en 0%, dropdown huérfano en DOM al cerrar, 2 flechas sin rotar, mark de selección invisible, overlay invisible/no-clicable, dropdown sin anclar) + 6 selectores sin CSS confirmados en el diagnóstico grounded de Rune (mod:50/mod:51), todos cerrados.
- **Decisión de reconciliación:** JS se alineó al contrato semántico ya declarado en CSS (`aria-expanded`/`aria-selected` en vez de duplicar estado en clases `.is-open`/`.is-selected`, conservadas además por compatibilidad con lógica JS existente) — no al revés. Sin borrador visual nuevo — reconciliación 1:1 contra el diseño ya aprobado de TKT-D7.
- **TKT3 (Nova) — CSS:** `#bl-sprint-bar` ancla el dropdown (`position:relative`); `.bl-sprint-dropdown` flota (`position:absolute` + `z-index:var(--z-dropdown)`) con animación de cierre real (`@keyframes bl-sprint-drop-out`); 6 selectores huérfanos resueltos (`-option-meta`/`-bar-wrap`/`-pct`/`-badge`+modificadores, `-closed-toggle-count`); `.bl-sprint-option-label`/`-id` retirados sin retrocompatibilidad (`__BR-Execution §2`, sin instancia JS) → `.bl-sprint-option-name`; `.bl-sprint-active-name` (+`.is-empty`) agregada, faltaba desde origen.
- **TKT4 (Nova) — gap de integración detectado en sesión de cierre del REQ, no en el diagnóstico inicial:** `.bl-sprint-trigger-progress` y `.bl-sprint-closed-list` sin CSS — agregadas.
- **TKT1+TKT2 (Rune) — JS:** `_buildSprintSelector()` setea `--sprint-pct` (reemplaza `--sbar-w`, eliminado del codebase); `_blSprintOpen()`/`_blSprintClose()` setean `aria-expanded` en trigger y toggle de cerrados + `.open` en overlay; fallback de remoción con `setTimeout` como red de seguridad junto al listener de `animationend`; `_buildSprintOption()` setea `aria-selected` cuando la opción está seleccionada.
- **Barrido de cierre (Finn):** cero selectores `bl-sprint-*` consumidos por `locus-sprint-planificacion.js` sin regla CSS — confirmado por grep exhaustivo contra `locus-sprint.css` + `locus-backlog.css`.
- **Sin resolver — fuera de scope declarado:** `.bl-sprint-separator` / `.bl-sprint-empty` sin instancia JS confirmada, candidatas a huérfanas — requieren grep aparte.
- **`mod` de archivos reales:** `locus-sprint.css` mod:46→48 (Nova, TKT3+TKT4) · `locus-sprint-planificacion.js` mod:29→31 (Rune, TKT1+TKT2).
- **Nueva sección de referencia:** `### Sprint selector (Vista Planificación) — familia bl-sprint-trigger-* / bl-sprint-option-* / bl-sprint-*` reemplazada íntegramente con el estado reconciliado (ver `§Patrones de componentes flotantes`).

---

## Cambios (mod:52) — Sección Archivo Histórico corregida: nomenclatura `arch-*`→`historico-*` desactualizada + opacidad read-only obsoleta

- **Corrección de consistencia (Patch, sin cambio de comportamiento):** la sección documentaba `arch-*` y `locus-archive.css` — nomenclatura previa al rename a `historico-*`/`locus-historico.css` ya aplicado en código desde mod:22 de ese archivo. Detectado al aplicar el `doc_update` de opacidad de la sesión de founder sobre el panel Histórico.
- **Selectores renombrados** en la tabla: `.arch-*` → `.historico-*` (1:1, sin cambio de regla).
- **Nota de migración `--r/--t/--b/--p` → `--req/--tkt/--inc/--disc` eliminada** — ya aplicada en codebase y JS, quedaba como pendiente fantasma.
- **Read-only treatment actualizado:** `opacity: 0.65` → `0.9` (`:hover` → `0.95`) — `locus-historico.css` mod:6/mod:7. Motivo: Histórico en tab propio, diferenciación fuerte innecesaria. Valor 0.9 verificado por cálculo de luminancia relativa (WCAG) contra el peor caso de contraste (dark theme, `--text2`, filas `is-done`) — no confirmado con DevTools en vivo, founder pendiente de esa verificación.

## Cambios (mod:51) — Panel Q-DISC documentado por primera vez: `qdisc-limit-indicator`/`qdisc-grooming-banner` (huérfanas de documentación desde su origen, mismo patrón que el gap corregido en mod:48 para Q-INC) + patrones nuevos `.qdisc-stats-block`, `.qdisc-stats-caption`, `.qdisc-area-chips`/`.stat-area-chip` (gap de CSS cerrado por Nova, detectado por Rune en diagnóstico de render)

## Cambios (mod:50) — TKT1 (CAEL-02): `.bl-sprint-option-bar-fill` documentada — gap mayor detectado, 12 de 14 selectores de la familia sprint selector sin CSS

- **Clase nueva — `locus-backlog.css` mod:87, entregada en TKT1 (CAEL-02 — REQ CAEL-01, deuda técnica CSS Purity):**
  - `.bl-sprint-option-bar-fill` — `width: var(--sprint-option-bar-w, 0%)`, mismo patrón que `.bl-vl-progress-fill` / `.sps-burndown-fill`. Reemplaza `style="width:${pct}%"` (violación CSS Purity confirmada en `_buildSprintOption()`, L129 previo) por la custom property. Integración en JS: `locus-sprint-planificacion.js` mod:29 (Rune).
- **Gap mayor detectado — familia completa del sprint selector de Vista Planificación sin CSS, salvo dos excepciones:** de los 14 selectores consumidos por `_buildSprintOption()` / `_buildSprintSelector()` en `locus-sprint-planificacion.js`, confirmado con CSS real (`locus-backlog.css` mod:87, grep completo) que solo `.bl-sprint-retro-btn` (~L3232, preexistente) y la nueva `.bl-sprint-option-bar-fill` (~L6029) tienen declaración CSS. Los 12 restantes — `.bl-sprint-option`, `.bl-sprint-option-mark`, `.bl-sprint-option-name`, `.bl-sprint-option-meta`, `.bl-sprint-option-bar-wrap`, `.bl-sprint-option-pct`, `.bl-sprint-option-badge`, `.bl-sprint-badge--active`, `.bl-sprint-badge--closed`, `.bl-sprint-active-name`, `.bl-sprint-trigger-progress`, `.bl-sprint-trigger-bar-wrap`, `.bl-sprint-trigger-pct` y `.bl-sprint-trigger-bar-fill` — no tienen ninguna regla CSS en el codebase.
  - `.bl-sprint-trigger-bar-fill` ya consumía `--sbar-w` vía custom property en el JS antes de este TKT — sin violación CSS Purity — pero la clase no tiene base CSS que la use.
  - **No se resuelve en este DOC-UPDATE.** Definir estilos para 12 selectores requiere decisiones de diseño (color, spacing, layout del dropdown) fuera del alcance de una corrección documental — ver Hallazgo fuera de scope en el CHECKPOINT de la sesión, destino Cael, para abrir REQ propio con `design_intent`.
- **Nueva sección de referencia:** `### Sprint selector (Vista Planificación) — familia bl-sprint-option-* / bl-sprint-trigger-*` (ver `§Patrones de componentes flotantes`, junto a `Vista Planificación — familia bl-plan-*`).
- **`mod` de archivos reales:** `locus-backlog.css` mod:86→87 (Nova, TKT1) · `locus-sprint-planificacion.js` mod:28→29 (Rune, TKT1, integración).

---

## Cambios (mod:49) — corrección de hecho: `.sps-empty-cta` / `openNewSprintInline()` es referencia falsa — mismo patrón que `.sps-actions` (corregido en mod:39)

- **`openNewSprintInline()` no existe en el codebase.** Confirmado por grep completo contra `locus-sprint.js` (mod:84) en sesión de Cael/Finn (Fase 5, REQ migración Step 0 → panel Sprint subtab). El empty state real de `#sps-activo` (`_renderSpsActivo()`, sin sprint activo) renderiza únicamente texto informativo: `.sps-empty` + `<p class="sps-empty-hint">La apertura de sprint se propone desde Cael (sprint_proposal) — no hay creación manual.</p>` — sin CTA, sin botón, sin función invocada.
- **`.sps-empty-cta` está declarada en `locus-sprint.css` (L1745-1764) pero con 0 uso en JS** — mismo patrón exacto que `.sps-actions` (documentado en mod:39: clase CSS viva, cero call sites reales). No es huérfana por eliminar en este mod — queda registrada como candidata a limpieza, mismo tratamiento que se le dio a `.sps-actions` en su momento (línea ~853, tabla "Menú de acciones del sprint activo").
- **Origen del error:** la entrada original de `.sps-empty-cta` (anterior a mod:12) nunca fue verificada contra `locus-sprint.js` real — describía el comportamiento que el TKT original probablemente pretendía, no el que quedó implementado. Ningún mod posterior (13→48) la auditó pese a que la auditoría de mod:39 sí cerró el caso gemelo `.sps-actions` en la misma sección.
- **Acción:** tabla de la familia `sps-*` corregida (ver `§Sprint activo`). Sin cambio de archivo `.js` ni `.css` — es corrección documental pura, la clase sigue existiendo en CSS sin uso.
- **Excepción de resolución directa aplicada (`__BR-Core`):** dueña del doc presente en la sesión (Nova) + corrección nivel Patch (no cambia comportamiento, elimina atribución falsa) + sin bifurcación de founder → resuelto en la misma sesión en vez de solo registrarse como Hallazgo fuera de scope.

---
## Cambios (mod:48) — TKT1 (Countdown SLA riesgo + badges huérfanos) + corrección de mod:21: `qinc-item--sla-vencido`/`--sla-riesgo` nunca estuvieron documentadas en §Sprint groups — la referencia era falsa desde su origen

- **Clases nuevas — `locus-backlog.css` mod:86, entregadas en TKT1 (Countdown SLA — Q-INC):**
  - `.qinc-sla-countdown--riesgo` — modificador de `.qinc-sla-countdown` (span de texto dentro de la card de INC high). Activa cuando `remaining < SLA_RIESGO_WINDOW_MS` (< 6h), mismo umbral que ya dispara `.qinc-item--sla-riesgo` a nivel de card en `buildQIncItem()`. Color: `var(--c-severity-high-*)`. Antes de este TKT el countdown en ventana de riesgo no tenía tratamiento visual propio — solo el borde de la card (vía `.qinc-item--sla-riesgo`) señalaba el estado.
  - `.qinc-badge--sla-high` / `--sla-medium` / `--sla-low` — modificadores de `.qinc-badge--sla`. **Gap cerrado — huérfanos desde su introducción:** referenciados en `locus-backlog-item.js:2729` sin definición CSS propia; sin distinción por prioridad, todo badge caía en el rojo genérico de `.qinc-badge--sla` base. Ahora cada modificador declara su propio color por prioridad SLA.
- **Corrección de hecho — origen mod:21:** la nota de mod:21 (`§Cambios mod:21`, línea 209 histórica) afirmaba que `qinc-item--sla-vencido` / `qinc-item--sla-riesgo` estaban "documentadas en §Sprint groups (referencia a sección qinc-* en §Patrones de componentes)". Esa sección (`### Sprint groups y badges — familia .sprint-group-* / .sprint-badge-*`) es sobre el header de sprint en Vista Lista — nunca contuvo patrón `qinc-*` alguno. La referencia fue falsa desde el momento en que se escribió, sin que ninguna auditoría posterior la detectara hasta esta sesión (gap señalado por Nova durante Fase 1/Momento 2 del TKT1, verificado contra el archivo real).
- **Acción:** nueva sección `### Panel Q-INC — familia qinc-*` (ver `§Patrones de componentes flotantes`) documenta el patrón real completo — card-level (`--sla-vencido`/`--sla-riesgo`), countdown (`--riesgo`/`--vencido`) y badge de prioridad (`--sla-high/medium/low`). Tabla de prefijos (línea ~391) y nota de mod:21 actualizadas para apuntar a la sección real en vez de a `§Sprint groups`.
- **`mod` de archivos reales:** `locus-backlog.css` mod:85→86 (Nova, TKT1). Sin cambios sobre `.js` en esta entrega — la integración de `--riesgo` en `buildQIncItem()` queda pendiente de Rune.

---

## Cambios (mod:47) — corrección de mod:38/mod:39: `version-progress-inline/-bar-wrap/-bar/-label` no existe en el codebase — atribución falsa arrastrada 2 correcciones sin verificar contra archivo real (TKT-202607-050, gap detectado en sesión de implementación)

- **`version-progress-*` no vive en `locus-analytics.css` L700-736 ni en ningún otro archivo.** Grep completo del codebase (verificado en sesión de implementación de TKT-202607-050): cero ocurrencias del string, en cualquier posición. L700-736 de `locus-analytics.css` contiene un bloque distinto y activo — `.req-children-block`/`.req-children-progress`/`.req-children-bar-wrap`/`.req-children-bar`/`.req-children-label` — comentado en el propio archivo como `T-202604-048: R→T children block`, feature de progreso de TKTs hijos de un REQ, sin relación con T-051 ni con "progreso por versión".
- **Origen del error:** mod:38 corrigió la atribución de módulo (de `locus-backlog.css` a `locus-analytics.css`) sin verificar el nombre de selector contra el archivo real — el nombre `version-progress-*` era una paráfrasis descriptiva del TKT original, nunca un selector literal. mod:39 heredó el error y lo confirmó "con grep completo" sin que ese grep detectara la ausencia real. Dos correcciones sucesivas sin cerrar el gap real.
- **Acción:** Retirada toda mención de `version-progress-inline/-bar-wrap/-bar/-label` como orphan pendiente de grooming — no hay clase que remover. `.req-children-*` (L700-736 real) no ha sido auditado como huérfano por Rune — si el founder quiere evaluarlo, requiere grep propio, ítem nuevo.
- TKT-202607-050 (removerlo como huérfano) descartado por Cael — AC inválido de origen.

## Cambios (mod:46) — corrección de mod:39/mod:40: `.bl-vc`/`.bl-vc-r*`/`.bl-vc-t*` NO es huérfano — es la Vista consolidada, activa vía `locus-backlog-render.js`

- **Corrección de hecho — origen TKT-202607-068 (descartado por Cael):** el grep de mod:39 buscó el literal `.bl-vc` (con punto inicial) contra el codebase JS y confirmó "cero referencias". Ese patrón no detecta el consumo real — `locus-backlog-render.js` aplica la clase sin punto (`classList.add('bl-vc-r')` o equivalente), forma que el grep de mod:39 no capturaba. Mismo tipo de error que mod:39 corrigió sobre mod:38 y mod:44 corrigió sobre mod:43: grep incompleto, no ausencia real de consumidor.
- **Evidencia:** header de `locus-backlog.css` (mod:82, misma entrega que retiró Vista Kanban deprecada en TKT-202607-027) declara explícitamente: `.bl-vc — esa clase es la vista consolidada (REQs con TKTs anidados), activa, mal etiquetada como "Vista Kanban" por coincidencia de nombre histórico` y, en el bloque de selectores (L5809-5810): `bl-vc — Vista consolidada: REQs con TKTs anidados` / `locus-backlog-render.js — feature activa, no confundir con Vista Kanban deprecada`.
- **DISC de grooming originada en mod:39/mod:40 (registrada por Rune) se descarta** — mismo destino que TKT-202607-068. `.bl-vc*` se retira de cualquier lista de candidatos a eliminación.
- **`mod` de archivos reales:** ninguno tocado — sesión de corrección documental sobre `_Locus-css-ref` únicamente, sin escritura sobre `.css`/`.js` reales.
- **Aprendizaje registrado:** grep de consumo JS para clases CSS debe buscar el selector sin el punto inicial (`bl-vc`, no `.bl-vc`) — el punto es sintaxis CSS, no aparece en `classList.add()` ni en construcción de `className`. Aplica a toda auditoría futura de selectores potencialmente huérfanos en este proyecto.

---

## Cambios (mod:45) — TKT-202607-063: agregado staleness--itil-incompleto; corregida sección §Staleness pill que declaraba el bloque completo como "CSS pendiente" cuando ya estaba implementado (incluía staleness--orphaned no documentado)

## Cambios (mod:44) — corrección de mod:43: `--hover` sí tiene uso confirmado — TKT-202607-016 cierra completo

- **Corrección de hecho:** el grep de mod:43 usó el patrón literal `var(--hover)` (cierre de paréntesis inmediato) y no encontró coincidencias — pero `locus-analytics.css:1773` usa la forma con fallback `var(--hover, rgb(255 255 255 / 3%))`, que ese patrón no capturaba. Con `.js`/`.html` reales ahora adjuntos (`Archivo.zip` — `index.html` + 45 `.js`) y patrón de grep corregido (`--hover\b`, sin asumir cierre de paréntesis), `--hover` **sí tiene 1+ coincidencia real** — se conserva, no se purga. Mismo tipo de error que mod:39 corrigió sobre mod:38 — grep incompleto, no asunción sin evidencia.
- **TKT-202607-016 — completo, los 8 aliases legacy de color/texto confirmados con uso activo vía grep sobre 17 `.css` + 45 `.js` + `index.html` reales:** `--text-muted` · `--text1` · `--text3` (incluye 1 consumidor JS real — `locus-analytics-charts.js:487,507`, valor de color pasado a config de chart) · `--text-secondary` · `--bg-hover` · `--bg-subtle` · `--hover` · `--hover-bg`. Ninguno se purga — AC de edge case ("alias con 1+ coincidencia se conserva") aplica a los ocho. Sin cambios de código — TKT resuelto por verificación, no por eliminación.
- **`mod` de archivos reales:** ninguno tocado — sesión fue solo de verificación/grep, sin escritura sobre `.css`/`.js` reales.

---

## Cambios (mod:43) — TKT-202607-016/017 (REQ-202607-009): purga de aliases legacy sin uso + cadencia de revisión de lint

- **TKT-202607-017 — completo:** `§Reglas lint desactivadas` declara `próxima revisión: 2026-10-08` (cadencia trimestral desde esta entrega, 2026-07-08). Ver nota en esa sección para el criterio de herencia de reglas lint desactivadas nuevas.
- **TKT-202607-016 — parcial, gap registrado:** grep completo sobre los 17 `.css` reales del proyecto (`Archivo_2.zip`, sin `__MACOSX`) contra los 8 aliases legacy de color/texto declarados en `§Aliases de texto` y `§Aliases de fondo`:
  - `--text-muted` · `--text1` · `--text3` · `--text-secondary` · `--bg-hover` · `--bg-subtle` · `--hover-bg` → **1+ coincidencia confirmada cada uno** (consumo real vía `var()` en múltiples archivos). Conservados sin cambio — cumple AC de edge case.
  - `--hover` (fila combinada `--hover` / `--hover-bg` en `§Aliases de fondo`) → **cero coincidencias** como `var(--hover)` en los 17 `.css` — solo aparece en su propia declaración (`locus-base.css:279,442`, redirigiendo a `--bg-hover`). Sin `.js` adjuntos en la sesión para completar el grep que el AC exige sobre `.css`/`.js` reales — no se purga sin esa verificación. **No se aplicó el happy path del AC para este alias — gap registrado, no ejecutado a ciegas.**
- **Acción sugerida:** adjuntar archivos `.js` reales del proyecto (o confirmar explícitamente que `--hover` no se referencia fuera de CSS) para cerrar el TKT-202607-016 sobre este alias puntual. El resto del TKT está resuelto.

---

## Cambios (mod:41) — decisión founder: `.danger-zone` sin fondo crítico persistente — consistencia con `.sps-dropdown-item--danger`/`.blf-*`/`.blt-*`

- **Hallazgo (mod:40) resuelto:** la versión viva de `.danger-zone` (`locus-sesiones-card.css`) solo tiene `color`/hover-tint en `.card-dot-item.danger` — sin el fondo crítico persistente que tenía el bloque muerto eliminado de `locus-backlog.css`.
- **Decisión del founder:** mantener consistencia con el tratamiento liviano ya establecido en `.sps-dropdown-item--danger` y `.blf-*`/`.blt-*` — no restaurar el fondo persistente. No es una regresión — es alineación con la convención ya vigente en el resto de dropdowns del sistema.
- **Sin cambio de código** — decisión documental únicamente. Registrado en `§AI Card rediseño` para que no se re-flaguee como gap en auditorías futuras.

---

## Cambios (mod:40) — INC-[pendiente-ID]: flip-to-fit `.sps-dropdown--flip` + auditoría de patrón dropdown/overflow en toda la base + limpieza de 2 bloques muertos

- **Fix:** `.sps-dropdown--flip` agregado en `locus-sprint.css` (mod:44) — resuelve clipping del menú `···` de sprint en `#sps-programados` contra `overflow: hidden` de `.sps-card`. Ver tabla `sps-*` y nueva nota de arquitectura en esa misma sección. Patrón documentado como convención canónica en `_Locus-ux-ref §E-10` — no es un fix puntual.
- **Auditoría de patrón dropdown/overflow — toda la base CSS (17 archivos):** revisadas todas las familias `dropdown`/`popover`/`menu` (`.sps-*`, `.blf-*`/`.blt-*`, `.card-dot-*`, `.bitem-status-popover`) contra sus contenedores ancestros:
  - `.blf-popover`/`.blt-popover` — ancestro `.bl-toolbar` declara `overflow: visible` explícito. Sin bug activo — riesgo estructural igual si ese `overflow` cambia, adopción de `--flip` declarada como pendiente en `_Locus-ux-ref §E-10`, no ejecutada sin necesidad.
  - `.card-dot-dropdown` (`locus-sesiones-card.css`, versión viva) y `.bitem-status-popover` — ya usan portal `position: fixed` con coordenadas inyectadas por JS (`--card-menu-top/-left`, `--sp-top/-left`). Sin riesgo de clipping por diseño — no requieren `--flip`.
- **Limpieza — bloque `.card-dot-*` muerto en `locus-backlog.css`:** eliminado bloque completo (`.card-dot-menu`/`.card-dot-btn`/`.card-dot-dropdown`/`.card-dot-item`/`.card-dot-divider`/`.card-dot-dropdown .danger-zone`) — superseded por `locus-sesiones-card.css` desde B-202605-020. Cero consumidor confirmado con grep completo (`index.html` + los 17 `.css`). `.dot-confirm-row` conservado — consumidor activo. Ver nota en `§AI Card rediseño`.
- **Limpieza — override `.bl-sprint-dropdown` huérfano en `locus-backlog.css`:** eliminado override de `prefers-reduced-motion` para `.bl-sprint-dropdown`/`.bl-sprint-dropdown.is-closing` — ni la clase base ni las keyframes `bl-sprint-drop-in`/`bl-sprint-drop-out` existen en ningún `.css` del codebase. Hallazgo de esta auditoría, sin INC/TKT previo — override sin regla base que anular.
- **`mod` de archivos reales tocados:** `locus-sprint.css` mod:43→44 · `locus-backlog.css` mod:80→81.

---

## Cambios (mod:39) — corrección de atribución con grep completo del codebase (Rune, post-zip). Mi nota mod:38 tenía dos errores de hecho, ambos corregidos aquí con evidencia:

- **`version-progress-inline/-bar-wrap/-bar/-label` no está ausente del codebase** — vive en `locus-analytics.css` L700-736 (T-051, progreso por versión en Tab Analytics), módulo sin relación con Vista Kanban ni con `locus-backlog.css`. Mi mod:38 afirmó "cero ocurrencias" porque solo verifiqué contra `locus-backlog-render.js` — el doc apuntaba al módulo equivocado desde antes de esa sesión. Confirmado con grep sobre el codebase completo: **cero consumidor JS** en ningún archivo — orphan real, pero en `locus-analytics.css`, no en `locus-backlog.css`.
- **`.bl-vc`/`.bl-vc-r*`/`.bl-vc-t*` sí existe** — ~30 selectores en `locus-backlog.css` L6678-6881. Mi mod:38 afirmó "no existe .bl-vc" — falso, existe como CSS. Lo que no existe es un consumidor: grep completo confirma **cero referencias en ningún `.js` del codebase** — ningún archivo lo construye.
- Ambos hallazgos ya están registrados como DISC por Rune para grooming de Cael — este doc solo corrige la atribución, no declara remoción.

## Cambios (mod:38) — TKT-202607-027 (Vista Kanban deprecada) reaplicado sobre base correcta (mod:37, obsoleta la mod:35 usada en sesión previa). Removida mención a kanban en scope de locus-backlog.css. Corrección con evidencia real: verifiqué directamente contra locus-backlog-render.js — cero ocurrencias de version-progress-*, no existe .bl-vc ni _renderVistaArbol. Retirado el "No eliminar" de esas clases — mi nota anterior (mod:36, nunca aplicada) asumía un bloque árbol separado que no existe. Sin grep completo del codebase no puedo confirmar orphan total — dejo acción sugerida a Cael/Rune.

## Cambios (mod:37) — wrapper `.ct-type-cols` para split de 2 columnas en 'Por tipo' — TKT-202607-003

- **Gap cerrado:** Rune señaló que `.ct-type-rows` (flex-column simple) no soporta el split de 4/3 filas en 2 columnas que pide el AC3 de TKT-202607-003. Agregado `.ct-type-cols` (`locus-analytics.css` mod:8) — envuelve dos `.ct-type-rows` hijos vía `display:flex; gap:16px` sin modificar `.ct-type-rows` en sí, que sigue usándose sin wrapper en el bloque 'Por effort' (`ct-grid` > `ct-block` > `ct-type-rows` directo, sin cambio).
- Markup esperado: `<div class="ct-type-cols"><div class="ct-type-rows">[4 filas: REQ,TKT,DISC,INC]</div><div class="ct-type-rows">[2 filas: PRB,CHG]</div></div>`. **Corregido — retiro de KE (mod:124, TKT2/REQ CAEL-0724-11):** la segunda columna listaba 3 filas (PRB,KE,CHG) — `KE` fue fusionado a `PRB.root_cause_confirmed` (infra_version 51) y ya no tiene selector propio; la columna pasa a 2 filas.

## Cambios (mod:36) — familia `.ct-pill-*` extendida a 7 tipos Gen2 + Cluster B contraste ITIL — TKT-202607-003

- **Gap cerrado — contraste de texto ITIL bajo 4.5:1:** `--orange`/`--yellow` (light) y `--slate` (dark) fallaban como color de texto de pill (2.93–3.46:1 / 3.31–4.02:1) — no habían sido verificados para ese uso, solo documentados como color de tag/severity. Tokens `--orange-text`/`--yellow-text`/`--slate-text` agregados en `locus-base.css` mod:7 — ver `§Colores declarados — .ct-pill-*`.
- **Migración `.ct-pill-r/t/b` → `.ct-pill-req/tkt/inc`** (`locus-analytics.css` mod:7) + agregadas `.ct-pill-disc`/`.ct-pill-prb`/`.ct-pill-ke`/`.ct-pill-chg` — Cycle Time por tipo ahora cubre los 7 tipos Gen2. Ver `§Selectores Gen 1` y `§Colores declarados — .ct-pill-*`.
- **Hallazgo sin resolver — fuera de scope:** `--blue`/`--red` como texto de pill (`.item-type-pill`/`.ct-pill-req`/`.ct-pill-inc`) caen bajo 4.5:1 en light theme contra `--surface3`/`--bg2` (~3.31–4.11:1) — mismo patrón que el gap de ITIL recién cerrado, pero no corregido en este TKT. Registrado como DISC. **Gap cerrado en mod:54** — `--blue-text`/`--red-text` agregados; `.item-type-pill`/`.ct-pill-req`/`.ct-pill-inc` siguen usando `--blue`/`--red` directos (fuera de scope de mod:54 también) — la migración de esos selectores a los tokens `-text` queda pendiente, DISC no descartada.

## Cambios (mod:35) — familias `.blf-*` (popover Filtros) y `.blt-*` (popover Tipos) documentadas — TKT1/TKT2 [tmp:req-clutter-backlog]

- **Gap cerrado:** `#bl-filter-badge` (§1249, T-202606-057) documentaba un selector sin instancia activa en el codebase desde el REQ de consolidación de toolbar anterior — deuda de documentación señalada por Rune y confirmada por Nova al iniciar TKT1. Reemplazado por la familia real introducida en este REQ.
- **Nueva sección `### Popovers de toolbar/stats — familia .blf-* / .blt-* (TKT1/TKT2)` en `§Patrones de componentes flotantes`** — documenta ambos popovers como adaptación del patrón ya validado `.sps-menu-wrap` / `.sps-btn-menu` / `.sps-dropdown` (visibilidad via atributo `hidden` nativo, no `.is-hidden`).
- **Principio de diseño:** se reutilizó el patrón `.sps-dropdown` en vez de crear un componente de popover nuevo — mismo lenguaje visual ya conocido por el sistema, menor superficie de mantenimiento. Trigger visual basado en `.bl-strip-btn` para consistencia con la fila de toolbar existente.
- **Accesibilidad verificada:** `:focus-visible` con `outline: 2px solid var(--accent)` heredado del mismo patrón que `.sps-btn-menu`. Contraste de badge (`--accent` + `--text-on-accent`) — mismo par ya validado en el sistema.
- **Sin tokens nuevos** — reuso exclusivo de `--text-xs` · `--text-sm` · `--text-2xs` · `--radius-xs/sm/md/pill` · `--surface/2/3` · `--border/2` · `--accent` · `--accent-dim` · `--text-on-accent` · `--z-popover` · `--trans-fast/color`.
- **Archivo:** `locus-backlog.css` (mod:75).
- **Origen:** Propuesta de mejora emitida por Nova al cierre del REQ, aplicada en esta sesión de doc por instrucción del founder.
- **`infra_version`:** sin cambio — Doc Ref, usa `mod` como señal de frescura.

---

## Cambios (mod:34) — `.bitem-collapse-arrow` agrandado + reposicionado como primer control del header; cleanup de selector huérfano

- **Gap cerrado — target de click insuficiente:** `.bitem-collapse-arrow` usaba `var(--text-2xs-plus)` (10px) sobre un `width: 12px` — carácter de disclosure triangle apenas clickeable (Fitts's Law). Nunca estuvo documentado en este ref pese a tener familia activa en `locus-backlog-item.css` — gap de cobertura, no solo de tamaño.
- **Fix aplicado:** `font-size: var(--text-lg)` (16px) + `width: 20px` + `color` en hover heredado de `.bitem-header:hover` (antes sin feedback de hover propio). Ver nueva sección `### Header de ítem — orden de controles` en `§Patrones de layout`.
- **Reposición HTML (Rune):** el chevron pasó a ser el primer elemento del `.bitem-header`, antes de `.item-drag-handle` — convención de disclosure triangle (anticipa contenido, se lee antes). Selección por `id`/`class` en JS — sin dependencia de orden DOM, reposición sin riesgo de romper toggle.
- **Cleanup — selector huérfano detectado por el reorder:** `.bitem-type-TKT ~ .bitem-title-col ~ .bitem-collapse-arrow ~ .bitem-header-right .bitem-effort-dot.on` dependía del orden DOM anterior (chevron después de `.bitem-title-col`). Tras el reorder dejó de matchear — sin efecto visible porque la misma regla ya tenía `.item.bitem[data-type="TKT"] .bitem-effort-dot.on` como selector duplicado por atributo. Eliminado — cero selectores combinador-hermano dependientes de orden de header restantes, verificado con grep antes de entregar.
- **Origen:** hallazgo fuera de scope registrado por Rune durante TKT de fix del chip de sprint en DISC.
- **`infra_version`:** sin cambio — Doc Ref, usa `mod` como señal de frescura.

---

## Cambios (mod:33) — familia `--idea-*` (card DISC) desconectada de `--purple`: INC de color naranja resuelto

- **Gap cerrado:** `.bitem--idea` (card completa de DISC en `locus-backlog.css`) declaraba una paleta HSL propia y paralela — `--idea-hue: 42` (naranja) — que nunca estuvo atada a `var(--purple)`, el token semántico de DISC ya correcto en `.item-type-pill.DISC` / `.bitem-type-DISC`. La card se renderizaba naranja pese a que el pill de tipo sí mostraba púrpura.
- **Fix aplicado:** `--idea-color` / `--idea-color-dim` / `--idea-bg` / `--idea-bg-hover` / `--idea-border` / `--idea-badge-bg` / `--idea-badge-text` ahora se derivan de `var(--purple)` vía `color-mix`, en el bloque light y en `[data-theme="dark"]`. `--idea-hue` fue eliminado — cero declaraciones ni consumidores residuales, verificado antes de entregar.
- **Contraste verificado:** texto del badge en negro sobre `var(--purple)` → 5.26:1, cumple AA 4.5:1.
- **Anti-pattern registrado:** una familia de variables de card completa (`--idea-*`) puede declararse en hue crudo (`--idea-hue`) sin referenciar el token semántico del tipo correspondiente, sin que ninguna auditoría de este doc lo capture si esa familia no está inventariada junto a `.item-type-pill`/`.bitem-type-*`. Ver tabla `§Colores declarados — item-type-pill Gen2` — la familia `.bitem--idea` ahora referenciada explícitamente ahí.
- **Origen:** INC reportado por el founder — DISC visualmente naranja. Investigado por Rune (causa raíz), fix implementado por Nova.
- **`infra_version`:** sin cambio — Doc Ref, usa `mod` como señal de frescura.

---

## Cambios (mod:32) — bug visual real en bloque "Intención del R": `.ie-intencion-group`/`.ie-intencion-field` sin layout

- **Gap cerrado:** `#item-editor-overlay .ie-intencion-group` (gap:10px) y `#item-editor-overlay .ie-intencion-field` (gap:5px) agregados en `locus-sesiones.css` (mod:19→20). Sin estas reglas, los 3 sub-campos del bloque Intención (Problema/Done cuando/No incluye) se apilaban sin espaciado.
- **Detectado durante:** verificación manual del árbol HTML del Item Editor al resolver el `Hallazgo — clases CSS referenciadas sin definición` — no capturado por el cruce automático del inventario porque los wrappers no tienen ID propio.
- **Falsos positivos confirmados en el mismo hallazgo (sin cambio de CSS):** `ie-input` (3 inputs del bloque intención) y `ie-select` (`#item-sprint`) — ya cubiertos por los selectores de tipo `#item-editor-overlay .ie-field input/select`, mismo mecanismo que Cat.1 del inventario.
- **Fila `ie-` en `§Prefijos de módulo` actualizada** con la sub-familia `ie-intencion-*`.
- **`infra_version`:** sin cambio.

---

## Cambios (mod:31) — cierre de 2 gaps de nomenclatura del inventario UI (auditoría Finn, mod:14): prefijo `ie-` y familia `.status-confirm-*` documentados

- **Gap cerrado 1 — `#item-sprint-inherited-val` sin CSS:** nueva regla `#item-editor-overlay .ie-field .ie-sprint-inherited` en `locus-sesiones.css` (mod:19) — mismo box que input/select del Item Editor, color `--text2` para señalar valor no editable.
- **Gap cerrado 2 — `#status-confirm-title` sin CSS:** nueva regla `.status-confirm-title` en `locus-backlog.css` (mod:73) — mismo patrón que `.tag-modal-title` (box de 340px).
- **Prefijo `ie-` agregado a `§Prefijos de módulo`** — no estaba documentado pese a tener familia activa en `locus-sesiones.css` y `locus-modals.css`.
- **Nueva sección `### Confirmación de status — familia .status-confirm-*` en `§Patrones de componentes flotantes`** — documenta la arquitectura: base visual en `locus-backlog.css`, animación/estados compartidos con otras familias de modal en `locus-modals.css`.
- **Hallazgo sin resolver en este mod:** comentario en `locus-modals.css:2925` declara que los compuestos `#item-editor-overlay .ie-*` viven en `locus-tracker.css` — archivo inexistente en el proyecto, en realidad viven en `locus-sesiones.css`. Fuera de scope de este cierre — requiere sesión propia de limpieza de comentarios.
- **`infra_version`:** sin cambio — Doc Ref, usa `mod` como señal de frescura.

---

## Cambios (mod:30) — TKT3 REQ Fixes subtab Backlog Histórico: `.arch-zone-divider` documentado

- **Gap cerrado:** `.arch-zone-divider` se inserta en el DOM por `renderArchivoHistorico()` (`locus-backlog-archive.js`) desde antes de este sprint, sin definición CSS — divisor invisible entre zonas de sprint consecutivas en el panel Histórico. Detectado en auditoría de Finn.
- **Nueva sección `### Divisor de zona — .arch-zone-divider` en `§Patrones de componentes flotantes`.**
- **Sin tokens nuevos:** reuso exclusivo de `--border`, mismo token que `.arch-historico-body` y `.arch-item-row` en el mismo archivo.
- **`infra_version`:** sin cambio — Doc Ref, no versiona por infra_version (usa `mod` como señal de frescura).

---

## Cambios (mod:29) — TKT1 REQ gutter subtabs + patrón barra sticky de contenedor (INC-202607-001)

- **Gap cerrado 1 — gutter unificado de subtabs:** Token `--subtab-gutter: 12px` declarado en `locus-base.css` (mod:6). Consumido como `padding-left` en `.tpl-detail` (`locus-proyectos.css` mod:6), `#tab-proyectos` (`locus-backlog.css` mod:72) y `#tab-sesiones` (`locus-sesiones.css` mod:18). `#tab-analytics` y el contenedor externo de `#tab-backlog` quedan fuera — ya declaran `padding: 2rem` propio, mayor al gutter objetivo; aplicar el token ahí habría apilado el valor en vez de unificarlo. Nueva sección `### Gutter unificado de subtabs — token --subtab-gutter` en `§Patrones de layout`.
- **Gap cerrado 2 — barra sticky de contenedor:** Patrón documentado para `.bl-toolbar`, `.active-filter-chips` y equivalentes futuros — ver detalle en nueva sección `### Barras sticky de contenedor (toolbar/stats)` en `§Patrones de layout`. Origen: INC-202607-001.
- **Nueva sección de nivel superior `## Patrones de layout`** — agrupa ambos patrones; antes no existía un lugar natural para reglas de layout estructural (distintas de `§Patrones de componentes flotantes`, que cubre overlays/popups).
- **`infra_version`:** sin cambio — Doc Ref, no versiona por infra_version (usa `mod` como señal de frescura).

---

## Cambios (mod:28) — familia `tvh-notif-*` documentada, TKT3a (teaser de notificación en tracker-view-header)

- **Gap cerrado:** TKT3a introdujo `.tvh-notif-teaser`, `.tvh-notif-icon`, `.tvh-notif-title`, `.tvh-notif-body`, `.tvh-notif-viewall` en `locus-sesiones.css` sin sección propia — el prefijo `tvh-` ya estaba listado en la tabla de prefijos pero sin patrón documentado.
- **Nueva sección `### Teaser de notificación — familia tvh-notif-*` en `§Patrones de componentes flotantes`** — ver detalle abajo.
- **Tokens reusados, sin tokens nuevos:** `--card-bg-hover`, `--text`, `--color-primary` — mismos que `.rsb-notif-item--unseen`/`.rsb-notif-title` en `locus-radar.css`, contraste ya validado en ese componente.
- **`infra_version`:** sin cambio — Doc Ref, no versiona por infra_version (usa `mod` como señal de frescura).

---

## Cambios (mod:26) — gap de contraste --green (light) como elemento gráfico no-texto, detectado en fix de acento por tipo del modal DIFF

- **Gap cerrado:** `--green` (light, `#1aab5a`) sobre `--surface1`/`--surface2` da 2.99:1/2.82:1 — falla el mínimo 3:1 para elementos gráficos no-texto (bordes, acentos), estándar WCAG 2.1 AA distinto del 4.5:1 de texto que este doc ya verificaba para otros tokens (ej. `--purple`). Como color de texto no fue verificado en este análisis — puede seguir siendo válido para ese uso.
- **Tabla de tokens de color utilitarios:** fila `--green` actualizada con la nota de contraste y referencia al override aplicado.
- **Override acotado, sin tocar el token global:** `locus-backlog-item.css` usa `#16914c` en `[data-theme="light"] .mdiff-card.mdiff-type--tkt` — corrige solo el uso de acento de card (2px border-top), no afecta otros consumidores de `--green`.
- **Origen:** detectado durante auditoría de Finn del fix de acento por tipo (7 tipos) del modal DIFF — `--yellow`/`--slate` (KE/CHG) inicialmente señalados no requerían ajuste al re-evaluar contra el estándar correcto (3:1); único caso real fue `--green` en TKT/light.
- **`infra_version`:** sin cambio — Doc Ref, no versiona por infra_version (usa `mod` como señal de frescura).

---

## Cambios (mod:25) — REQ header en 3 zonas + limpieza CSS muerta

- **Gap cerrado:** `.header-zone` (familia `--brand` / `--nav` / `--utils`) introducida en `locus-layout.css` mod:8 no tenía sección propia pese a reorganizar `.header-inner` completo — auditoría de header requería grep manual. Nueva sección `### Header global — familia .header-zone-*` en `§Patrones de componentes flotantes`.
- **`.cmd-k-pill` eliminada** de `locus-layout.css` (mod:9) — sin instancias activas en `index.html` ni en ningún otro archivo real del proyecto. Confirmado por grep completo antes de eliminar. No pasa por `§Deprecated` porque no había call sites que migrar — eliminación directa, no candidata a sprint siguiente.
- **`.tabs` pierde `margin-inline: auto`** — el centrado de la navegación ahora vive en `.header-zone--nav`. Único call site de `.tabs` es el header (`index.html` L72) — sin impacto lateral fuera de este módulo.
- **`infra_version`:** sin cambio — `10` sigue vigente, coincide con BR-Execution v1.4 y OB-Strategy v1.9.

## Cambios (mod:24) — TKT-202607-001: documentado patrón mdiff-queue-badge, gap detectado por Finn

- **Gap cerrado:** `.mdiff-queue-badge` / `.mdiff-queue-badge--qinc` nunca estuvieron documentados en este doc pese a tener call sites activos desde INC-[pendiente-ID] — detectado durante el fix de `--qdisc` (DIFF mostraba selector de sprint incorrecto para DISC).
- **Nueva sección** en `§Patrones de componentes flotantes`: `mdiff-queue-badge` — badge de cola fija en modal DIFF. Documenta las tres variantes (`base` / `--qinc` / `--qdisc`) y la lógica de selección en JS (`_QINC_TYPES` / `_QDISC_TYPES`).
- **`--qdisc` agregado** — color `var(--purple)`, mismo token que `.item-type-pill.DISC` (consistencia con `§Colores declarados — item-type-pill Gen2`, ya existente).
- **Anti-pattern registrado:** declarar clase modificadora en JS no garantiza CSS existente — `--qinc` estuvo sin color propio sin que se detectara, por seguir siendo visualmente aceptable en el tono neutro heredado de la clase base.
- **`infra_version`:** `8` → `10`, sincronizado con BR-Execution v1.4 y OB-Strategy v1.9 vigentes.

## Cambios (mod:23) — TKT2/TKT3 REQ-tmp-qa-cleanup S'02: limpieza de CSS huérfano detectada en auditoría QA

- **Eliminadas de `locus-backlog.css`:** `.stat-progress-pct` · `.stat-mini-track` · `.stat-mini-fill` (+ override `[data-theme="light"] .stat-mini-fill`) — sin call sites en JS ni HTML, huérfanas desde un rediseño previo de la barra de progreso de stats-bar. Detectado por Finn durante auditoría QA de stats-bars (hallazgo #3b).
- **Eliminado de `locus-base.css`:** token `--green-dark` — huérfano tras la eliminación de `.stat-mini-fill`, su único consumidor en todo el codebase. Verificado: 0 referencias tras el cambio.
- **Tabla de tokens de color utilitarios:** fila `--green-dark` removida.
- **Regla `--green-dark`:** removida — ya no aplica, componente eliminado.

---

## Cambios (mod:22) — corrección de color --c-high-* y anti-pattern de naming vs --c-severity-high-*

Discrepancia detectada por Finn en cierre de REQ-limpieza-ui-locus: este doc declaraba `--c-high-bg/text/border` como Azul, pero `locus-base.css` (mod:3) los implementa en naranja desde origen — error preexistente del doc, no del código. Corregido el color declarado. Agregada nota de anti-pattern para no confundir con el token `--c-severity-high-*` (familia distinta, introducida en TKT2 del mismo sprint) — ambos comparten naranja por coincidencia.

---

## Cambios (mod:21) — TKT-D3 / TKT-D5: Q-INC reemplaza S-HOTFIX

- **Prefijo `qinc-` agregado** a tabla de prefijos de módulo — `locus-backlog.css`. Cubre panel Q-INC, cards ITIL, badges SLA, secciones y stats bar del panel.
- **`#sps-hotfix` → `#sps-qinc`** — renombrado en `index.html` (TKT-D1). Tabla de secciones del sub-tab Sprints actualizada.
- **`sprint-group-hotfix` / `sprint-badge-hotfix`** — eliminadas de `locus-backlog.css` y `locus-sprint.css` (TKT-D3). Filas marcadas como eliminadas en tabla de sprint groups.
- **Nota de detección de hotfix** (`isHotfix`) — eliminada. `S-HOTFIX` no existe en Gen 2; la detección ya no aplica.
- ~~**Clases `qinc-item--sla-vencido` / `qinc-item--sla-riesgo`** documentadas en §Sprint groups (referencia a sección qinc-* en §Patrones de componentes).~~ **Corregido en mod:48 — referencia falsa desde su origen:** §Sprint groups nunca contuvo patrón `qinc-*`. Documentación real → `§Panel Q-INC — familia qinc-*`.

---

## Cambios v0.6.4 (mod:19) — coherencia con BR Gen 2 (infra_version: 5)

- **Encabezado actualizado:** `infra_version: 20` → `5` · versiones BR actualizadas a Gen 2 (BR-Core v1.3 · BR-Ecosystem v1.2 · BR-Execution v1.1 · OB-Strategy v1.4). El archivo ya no declara versión en el nombre (patrón Doc Ref correcto per `__OB-Strategy §5`).
- **Terminología de tipos de ítem:** Referencias a letras cortas Gen 1 en texto descriptivo actualizadas a nombres canónicos Gen 2. Selectores CSS reales (`--r/--t/--b/--p`) documentados como estado actual del codebase — pendientes de migración por Rune (ver nota de migración al final de cada sección afectada).
  - `bl-vl-`: "Rs y Ts" → "REQs y TKTs"
  - `spl-row-counts`: "pills R/T/B" → "pills REQ/TKT/INC"
  - `spl-type--r/t/b`: documentado con nota de migración a `--req/--tkt/--inc`
  - `arch-row-type--r/t/b/p`: documentado con nota de migración a `--req/--tkt/--inc/--disc`
  - Sección Cerradas: "P terminales" → "DISC terminales"

---

## Cambios v0.6.3 (mod:18) — unificación naming Col 3 popup

- **Selectores canónicos definitivos para T-202606-016/017:** `du-doc` · `du-section` · `du-badge` · `du-badge--agregar/--reemplazar/--eliminar` · `du-escalacion` · `docupdate-rows` · `file-rows` · `file-row-mod-pill`.
- **Eliminados de `locus-sesiones.css`:** `docupdate-doc` · `docupdate-section` · `docupdate-action` · `docupdate-escalate`. Sin call sites JS — eliminación limpia confirmada por grep.
- **css-ref actualizado:** sección popup de T-202606-016/017 refleja naming canónico final. Mención de aliases y coexistencia eliminada.

---

## Cambios v0.6.2 (mod:17) — T-202606-016 · selectores popup Col 3 (Archivos tocados + Doc-updates)

- **`.sps-actions` confirmado inexistente** — sin instancia en CSS ni JS. El componente real de acciones del sprint activo es `.sps-menu-wrap` (contenedor) → `.sps-btn-menu` (botón trigger, atributo `data-sps-activo-menu`) → `.sps-dropdown` (panel de opciones, visibilidad via atributo HTML `hidden` nativo — **no** clase `.is-hidden` como el resto del sistema). Ítems del dropdown: `.sps-dropdown-item` / `.sps-dropdown-item--danger` / separador `.sps-dropdown-sep`.
- El mismo patrón (`.sps-menu-wrap` + `.sps-dropdown`) se reutiliza en la sección `#sps-programados` para la acción "Descartar sprint" — confirmado en `_renderSpsProgramados()`, `locus-sprint.js` L545-548.
- Eliminado el ⚠️ "no confirmado" sobre `.sps-actions` — gap cerrado.

---

## Cambios v0.6.0 (mod:15) — DOC-UPDATE T-202606-002, verificado contra locus-sprint.css mod:36 + index.html mod:73

- **Sección "Sprint activo — familia `sps-*`" reconciliada contra código real:**
  - `.sps-header` no es el nombre real del header de card — el selector real es `.sps-card-header` (ver `locus-sprint.css` L2016/L2566). `.sps-header` sí existe como bloque propio pero es el contenedor de meta-grid (versión/release/goal/scope), no el header de ID+título.
  - `.sps-burndown-wrap` no existe — el selector real es `.sps-progress-wrap`.
  - `.sps-actions` no tiene instancia de markup activa confirmada en `index.html` — solo mencionado en comentario (T-202606-042). Comentario en `locus-sprint.css` indica superseded por `.sps-menu-wrap`/`.sps-dropdown`, generados dinámicamente por `_renderSpsActivo()` — no confirmado en CSS ni HTML estático, pendiente de verificación con `locus-sprint.js`.
  - `.sps-card--pausado` confirmado vigente (no `.sps-card--paused`, deprecada — 0 uso en JS, ver `locus-sprint.css` L1991).
  - `#sprint-panel-sprints` es selector por **ID**, no clase `.sprint-panel-sprints` — corregido en toda referencia de este doc.
  - No existen `.sps-layout` ni `.sps-sidebar` en ningún punto del codebase — `#sprint-panel-sprints` es `flex; flex-direction: column` de una sola sección, sin layout de dos columnas que anular.
  - **Estructura real confirmada (`index.html` L728-736):** `#sprint-panel-sprints` contiene 5 hijos directos sin wrapper intermedio — `#sps-activo` · `#sps-programados` · `#sps-pausados` · `#sps-hotfix` (renombrado a `#sps-qinc` en TKT-D1) · `#sps-cerrados`. La tabla previa solo documentaba 3 de los 5. `#sps-programados` y `#sps-hotfix` agregados a la tabla de naming.
- **Nueva entrada:** familia `.spt-context-header` — encabezado de contexto "Sin sprint activo" para modo vista-principal del sub-tab Sprints (T-202606-002). Ver sección dedicada abajo.
- **Nota de arquitectura:** `.sph-header` (`#sprint-panel-header`) es hermano de los 4 paneles del Tab Sprint, no hijo de `#sprint-panel-sprints`. Su visibilidad (`is-hidden`) la controla JS — no es responsabilidad CSS de este T.

---

## Cambios v0.5.0 (mod:14) — gap detectado en consulta UX de Fase 1, R sidebar Backlog (sin código asignado aún)

- Agregada fila `tpl-` a la tabla de Prefijos de módulo — familia activa en producción (`tpl-sidebar-nav`, `tpl-nav-btn`, `tpl-sidebar-label`, `tpl-sidebar-section`, `tpl-nav-badge`, usados en `index.html` dentro de `tab-backlog`) que no tenía entrada en esta tabla.
- **Archivo fuente no confirmado.** Verificado contra los CSS adjuntos en esta sesión (`locus-backlog.css`, `locus-backlog-item.css`, `locus-layout.css`): solo `.tpl-nav-badge` y sus modificadores aparecen definidos (en `locus-layout.css`, junto a `.doc-subtab-btn`/`.sspanel-btn`, posible alias o resto de naming previo — no confirmado). Las clases base `.tpl-sidebar-label`, `.tpl-sidebar-nav`, `.tpl-sidebar-section`, `.tpl-nav-btn` no aparecen en ningún archivo adjunto a esta sesión. La columna `Archivo fuente` queda con el valor `no confirmado — ver nota` hasta que se audite con el `.css` real correcto adjunto.
- No reconciliado en esta versión: confirmar si `.doc-subtab-btn` / `.sspanel-btn` (ambos en `locus-layout.css`, sin call site en el `index.html` adjunto a esta sesión) son naming previo de este mismo componente o código muerto — pendiente de sesión con Rune para grep contra los 50 módulos JS reales.

---

## Cambios v0.5.0 (mod:13) — T-202606-028

- Prefijo `sh-` (Sprint Health panel, `locus-analytics.css`) eliminado de la tabla de naming. Bloque CSS correspondiente (~620 líneas) removido por Rune — verificado contra los 50 módulos JS reales: cero call sites. Las funciones de atribución original (`renderSprintBurndown` · `_scmStep1Html` · `createSprint`) generan hoy `sph-*` y `scm-*`, no `sh-*`.
- El componente "Sprint Health" vivo hoy usa namespace `sprint-health-*` en `locus-projects.js` / `locus-backlog-panel.js` — su CSS no vive en `locus-analytics.css`. No se agrega entrada de naming para `sprint-health-*` en esta versión — pendiente de auditoría propia si se confirma que necesita doc formal (no es prefijo BEM compacto, es namespace literal sin abreviar; evaluar si conviene normalizar).
- `.sprint-inline-hint` y `.badge-scope-added` — preservadas en `locus-analytics.css`, estaban intercaladas en el rango eliminado. Sin cambio de comportamiento.

---

## Cambios v0.5.0 (mod:12) — auditoría contra 17 CSS reales, 2026-06-21

- Escala de z-index: heading corregido de "30 tokens" a "31 tokens" — la tabla ya listaba 31 filas, el heading estaba desfasado.
- Auditoría completa de los 17 archivos reales: tabla de arquitectura (líneas) detectada desactualizada en 11 de 17 filas. **No reconciliada en esta versión** — los CSS reales usados para esa parte de la auditoría no están adjuntos en esta sesión de cierre. Pendiente: re-adjuntar los 17 archivos para actualizar la columna `Líneas` con valores exactos.
- Gap de L.813 (`preview-tg-tag--warn`/`--info` sin archivo canónico confirmado) — auditoría encontró indicios de resolución parcial. **No reconciliado en esta versión** por el mismo motivo — requiere los archivos reales adjuntos para confirmar archivo canónico exacto.
- 2 defectos detectados en archivos reales durante la auditoría — no son contenido de este doc, registrados como hallazgos en el CHECKPOINT de cierre para Cael/Rune: header de identidad duplicado en `locus-sesiones.css` (mod:3 y mod:9 apilados) · `sprint:PP-S-housekeeping` inválido en `locus-backlog-item.css` (no es un ID `[Prefijo]-S-XX`).

---

## Propósito y dueño

**Dueño:** Nova — lo mantiene actualizado al cerrar cada sprint donde interviene.
**Audiencia:** Rune — lo consume como referencia de implementación. Si Rune detecta un conflicto entre este documento y un R activo, devuelve a Nova antes de resolver por su cuenta.

---

## Arquitectura de módulos CSS

**Auditoría completa 2026-07-17 (Nova) — 21 archivos, verificado línea por línea contra `index.html` (`<link>` L118-138) + los 21 `.css` reales del ZIP. Reemplaza la tabla de 17 archivos, desactualizada desde el split de `locus-modals.css` y los renames de `locus-sprint-plan.css`/`locus-archive.css`.** **Fila 3 y fila 4 nueva actualizadas mod:126 (extracción Q-INC, ver `§Cambios mod:126`) — resto de la tabla sin reverificar en esta sesión, valores heredados de la auditoría 2026-07-17.**

22 archivos en orden de carga en `index.html`:

| # | Archivo | Líneas | mod · autor | Scope |
|---|---|---|---|---|
| 1 | `locus-base.css` | 547 | mod:11 · Nova | Variables globales, reset, tokens `:root` |
| 2 | `locus-layout.css` | 2440 | mod:19 · Nova | Shell, header, tabs, botones base, search |
| 3 | `locus-backlog.css` | 6349 | mod:128 · Nova | Tab Backlog — lista, filtros, sprint selector, tree view. Rama Reactiva (Q-INC) extraída a fila 4 (mod:126) |
| 4 | `locus-incidents.css` | 480 (verificado contra archivo real, mod:127) | mod:2 · Nova | **Alta (mod:126), corrección de atribución en mod:127.** Tab Incidentes (Q-INC) — `#tab-incidentes`, badges de tipo ITIL (4 variantes vigentes, `--ke` reachable — bug de clasificación en `_isQIncTerminal`, ver `§Cambios mod:128`), señales SLA, comportamiento actual, card/sección/badge/countdown/columnas. Extraído de `locus-backlog.css`. Sin dependencia de cascada con archivo vecino — posición es trazabilidad de origen, no requisito de especificidad |
| 5 | `locus-backlog-item.css` | 4567 | mod:78 · Nova | `buildBacklogItem()` — item expandido, IDP, merge diff. **Fila actualizada mod:133** (previo: mod:76/4600 — desfase de 2 mods, ver `§Cambios mod:133`) — histórico: **corregida también en mod:129, tabla declaraba mod:62/4212** (ver `§Cambios mod:129`, Hallazgo fuera de scope) |
| 6 | `locus-sprint.css` | 3362 | mod:57 · Nova | Tab Sprint — header, burndown, lista Rs, scope added, workers, sprint picker, subtab nav |
| 7 | `locus-sprint-close.css` | 1153 | mod:2 · Nova | Modal cierre de sprint — `sprint-close-*` · `scm-*` · `scm-retro3-*` |
| 8 | `locus-contracts.css` | 565 | mod:7 · Nova | Sub-tab Plan · Contratos — `plan-*` · `acv-*` · `ctr-*` — renombrado desde `locus-sprint-plan.css` |
| 9 | `locus-sprint-ui.css` | 703 | mod:9 · **Rune ⚠️** | Vista Planificación drag & drop · EXECUTION-PLAN UI — `bl-plan-*` |
| 10 | `locus-historico.css` | 531 | mod:7 · Nova | Histórico unificado — `historico-*` — renombrado desde `locus-archive.css` (`arch-*`) |
| 11 | `locus-sesiones.css` | 8210 | mod:32 · Nova | Tab Tracker — grid, cards IA, sesiones, historial |
| 12 | `locus-sesiones-card.css` | 678 | mod:10 · Nova | Rediseño AI Card — `sc-*` · `card-dot-*` |
| 13 | `locus-radar.css` | 1674 | mod:6 · Nova | Radar Sidebar global — `rsb-*` |
| 14 | `locus-analytics.css` | 3098 | mod:11 · Nova | Tab Analytics — KPIs, charts, heatmap |
| 15 | `locus-modals-base.css` | 1247 | mod:20 · Nova | Shell modal genérico — `.modal-overlay`, `.modal--ingest`, `.modal-split*`, `.mdiff-overlay--docked`, `.msc-diff-empty*`, avatar/clean-project/gconfirm overlays, `.blocker-*`. **Fila corregida mod:129 — tabla declaraba mod:12/1210, desfasada del archivo real (ver `§Cambios mod:129`, Hallazgo fuera de scope)** |
| 16 | `locus-modals-toast.css` | 725 | mod:1 · **Rune ⚠️** | Toast stack (`#toast-stack`) + panel CHECKPOINT (`#ckpt-panel`, `.ckpt-section*`, `.ckpt-body/-context/-decision`) |
| 17 | `locus-modals-tracker.css` | 263 | mod:1 · **Rune ⚠️** | Header de CHECKPOINT expandido (`.ckpt-header*`), avatar picker (`.avatar-grid/-lg/-option`), blind-exhaust flow, splash `#pepe-splash` |
| 18 | `locus-modals-editor.css` | 277 | mod:2 · Nova | Editor de template/IDP inline — `.ie-*`, `.tpl-picker-*`, `.tpl-save-*` |
| 19 | `locus-modals-misc.css` | 2403 | mod:3 · Nova | Quick Capture (`.qc-*`), auth (`.auth-*`), Doc Log drawer, ~~cmd palette~~ (`.cmd-palette-*` — 9 reglas huérfanas, Command Palette retirado del JS 2026-07-13, ver `§Cambios mod:141`), clean-project checks/panel |
| 20 | `locus-docs.css` | 1060 | mod:6 · Nova | HTML-MAP viewer y Context vivo — `htmlmap-*` · `mm-*` · `context-*` · `du-*` (DOC-UPDATEs pendientes, T-202606-033) · `du-resolved-*` (Sub-tab Resueltos, TKT-202608-237) |
| 21 | `locus-document-generator.css` | 921 | mod:2 · Nova | Map Generator overlay — `mg-*` |
| 22 | `locus-proyectos.css` | 3871 | mod:10 · Nova | Tab Proyectos — dashboard, contexto, notas, tmpl-trigger |

**Regla de orden:** El orden de carga es invariante. No reordenar sin aprobación de Nova. Rune verifica que `index.html` cargue los 22 archivos en este orden exacto al inicio de cada sesión que toque CSS.

**⚠️ Hallazgo de esta auditoría — CSS Purity violado en 3 archivos:** `locus-sprint-ui.css` (mod:9), `locus-modals-toast.css` (mod:1) y `locus-modals-tracker.css` (mod:1) declaran header de identidad con `autor:Rune`. `__BR-Execution §3` y `__Role-Nova §Propósito` son explícitos y sin excepción: Nova es la única rol que escribe en archivos `.css` en todo el ecosistema. No se corrige en esta entrada — reescribir el header no resuelve si el contenido real fue escrito por Rune sin pasar por Nova. Registrado como `Hallazgo fuera de scope` — acción sugerida: Cael evalúa si amerita INC (violación de regla dura ya ocurrida, contenido a auditar por Nova antes de confiar en esos 3 archivos como referencia) o DISC (si el contenido resulta correcto y solo es el header el que está mal atribuido). `locus-sprint-ui.css` es particularmente relevante — mod:9 implica ediciones repetidas, no un accidente aislado de mod:1.

**Iconografía del sistema (mod:73):** Todo ícono `ti ti-*` del ecosistema depende de Tabler Icons, cargado vía CDN en `index.html <head>`: `https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/dist/tabler-icons.min.css`. No hay `@font-face` local, no hay bundling — dependencia externa, no uno de los 21 archivos de este listado. Sin este `<link>`, cualquier `<i class="ti ti-...">` renderiza como caja vacía sin fallback de texto. Rune verifica presencia del link en `index.html <head>` al inicio de sesión que toque iconografía — ausencia bloquea, no se asume cargado.

**Cambio V2.6:** Se añaden `locus-sesiones-card.css` (pos. 11, después de `locus-sesiones.css`) y `locus-docs.css` (pos. 15, después de `locus-modals.css`). La tabla anterior de V2.5 tenía 15 archivos — ahora son 17.

**Cambio V2.15:** Tabla de líneas actualizada con valores reales post-auditoría. 9 prefijos nuevos documentados: `spm-` · `sml-` · `spt-` · `arranque-` · `arr-` · `idp-` · `bl-vl-` · `scm-retro3-`. Scope de `locus-backlog.css` y `locus-sprint-close.css` actualizado para reflejar componentes añadidos en sprints recientes.

**Cambio V2.8:** `locus-tracker.css` renombrado a `locus-sesiones.css` (pos. 10). `locus-tracker-card.css` renombrado a `locus-sesiones-card.css` (pos. 11). Columna Líneas añadida a la tabla de arquitectura — valores extraídos de archivos reales.

**Cambio V2.21:** Deprecación de Sesión de Arranque y Pulso del Ecosistema (founder, sesión 2026-07-08 — origen: INC main.js falla al arrancar por import huérfano de `loadPlan`, `triggered_by: TKT-202607-042`). Removida sección `### Pulso dot y panel` (familia `pulso-*`) completa. Removidos de la tabla de prefijos: `pulso-`, `pls-`, `arranque-`, `arr-` — sin archivo fuente tras el borrado de `locus-pulso.js` y `locus-sesiones-arranque.js` por Rune. Fila 3 (`locus-backlog.css`) y fila 7 (`locus-sprint-plan.css`) de la tabla de arquitectura actualizadas — scope y líneas reales post-limpieza. Fila 4 (`locus-backlog-item.css`) actualizada — clases `.gf-pulso*` y su `@media (max-width: 480px)` removidas. Token `--green` — removida referencia a "dot Pulso verde" en su descripción de uso.

---

## Naming de clases

### Convención general: BEM con modificador `--`

```
[componente]-[elemento]--[modificador]
```

La regla `selector-class-pattern` está desactivada en `.stylelintrc.json` para permitir `--` y clases de un carácter.

### Prefijos de módulo

| Prefijo | Módulo | Archivo fuente |
|---|---|---|
| `bl-` | Backlog | `locus-backlog.css` |
| `bl-plan-` | Vista Planificación drag & drop | `locus-sprint-ui.css` |
| `stat-` | Analytics — estadísticas | `locus-analytics.css` |
| `tracker-` | Tracker | `locus-sesiones.css` |
| `sc-` | AI Card rediseño — header, stats, stepper, footer | `locus-sesiones-card.css` |
| `card-dot-` | Dropdown menú de card IA | `locus-sesiones-card.css` |
| `popup-` | Popup de detalle de sesión | `locus-sesiones.css` |
| `filter-` | Filtros de backlog | `locus-backlog.css` |
| `sprint-` | Sprint selector y header | `locus-backlog.css` / `locus-sprint.css` |
| `sph-` | Sprint panel header (sticky) | `locus-sprint.css` |
| `spi-` | Sprint items list | `locus-sprint.css` |
| `sca-` | Sprint scope added | `locus-sprint.css` |
| `spw-` | Sprint workers vinculados | `locus-sprint.css` |
| `scm-` | Sprint close modal | `locus-sprint-close.css` |
| `plan-` | **Corregido en esta auditoría (mod:86):** familia original de la Sub-tab Plan (`#sspanel-plan`, `.plan-*`) eliminada en TKT-202607-067 (comentario confirmado en `locus-contracts.css:5`) — la fila anterior (`locus-sprint-plan.css`) referenciaba un archivo y un componente que ya no existen. Prefijo `plan-` hoy vive en dos familias sin relación con la original: `.plan-scope-*`/`.plan-zone-toggle`/`.plan-sessions-row` (Vista Planificación, scope por sesión/sprint) en `locus-sprint-ui.css`, y `.plan-file-pill--broken` (dependencias de archivo rotas) en `locus-sesiones.css` | `locus-sprint-ui.css` + `locus-sesiones.css` |
| `acv-` | AC viewer en sub-tab Plan | `locus-contracts.css` |
| `ctr-` | Contratos de módulo — panel y detalle | `locus-contracts.css` (residual: `.ctr-layout`/`.ctr-search`/`.ctr-body` — 3 reglas también en `locus-proyectos.css`, sin confirmar si son dead code o duplicado activo — ver Hallazgo abajo) |
| `historico-` | Archivo Histórico de sprints — renombrado de `arch-*`/`locus-archive.css` (ver mod:22 del archivo, `_ob-history-log-gen1`) | `locus-historico.css` |
| `rsb-` | Radar Sidebar | `locus-radar.css` |
| `tpl-` | Templates sidebar — `tpl-sidebar-actions` (fila de acciones horizontal, `flex-shrink:0`, hermana de `.spt-nav`/`#proj-doc-actions`), `tpl-detail`, `tpl-action-btn`, `tpl-action-row` — familia activa en producción, confirmada en `locus-proyectos.css`. `tpl-nav-badge`: activo, definido en `locus-layout.css`. **`tpl-sidebar-nav`, `tpl-nav-btn`, `tpl-sidebar-label`, `tpl-sidebar-section` eliminadas de `locus-proyectos.css` (mod:9, 2026-07-15) — dead code confirmado de la migración a tablist horizontal (REQ CAEL-01), cero referencias en HTML/JS al momento de eliminar**. **Corrección (mod:110, hallazgo de Rune contra código real, TKT1/CAEL-0723-01):** los IDs `#tpl-badge-backlog`/`#tpl-badge-qbacklog`/`#tpl-badge-qdisc` (`index.html`) **no pertenecen a esta familia** pese al prefijo del ID — son instancias de `.spt-tab-badge` (ver fila `spt-` abajo), pobladas por `_renderZonePanel()` (`locus-backlog-zone-engine.js`). El naming del ID es legado y engañoso, no un error de arquitectura — no renombrar sin REQ propio (fuera de scope de este DOC-UPDATE). Ver `_Locus-ui-Inventory` fila 51 para la corrección equivalente. | `tpl-sidebar-actions`/`tpl-detail`/`tpl-action-btn`/`tpl-action-row`: `locus-proyectos.css` confirmado · `tpl-nav-badge`: `locus-layout.css` confirmado |
| `rm-` | Roadmap chips | `locus-analytics.css` |
| `mg-` | Map/Document Generator | `locus-document-generator.css` |
| `mdiff-` | Merge diff panel | `locus-backlog-item.css` |
| `akpi-` | Analytics KPI | `locus-analytics.css` |
| `gf-` | Global footer | `locus-backlog-item.css` |
| `pend-` | Panel de pendientes | `locus-modals-misc.css` (corregido — `locus-modals.css` no existe post-split) |
| `bitem-` | Backlog item — elementos internos expandidos | `locus-backlog-item.css` |
| `staleness-pill` | Pill de antigüedad de status — inline en subline del ítem | `locus-backlog-item.css` |
| `viz-` | Checkpoint viz | `locus-modals-misc.css` (corregido — `locus-modals.css` no existe post-split) |
| `ckpt-` | Checkpoint viz — secciones del panel (`.ckpt-section*`/`.ckpt-body`/`.ckpt-item-arrow`/`.ckpt-context`/`.ckpt-decision`) y header expandido (`.ckpt-header*`) | `locus-modals-toast.css` (secciones del panel) + `locus-modals-tracker.css` (`.ckpt-header*`) — corregido, `locus-modals.css` no existe post-split |
| `sprint-inline-` | Sprint inline — formulario en merge diff | `locus-backlog-item.css` |
| `promote-` | Promote modal | `locus-backlog.css` (residual: `.promote-modal-info` también en `locus-backlog-item.css`) — corregido, `locus-modals.css` no existe post-split |
| `item-` | Backlog item pills y badges | `locus-backlog.css` |
| `qc-` | Quick Capture modal | `locus-modals-misc.css` (corregido mod:67 — antes decía `locus-modals.css`, nombre pre-split inexistente) |
| `hsr-` | Header sprint row | `locus-backlog.css` |
| `tci-` | Tracker col input | `locus-sesiones.css` |
| `tvh-` | Tracker view header | `locus-sesiones.css` |
| `htmlmap-` | HTML-MAP viewer — tabla y filtros | `locus-docs.css` |
| `mm-` | Module Map árbol modular — módulos y funciones | `locus-docs.css` |
| `hmfilter-` | Filtros pill del HTML-MAP viewer | `locus-docs.css` |
| `context-` | Context vivo — placeholder, raw block, conflicto | `locus-docs.css` |
| `spm-` | Sprint picker modal — selector de sprints y meta edición | `locus-sprint.css` |
| `sml-` | Sprint meta list — lista de sprints en picker | `locus-sprint.css` |
| `ssm-` | Sprint summary — resumen agregado de sprints normales + edición inline de goal/scope/version_target | `locus-sprint.css` |
| `spt-` | Sprint tab nav (`spt-nav`/`spt-tab`) + encabezado de contexto vista-principal (`spt-context-header`, T-202606-002). **`.spt-tab-badge`** (T-202606-098) — badge de conteo hijo de `.spt-tab`, `display:none` en `:empty`, consumido por los 3 sub-tabs de Tab Backlog vía `#tpl-badge-backlog`/`#tpl-badge-qbacklog`/`#tpl-badge-qdisc` (naming de ID heredado, no del prefijo `tpl-` — ver corrección en fila `tpl-` arriba) | `locus-sprint.css` |
| `sps-` | Sub-tab Sprints — bloque de métricas + 4 secciones reales: `#sps-stats-block` · `#sps-activo` · `#sps-programados` · `#sps-pausados` · `#sps-cerrados` (`index.html` mod:151 — corregido mod:107, `#sps-qinc` no existe, ver `§Panel Q-INC`) | `locus-sprint.css` |
| `sps-` | Sprint activo — card en sub-tab Sprints | `locus-sprint.css` |
| `idp-` | Item Detail Panel — panel lateral de detalle de ítem | `locus-backlog-item.css` |
| `bl-vl-` | Backlog vista lineal — árbol de REQs y TKTs en vista tree | `locus-backlog.css` |
| `scm-retro3-` | Sprint close retro paso 3 — métricas, deltas, notas | `locus-sprint-close.css` |
| `hdr-menu-` | Subpanel inline (textarea + botón + error) dentro de #more-menu — no es dropdown propio | `locus-layout.css` |
| `qinc-` | Panel Q-INC — cards ITIL, badges SLA, secciones, stats bar · `qinc-item--sla-vencido` · `qinc-item--sla-riesgo` · `qinc-type-badge` · `qinc-sla-countdown(--riesgo/--vencido)` · `qinc-badge--sla-(high/medium/low)` — ver `§Panel Q-INC — familia qinc-*` (corrección mod:48: la referencia previa a §Sprint groups era falsa) | `locus-backlog.css` |
| `qbacklog-draft-` | Grupo colapsable de REQ/TKT en `draft:true` (pendientes de aval Fase 5 de Finn) — solo en Q-Backlog, no en Q-DISC. Alta mod:113, REQ-202607-019 — ver `§Panel Backlog — grupo de drafts qbacklog-draft-*` | `locus-backlog.css` |
| `ie-` | Item Editor overlay — filas, campos, labels, footer, sub-grupo de intención (`ie-intencion-group`, `ie-intencion-field`). Compuestos `#item-editor-overlay .ie-*` en `locus-sesiones.css`; clases sueltas (`ie-label`, `ie-label-opt`, `ie-field-mt`, `ie-input-mono`, `ie-textarea`, `ie-btn-tpl-save`) en `locus-modals-editor.css` — corregido, `locus-modals.css` no existe post-split. **Colisión detectada — `.ie-body` duplicada:** declarada en `locus-sesiones.css:2978` (`#item-editor-overlay .ie-body`, calificada) y en `locus-modals-misc.css:1975` (`.ie-body`, sin calificar) — no auditado en esta sesión cuál gana o si es dead code, ver Hallazgo abajo | `locus-sesiones.css` + `locus-modals-editor.css` |
| `du-` | DOC-UPDATEs pendientes — panel, lista, fila, botones Aplicar/Descartar, badge vencido, resumen de conflicto (`.du-panel-*`/`.du-list`/`.du-entry*`/`.du-btn-*`/`.du-meta-vencido`/`.du-conflict-*`). En producción desde T-202606-033 — nunca tuvo entrada propia en esta tabla hasta esta sesión (gap cerrado en `§Cambios mod:164`). No confundir con `scm-du-*` (DOC-UPDATEs list dentro del Sprint Close Modal — mismo dominio semántico, componente distinto, `locus-sprint-close.css`) | `locus-docs.css` |
| `du-resolved-` | Sub-tab "Resueltos" — log de DOC-UPDATEs ya aplicados/descartados, toolbar de búsqueda, lista, badge por acción, dos empty states (sin resoluciones / sin resultados de búsqueda). Alta TKT-202608-237 (REQ-202608-090) | `locus-docs.css` |

### Clases de un carácter — `.P` `.T` `.R` `.B` `.I`

Representan tipos de ítem del backlog. **Siempre como modificadores compuestos**, nunca solos:

```css
/* ✓ Correcto */
.item-type-pill.P { background: ...; }

/* ✗ Incorrecto */
.P { color: red; }
```

### Variables privadas `--_name`

Variables con prefijo `--_` son de scope local intencional. La regla `custom-property-pattern` está desactivada.

### Keyframes

Codebase existente usa camelCase. Nuevos pueden usar kebab-case — ambas convenciones coexisten.

---

## Reglas lint desactivadas

| Regla | Razón |
|---|---|
| `selector-class-pattern` | BEM con `--` y clases `.P .T .R .B` |
| `keyframes-name-pattern` | Nombres camelCase existentes intencionales |
| `custom-property-pattern` | Variables `--_private` válidas |
| `no-descending-specificity` | Módulos CSS de scope sobreescriben selectores base intencionalmente — `locus-overrides.css` eliminado en PP-S-01 (R-202605-018) |
| `alpha-value-notation` | Notación moderna y legacy coexisten |
| `color-function-notation` | Ídem anterior |
| `import-notation` | Sin `@import` en el proyecto |
| `declaration-property-value-keyword-no-deprecated` | `word-break: break-word` en múltiples archivos |

**Próxima revisión:** 2026-10-08 — cadencia trimestral desde esta entrega. Una regla lint desactivada nueva hereda la misma cadencia sin declaración adicional — su fecha de revisión es la misma próxima revisión trimestral ya vigente para esta tabla, no una cadencia propia por regla.

### Reglas activas relevantes

| Regla | Estado |
|---|---|
| `color-no-invalid-hex` | Activa |
| `block-no-empty` | Activa |
| `declaration-block-no-shorthand-property-overrides` | Activa |
| `declaration-block-no-duplicate-properties` | Activa (con excepción) |
| `custom-property-no-missing-var-function` | Activa |

---

## Tokens

### Escala tipográfica (15 pasos)

| Token | Valor | Uso | Nivel canónico (A-08) |
|---|---|---|---|
| `--text-3xs` | 8px | Badge ultra-compacto | — |
| `--text-2xs` | 9px | Labels de metadatos compactos | — |
| `--text-2xs-plus` | 10px | Componentes compactos en modales | — |
| `--text-xs` | 11px | Labels secundarios | **Nivel 4 — Eyebrow label** |
| `--text-sm` | 12px | Texto UI estándar compacto | — |
| `--text-base` | 13px | Tamaño base (`html { font-size }`) | — |
| `--text-md` | 14px | Texto UI estándar | **Nivel 3 — Card title** |
| `--text-lg` | 16px | Títulos compactos | **Nivel 2 — Modal-section title** |
| `--text-xl` | 18px | Subtítulos | — |
| `--text-2xl` | 22px | Títulos principales | **Nivel 1 — Tab title** |
| `--text-display-sm` | 17px | Heading de sección | — |
| `--text-display-md` | 26px | Stat numbers | — |
| `--text-display-lg` | 28px | Stat values prominentes | — |
| `--text-display-xl` | 32px | Stat / ícono grande | — |
| `--text-display-2xl` | 40px | Empty state icons | — |

**Excepciones documentadas:** `font-size: 0` (cuando `::before` reemplaza texto), `font-size: 1-2px` (micro-layout).

**Ver `_Locus-ux-ref` A-08** para la tabla completa de los 4 niveles canónicos (tamaño + peso + `letter-spacing` + `text-transform`) y el criterio de asignación. Esta tabla solo marca qué token corresponde a qué nivel — el criterio de decisión vive en A-08.

### Correcciones aplicadas en mod:82 — selectores tocados

**Colisiones de selector-base resueltas (declaración perdedora retirada):**

| Selector | Archivo vigente | Valor vigente | Declaración retirada |
|---|---|---|---|
| `.bitem-title` | `locus-backlog-item.css` | `var(--text-base)` (13px) / `500` | `locus-backlog.css:5528` — `13px` hardcoded / `400` |
| `.mdiff-right-section-title` | `locus-modals-misc.css` | `var(--text-2xs)` (9px) / `600` / uppercase | `locus-backlog-item.css:3790` — `var(--text-xs)` / `700` |

**`letter-spacing` unificado a `0.06em` — selectores que cambiaron de valor:**

| Selector | Archivo | Valor anterior | Valor nuevo |
|---|---|---|---|
| `.mdiff-narrative-header` | `locus-backlog-item.css` | `0.04em` | `0.06em` |
| `.mdiff-summary-title` | `locus-backlog-item.css` | `0.07em` | `0.06em` |
| `.closed-sprints-title` | `locus-backlog.css` | `0.05em` | `0.06em` |
| `.proj-view-title` | `locus-backlog.css` | `0.06em` | sin cambio |
| `.bl-vl-orphans-header-title` | `locus-backlog.css` | `0.04em` | `0.06em` |
| `.qdisc-status-title` | `locus-backlog.css` | `0.04em` | `0.06em` |
| `.qinc-section-header` | `locus-backlog.css` | `0.04em` | `0.06em` |
| `.proj-blocked-title` | `locus-backlog.css` | `0.05em` | `0.06em` |
| `.ckpt-header-title` | `locus-modals-tracker.css` | `0.08em` | `0.06em` |
| `.proj-notes-title` | `locus-proyectos.css` | `0.05em` | `0.06em` |
| `.proj-suggested-title` | `locus-proyectos.css` | `0.05em` | `0.06em` |
| `.ckpt-section-header--diff` | `locus-proyectos.css` | `0.04em` | `0.06em` |
| `.proj-analytics-block-title` | `locus-proyectos.css` | `0.05em` | `0.06em` |
| `.sph-title` | `locus-sprint.css` | `0.07em` | `0.06em` |
| `.ct-block-header` | `locus-analytics.css` | `0.06em` | sin cambio |
| `.ct-outliers-title` | `locus-analytics.css` | `0.06em` | sin cambio |
| `.mg-section-title` | `locus-document-generator.css` | `.05em` | `0.06em` |
| `.historico-title` | `locus-historico.css` | `0.04em` | `0.06em` |
| `.ckpt-section-header` | `locus-modals-toast.css` | `0.07em` | `0.06em` |
| `.historico-legacy-title` | `locus-historico.css` | `0.06em` | sin cambio |
| `.tg-section-title` | `locus-sesiones.css` | `0.07em` | `0.06em` |
| `.hoy-section-title` | `locus-sesiones.css` | `0.08em` | `0.06em` |
| `.scm-confirm-movements-title` | `locus-sprint-close.css` | `.05em` | `0.06em` |

**Selectores fuera de esta corrección — no son eyebrow uppercase, no aplica A-08 Nivel 4:** `.mdiff-section-header` (11px/700, sin uppercase declarado en el selector base — heredado de contexto, verificar antes de tocar) queda fuera de esta pasada; señalar a Nova si un TKT futuro lo toca. `.scm-retro3-title` (10px/600, `letter-spacing: .02em`, sin `text-transform: uppercase`) tampoco es Nivel 4 — es título de sub-bloque sin transform, distinto del patrón eyebrow; conserva su valor original.

### Escala de border-radius (11 tokens)

| Token | Valor | Uso |
|---|---|---|
| `--radius-3xs` | 1px | Suavizado mínimo — separadores, líneas |
| `--radius-2xs` | 2px | Detalle fino — barras de progreso, focus outlines, dots |
| `--radius-sm` | 4px | Elementos compactos |
| `--radius-xs` | 6px | Tooltips, variante intermedia |
| `--radius-md` | 8px | Componentes estándar |
| `--radius-md-plus` | 10px | Cards secundarias |
| `--radius-lg` | 12px | Cards y paneles |
| `--radius-lg-plus` | 14px | Popups, modales compactos |
| `--radius-xl` | 16px | Componentes prominentes |
| `--radius-2xl` | 20px | Modales y superficies grandes |
| `--radius-pill` | 999px | Badges y chips |

Aliases: `--radius` (→ `--radius-md`), `--border-radius-sm/md/lg/xl`.

**Excepciones documentadas:** `border-radius: 0` (reset), `border-radius: 50%` (solo cuando difiere visualmente de `999px`).

**Nota:** `--radius-3xs` y `--radius-2xs` fueron añadidos en CSS-02. Reemplazan los hardcodes `1px` y `2px`. Usar los tokens — no los valores literales.

### Escala de z-index (31 tokens)

| Token | Valor | Semántica |
|---|---|---|
| `--z-deep` | 1 | Fondos decorativos |
| `--z-raised` | 2 | Elevación leve inline |
| `--z-base` | 10 | Base de stacking |
| `--z-float-sm` | 30 | Flotantes baja prioridad |
| `--z-float-md` | 40 | Flotantes media prioridad |
| `--z-float` | 50 | Flotantes estándar |
| `--z-sticky` | 100 | Headers pegados |
| `--z-popover` | 120 | Popovers · dropdowns compactos |
| `--z-sidebar` | 200 | Sidebars |
| `--z-sidebar-plus` | 210 | Elementos sobre sidebar |
| `--z-layer` | 250 | Capa intermedia |
| `--z-layer-2` | 300 | Segunda capa |
| `--z-dropdown` | 400 | Dropdowns principales |
| `--z-modal` | 500 | Modales base |
| `--z-modal-plus` | 600 | Sobre modal base |
| `--z-overlay-sub` | 800 | Sub-overlay |
| `--z-overlay` | 900 | Overlays pantalla completa |
| `--z-toast` | 1000 | Toast system |
| `--z-toast-plus` | 1001 | Sobre toast |
| `--z-panel` | 1100 | Paneles sobre modal |
| `--z-panel-2` | 1200 | Paneles secundarios |
| `--z-panel-3` | 1300 | Tercer nivel de panel |
| `--z-panel-top` | 3100 | Panel máxima prioridad |
| `--z-supreme-sub` | 8000 | Sub-nivel supreme |
| `--z-supreme-mid` | 8500 | Nivel medio supreme |
| `--z-supreme` | 9000 | Sobre overlay general |
| `--z-supreme-2` | 9200 | Segundo nivel supreme |
| `--z-critical` | 9500 | Entre supreme-2 y top |
| `--z-critical-2` | 9900 | Segundo nivel crítico |
| `--z-top` | 9999 | Techo general |
| `--z-absolute` | 10000 | Máximo absoluto |

### Tokens de color adicionales — T-202605-033

#### Texto sobre fondos de color

| Token | Dark | Light | Uso |
|---|---|---|---|
| `--text-on-accent` | `#000` | `#000` | Texto sobre `var(--accent)` lime-green — contraste ~8:1 |
| `--text-on-danger` | `#fff` | `#fff` | Texto sobre `var(--red)` y fondos destructivos |

**Regla:** Nunca usar `#000` o `#fff` directamente sobre fondos de color. Usar estos tokens para que el valor sea correcto en ambos temas si alguno cambia.

#### Colores de tag extendidos

| Token | Dark | Light | Uso |
|---|---|---|---|
| `--pink` | `#f472b6` | `#d6509e` | Texto de tag `.tc-5`. También Toast `t-copy` (background/border/color/`::before`, mod:116, ver `§Cambios (mod:116)`) |
| `--lime` | `#a3e635` | `#6a9e1a` | Texto de tag `.tc-6` |
| `--orange` | `#fb923c` | `#d4691a` | Texto de tag `.tc-7` |

**Excepción documentada — `tag-color-fixed`:** Los `border-color` de `.tc-0` a `.tc-7` en `locus-modals-misc.css` (corregido en esta auditoría — `locus-modals.css` no existe post-split) son paleta fija de instancia de componente. No varían por tema. No se tokenizan. Identificados con comentario `/* tag-color-fixed */` inline. No replicar fuera del componente de tags sin aprobación de Nova.

---

### Tokens de color utilitarios — verificados en locus-base.css

| Token | Dark | Light | Uso |
|---|---|---|---|
| `--green` | `#39e87c` | `#1aab5a` | Éxito, confirmación, badges de contrato activo. Contraste como elemento gráfico no-texto (borde/acento 2px) sobre `--surface1`/`--surface2`: light ⚠️ 2.99:1/2.82:1 — falla el mínimo 3:1 (WCAG "graphical objects and UI components"). Como color de texto no fue verificado en este análisis — puede seguir siendo válido para ese uso. Override acotado en uso de acento de card: `locus-backlog-item.css` usa `#16914c` en `[data-theme="light"] .mdiff-card.mdiff-type--tkt` — no se tocó el token `--green` global. |
| `--green-dim` | `#071a10` | `#e6f9ef` | Fondo sutil de contextos de éxito |
| `--red-dim` | `#1a0810` | *(verificar light)* | Fondo sutil destructivo — alias `--bg-danger-subtle` |
| `--blue` | `#4fc3f7` | `#0288d1` | Color informativo — `--blue-dim` y `--blue-border` disponibles. Discovery — tipo DISC en backlog, archive y sprint (mod:55, ver `§Cambios (mod:55)` — antes era `--purple`). Como texto falla 4.5:1 en light (~3.31–4.11:1) — usar `--blue-text` para texto, no este token directo |
| `--blue-text` | `var(--blue)` | `#026aa8` | Texto sobre fondo tintado — mod:54. Dark sin override (ya pasaba 7.85–9.55:1); light oscurecido, 4.96–5.90:1 verificado vs `--surface2`/`--surface3`/`--bg2` |
| `--red-text` | `var(--red)` | `#b8253f` | Texto sobre fondo tintado — mod:54. Dark sin override (ya pasaba 4.68–5.69:1); light oscurecido, 5.33–5.87:1 verificado vs `--surface2`/`--surface3`/`--bg2` |
| `--purple` | `#c084fc` | `#7c3aed` | Requerimiento — tipo REQ en backlog, archive y sprint (mod:55, ver `§Cambios (mod:55)` — antes era `--blue`, token de DISC). Contraste: dark ~8:1 ✅ · light ~5.9:1 ✅. Ya no reusado en Toast `t-copy` — migrado a `--pink` en mod:116, ver `§Cambios (mod:116)` |
| `--hint` | `#3a3d5c` | `#a0a4c8` | Bordes sutiles y fills decorativos — NO usar para texto legible, no cumple 4.5:1 |
| `--text3` | `#868bb8` | `#5a6192` | Texto terciario/placeholder/inactivo — 5.21:1/4.79:1 (dark) · 5.56:1/5.18:1 (light) vs `--surface2`/`--surface3`, WCAG AA |
| `--accent-dim` | `rgb(166 226 46 / 8%)` | `rgb(109 184 33 / 7%)` | Fondo sutil de acción primaria |
| `--accent-border` | `rgb(166 226 46 / 25%)` | *(light derivado)* | Borde sutil de acción primaria |
| `--accent-text` | `var(--accent)` | `#45700f` | Texto de acción sobre `var(--accent-dim)` — mod:96. Dark sin override (ya pasaba 11:1 vs `--surface2`); light valor propio, `var(--accent)` directo da 2.32:1 vs `--surface2` (falla AA). Mismo criterio que `--green-text`/`--blue-text`/`--red-text`. **Nunca usar `var(--accent)` ni `var(--text-on-accent)` como color de texto sobre `var(--accent-dim)`** — `--text-on-accent` es exclusivo de fondo `--accent` sólido, no de la variante dim |

**Regla `--green-dark`:** Eliminada — TKT3 REQ-tmp-qa-cleanup S'02. Su único consumidor (`.stat-mini-fill`) fue eliminado por código muerto (sin call sites en JS/HTML). Si un futuro componente necesita un fill de barra de progreso en light mode con contraste 4.5:1+, declarar un token nuevo — no reintroducir `--green-dark` sin verificar necesidad real.

#### Aliases de texto (legado — no usar en código nuevo)

| Alias | Canónico | Usos activos |
|---|---|---|
| `--text-muted` | `--text2` | 69 usos en codebase |
| `--text1` | `--text` | 21 usos |
| `--text-secondary` | `--text2` | múltiples |

**`--text3` dejó de ser alias — TKT2/3 REQ separar-rol-texto-hint (`ref_id` CAEL-01):** `--text3` era `var(--hint)` (38 usos declarados + ~488 usos directos de `color:var(--hint)` sin pasar por el alias). El uso como texto nunca cumplió WCAG AA (1.5–2.3:1 real). Ahora `--text3` es token canónico propio con valor independiente — ver tabla de tokens de color. `--hint` conserva su valor hex original sin cambio, y queda exclusivo para bordes sutiles y fills decorativos (~74 usos, incluye `color: var(--text3)` en `locus-analytics-charts.js:487,507` que sigue siendo válido como fill de chart categórico, no texto).

**Regla:** En código nuevo usar siempre el canónico (`--text`, `--text2`, `--text3`, `--hint`). `--text3` es el nivel de texto terciario/placeholder — nunca usar `--hint` para texto legible. Los tres aliases restantes de esta tabla son legado y no se introducen en Rs nuevos.

#### Aliases de fondo (legado — no usar en código nuevo)

| Alias | Canónico |
|---|---|
| `--bg-hover` | Fondo de hover sutil — `rgb(255 255 255 / 5%)` en dark |
| `--bg-subtle` | Fondo sutil — `rgb(255 255 255 / 4%)` en dark |
| `--hover` / `--hover-bg` | → `--bg-hover` |

**Regla:** En código nuevo usar `var(--surface2)` para hover states o `var(--surface3)` para estados activos. `--bg-hover` y `--bg-subtle` no se introducen en Rs nuevos.

**Nota sobre `--warn`:** El token `--warn` **no existe** en `locus-base.css`. El codebase lo usa con fallback `#e8a832`. El token correcto es `--amber`. Migración pendiente en backlog. No usar `--warn` en código nuevo.

---

### Transiciones

#### Curvas de easing

| Token | Curva |
|---|---|
| `--ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` |
| `--ease-in-out` | `cubic-bezier(0.45, 0, 0.55, 1)` |
| `--ease-bounce` | `cubic-bezier(0.34, 1.56, 0.64, 1)` |
| `--ease-standard` | `cubic-bezier(0.4, 0, 0.2, 1)` |
| `--ease-decel` | `cubic-bezier(0.22, 1, 0.36, 1)` |
| `--ease-spring` | `cubic-bezier(0.34, 1.4, 0.64, 1)` |

#### Velocidades

| Token | Valor |
|---|---|
| `--trans-fast` | `all 0.12s var(--ease-out)` |
| `--trans-medium` | `all 0.20s var(--ease-out)` |
| `--trans-slow` | `all 0.32s var(--ease-out)` |
| `--trans-color` | `color/bg/border/opacity 0.15s var(--ease-out)` |
| `--transition-base` | `150ms ease` |

---

## Clases de visibilidad

| Clase | Definición | Uso |
|---|---|---|
| `.is-hidden` | `display: none !important` — **canónica** | Todos los componentes nuevos |
| `.hidden` | `display: none !important` — alias legacy | `.tab-notif-badge`, `.header-worker-chip` y otros |
| `.gf-hidden` | `display: none` | Footer elements (`#gf-*`) |
| `.breadcrumb-seg--hidden` | `display: none !important` | Segmentos del breadcrumb |
| `.force-hidden` | `display: none !important` | Override de máxima especificidad |

**Regla:** usar `.is-hidden` en componentes nuevos. No crear nuevas clases de visibilidad sin aprobación de Nova.

**Excepción documentada — `tmpl-trigger-wrap`:** `.tmpl-trigger-body.is-hidden` no produce `display: none` en este componente. El patrón usa `max-height` y `opacity` para colapso animado. Ver § Patrones de componentes flotantes → `tmpl-trigger-wrap`.

**Excepción documentada — `header-actions position lock`:** `.header-pend-btn.is-hidden` y `.header-active-worker.is-hidden` sobreescriben el `display: none !important` de `.is-hidden` con `display: block !important; visibility: hidden` — reservan el espacio del elemento en el layout para evitar desplazamiento horizontal de `theme-toggle-btn`. Patrón idéntico a `.tmpl-trigger-body.is-hidden`. T-202606-091.

---

## Patrones de layout

### Gutter unificado de subtabs — token `--subtab-gutter`

Token: `--subtab-gutter: 12px` (declarado en `:root`, `locus-base.css`).

Consumido como `padding-left` en los contenedores de subtab que carecían de gutter propio:

| Selector | Archivo | Nota |
|---|---|---|
| `.tpl-detail` (scope `#tab-backlog`) | `locus-proyectos.css` | Contenedor interno de Sprint/Backlog — sin gutter propio antes del fix |
| `#sprint-panel-sprints` | `locus-sprint.css` | Sin gutter propio antes del fix — gap cerrado mod:62 (INC, variante ligera) |
| `#tab-proyectos` | `locus-backlog.css` | Sin padding declarado antes del fix |
| `#tab-sesiones` | `locus-sesiones.css` | `padding: 0` explícito — el token se aplica después en la misma regla para no perder el reset del resto de lados |

**Criterio:** el objetivo es paridad de resultado visual final (gutter mínimo por tier), no aplicación uniforme de un único token en todos los selectores por igual. Un contenedor con padding propio ≥ al gutter objetivo de su tier no lo necesita.

**Nota — eje vertical de `#tab-backlog` distinto del horizontal (INC, `locus-backlog.css` mod:99):** Esta sección solo cubre el eje horizontal (gutter izquierdo). `#tab-backlog` declara `padding: 0 var(--gutter-shell) 2rem` — `padding-top: 0` es una corrección aparte, sin relación con ningún token de gutter. Causa: `.spt-nav` (fila de sub-tabs, sticky) debe quedar flush contra el header — mismo tratamiento que `#tab-sprint`, que no declara padding propio. Con `padding-top: 2rem` heredado de antes de la migración a `.spt-nav` (REQ CAEL-01), el sub-nav de Backlog quedaba separado del header por un gap visible que `#tab-sprint` no tiene. `#tab-analytics` no comparte este bug — su primer hijo (`#tab-analytics-inner`) no es un nav sticky, no hay comparación válida de flush-top. No revertir `padding-top` a `2rem` — el criterio horizontal de esta sección no aplica al eje vertical.

### Gutter de shell/viewport completo — token `--gutter-shell`

Token: `--gutter-shell: 24px` (declarado en `:root`, `locus-base.css`, mod:11) — introducido en REQ CAEL-0717-02 (TKT1, Nova), retira `--split-viewport-gutter` (mod:87, vida efímera de un sprint — sin período de gracia, `__BR-Execution §2`).

Tier separado de `--subtab-gutter` (12px) — para contenedores de nivel shell/viewport completo, no subtabs internos. Consumido como `padding`/`padding-left` en:

| Selector | Archivo | Nota |
|---|---|---|
| `#tab-analytics` | `locus-analytics.css` | Antes `padding: 2rem` (32px hardcoded) — eje vertical sin cambio, solo horizontal migra |
| `#tab-backlog` | `locus-backlog.css` | Antes `padding: 0 2rem 2rem` — solo right/left migran a `var(--gutter-shell)`; top/bottom sin cambio (ver nota de eje vertical, arriba) |
| `.modal-overlay.modal-split` (`padding-left`) + `--split-total-w` ×2 en sus 3 variantes | `locus-modals-base.css` | Antes `--split-viewport-gutter` (token propio, retirado) |

**Modal de ingesta (`.modal--ingest`) — consolidado a `--subtab-gutter`, no a `--gutter-shell`:** `.ingest-modal-header`, `.ingest-modal-columns`, `.ingest-modal-actions` y el par `.ingest-modal-meta`/`.ingest-validation-panel` (`locus-modals-base.css`) migraron de `18px` hardcoded a `var(--subtab-gutter)` (12px) — las 4 secciones internas del modal comparten el mismo inset, evitando la desalineación que habría dejado migrar solo un subconjunto. `18px` no correspondía a ningún tier de la escala; no se creó tier nuevo para ese valor.

**Escala final de gutter horizontal — 2 tiers:** `--subtab-gutter` (12px, subtabs internos y componentes de modal) · `--gutter-shell` (24px, contenedores de nivel shell/viewport completo). `.tpl-sidebar-actions` (`padding: 8px 24px`) no consume `--gutter-shell` como padding propio — es padding de toolbar/componente, no gutter de página; coincidencia de valor casual, fuera de scope de REQ CAEL-0717-02. **Actualizado en REQ CAEL-0717-01 (ver patrón siguiente):** aunque no lo consume como padding propio, sí lo consume ahora vía `margin-inline` negativo para cancelarlo como heredado — ver `### Full-bleed dentro de contenedor con gutter heredado` abajo.

### Full-bleed dentro de contenedor con gutter heredado — `margin-inline: calc(-1 * var(--gutter-shell))`

Origen: REQ CAEL-0717-01 (TKT1, Nova) — `#tab-backlog .tpl-sidebar-actions` y `#tab-backlog .spt-nav` (`locus-backlog.css`, mod:100).

**Problema:** un elemento hijo directo de un contenedor con `padding` lateral (`--gutter-shell`, 24px) hereda ese padding — su fondo/borde queda contraído, sin poder llegar a los bordes reales del contenedor aunque el elemento declare su propio padding interno.

**Patrón:** si el elemento ya declara su propio padding lateral (gutter de contenido, ej. `.tpl-sidebar-actions` con `8px 24px`, `.spt-nav` con `0 24px`), aplicar `margin-inline: calc(-1 * var(--gutter-shell))` cancela exactamente el padding heredado del contenedor — el elemento pasa a ocupar el ancho completo (fondo/borde full-bleed), mientras su padding propio sigue funcionando como gutter de contenido. Mismo criterio visual que `.header-inner` (`§Header global`), con mecanismo distinto: `.header-inner` vive en un `<header>` sin padding propio; aquí el padre (`#tab-backlog`) sí tiene padding, por lo que el escape se hace con margin negativo en vez de ausencia de padding en el padre.

**Condición de aplicación:** solo cuando el valor del margin negativo coincide exactamente con el padding real heredado del contenedor inmediato — un desfase entre ambos deja franja residual o overflow. Scope explícito al contenedor (`#tab-backlog .selector`, no el selector global) cuando la clase pueda reutilizarse en otro contenedor con gutter distinto o ausente.

**No incluye:** no cambia el padding propio del elemento (sigue siendo el gutter de contenido) ni el padding del contenedor (`#tab-backlog` conserva `var(--gutter-shell)` para el resto de sus hijos, ej. `.tpl-detail`).

**Variante asimétrica — `#tab-proyectos` (REQ CAEL-0718-01, TKT1, Nova, mod:101):** mismos componentes reutilizados (`.spt-nav`, `.tpl-sidebar-actions` vía `#proj-doc-actions` — ver `index.html`, comentario de migración TKT1/REQ CAEL-01), pero el contenedor (`#tab-proyectos`) solo declara `padding-left: var(--subtab-gutter)` (12px) — sin `padding-right`. Cancelar solo el lado con padding real: `margin-left: calc(-1 * var(--subtab-gutter))`, sin tocar el lado derecho (cancelar ahí introduciría overflow, no hay padding que compensar). Regla general: el margin negativo debe reflejar exactamente qué lados del contenedor tienen padding — no asumir simetría por defecto.

### Barras sticky de contenedor (toolbar/stats)

Toda barra de contenedor (`.bl-toolbar`, `.bl-header-unified`, `.active-filter-chips` y equivalentes futuros en otros subtabs) que combine `display: flex` + `position: sticky` debe declarar `width` explícito — nunca depender de `margin: auto` con `width: auto`.

**Patrón (corregido mod:100 — ver `§Cambios mod:100`):**
```css
max-width: [N]px;
width: 100%;
```

**Historial del patrón — por qué no lleva `margin-left`:** la versión anterior de este patrón declaraba `width: calc(100% - [gutter]px)` + `margin-left: [gutter]px`, compensando `.tpl-sidebar` (wrapper vertical Gen1). `.tpl-sidebar` fue eliminado en `locus-proyectos.css` (REQ CAEL-01) — el margen quedó compensando un vecino que ya no existe, desalineando la barra respecto al resto del contenido del panel (ej. `#backlog-list`). Corregido en `.bl-header-unified`/`.active-filter-chips` en `TKT-202607-041`. Si un consumidor del patrón antiguo aparece desalineado, aplica el mismo diagnóstico — no asumir que el margin-left sigue siendo necesario.

**Anti-pattern registrado:** `margin-inline: auto` o `margin-right: auto` en un contenedor `flex` + `sticky` colapsa a shrink-to-fit en al menos un navegador de referencia — el bug es invisible si el contenido de la barra es ancho por sí mismo y solo se manifiesta con contenido angosto. Ver `INC-202607-001`. **Anti-pattern registrado (mod:100):** `margin-left` compensando un sidebar/vecino sin verificar que ese vecino sigue existiendo en el DOM — el margen sobrevive al refactor que eliminó lo que compensaba, y solo se detecta por síntoma visual (gutter duplicado), no por lint.

### Header de ítem — orden de controles

`.bitem-header` (`.item-header` en el DOM) declara sus controles en este orden fijo — el primer elemento siempre es el disclosure triangle:

```
.bitem-collapse-arrow → .item-drag-handle (condicional, solo si item.sprint) → .bitem-activity-dot (condicional) → copy-item-btn → typeBlock → .bitem-title-col → .bitem-header-right
```

**Criterio:** el chevron anticipa el contenido — se lee antes, no después — y va primero por convención de disclosure triangle. `.item-drag-handle` nunca aparece en DISC (sin sprint asignado), por lo que ambos controles no compiten por espacio en ese tipo; en REQ/TKT/INC conviven sin conflicto porque cada uno tiene su propio target de click con `stopPropagation()` en el handler JS — la posición DOM no afecta esa separación.

**Tokens:** `.bitem-collapse-arrow` usa `var(--text-lg)` + `width: 20px` (target de click ampliado, Fitts's Law). `.item-drag-handle` usa `var(--text-base)` + `padding: 0 4px 0 0` (`locus-backlog.css`) — visible solo en `:hover` del ítem, a diferencia del chevron que es siempre visible por ser el control primario de expansión.

**Anti-pattern registrado:** no declarar selectores CSS con combinador general-hermano (`~`) que dependan del orden relativo de estos controles en el DOM (ej. `.bitem-type-X ~ .bitem-title-col ~ .bitem-collapse-arrow ~ .bitem-header-right ...`) — un reorder futuro de estos elementos los deja huérfanos en silencio, sin fallar el lint ni romper visualmente si existe un selector de respaldo por atributo (`[data-type="X"]`). Preferir siempre el selector por atributo sobre el ancestro (`.item.bitem[data-type="X"] .selector-hijo`) para reglas que dependen del tipo de ítem.

---

## Patrones de componentes flotantes

### Header global — familia `.header-zone-*`

Canónico en `locus-layout.css` (introducida mod:8, ver `Cambios mod:25`). `.header-inner` ya no es un flex row plano de 5 elementos — agrupa 3 zonas por proximidad.

| Selector | Rol |
|---|---|
| `.header-zone` | Wrapper genérico — `display:flex`, `gap:8px`. Aplicado con modificador, nunca solo |
| `.header-zone--brand` | Zona 1 — envuelve `.logo` |
| `.header-zone--nav` | Zona 2 — envuelve `.tabs`. Dueña de `margin-inline:auto` (centrado) — `.tabs` ya no lo declara |
| `.header-zone--utils` | Zona 3 — envuelve `.header-search` + `.header-actions` |
| `.header-zone + .header-zone` | Separador — `border-left: 1px solid var(--border)`, `padding-left: 12px` |

**Anti-pattern:** no reintroducir `margin-inline:auto` en `.tabs` — el centrado se rompe si se declara en ambos niveles (zona + hijo) por acumulación de espacio libre.

**Íconos SVG del header — 18 instancias (REQ CAEL-01, mod:69):** reemplazan los emojis Unicode que antes vivían como `textContent` en los 6 tabs, `#header-pend-btn` y los 11 ítems de `#more-menu`.

| Regla | Valor |
|---|---|
| Tamaño | `18×18` viewBox |
| Color | `stroke="currentColor"`, `fill="none"` — sin paleta propia, hereda `--text2`/`--text` del elemento contenedor (tab inactivo/activo, ítem de menú) |
| Tokens nuevos | Ninguno — mismo par de contraste ya validado WCAG AA en el sistema |
| Excepción | `#mm-btn-sync` conserva `.sync-status-dot` — no forma parte del reemplazo |

**Anti-pattern:** no fijar `stroke` con un valor de color literal — el ícono pierde su herencia de estado (activo/inactivo/hover) y queda desincronizado del texto que lo acompaña.

#### `.breadcrumb-seg--proj` — nombre de proyecto, segmento 1 del breadcrumb de header (mod:136, corrige mod:135)

Vive dentro de `.logo-project-label`, en `.header-zone--utils` (`R-202605-167`). **No tiene `id` propio** — `#breadcrumb-proj` de `mod:135` no existe en `locus-layout.css` real, corregido en `mod:136`.

| Selector | Declaración |
|---|---|
| `.breadcrumb-seg--proj` | `font-size: var(--text-md)` (mod:136, sube desde `13px` hardcoded) / `font-weight: 500` / `color: var(--text2)` |
| `.breadcrumb-seg` (base) | `transition: var(--trans-color)` (mod:136, sube desde literal `color 0.15s var(--ease-out)`) — compartida por los 3 segmentos |
| `.breadcrumb-seg--proj:not(:disabled):hover` | `color: var(--accent-text)` + `background: var(--accent-dim)` — ya existente desde `R-202605-167`, WCAG-safe |
| `.breadcrumb-seg--proj:disabled` | `color: var(--text2)`, sin background/chevron — sin proyecto activo |
| `:focus-visible` | Hereda la regla global (`locus-layout.css` ~L744) — sin override propio |

`.breadcrumb-seg--hidden` (`§Clases de visibilidad`) sigue aplicando igual sobre este selector cuando corresponda ocultar el segmento.

### Footer global — familia `.gf-ckpt--alert-*`

Canónico en `locus-backlog-item.css` (introducida mod:53→54, extendida mod:55→56). `#gf-ckpt` es el elemento de texto clickeable del footer global (`R-202604-080`) — muestra la alerta de mayor prioridad del proyecto activo o, en su ausencia, el `next_step`/título de la última sesión. La lógica de prioridad vive en `_getFooterAlert()` (`locus-sesiones-stats.js`) — este doc solo declara el color, no la lógica de selección.

| Selector | Prioridad | Color | Uso |
|---|---|---|---|
| `.gf-ckpt--alert-inc` | 1 (más alta) | `var(--red)` | INC con `sla_priority:high` vencido |
| `.gf-ckpt--alert-sprint` | 2 | `var(--amber)` | Sprint activo con ≥40% de ítems en en-revisión |
| `.gf-ckpt--alert-backlog` | 3 | `var(--purple)` | Ítems vencidos en Q-Backlog/Q-DISC (`_zoneStaleness`) |
| `.gf-ckpt--alert-docupdate` | 4 (más baja) | `var(--blue-text)` | DOC-UPDATEs sin resolver +14d (`_docUpdateStaleness`) |
| `.gf-ckpt--link` | n/a — sin alerta activa | `--text2` (heredado, sin modificador propio) | Fallback: próximo paso o título de última sesión |

Las cuatro variantes de alerta comparten `font-weight: 600` y heredan `pointer-events`/`cursor` de `.gf-ckpt--link` — siempre clickeables, el destino de navegación (`targetTab`/`targetSubTab`) lo resuelve el JS, no el CSS.

**Anti-pattern:** no usar `--blue` directo para `--alert-docupdate` — falla 4.5:1 como texto en light theme (ver `§Tokens de color utilitarios`). Usar siempre `--blue-text`.

### gconfirm — shell de confirmación genérico unificado (`locus-sesiones.css`)

**Reemplaza a esta sección** — `.status-confirm-*` (`T-202604-055`) fue retirada del codebase (REQ CAEL-0720-01, TKT3/TKT4) junto con `export-confirm-overlay` (TKT2). Ambos absorbidos por el shell genérico `gconfirm` vía un parámetro `bodyHtml` nuevo en `_gconfirmOpen()` (`locus-modals.js`). 8 call sites conocidos: 6 originales sin `bodyHtml` (`locus-reports.js` ×2, `locus-sesiones-capture.js`, `locus-sprint-project.js`, `locus-backlog-item.js`, `locus-sprint.js`) + 2 nuevos con `bodyHtml` (`locus-backlog-generator.js` — exportación, `locus-backlog-merge.js` vía wrapper `_openStatusConfirm()` — retroceso/descarte).

| Selector | Rol |
|---|---|
| `.gconfirm-overlay` / `.gconfirm-overlay.open` | Overlay fijo — `rgb(0 0 0 / 60%)`, `--z-modal`, oculto por `display:none` / visible por `.open` |
| `.gconfirm-modal` | Caja — `var(--surface)`/`var(--border2)`, `--radius-lg-plus`, `max-width: 360px` (ancho fijo, ninguna variante lo excede — ver `design_intent` de TKT1), `animation: modalSpring 0.22s var(--ease-spring)` |
| `.gconfirm-title` | `--text-md` 600, `var(--text1)`, `margin-bottom: 8px` |
| `.gconfirm-msg` | Mensaje del happy path original (input/mensaje simple) — `--text-base`, `var(--text2)`, `line-height: 1.5` |
| `.gconfirm-input-wrap` / `.gconfirm-input-label` / `.gconfirm-input` / `.gconfirm-input:focus` | Input inline opcional (6 call sites originales) — foco con `border-color: var(--accent)`, sin `box-shadow` propio |
| `.gconfirm-body-html` | **Nuevo (TKT1)** — contenedor para HTML arbitrario inyectado vía `bodyHtml`. `margin-bottom: 1rem` (mismo valor que `.gconfirm-input-wrap`), sin regla propia de `display` — visibilidad vía `.is-hidden` global (`locus-base.css`). Cuando `bodyHtml` está presente, `#gconfirm-input-wrap` se fuerza oculto sin importar `inputLabel` — mutuamente excluyentes en runtime |
| `.gconfirm-actions` | `display:flex; gap:8px; justify-content:flex-end` |

**Controles inyectados dentro de `bodyHtml` — sin clases propias `gconfirm-*`:** `.export-confirm-filename` (+ `code` anidado, `locus-proyectos.css`) y `.discard-field-label`/`.discard-field-select`/`.discard-field-input`/`.discard-modal-fields`/`.discard-modal-hint` (inline en `locus-backlog-merge.js` vía `bodyHtml`) — decisión de TKT2/TKT3: reutilizar el CSS ya existente de los shells retirados en vez de renombrar a un namespace nuevo, para minimizar diff. `gconfirm` no impone contraste/foco propio sobre ese contenido — responsabilidad de quien inyecta, según `design_intent` de TKT1.

**Comportamiento nuevo heredado por retroceso/descarte:** a diferencia del `.status-confirm-overlay` retirado (sin cierre por click-fuera ni Escape), `gconfirm-overlay` sí los tiene — efecto colateral intencional de la fusión, declarado en AC de TKT3.

**Gap documental cerrado (sesión de cierre del REQ CAEL-0720-01):** `.gconfirm-title`/`.gconfirm-modal` se implementaron en TKT1 sin entrada en este doc. Valores verificados contra código real (`locus-sesiones.css` mod:34) — coinciden con `design_intent` aprobado, sin discrepancia.

### Subpanel inline en #more-menu — familia `hdr-menu-*`

Canónico en `locus-layout.css`. NO es un dropdown independiente — `#more-menu-btn` ya controla `#more-menu` (R-202605-012). El subpanel se inserta como bloque inline dentro de `#more-menu`, debajo del botón que lo activa.

| Selector | Rol |
|---|---|
| `.hdr-menu-subpanel` | Contenedor inline — oculto por defecto, `.open` revela |
| `.hdr-menu-textarea` | Textarea de entrada — `min-height: 80px`, `resize: none` |
| `.hdr-menu-textarea--error` | Error state — `border-color: var(--red)` |
| `.hdr-menu-error-msg` | Mensaje de error inline — `var(--red)`, `aria-live='polite'` en HTML |
| `.hdr-menu-apply-btn` | Botón de acción — D-04 via `:disabled` |

Botones nuevos dentro de `#more-menu` (ej. `#mm-btn-sync-infra`) heredan estilo de `.more-menu button` (línea ~802) — sin clase adicional.

### Sprint groups y badges — familia `.sprint-group-*` / `.sprint-badge-*`

Modificadores aplicados a `.bl-vl-sprint-group` según el estado del sprint. A partir de V2.20, el header usa layout de 3 filas en lugar de una sola fila flat. Ver estructura de clases internas más abajo.

**Segundo consumidor — Tab Sprint (mod:105):** `.sprint-badge-active` y `.sprint-badge-paused` también se usan sueltas (sin `.sprint-group-*` como ancestro) en las cards de `_renderSpsActivo()`/`_renderSpsPausados()` (`locus-sprint.js`, `#sps-activo`/`#sps-pausados`). No confundir con la familia `.sml-*` de `locus-sprint.css` (badges/labels de sesión — sigue viva para otros usos) — `.sml-badge*` como estado de sprint fue eliminada en mod:105, ver changelog. Antes de agregar una variante nueva a esta familia (ej. `.sprint-badge-scheduled` suelta), verificar ambos consumidores — un cambio visual aquí afecta Vista Lista de Backlog y Tab Sprint simultáneamente.

| Estado | Clase grupo | Clase badge | Color texto badge | Fondo header |
|---|---|---|---|---|
| Activo | `.sprint-group-active` | `.sprint-badge-active` | `--amber-text` (mod:121 — corrección de notación, sin cambio de código) | `rgb(245 158 11 / 8%)` |
| ~~Hotfix~~ | ~~`.sprint-group-hotfix`~~ | ~~`.sprint-badge-hotfix`~~ | ~~rojo `rgb(163 45 45)`~~ | ~~`rgb(226 75 74 / 6%)`~~ — **eliminadas en TKT-D3** · `S-HOTFIX` no existe en Gen 2 |
| Cerrado | `.sprint-group-closed` | `.sprint-badge-closed` | `--hint` | ninguno · `opacity: 0.8` |
| Planificado (T-202606-040, fondo agregado mod:121) | `.sprint-group-planned` | `.sprint-badge-planned` | `--blue` | `rgb(2 136 209 / 8%)` |
| Programado (ssm) | — | `.sprint-badge-programado` | `--blue` | — |
| Pausado (ssm) | — | `.sprint-badge-paused` | `--hint` | — |

**Detección de hotfix:** ~~`isHotfix` se evalúa como `sprintId.toUpperCase().includes('HOTFIX')` — no depende de `sprintObj.status`. Tiene precedencia sobre `isActive` e `isPlanned` en la construcción de la clase del grupo.~~ **Eliminado en Gen 2 (TKT-D1/D3)** — `S-HOTFIX` no existe, `isHotfix` eliminado de todos los módulos.

#### Estructura interna de `.bl-vl-sprint-header` — 3 filas (V2.20)

El header pasó de una sola fila `display: flex` a un bloque con 3 filas semánticas. `border-left: 3px` codifica el estado periféricamente.

| Clase | Rol | Contenido |
|---|---|---|
| `.bl-vl-sprint-header-row1` | Fila 1 — identidad | arrow + `.version-tag` (ID monospace, `--text-xs`) + `.sprint-name-label` (nombre, **Nivel 3 `--text-md`/`500` desde mod:121**) + badge de estado |
| `.bl-vl-sprint-header-meta` | Fila 2 — contexto secundario | Velocity para activo · fecha de cierre para cerrado · effort estimado para planificado. Split label/valor desde mod:123 — `.bl-vl-sprint-header-meta-label` (Nivel 4 uppercase) + `.bl-vl-sprint-header-meta-value` (`--text-sm`), consumiendo `{label, valor}` de `_sprintVelocityLabel`/`_metaText`. `.hsr-velocity` retirada — ver `§Cambios (mod:123)` |
| `.bl-vl-sprint-header-progress` | Fila 3 — progress bar full-width. **Solo Activo y Planificado** desde mod:121 | `.bl-vl-progress-track` + `.bl-vl-progress-fill` + `.bl-vl-progress-label` |
| `.bl-vl-sprint-header-summary` | Fila 3 — resumen estático. **Solo Cerrado**, nueva en mod:121 | `.bl-vl-progress-label` reutilizada — texto `X/X ítems · vX.Y.Z` |

#### Progress bar — clases nuevas V2.20

**Corrección (mod:47):** `version-progress-inline`, `version-progress-bar-wrap`, `version-progress-bar` y `version-progress-label` no existen en el codebase — ni en `locus-backlog.css` ni en `locus-analytics.css` ni en ningún otro archivo. La atribución a `locus-analytics.css` L700-736 (registrada en mod:38/mod:39) era incorrecta: ese rango contiene `.req-children-*` (`T-202604-048: R→T children block`), feature de progreso de TKTs hijos de un REQ, sin relación con Vista Kanban, Vista Lista de Backlog, ni con este bloque de progreso de versión. No hay orphan que remover bajo ese nombre — ver `§Cambios (mod:47)`.

**Corrección (mod:46):** `.bl-vc`/`.bl-vc-r*`/`.bl-vc-t*` **no es huérfano** — es la Vista consolidada (REQs con TKTs anidados), consumida activamente por `locus-backlog-render.js`. El grep de mod:39 buscó el literal con punto inicial y no detectó el patrón real de consumo (`classList.add('bl-vc-r')`, sin punto) — ver corrección completa arriba. `_renderVistaLista` sigue siendo la única función de render de Vista Lista y usa exclusivamente las clases `.bl-vl-progress-*` de abajo — `.bl-vc*` pertenece a una vista distinta (consolidada), no a Vista Lista. No confundir ambas.

| Clase | Rol |
|---|---|
| `.bl-vl-progress-track` | Track de la barra — `height: 3px`, `background: var(--border)`, `border-radius: 99px` |
| `.bl-vl-progress-fill` | Fill — `width: var(--ver-bar-w, 0%)`, color heredado del estado del grupo |
| `.bl-vl-progress-label` | Etiqueta `done/total · pct%` — `var(--mono)`, `var(--text-xs)` |

**Variable CSS:** `--ver-bar-w` — porcentaje de progreso inyectado via `style` inline en el elemento `.bl-vl-progress-fill`. Valor: `0%`–`100%`. Excepción CSS Purity permitida.

**Color de `.bl-vl-progress-fill` por estado:**

| Estado grupo | Color fill |
|---|---|
| `.sprint-group-active` | `var(--amber)` |
| ~~`.sprint-group-hotfix`~~ | ~~`rgb(163 45 45)`~~ — **eliminado en TKT-D3** |
| `.sprint-group-planned` | `var(--blue)` |
| ~~`.sprint-group-closed`~~ | ~~`var(--border-secondary)`~~ — **no aplica desde mod:121**, Cerrado usa `.bl-vl-sprint-header-summary` sin fill/track |

#### Dark mode

Solo activo tiene override de dark mode en `locus-backlog.css` bajo `[data-theme="dark"]`. El fondo se intensifica ligeramente y el texto usa stops más claros del mismo ramp. Cerrado y planificado no requieren override.

Definiciones en `locus-backlog.css` (~L5592+). `.sprint-group-active/closed` existían previamente — rediseñados en V2.20. ~~`sprint-group-hotfix` y `sprint-badge-hotfix` son nuevos en V2.20~~ — **eliminadas en TKT-D3**.

**Cambio V2.20:** Rediseño completo del header de sprint en Vista Lista (`_renderVistaLista`). Layout de 3 filas, fondo ámbar 50 para activo, border-left de 3px por estado. `_renderVistaLista` es la única función de render de Vista Lista — `version-progress-*` no existe en el codebase y nunca fue consumida aquí. Ver nota de corrección arriba (mod:47).

### Sprint items list — familia `.spi-item` / `.spi-item-status` (Tab Sprint)

**Gap cerrado en mod:106** — familia con 4 variantes de fila y 5 de badge activas en `locus-sprint.js`/`locus-sprint.css` desde antes de esta entrada, nunca documentada en este doc pese a existir la fila de prefijo `spi-` en `§Prefijos y convenciones de naming`. Documentado ahora a raíz de TKT-202607-048 (REQ CAEL-0721-01/CAEL-0721-05) — ver changelog mod:106.

Renderizada por `_sprintItemHtml()` (`locus-sprint.js`) — único renderer de ítem (REQ o TKT) dentro del board del Tab Sprint, todas las secciones (pendiente/en-revisión/done/bloqueado).

**Fila — modificadores de `.spi-item`:**

| Clase | Condición | Tratamiento |
|---|---|---|
| `.spi-item--blocked` | `bucket === 'bloqueado'` | Ver estilos propios — `.spi-item--blocked:hover { opacity: 0.9 }` |
| `.spi-item--done` | `bucket === 'done'` | `opacity: 0.6` + `.spi-item-title` con `text-decoration: line-through` y `color: var(--text2)` |
| `.spi-item--orphaned` | `item.status === 'orphaned'` (REQ) | `opacity: 0.6`, `border-color: var(--hint)` — mismo tratamiento neutro que `.sps-card--pausado`, sin color, sin ícono |

**Badge — modificadores de `.spi-item-status` (base: `font-size: var(--text-xs)`, `padding: 2px 7px`, `border-radius: var(--radius-pill)`):**

| Clase | Texto | Color |
|---|---|---|
| `.spi-item-status--pendiente` | 'Pendiente' | `background: var(--surface2, var(--surface))`, `color: var(--text2)`, `border: 1px solid var(--border)` |
| `.spi-item-status--en-revision` | 'En revisión' | `background: color-mix(in srgb, var(--amber) 10%, transparent)`, `color: var(--amber-text)`, `border: 1px solid color-mix(in srgb, var(--amber) 28%, transparent)` |
| `.spi-item-status--done` | 'Done' | `--c-low-bg` / `--c-low-text` / `--c-low-border` |
| `.spi-item-status--blocked` | 'Bloqueado' | `--c-high-bg` / `--c-high-text` / `--c-high-border` |
| `.spi-item-status--orphaned` | 'Huérfano' | Mismo par que `--en-revision` — `color: var(--amber-text)` (no `var(--amber)` crudo). Ver nota de anti-pattern abajo |

**Regla — orphaned es status de REQ, no de bucket:** `_sprintItemBucket()` colapsa `item.status === 'orphaned'` al bucket visual `'pendiente'` por diseño (§4 `__BR-Core` — orphaned es visibilidad, no bloquea release). `_sprintItemHtml()` lee `isOrphaned` de forma independiente (`item.status === 'orphaned'` directo) para decidir la clase de fila y de badge — **no** se deriva del bucket. Antes de mod:106, `statusCls` no tenía rama `isOrphaned` y caía en el default `'spi-item-status--pendiente'` — bug cerrado en TKT-202607-048.

**Anti-pattern evitado — `color: var(--amber)` crudo en badge de texto:** El borrador inicial de esta clase usaba `color: var(--amber)` directo. Es el mismo anti-pattern ya migrado en 296 instancias / 19 archivos en `§Cambios mod:99/100` (`--amber`→`--amber-text` por contraste WCAG AA). `.spi-item-status--orphaned` se corrigió antes de entregar — usa `--amber-text`, mismo patrón que `--en-revision` en esta misma familia. No repetir `--amber` crudo como `color:` de texto en ninguna clase nueva de este proyecto.

### Badges de status de ítem — familia `.badge-status-*` (Vista Lista / Kanban de Backlog)

**Gap cerrado en mod:151** — familia consumida por `statusClass()`/`statusLabel()` (`locus-backlog-core.js`, módulo crítico) desde su origen, nunca documentada en este doc pese a que `.spi-item-status` (familia equivalente del Tab Sprint) sí lo está desde mod:106. Documentado a raíz de TKT1/TKT2 (REQ CAEL-0731-01).

Renderizada por cualquier vista que consuma `statusClass()`/`statusLabel()` — Vista Lista y Kanban de Backlog, entre otras.

| Clase | Texto (`statusLabel`) | Color | Definida en |
|---|---|---|---|
| `.badge-status-backlog` | 'Pendiente' | `background: var(--surface3)`, `border-color: var(--border2)`, `color: var(--text3)` — también fallback de `statusClass()` para valores no reconocidos | `locus-backlog.css` |
| `.badge-status-en-revision` | 'En revisión' | `background: var(--c-high-bg)`, `border-color: var(--c-high-border)`, `color: var(--c-high-text)` — **nota:** reusa tokens `--c-high-*` (naranja), no `--amber` — no confundir con `.spi-item-status--en-revision`, que sí usa ámbar | `locus-backlog.css` |
| `.badge-status-done` | 'Hecho' | `--c-done-bg` / `--c-done-border` / `--c-done-text` | `locus-backlog.css` |
| `.badge-status-descartado` | 'Descartado' | Mismo par que `--done` — `--c-done-bg` / `--c-done-border` / `--c-done-text` | `locus-backlog.css` |
| `.badge-status-historico` | 'Histórico' | Ver `locus-historico.css` — no auditado en este mod | `locus-historico.css` |
| `.badge-status-orphaned` | 'Huérfano' (mod:151 — antes: string crudo `'orphaned'`, sin case propio) | `background: color-mix(in srgb, var(--amber) 10%, transparent)`, `border-color: color-mix(in srgb, var(--amber) 28%, transparent)`, `color: var(--amber-text)` — mismo par que `.spi-item-status--orphaned`/`.staleness-pill.staleness--orphaned` (mod:151, unifica desde el gris de B-202606-095) | `locus-backlog.css` |

**Regla — no confundir con `.spi-item-status--*`:** son dos familias paralelas para el mismo concepto de status, una por vista (Backlog vs Tab Sprint). No comparten selector ni necesariamente el mismo tratamiento de color por status — verificado en este mod que `en-revision` difiere entre ambas (`--c-high-*` vs `--amber`); `orphaned` ahora coincide en ambas tras mod:151.

**Hallazgo fuera de scope — dead code sin caller (registrado como DISC, no resuelto en este mod):** `.badge-status-en-progreso` y `.badge-status-bloqueado` están declaradas en `locus-backlog.css` sin ningún caller confirmado en `statusClass()` ni en otro punto del código — mismo patrón que tenía `.badge-status-orphaned` antes de este mod.

### Sprints planificados — familia `spl-*` (T-202606-040)

Sección "Sprints planificados" en Tab Sprints (`#sprint-planned-list`), generada por `_renderPlannedSprints()` en `locus-sprint.js`.

| Selector | Rol |
|---|---|
| `.spl-section` | Wrapper de la sección — column, gap 6px |
| `.spl-header` | Fila título + contador |
| `.spl-title` | "Sprints planificados" — `--text2` |
| `.spl-count` | Pill de conteo total — `--blue` |
| `.spl-list` | Contenedor de filas — column, gap 6px |
| `.spl-row` | Fila por sprint — fondo/borde `--blue` sutil |
| `.spl-row-id` | ID del sprint — mono, `--blue` |
| `.spl-row-name` | Nombre descriptivo — ellipsis |
| `.spl-row-counts` | Wrapper de pills REQ/TKT/INC |
| `.spl-type` + `.spl-type--r/t/b` | Pills de conteo por tipo — colores replican `.item-type-pill.[R/T/B]` (`--blue`/`--green`/`--red`). **⚠️ Migración pendiente (Rune):** selectores CSS a renombrar a `--req/--tkt/--inc` junto con call sites JS — ver nota de migración §Selectores Gen 1. |
| `.spl-row-effort` | Effort total — `--text2` |

Definiciones en `locus-sprint.css` (~L1038-1140), junto a `.sml-*`.

### Sprint activo — familia `sps-*` (T-202606-036)

Card del sprint activo en sub-tab Sprints (`#sps-activo`), generada por `_renderSpsActivo()` en `locus-sprint.js`.

**Estructura real del sub-tab Sprints (`index.html` mod:151) — bloque de métricas + 4 secciones, sin wrapper intermedio:**

**Corrección mod:107:** esta tabla declaraba 5 secciones incluyendo `#sps-qinc` — no existe en `index.html` real, Q-INC vive en su propio tab (remoción anterior a mod:107, nunca reflejada en este doc). `#sps-stats-block` agregado — precede a las 4 secciones, primer hijo de `#sprint-panel-sprints`.

| ID | Contenido |
|---|---|
| `#sps-stats-block` | Bloque de métricas — 4 celdas fijas, ver `§Bloque de métricas` abajo |
| `#sps-activo` | Card del sprint activo |
| `#sps-programados` | Sprints en estado `programado` |
| `#sps-pausados` | Sprints en estado `pausado` |
| `#sps-cerrados` | Lista de sprints cerrados — filas `.sps-closed-row` (mod:107 — reemplaza `.sps-cerrados-row` colapsable, ver `§Fila Cerrados` abajo) |

**`.sps-status-group` / `.sps-status-header` / `.sps-status-body` — wrapper vertical de las 4 secciones (mod:107, `locus-sprint.css` mod:64 / `locus-sprint.js` mod:111, `design_intent: sprint_subtab_redesign`):** reemplaza `.sps-section-label`/`.sps-section-count` (retiradas, ver tabla tachada abajo). Mismo mecanismo de colapso que `.qdisc-status-group` — chevron + `is-collapsed`, estado en memoria (`_SPS_GROUP_COLLAPSED`, no persistido, resetea a expandido en reload).

| Selector | Rol |
|---|---|
| `.sps-status-group` | Wrapper de cada una de las 4 secciones — `margin-top: 12px` entre bloques |
| `.sps-status-header` | Barra de header — flex space-between, `cursor: pointer`, borde redondeado solo arriba (se cierra con `.sps-status-body` abajo), `role="button"` + `aria-expanded` |
| `.sps-status-header--activo` | Fondo `--green-dim` / borde `--green-border` / texto `--green-text` |
| `.sps-status-header--programados` | Fondo `--blue-dim` / borde `--blue-border` / texto `--blue-text` |
| `.sps-status-header--pausados` / `.sps-status-header--cerrados` | Neutros a propósito — `--surface2`/`--border`/`--text3`. Mismo criterio que Descartado en `.qdisc-stat-cell`: pausar o cerrar un sprint no es un estado de error, no lleva color de acento |
| `.sps-status-header-meta` | Contenedor flex de título + contador |
| `.sps-status-title` | Label uppercase, `--text-xs`, `600` |
| `.sps-status-count` | Contador mono, `700`, tabular-nums — hereda color del modificador del header padre |
| `.sps-status-chevron` | Ícono `▼` — rotación `-90deg` cuando `.sps-status-group.is-collapsed` |
| `.sps-status-body` | Contenedor de contenido — `min-height: 8px` (no colapsa a cero con 0 ítems), `display: none` cuando el grupo padre está `.is-collapsed` |
| `.sps-status-empty` / `.sps-status-empty-title` / `.sps-status-empty-hint` | Empty state dentro de `.sps-status-body` — mismo patrón textual que `.sps-empty`/`.qc-empty`, sin ícono |

~~`.sps-section-label`~~ / ~~`.sps-section-count`~~ — **retiradas en mod:107, reemplazadas por `.sps-status-group`/`.sps-status-header`/`.sps-status-count` arriba.** Registro histórico conservado: `font-size: var(--text-xs)`, `font-weight: 600`, `text-transform: uppercase`, presente en las 4 secciones desde mod:63/64.

**Bloque de métricas — `.sps-stats-block` / `.sps-stat-cell` (`_renderSpsStatsBlock()`, mod:107 — `locus-sprint.css` mod:64 / `index.html` mod:151 / `locus-sprint.js` mod:112, `design_intent: sprint_subtab_redesign`):**

| Selector | Rol |
|---|---|
| `.sps-stats-block` | Contenedor grid, `repeat(4, minmax(120px, 1fr))`, 4 celdas fijas — Activo / Programados / Pausados / Cerrados. Shell estático en `index.html`, nunca se oculta (BR-Execution §5) — JS solo actualiza `textContent` de `.sps-stat-n`, no regenera estructura |
| `.sps-stat-cell` | Base neutra — `var(--surface2)`/`var(--border)`. Usada tal cual para Pausados y Cerrados |
| `.sps-stat-cell--activo` | Fondo `--green-dim` / borde `--green-border` — mismo par que `.sps-status-header--activo` |
| `.sps-stat-cell--programados` | Fondo `--blue-dim` / borde `--blue-border` — mismo par que `.sps-status-header--programados` |
| `.sps-stat-cell--en-revision` (mod:131, `locus-sprint.css` mod:67, `TKT-202607-126`) | Fondo `color-mix(in srgb, var(--amber) 10%, transparent)` / borde `color-mix(in srgb, var(--amber) 28%, transparent)`, texto `--amber-text` — reusada en sub-tab Ítems vía `#spi-stats-block` (mismas clases, `id` de contenedor propio solo para lectura JS) |
| `.sps-stat-cell--bloqueado` (mod:131, `locus-sprint.css` mod:67, `TKT-202607-126`) | Fondo `--c-high-bg` / borde `--c-high-border`, texto `--c-high-text` — token semántico `--c-high-*` (ya usado para "bloqueado" en `.spi-item-status--blocked`, no confundir con la familia `--c-severity-high-*`), no `--red` (sin precedente en esta familia) |
| `.sps-stat-label` / `.sps-stat-n` | Label (2xs, uppercase, `--text2`) y número (mono, tabular-nums, `--text`) — colores heredan del modificador de celda cuando aplica |

**Identity y empty-state — familia `.spt-identity*` / `.spt-content-empty*` (mod:131, `locus-sprint.css` mod:67, `TKT-202607-126`, `design_intent: sprint_subtab_redesign`):** documentadas por primera vez — vivían sin entrada propia en este doc pese a estar presentes en `locus-sprint.css` desde antes de mod:66/67.

| Selector | Rol |
|---|---|
| `.spt-identity` | Chip de sprint + label — instancia única compartida entre sub-tabs Ítems y Planificar (shell en `index.html`), flex con `min-width: 0` para permitir truncado del label |
| `.spt-identity-chip` | Chip mono, `--text-xs`, `700`, fondo `--surface3`, borde `--border`, `border-radius: var(--radius-pill)` — código del sprint (ej. `PP-S-13`) |
| `.spt-identity-label` | Label del sprint — `--text-sm`, `--text2`, `text-overflow: ellipsis` |
| `.spt-content-empty` | Empty-state ícono+título+hint — mismo patrón visual que `.msc-diff-empty*` (`locus-backlog-item.css`) y `.sps-empty`, nunca área en blanco (`BR-Execution §5`). Contenedor `flex column`, `align-items: center`, `padding: 32px 24px`, `text-align: center` |
| `.spt-content-empty-icon` | Ícono — `--text-display-2xl`, `--text3` |
| `.spt-content-empty-title` | Título — `--text-sm`, `--text2` |
| `.spt-content-empty-hint` | Hint — `--text-xs`, `--text3` |

**Diferencia con `.qdisc-stats-block`:** sin `.sps-stat-icon` — no existe en `locus-sprint.css`, a diferencia de los emoji-icons de `.qdisc-stat-cell`. Solo 2 de las 4 celdas llevan modificador de color; Pausados/Cerrados quedan neutras a propósito, mismo criterio que Descartado en `.qdisc-stat-cell` (sin rojo — no es un estado de error).

**Fila Cerrados — `.sps-closed-row` (mod:107 — reemplaza `.sps-cerrados-row`/`.sps-cerrados-header`/`.sps-cerrados-retro`, nunca documentadas con tabla propia en este doc):** fila plana con acento lateral, mismo lenguaje visual que las cards PROMOTED de Q-DISC — la fila completa es el control (click o Enter/Space invoca `openSprintRetroView()` directamente). El menú `···` (Ver retro completa / Exportar .md) se retira — ambas acciones eran redundantes entre sí.

| Selector | Rol |
|---|---|
| `.sps-closed-row` | Fila — border-left `2px solid var(--hint)`, fondo `--surface2`, `cursor` implícito por ser el control completo |
| `.sps-closed-row-id` | Código del sprint — mono, `--text-md`, `500` |
| `.sps-closed-row-label` | Título — `--text-sm`, `--text2`, `text-overflow: ellipsis` |
| `.sps-closed-row-date` | Fecha de cierre — `--text-sm`, `--text3` |
| `.sps-closed-row-done` | Conteo done/total — `--text-sm`, `--green-text` |
| `.sps-closed-retro-pending` | Chip ámbar cuando no hay retro (`sin retroDoc`) — reemplaza el texto plano "Retro no disponible". Mismo tono que `.qdisc-limit--warn` |

| Selector | Rol |
|---|---|
| `.sps-card` | Contenedor card — `border: 1px solid var(--border)`, `border-radius: var(--radius-lg)`, `overflow: hidden` (necesario para el `border-radius` — relevante para cualquier `::before`/`::after` que se agregue a este selector, ver nota de `#sps-activo::after` abajo) |
| `#sps-activo .sps-card` | Card del sprint activo — además de la base, declara `border-left: 2px solid var(--accent)` (T-202606-099, reducido de 3px a 2px en mod:64/CAEL-01 — reemplazo consciente, `padding-left: 12px` de los hijos conservado sin cambio) |
| `#sps-activo::after` | Conector decorativo estático hacia la sección Programados (nuevo en mod:64, CAEL-01/REQ CAEL-05) — `content:''`, `position:absolute`, `left:2px`, `bottom:-14px`, `width:1px`, `height:14px`, `background:var(--border)`. Vive en `#sps-activo` (el contenedor), no en `.sps-card` — `.sps-card` tiene `overflow:hidden` para su `border-radius`, un `::after` ahí quedaría recortado. Sin comportamiento — no depende de `activationOrder` ni de ningún dato, no se oculta si Programados está vacío |
| `.sps-card--pausado` | Estado pausado — `background: var(--surface2)`, `border-color: var(--hint)` |
| ~~`.sps-card--hotfix`~~ | ~~Estado hotfix — `border-color: var(--c-critical-border)`~~ — **eliminado en TKT-D3** · `S-HOTFIX` no existe en Gen 2 |
| `.sps-card-header` | Fila superior dentro de la card — ID + label editable + badge de estado (selector real; `.sps-header` es un bloque distinto, ver fila siguiente) |
| `.sps-header` | Bloque de meta-grid — versión/release/goal/scope en 2 columnas (no confundir con `.sps-card-header`) |
| `.sps-title` | Label del sprint — clickeable para edición inline |
| `.sps-inline-input` | Input inline compartido por label / goal / scope |
| `.sps-inline-input--goal` | Modificador goal — `font-weight: 400` |
| `.sps-inline-input--scope` | Modificador scope — `font-weight: 400` |
| `.sps-meta` | Bloque de metadatos — grid `1fr 1fr` |
| `.sps-meta-item` | Fila de metadato — label + valor editable |
| `.sps-meta-item--full` | Modificador — ocupa las 2 columnas del grid |
| `.sps-meta-label` | Etiqueta uppercase — `var(--text3)`, `var(--text-xs)` |
| `.sps-meta-value` | Valor clickeable para edición inline |
| ~~`.sps-progress-wrap`~~ | **Eliminado en TKT1 REQ CAEL-05** (`locus-sprint.js` mod:96 / `locus-sprint.css` mod:49). Vivía oculto por `display:none` desde T-202606-033 sin consumidor real — 0 call sites confirmados por grep antes de eliminar. La barra de progreso de `#sps-activo` es ahora exclusivamente `.sph-panel` — ver tabla dedicada abajo |
| ~~`.sps-burndown-bar`~~ / ~~`.sps-burndown-fill`~~ / ~~`.sps-card--pausado .sps-burndown-fill`~~ / ~~`.sps-burndown-label`~~ | Eliminadas junto con `.sps-progress-wrap` — mismo TKT. No quedan referencias en `locus-sprint.js`/`locus-sprint.css` fuera de comentarios explicativos del cambio |
| `.sps-btn` | Botón base neutral |
| `.sps-btn--close` | Modificador destructivo — `color: var(--red)` |
| `.sps-btn-menu` | Botón trigger del menú de acciones — `aria-haspopup="true"`, atributo `data-sps-activo-menu` |
| `.sps-empty` | Empty state cuando no hay sprint activo — texto informativo únicamente (`_renderSpsActivo()`). El botón `+ Sprint nuevo` es independiente de este estado — vive siempre visible arriba de las 4 secciones, ver `§Panel "+ Sprint nuevo" — familia spnp-*` |
| ~~`.sps-empty-cta`~~ | ~~CTA del empty state — invoca `openNewSprintInline()`~~ — **corregido mod:49:** clase declarada en `locus-sprint.css` sin uso en JS. `openNewSprintInline()` no existe en el codebase. El empty state real no tiene CTA, solo `.sps-empty-hint` (texto). Candidata a limpieza CSS, no eliminada en este mod |

**Panel "Salud del sprint" — familia `.sph-*` (T-202606-033; fusionada como hijo de `.sps-card` en TKT2 REQ CAEL-05 — antes hermana, ver nota abajo):** hijo directo de `.sps-card` dentro de `#sps-activo`, no hermano — la fusión visual las lee como un único bloque bordeado.

| Selector | Rol |
|---|---|
| `.sph-panel` | Sin border/background/radius propios desde TKT2 — hereda el fondo de `.sps-card`. `border-top: 1px solid var(--border)` como divisor, `margin-top: 4px`, `padding: 14px 14px 0` (padding-left compensado a `12px` por la regla de border-left de `#sps-activo .sps-card` — border-left reducido a `2px` en CAEL-01/REQ CAEL-05, `padding-left: 12px` conservado sin cambio pese al nuevo ancho, delta de 1px evaluado como no perceptible por Nova, decisión documentada en CHECKPOINT de esa sesión, no en el CSS —, misma familia que `.sps-card-header`/`.sps-meta`), `flex; flex-direction: column; gap: 10px` |
| `.sph-title` | Título "Salud del sprint" — uppercase, `var(--text-xs)`, `var(--text3)` |
| `.sph-row` | Fila flex — contiene `.sph-bar-track` + `.sph-pct` |
| `.sph-bar-track` | Track — `height: 5px`, `background: var(--surface3)`, `border-radius: var(--radius-pill)`. Markup real lleva `role="progressbar"` + `aria-valuenow`/`aria-valuemin`/`aria-valuemax`/`aria-label` (generado por `_renderSpsActivo()`) |
| `.sph-bar-fill` | Fill — `width: var(--sps-burndown-pct, 0%)`, `background: var(--accent)`, `transition: width 0.3s var(--ease-out)` |
| `.sps-card--pausado .sph-panel .sph-bar-fill` | Fill en estado pausado — `background: var(--hint)`. **Combinador descendiente desde TKT2** — antes de la fusión era `.sps-card--pausado ~ .sph-panel .sph-bar-fill` (hermano general); dejó de aplicar en cuanto `.sph-panel` pasó a vivir dentro de `.sps-card` y se corrigió en el mismo TKT |
| `.sph-pct` | Porcentaje textual junto al track — `var(--text-lg)`, `600`, `var(--accent)` — ampliado en CAEL-01/REQ CAEL-05 para que el dato de mayor jerarquía (salud del sprint) lidere visualmente sobre el resto de la card |
| `.sph-count` | Texto `done / total ítems` |
| `.sph-alert` | Fila de alerta de bloqueados — visibilidad via `classList.toggle('is-visible', bloqueadosCount > 0)`, nunca por ausencia/presencia en el DOM (CSS Purity) |
| `.sph-alert-icon` / `.sph-alert-text` | Ícono y texto de la fila de alerta |

**Variable CSS:** `--sps-burndown-pct` — porcentaje de progreso del sprint activo inyectado desde JS via `style.setProperty('--sps-burndown-pct', pct + '%')` en `_renderSpsActivo()`. Valor: `0%`–`100%`. El nombre de la variable no se renombró junto con el markup (`.sps-burndown-*` → `.sph-*`) para no invalidar el header de identidad de `locus-sprint.js` con un cambio no funcional — consumidor único hoy es `.sph-bar-fill`.

**Menú de acciones del sprint activo — familia `.sps-menu-wrap` (T-202606-036/T-202606-037):**

`.sps-actions` no existe en ningún archivo real — confirmado contra `locus-sprint.css` (mod:36) y `locus-sprint.js` (mod:57). El componente real es este:

| Selector | Rol |
|---|---|
| `.sps-menu-wrap` | Contenedor del menú — wrapper de botón + dropdown |
| `.sps-btn-menu` | Botón trigger — `aria-haspopup="true"`, `aria-expanded` dinámico, atributo `data-sps-activo-menu` |
| `.sps-dropdown` | Panel de opciones — `role="menu"`. **Visibilidad via atributo HTML `hidden` nativo, no clase `.is-hidden`** — excepción a la convención general del sistema |
| `.sps-dropdown--flip` | Modificador flip-to-fit — `top: auto; bottom: 32px`. Rune lo aplica (sin quitar `.sps-dropdown` base) cuando `getBoundingClientRect()` mide que el espacio entre el botón `···` y el borde inferior de `.sps-card` es menor que la altura del dropdown. Ver `_Locus-ux-ref §E-10` |
| `.sps-dropdown-item` | Ítem de menú — `role="menuitem"` |
| `.sps-dropdown-item--danger` | Modificador para acción destructiva (ej. "Cerrar sprint", "Descartar sprint") |
| `.sps-dropdown-sep` | Separador — `role="separator"` |

Reutilizado tal cual en `#sps-programados` (`_renderSpsProgramados()`) para la acción "Descartar sprint".

**Nota de arquitectura — clipping por `overflow: hidden` del `.sps-card` compartido:** `.sps-card` (línea `overflow: hidden`, necesario para su `border-radius`) es el contenedor compartido de todas las filas de `#sps-programados`. Un `.sps-dropdown` abierto en una fila cercana al borde inferior del card se recorta/oculta detrás de `#sps-cerrados` — `INC-[pendiente-ID]`. `.sps-dropdown--flip` es el escape hatch — ver fila de la tabla anterior y `_Locus-ux-ref §E-10` para el criterio completo.

**Nota tokens:** `--c-medium-*` referenciado en AC del T no existe en `locus-base.css`. Estado pausado mapeado a `--surface2` / `--hint` — mismo tratamiento que `.sprint-badge-paused`.

**Nota de arquitectura — `#sprint-panel-sprints`:** Selector por **ID** (no clase `.sprint-panel-sprints`). `display: flex; flex-direction: column` — una sola sección vertical, sin grid de dos columnas. No existen `.sps-layout` ni `.sps-sidebar` en el codebase — cualquier T que asuma anular un layout de dos columnas en este panel parte de una premisa incorrecta. Declara `padding-left: var(--subtab-gutter)` desde mod:62 (`locus-sprint.css` mod:53) — ver `§Gutter unificado de subtabs`.

**Nota de arquitectura — `.sph-header` (`#sprint-panel-header`):** Hermano de los 4 paneles del Tab Sprint (`#sprint-panel-items` / `-planificar` / `-plan` / `-sprints`), no hijo de ninguno. Visibilidad (`is-hidden`) controlada por JS según haya o no sprint activo — fuera de scope CSS.

### Popovers de toolbar/stats — familia `.blf-*` / `.blt-*` (TKT1/TKT2, [tmp:req-clutter-backlog])

Canónico en `locus-backlog.css` (mod:75). Consolidan controles secundarios de la toolbar del Backlog (Deps/Hijos/Sin AC/Orden/Colapsar) y los chips de tipo de la stats bar detrás de un trigger con badge — reduce clutter visual sin eliminar ningún filtro existente.

**Principio de diseño:** adaptación directa del patrón ya validado `.sps-menu-wrap` / `.sps-btn-menu` / `.sps-dropdown` (ver sección anterior) — mismo mecanismo de visibilidad (`hidden` nativo, no `.is-hidden`), mismo `role="menu"`. No se introdujo un componente de popover nuevo.

**Popover Filtros — familia `.blf-*` (TKT1, trigger `#fbar-filter-btn`):**

| Selector | Rol |
|---|---|
| `.blf-wrap` | Contenedor del trigger + popover |
| `.blf-trigger` | Botón trigger — visualmente basado en `.bl-strip-btn` para consistencia con la fila de toolbar. `aria-haspopup="true"`, `aria-expanded` dinámico |
| `.blf-badge` | Badge de conteo sobre el trigger — cantidad de filtros secundarios activos (Deps/Hijos/Sin AC activos o sort ≠ default). `classList.toggle('is-hidden', n === 0)` — usa la clase global, sin regla propia de ocultamiento |
| `.blf-popover` | Panel — `role="menu"`, visibilidad via atributo `hidden` nativo |
| `.blf-popover-item` | Envoltorio de cada control reubicado (Deps/Hijos/Sin AC/Colapsar) — conserva el control original con su ID intacto |
| `.blf-popover-sep` | Separador — `role="separator"`, mismo tratamiento que `.sps-dropdown-sep` |
| `.blf-popover-sort` | Fila del control de orden — envuelve `#fbar-sort-select` + `#fbar-sort-dir-btn` |

**Popover Tipos — familia `.blt-*` (TKT2, trigger `#bstats-types-btn`):**

| Selector | Rol |
|---|---|
| `.blt-wrap` | Contenedor del trigger + popover — vive dentro del template literal de `_renderStatsBar()`, recreado en cada render |
| `.blt-trigger` | Botón trigger — mismo tratamiento visual que `.blf-trigger` |
| `.blt-badge` | Badge de conteo — cantidad de tipos con `count > 0` |
| `.blt-popover` | Panel — `role="menu"`, contiene los `.stat-type-chip` existentes sin cambio de clase, solo reubicados |

**Accesibilidad:** `:focus-visible` con `outline: 2px solid var(--accent)` heredado del mismo patrón que `.sps-btn-menu` — sin regla propia. Contraste badge (`--accent` / `--text-on-accent`) ya validado en el sistema, mismo par usado en otros badges de acento.

**Sin tokens nuevos** — reuso exclusivo de `--text-xs` · `--text-sm` · `--text-2xs` · `--radius-xs/sm/md/pill` · `--surface/2/3` · `--border/2` · `--accent` · `--accent-dim` · `--text-on-accent` · `--z-popover` · `--trans-fast/color`.

**Nota de arquitectura — recreación en render:** `.blt-wrap` se destruye y recrea en cada `_renderStatsBar()` (innerHTML completo) — su trigger usa delegación de eventos (`data-action="stats-toggle-types"`), no un listener directo. `.blf-wrap` vive en HTML estático (`index.html`) — su trigger usa listener directo, no delegación. No asumir el mismo mecanismo de binding entre ambas familias pese a compartir patrón visual.

### Encabezado de contexto vista-principal — familia `.spt-context-header` (T-202606-002)

Canónico en `locus-sprint.css`. Visible solo cuando `#sprint-panel-sprints` actúa como default en estado sin-sprint-activo (R-202606-001) — clase `.spt-main-view` aplicada por Rune (T-202606-001) según su lógica de detección.

| Selector | Rol |
|---|---|
| `.spt-context-header` | Header de contexto — `display: none` por defecto |
| `#sprint-panel-sprints.spt-main-view .spt-context-header` | Override — `display: flex` cuando el panel está en modo vista-principal |
| `.spt-context-header__icon` | Ícono decorativo del header — `var(--text3)`, `var(--text-xl)` |

**Comportamiento:** El panel ya es de columna única — el modo `.spt-main-view` no requiere anular ningún grid, solo mostrar el header de contexto. AC de empty-state total (ningún sprint de ningún tipo) pendiente — depende de que las 4 secciones (`#sps-activo`, `#sps-programados`, `#sps-pausados`, `#sps-cerrados`) queden vacías simultáneamente; lógica de JS, no resuelta por este CSS. **Corrección mod:107:** listaba `#sps-qinc` como 5ª sección — no existe, ver `§Panel Q-INC`. `#sps-stats-block` no entra en esta cuenta — nunca se oculta (siempre visible con 0s), no participa del criterio de empty-state total.

### Panel Q-INC — familia `qinc-*` (`#tab-incidentes` / `#qinc-panel-body`, TKT-D3/D5 + TKT1 countdown SLA)

**Corrección mod:107 (Hallazgo fuera de scope, auditoría contra `Archivo.zip` real):** este heading declaraba `#sps-qinc` como contenedor — stale desde REQ CAEL-0720-05 ("Shell persistente Q-INC"), que promovió Q-INC de sub-tab dentro de Sprint/Backlog a **tab de primer nivel** (`#tab-incidentes`, `index.html`). Verificado contra `locus-backlog.css` real (mod:121): `#tab-incidentes` envuelve `#qinc-toolbar` (estático, botón "Descargar Q-INC") + `.qinc-stats-bar`/`#qinc-stats-bar` + `#qinc-panel-body` (contenido dinámico vía `renderQIncPanel()`). `#sps-qinc` no existe en ningún archivo real — cambio anterior a este REQ, ajeno a `locus-sprint.css`/`locus-sprint.js`, nunca reflejado en este doc hasta ahora.

Canónico en `locus-backlog.css`. Cards ITIL (INC/PRB/CHG) del panel Q-INC, generadas por `buildQIncItem()` (`locus-incidents-item.js`, movida desde `locus-backlog-item.js` en TKT2/REQ split-itil-item, 2026-07-23). **Corrección mod:48:** hasta esta entrada, la tabla de prefijos (`§Tabla de prefijos`) y la nota de mod:21 declaraban estas clases "documentadas en §Sprint groups" — esa sección nunca tuvo patrón `qinc-*`, la referencia era falsa desde su origen. Esta sección es la primera documentación real del patrón. **Corregido mod:124 (TKT2/REQ CAEL-0724-11):** "INC/PRB/KE/CHG" listaba `KE` como cuarto tipo — fusionado a `PRB.root_cause_confirmed` (infra_version 51), retirado de la rama Reactiva activa; queda INC/PRB/CHG.

**Estado de card — mutuamente excluyentes, aplicadas en `buildQIncItem()` sobre la card completa:**

| Selector | Rol |
|---|---|
| `.qinc-item--sla-vencido` | INC `high` con `slaDeadline` superado — tratamiento de card completa (borde/fondo), no solo el texto del countdown |
| `.qinc-item--sla-riesgo` | INC `high` con `remaining < SLA_RIESGO_WINDOW_MS` (< 6h) y aún no vencido |
| (sin modificador) | INC `high` fuera de ventana de riesgo, o INC `medium`/`low` — `slaClass` solo se calcula para prioridad `high` |

**Countdown de texto — `.qinc-sla-countdown` (span dentro de la card, no la card misma):**

| Selector | Rol |
|---|---|
| `.qinc-sla-countdown` | Base — texto formateado `"Xh Ym"` generado por `buildQIncItem()`. No usa `getCD()` ni tiene tick en vivo (`setInterval`) — se recalcula solo al re-renderizar el panel |
| `.qinc-sla-countdown--riesgo` | **Nuevo — mod:86, TKT1.** Activa junto con `.qinc-item--sla-riesgo` (mismo umbral, `< 6h`). Color: `var(--c-severity-high-*)` |
| `.qinc-sla-countdown--vencido` | Texto se reemplaza por `"VENCIDO"` — nunca muestra tiempo negativo. Ya implementado antes de TKT1, sin cambio en esta entrega |

**Badge de prioridad SLA — `.qinc-badge--sla`:**

| Selector | Rol |
|---|---|
| `.qinc-badge--sla` | Base — sin modificador de prioridad, cae en rojo genérico |
| `.qinc-badge--sla-high` | **Nuevo — mod:86, TKT1.** Gap cerrado: referenciada en `locus-backlog-item.js:2729` desde su introducción original sin definición CSS — huérfana hasta esta entrega |
| `.qinc-badge--sla-medium` | Ídem — nueva en mod:86 |
| `.qinc-badge--sla-low` | Ídem — nueva en mod:86 |

**`.qinc-type-badge` — badge de tipo de ítem ITIL, auditoría cerrada (mod:56). 4 variantes vigentes — `--ke` NO retirada (corrección de `§Cambios mod:124`, ver `§Cambios mod:128`): esa entrada retiró `KE` de `.stat-type-chip`/`.item-type-pill`, pero nunca de esta familia. `.qinc-type-badge--ke` sigue siendo alcanzable desde `buildQIncItem()` para ítems históricos con `type:'KE'` persistidos en Supabase — ver `§Cambios mod:128` para el bug de clasificación asociado (`_isQIncTerminal`):**

| Selector | Color (light) | Color (dark) |
|---|---|---|
| `.qinc-type-badge--inc` | `#e85555` | `#f87171` |
| `.qinc-type-badge--prb` | `#f59e0b` | `#fbbf24` |
| `.qinc-type-badge--ke` | `#eab308` | `#fde047` |
| `.qinc-type-badge--chg` | `#64748b` | `#94a3b8` |

Color hardcoded por clase — `--*` propio de cada modificador (ver `locus-backlog.css`, ~L5556-5617), sin dependencia de `--red`/`--orange`/`--yellow`/`--slate` ni de ningún token compartido con `.item.bitem`/`.idp-type-chip`. Único source of truth del color de este badge — no confundir con la familia `--_type-color` de `.idp-type-chip`/`.idp-ac-dot` (`§Tabla de prefijos` → `idp-`), sistema de color independiente para un componente distinto.

**Corrección (mod:56):** `buildQIncItem()` (`locus-backlog-item.js`) calculaba un `typeColorMap` propio y lo inyectaba como `style="--qinc-type-color:..."` inline en el badge — variable nunca consumida por ninguna regla CSS (confirmado por grep completo contra `locus-backlog.css`). Cálculo y atributo eliminados en `locus-backlog-item.js` mod:108 (TKT1/CAEL-21) — sin cambio visual, el color siempre vino de la clase `.qinc-type-badge--[tipo]` de esta tabla, nunca de la variable inline.

**Botón "Copiar ítem" — `.qinc-item-copy-btn` (primera documentación real, mod:11 — huérfana de documentación desde TKT-B/REQ CAEL-0722-01, mismo patrón ya corregido para otros selectores en mod:48/mod:51):** Botón de acción secundaria dentro de `.qinc-item-header` — copia el bloque completo del ítem al portapapeles (`copyIncidentItemMd()`, `locus-incidents-generator.js`). Distinto de `.qinc-item-code-chip` (copia solo el código) — ambos coexisten en la misma card, mismo mecanismo de estado.

| Selector | Rol |
|---|---|
| `.qinc-item-copy-btn` | Base — icon-only, `22×22px`, `border-radius: var(--radius-xs)`. **Cambio de forma (mod:11):** antes botón-texto (`padding: 2px 6px`, `gap: 4px`, label "Copiar ítem" visible) — retirado el label del markup (`buildQIncItem()`, `locus-incidents-item.js` mod:10) para consistencia con el patrón icon-only ya adoptado en el resto del ecosistema para acciones secundarias de card (ej. `.sc-menu-btn`). `title`/`aria-label` conservan el texto completo — sin pérdida de accesibilidad. Ícono: `<i class="ti ti-copy">`, sin swap a `ti-check` en éxito (a diferencia de `.qinc-item-code-chip`) — el estado de éxito se comunica solo por color vía `.is-copied` |
| `.qinc-item-copy-btn:hover` | `border-color: var(--border2)`, `color: var(--text2)`, `background: var(--surface2)` |
| `.qinc-item-copy-btn.is-copied` | `color: var(--green)`, `border-color: var(--green)` — mismo criterio que `.copy-item-btn` (`locus-backlog-item.css`) |
| `.qinc-item-copy-btn.is-copy-error` | `color: var(--red-text)`, `border-color: var(--red-border)` — token de texto auditado WCAG, no `--red` crudo |

**Stats bar — `.qinc-stats-bar` (rediseño mod:11, análisis visual Nova):** Contenedor estático en `index.html`, llenado por `renderQIncStats()` (`locus-incidents-render.js`) — separado de `#qinc-panel-body` desde TKT2/REQ CAEL-0720-05. **Canónico ahora en `locus-incidents.css`** — la referencia a `locus-backlog.css` de la entrada de mod:109 quedó obsoleta con la extracción de Q-INC a archivo propio (ver `§Cambios mod:126`); esta sección ya vivía en el archivo correcto, solo la nota de ubicación no se había actualizado en esa entrada específica. `.qinc-stats-bar` deja de ser fila flex suelta — pasa a bloque con identidad de header propia (`border: 1px solid var(--border)`, `border-radius: var(--radius-md-plus)`, `overflow: hidden`), mismo principio de capas que `.bl-header-unified` (Q-Backlog/Q-DISC) pero **sin adoptar su `position: sticky`** — verificado contra `index.html` real: `#qinc-stats-bar` es sibling plano de `#qinc-panel-body` dentro de `#tab-incidentes` (tab de primer nivel), sin el mismo ancestro de scroll que Q-Backlog/Q-DISC tienen dentro de `.tpl-detail`. El layout flex original (chips + search) se conserva intacto, movido al hijo `.qinc-stats-bar-inner`.

| Selector | Rol |
|---|---|
| `.qinc-stats-bar` | **Nuevo rol (antes era el contenedor flex directo).** Shell de identidad — borde, radio, `overflow:hidden`. Sin layout propio |
| `.qinc-stats-bar-inner` | **Nuevo — mod:11.** Contiene el layout flex original: `display:flex; flex-wrap:wrap; gap:4px; padding:6px 10px`. Requiere que `renderQIncStats()` envuelva su `innerHTML` en este nodo — sin él, los chips pierden el padding lateral (el shell externo no tiene padding propio) |
| `.qinc-stats-types` | Wrapper de chips de tipo — flex, wrap. Sin cambio |
| `.qinc-stats-priority` | Wrapper de chips de prioridad SLA — flex, wrap. Sin cambio |
| `.qinc-search-input` | Input de búsqueda — `flex:1`, min-width 120px, mismo token set que inputs del ecosistema (`--surface2`/`--border`/`--radius-sm`), foco con `border-color: var(--accent)`. Sin cambio |

Chips de tipo y prioridad reutilizan la familia genérica `.stat-type-chip`/`.stat-pri-chip` — no se documenta de nuevo aquí, ver entrada de esa familia (`§Cambios mod:99`/`mod:105` para el mecanismo de `.active`). Prioridad SLA (`.pri-high`/`.pri-medium`/`.pri-low`) coincide en case entre JS y CSS — sin gap ahí.

**Gap real encontrado — resuelto (mod:124, TKT1/REQ CAEL-0724-11):** los chips de tipo del stats bar de Q-INC (`renderQIncStats()`, `locus-incidents-render.js`) emitían la clase con `t.toLowerCase()` → `tc-inc`/`tc-prb`/`tc-chg` (antes también `tc-ke`, retirado en el mismo TKT junto con el resto del vocabulario KE). El CSS solo define el selector compuesto en mayúsculas — `.stat-type-chip.tc-INC`/`.tc-PRB`/`.tc-CHG` (`locus-backlog.css` ~L610-680, confirmado también en `.active.tc-*`). El selector de clase CSS es case-sensitive — el compuesto nunca matchea. Efecto pendiente (no cerrado por este mod): los 3 chips de tipo de Q-INC solo aplican el estilo base de `.stat-type-chip`/`.stat-type-chip.active` (genérico, sin color por tipo) — pierden la intensificación de color que esta misma sección da por hecha (ver corrección de `.tc-INC`/`.tc-CHG` en `§Cambios mod:99`, que asume el selector aplicando). El mismo patrón (`t.toLowerCase()`) se repite en `locus-backlog-zone-engine.js:300`, que reutiliza este stats bar para el panel de Q-Backlog (`tc-req`/`tc-tkt` vs `.tc-REQ`/`.tc-TKT`, mismo mismatch). Q-DISC no tiene chips de tipo (`_typeChipDefs` vacío para `qdisc`, `zone-engine.js:261`) — no aplica ahí. El CSS está completo y correcto tal como está documentado en esta sección — el defecto de case-sensitivity sigue siendo de generación de clase en JS, no de este Doc Ref. Nova no lo corrige — no toca `.js`. **Este mod solo cierra la parte de `KE` (retirada del universo de tipos) — el mismatch de casing para INC/PRB/CHG permanece abierto, sin TKT propio a la fecha.**

**Pendiente de integración (Rune, TKT1):** `.qinc-sla-countdown--riesgo` y las 3 variantes de `.qinc-badge--sla-*` están definidas en CSS (mod:86) pero aún no aplicadas condicionalmente en `buildQIncItem()` — la clase base del countdown y del badge se emite siempre, sin el modificador. Ver CHECKPOINT de Nova, TKT1, `next_role: FS · Rune`.

**Secciones colapsables — `.qinc-section-header` / `.qinc-section-chevron` / `.qinc-section-body`** (`locus-incidents.css` mod:6 — TKT-202607-158, `design_intent: n/a`, reuso directo del patrón ya vigente en Q-DISC/Q-Backlog citado por Cael en especificación. **Rediseñado mod:11 (análisis visual Nova)** — ver tabla actualizada abajo, reemplaza la versión de mod:6):

**Discrepancia cerrada (mod:168 → resuelto en `locus-incidents.css` mod:12, fix inline el mismo día):** la entrega original de mod:11 usaba `letter-spacing: 0.04em`, en desacuerdo con el valor `0.06em` que la entrada de mod:6 declaraba "sin cambio". Corregido con fix inline sobre `locus-incidents.css` — `.qinc-section-header` queda en `0.06em`, alineado a la tabla de unificación general. Sin bifurcación de founder, dueño (Nova) presente, nivel Patch.

| Selector | Rol |
|---|---|
| `.qinc-section-header` | Base — layout (`flex space-between`), tipografía (`text-xs`, `uppercase`, `letter-spacing: 0.06em`), `cursor:pointer`, `:hover`/`:focus-visible`. **Deja de tener color propio** — mod:6 heredaba `color: var(--text2)` en la base; ahora el color vive exclusivamente en los modificadores `--activos`/`--terminados` de abajo. Header sin modificador (no debería ocurrir en producción — los dos únicos headers del panel siempre llevan uno de los dos) queda sin `background`/`border-color`/`color` explícitos, hereda del contexto |
| `.qinc-section-header--activos` | **Nuevo — mod:11.** Fondo `var(--green-dim)`, borde `var(--green-border)`, texto `var(--green-text)`, `font-weight:700` — mismo mecanismo de 3 capas que `.qdisc-status-header--promoted`. Aplicado al header "Activos" — sección operativamente relevante, ancla la atención primero (mismo principio que Q-DISC aplica a sus 3 bloques de status) |
| `.qinc-section-header--terminados` | **Nuevo — mod:11.** Fondo `var(--surface2)`, borde `var(--border)`, texto `var(--text3)`, `font-weight:600` — deliberadamente neutro, mismo criterio que `.sps-status-header--cerrados`: terminar un ítem no es estado de error ni de alerta, no lleva color de acento |
| `.qinc-section-count` | **Nuevo — mod:11.** Badge de conteo junto al título — `font-family: var(--mono)`, `font-weight:700`, `font-variant-numeric: tabular-nums`. Antes el número solo era implícito en el contenido renderizado debajo del header, sin badge propio |
| `.qinc-section-header-left` | Wrapper flex de chevron + título — layout puro, sin estilo propio. Mismo rol que `.qbacklog-draft-header-meta`. Sin cambio |
| `.qinc-section-chevron` | Ícono de colapso — rotación `0deg` ↔ `-90deg` vía `.qinc-section-header--collapsed`, mismo mecanismo que `.qdisc-status-chevron`/`.qbacklog-draft-chevron`. **Pierde su `color: var(--text3)` propio** en mod:11 — ahora hereda el color del header padre (`--activos`/`--terminados`), consistente con que el chevron es parte del bloque de identidad, no un elemento neutro independiente |
| `.qinc-section-header--collapsed` | Estado colapsado del header — activa la rotación del chevron |
| `.qinc-section-body--collapsed` | `display: none` — a diferencia de `.qdisc-status-body` (que conserva alto mínimo con contador "0" visible), esta sección sí colapsa a oculto total. Q-INC no tiene el mismo requisito de "estado vacío siempre visible" que Q-DISC declara para sus 3 status permanentes — Activos/Terminados son agrupación de vista, no categorías de ciclo de vida con AC de vacío explícito |

**`:focus-visible` — corrección de token antes de aplicar (Nova, sesión de doc_update):** el entregable de TKT-202607-158 declaró `var(--border)` como supuesto explícito por falta de `_Locus-css-ref` adjunto en esa sesión (CHECKPOINT: "sin `_Locus-css-ref` adjunto en sesión, el token de `:focus-visible` reutiliza `var(--border)` — ya presente en este mismo archivo"). Con el doc ya disponible, el token real y consistente en todo el sistema para `:focus-visible` de headers/triggers colapsables es `outline: 2px solid var(--accent); outline-offset: 2px` — mismo patrón que `.qdisc-status-header`, `.qbacklog-draft-header`, `.sps-status-header` y el resto de headers colapsables de esta sección. `var(--border)` no es un token de foco en ningún otro selector del sistema — es color de borde neutro, no outline de accesibilidad. **Acción sugerida: Rune corrige `locus-incidents.css` (mod:6 → mod:7) antes de que Finn audite TKT-202607-158/159** — gap de token contra Doc Ref, se cierra aquí sin volver a Cael (no es cambio de AC).

**Diferencia con E-13 (`_Locus-ux-ref`) — sin conflicto:** `.qinc-item-header` (header de card individual INC/PRB/CHG, sin chevron — abre el IDP al completo) y `.qinc-section-header` (header de sección "Activos"/"Terminados", con chevron — colapsa/expande el grupo) son elementos distintos en niveles distintos de la jerarquía visual. E-13 no aplica aquí — no se contradice ni se reabre.

### Panel Q-DISC — familia `qdisc-*` (`#sspanel-qdisc`)

Canónico en `locus-backlog.css`. **Primera documentación real de este panel** — `.qdisc-limit-indicator` y `.qdisc-grooming-banner` existían en código antes de esta entrada (mod:51) sin sección propia en este doc, mismo patrón de huérfana-de-documentación ya corregido para Q-INC en mod:48.

**Indicador de límite — `.qdisc-limit-indicator` (span único, `_renderQDiscLimitIndicator()` en `locus-backlog-qdisc.js`):**

| Selector | Rol |
|---|---|
| `.qdisc-limit-indicator` | Base — conteo de DISCs activos vs límite de 15 |
| `.qdisc-limit-indicator.qdisc-limit--warn` | Al llegar a 15/15 (enforcement bloqueado) — mismo token `--amber` que `.staleness--warn` |

**Banner de grooming — `.qdisc-grooming-banner` (`_renderQDiscGroomingBanner()`):**

| Selector | Rol |
|---|---|
| `.qdisc-grooming-banner` | Aviso ámbar cuando hay DISCs con staleness (30 días sin movimiento) — mismo tono que `.qdisc-limit--warn` |
| `.qdisc-grooming-banner:empty` | `display:none` — colapsa a cero DOM visible sin staleness, mismo patrón que `_renderDoneGroup` |

**~~Bloque de estadísticas — `.qdisc-stats-block` / `.qdisc-stat-cell`~~ — RETIRADO (mod:141, `REQ-202607-059`, `PP-S-18`, cierre 2026-07-28):** Reemplazado por `.bl-header-unified`/`.stats-row--compact` — mismo patrón ya vigente en Backlog list e Histórico, extendido a Q-Backlog y Q-DISC en el mismo REQ. `_renderQDiscProportionBar()` (JS) queda comentada, no borrada — reversión posible, no eliminación definitiva. Tabla original conservada abajo como referencia histórica, tachada no borrada (mismo criterio que `.sps-section-label`/`.sps-section-count`, `§Cambios mod:60`) — no usar como fuente de clases activas.

**Original — `.qdisc-stats-block` / `.qdisc-stat-cell` (`_renderQDiscStatsBlock()`, mod:90/91 — TKT `[pendiente-ID]`, `design_intent: qdisc_stats_block_v2`):**

| Selector | Rol |
|---|---|
| `.qdisc-stats-block` | Contenedor grid, 4 celdas — Total / Discovery / Promoted / Descartado. Universo: **todos** los DISC del proyecto (`_isQDisc`), no solo los activos — distinto del universo de `.qdisc-limit-indicator` (`_isQDiscActive`) |
| `.qdisc-stat-cell` | Base neutra — `var(--surface2)`/`var(--border)`. Usada tal cual para Total y Descartado |
| `.qdisc-stat-cell--discovery` | Reusa el tratamiento azul de `.item-type-pill.DISC` (`rgb(56 189 248 / 12%)` + `var(--blue)`) — identidad de color de DISC desde mod:55 (antes púrpura — ver `§Cambios (mod:55)`) |
| `.qdisc-stat-cell--promoted` | Reusa el verde de `.stat-type-chip.tc-TKT` (`rgb(46 204 120 / 12%)` + `var(--green)`) — único estado que representa avance real |
| `.qdisc-stat-label` / `.qdisc-stat-n` | Label (2xs, uppercase, `--text2`) y número (mono, tabular-nums, `--text`) — colores heredan del modificador de celda cuando aplica |

**Nota de decisión — sin rojo para "Descartado":** descartar una DISC es una decisión deliberada, no un error — el rojo se reserva para estados de fallo real (`.qinc-item--sla-vencido`, etc.). `.qdisc-stat-cell` sin modificador (neutro) es intencional, no un placeholder pendiente de color.

**Excepción consciente — `.qdisc-status-header--descartadas` SÍ usa rojo (mod:54):** el bloque vertical de status (abajo) rompe a propósito la nota de decisión de arriba — decisión explícita del founder confirmada en sesión, no una reversión de Rune/Nova ni una inconsistencia sin resolver. Las dos normas conviven en el mismo panel: `.qdisc-stat-cell` (stats globales) permanece neutro para Descartado; `.qdisc-status-header--descartadas` (bloque vertical, ítems reales) es rojo.

**Discovery deja de ser excepción (mod:55):** hasta mod:54, `.qdisc-status-header--discovery` usaba `--blue-text` como override consciente contra el `--purple` semántico de DISC vigente entonces. Tras el swap DISC↔REQ de mod:55 (ver `§Cambios (mod:55)`), `--blue-text` **coincide** con el nuevo semántico de DISC (`--blue`) — deja de ser excepción y pasa a ser la norma, sin CSS que cambiar en ese selector. `.item-type-pill.DISC` y `.qdisc-stat-cell--discovery` ya reflejan `--blue`. **Dos superficies quedan desalineadas, fuera de scope del REQ que hizo el swap:** `.mdiff-queue-badge--qdisc` (línea `§Colas fijas`, ver abajo) y `.bitem-type-DISC` (`locus-backlog-item.css`) siguen en `var(--purple)` — gap registrado como DISC en backlog, no corregido en este DOC-UPDATE.

**Bloques verticales por status — `.qdisc-status-group` / `.qdisc-status-header` / `.qdisc-status-body`** (`locus-backlog.css` mod:93 — REQ QDISC-headers-3-bloques-verticales, TKT1, `design_intent: QDISC-headers-3-bloques-verticales`):

| Selector | Uso |
|---|---|
| `.qdisc-status-group` | Wrapper de cada uno de los 3 bloques — `margin-top` entre bloques, sin fondo propio |
| `.qdisc-status-header` | Barra de header — flex space-between, borde redondeado solo arriba (se cierra con `.qdisc-status-body` abajo) |
| `.qdisc-status-header--discovery` | Fondo `--blue-dim` / borde `--blue-border` / texto `--blue-text` — excepción consciente, ver nota arriba |
| `.qdisc-status-header--promoted` | Fondo `--green-dim` / borde `--green-border` / texto `--green` — sin cambio respecto al patrón ya establecido en `.qdisc-stat-cell--promoted` |
| `.qdisc-status-header--descartadas` | Fondo `--red-dim` / borde `--red-border` / texto `--red-text` — excepción consciente, ver nota arriba |
| `.qdisc-status-title` / `.qdisc-status-count` | Label uppercase + contador mono — heredan color del modificador del header padre |
| `.qdisc-status-body` | Contenedor de cards — `min-height: 8px`, no colapsa a cero alto con 0 ítems (AC estado vacío: header + contador "0" visible sin card placeholder) |

Consumido por `#qdisc-panel-body` (Discovery, mismo nodo/pipeline de `_renderZonePanel` sin cambio), `#qdisc-promoted-body` y `#qdisc-descartadas-body` (nuevos, sin chips — `locus-backlog-qdisc.js`).

**Caption de universo — `.qdisc-stats-caption`:**

| Selector | Rol |
|---|---|
| `.qdisc-stats-caption` | Texto estático "Todo el proyecto — incluye promovidas y descartadas" — aclara que el bloque de stats no filtra, a diferencia de `#qdisc-panel-body` (solo `discovery`). Mismo tratamiento tipográfico que `.stat-detail-label` (`§Popovers de toolbar/stats`) — reuso de patrón, sin variable nueva |

**Chips de área — `.qdisc-area-chips` (contenedor) / `.stat-area-chip` (`showAreaChips`, `_renderZonePanel()` en `locus-backlog-zone-engine.js`):**

| Selector | Rol |
|---|---|
| `.qdisc-area-chips` | Contenedor — mismo patrón de wrap/gap que `.stat-detail-items` |
| `.stat-area-chip` | Chip neutro — a diferencia de `.stat-type-chip`, sin color-coding por valor porque el área es texto libre del proyecto, no un enum fijo |
| `.stat-area-chip.active` | Filtro de área aplicado — `var(--accent)` sólido + `var(--text-on-accent)` (no `var(--bg)` — ver corrección de contraste abajo) |
| `.stat-area-chip--none` | Modificador "Sin área" — mismo tratamiento visual, solo `font-style: italic`, sin color propio |
| `.stat-area-chip--static` | Modificador "+N más" — informativo, sin cursor pointer ni hover/transform (markup `<span>`, no `<button>`) |
| `.sac-n` / `.sac-label` | Número y label dentro del chip — mismo patrón que `.tc-count`/`.tc-label` de `.stat-type-chip` |

**Corrección de contraste aplicada antes de esta entrega:** el primer borrador de `.stat-area-chip.active` usaba `color: var(--bg)` — funciona por coincidencia en dark (`--bg` ~ negro) pero rompe contraste en light (`--bg` ~ blanco sobre `--accent` lime). Corregido a `var(--text-on-accent)` (mismo par ya validado ~8:1 en ambos temas) antes de integrar — detectado por Rune en verificación de CSS Reference, Fase 4.

### Panel Backlog — grupo de drafts `qbacklog-draft-*` (`#qbacklog-panel-body`)

Canónico en `locus-backlog.css`. **Primera documentación de este patrón** (mod:113, REQ-202607-019, TKT-202607-071 Nova / TKT-202607-072 Rune, `locus-backlog-zone-engine.js` mod:10). Cierra un gap detectado en sesión de auditoría: los REQ/TKT con `draft: true` (emitidos por Cael, pendientes de aval Fase 5 de Finn — ver `__BR-Ecosystem §8 Campo draft`) quedan excluidos de vistas activas por diseño, pero no había señal visible de que existían — el empty state de Q-Backlog los ocultaba sin distinguir "sin ítems" de "hay ítems esperando validación".

| Selector | Rol |
|---|---|
| `.qbacklog-draft-group` | Wrapper del grupo — inyectado al final de `_renderZonePanel()` (Q-Backlog únicamente, `opts.showDraftGroup`), debajo del bloque `bl-done-*` ("Terminados"). Ausente del DOM por completo cuando `draftItems.length === 0` — no colapsa a alto cero, se omite (a diferencia de `.qdisc-status-body`, que sí conserva header + contador "0" visible) |
| `.qbacklog-draft-header` | Barra de header clickeable — mismo tratamiento visual que `.qdisc-status-header`, tono neutro (sin variante de color por status, a diferencia de Q-DISC — no es un estado semántico, es una cola de proceso) |
| `.qbacklog-draft-header-meta` | Wrapper flex de chevron + título — layout puro, sin estilo propio |
| `.qbacklog-draft-title` | Label uppercase — texto fijo "Pendientes de validación Finn" |
| `.qbacklog-draft-count` | Contador mono, tabular-nums — mismo tratamiento que `.qdisc-status-count` |
| `.qbacklog-draft-chevron` | Ícono de colapso — rota con `.is-collapsed`, mismo mecanismo que `.qdisc-status-chevron` |
| `.qbacklog-draft-body` | Contenedor de filas — `display:none` bajo `.is-collapsed` |
| `.qbacklog-draft-group.is-collapsed` | Estado colapsado — mismo toggle delegado (click + `Enter`/`Space`) que `.qdisc-status-group`, sobre `body` en vez de por nodo individual |

**Filas internas — reuso sin clase nueva:** las filas de REQ/TKT dentro de `.qbacklog-draft-body` reutilizan el markup y las clases de la jerarquía R→hijos ya existente (`.bitem`/indentación de hijo) — sin badge de prioridad ni de área (fuera de scope declarado en Fase 1: "es una cola de espera de proceso, no un ítem priorizable"), sin hover ni drag-and-drop (tarjetas planas, no accionables — TKT no las hace targets de `dragstart`/`dragover`).

**Accesibilidad:** contraste mínimo 4.5:1 y foco visible (`:focus-visible`) en `.qbacklog-draft-header` — mismo criterio que el resto del panel, verificado antes de entrega (TKT-202607-071, AC 3).

**Diferencia deliberada con `.qdisc-status-group`:** Q-DISC mantiene sus 3 bloques de status siempre visibles con contador "0" (AC de estado vacío explícito, ver `§Panel Q-DISC`) porque son categorías permanentes del ciclo de vida de DISC. El grupo de drafts de Q-Backlog es transitorio — su ausencia total con 0 drafts es la señal correcta (no hay nada pendiente de validación), no un estado vacío que deba mostrarse.

### Drawer lateral — patrón `.pend-overlay`

Canónico en `locus-modals-misc.css` (corregido en esta auditoría — `locus-modals.css` no existe post-split). Reutilizar para futuros drawers de consulta rápida.

| Selector | Rol |
|---|---|
| `.pend-overlay` | Overlay base — `display: none` por defecto, `position: fixed`, `inset: 0` |
| `.pend-overlay.open` | Estado visible — `display: flex`, alinea panel al borde derecho |
| `.pend-panel` | Contenedor — `max-width: 360px`, `height: 100%`, scroll interno |
| `.pend-panel-header` | Cabecera fija |
| `.pend-panel-body` | Cuerpo scrolleable |

Convenciones: visibilidad via `.open`. `z-index: var(--z-panel)` (1100). Overlay: `rgb(0 0 0 / 40%)`.

### Modal de ingesta — familia `.pill-project` / `.ingest-modal-meta` / `.autosave-*` / `.char-counter` (CAEL-15)

Canónico en `locus-modals-base.css`, dentro de `.modal--ingest` (CAEL-06/07/08 — el shell del modal en sí no tiene entrada propia en este doc, gap heredado sin corregir aquí).

| Selector | Rol |
|---|---|
| `.ingest-modal-title-row` | Wrapper flex de layout puro — alinea `.ingest-modal-title` y `.pill-project` en una fila. Sin estilo visual propio |
| `.pill-project` | Pill estático junto al título — `var(--surface3)`/`var(--text3)`, `--radius-pill`, `--text-2xs` 600. Mismo par que `.sps-section-count` (`§Sprint activo — familia sps-*`) — dato pasivo, no acción |
| `.ingest-modal-meta` | Fila bajo el textarea — flex space-between. Plegada al selector compartido con `.ingest-validation-panel` para `margin-left/right: var(--subtab-gutter)` (12px, REQ CAEL-0717-02 — `.paste-ta-wrap`/`.sc-diff-preview`/`.sc-stepper` ya no viven en este selector desde CAEL-02, reciben el inset del padding de `.ingest-modal-columns`); `margin-top: 8px` propio |
| `.autosave-indicator` | Dot + label "Guardado automático" — `--text-2xs`/`var(--text3)`. El label acompaña siempre al dot, nunca solo color transmite el estado |
| `.autosave-dot` | Círculo 6px, `var(--green)` — decorativo, no-texto. Presentacional en este TKT; la lógica real de autosave es de otro módulo |
| `.char-counter` | Contador de caracteres del textarea — `--text-2xs`/`var(--text3)`. Estático en CAEL-15 (placeholder "0 caracteres"), wiring dinámico en CAEL-16 |

**Población dinámica pendiente:** `.pill-project` (texto del proyecto activo) depende de `_openIngestModal(aiId)` — bloqueado por Pausa de Ciclo de `CAEL-14` al momento de esta entrada. `.char-counter` se puebla en CAEL-16 vía evento `input` sobre `#ingest-ta`.

### Modal de ingesta — panel de validación `#ingest-validation-panel` (CAEL-19 + CAEL-23)

Canónico en `locus-modals-base.css`, dentro de `.modal--ingest`. Shell estático en `index.html` — tres sub-vistas mutuamente excluyentes vía `is-hidden`, contenido de texto/lista lo puebla JS (Rune).

| Selector | Rol |
|---|---|
| `.ingest-validation-panel` | Shell — chrome compartido de las tres sub-vistas: `var(--surface2)`/`var(--border2)`, `--radius-lg`, `padding:12px 14px`. Plegado al selector compartido con `.ingest-modal-meta` — `margin-left/right: var(--subtab-gutter)` (12px, REQ CAEL-0717-02). `margin-top:10px` propio, mismo valor que `.sc-diff-preview` |
| `.validation-error` | Sub-vista 1 — un solo `.validation-msg` con `var(--bg-danger-subtle)`/`var(--red-text)` |
| `.validation-warnings` | Sub-vista 2 — `.validation-msg` (mismo tratamiento, `color-mix(amber 10%)`/`var(--amber-text)`) + `.validation-force-btn` (botón "Procesar de todas formas", outline ámbar) |
| `.validation-msg` | Mensaje de error/warning — `--text-base`, `--radius-md`, `padding:8px 10px`. El color de fondo/texto lo define la clase padre (`.validation-error`/`.validation-warnings`), `.validation-msg` en sí es neutro |
| `.validation-force-btn` | Botón de override — outline `color-mix(amber 28%)`, texto `var(--amber-text)`, hover `color-mix(amber 10%)` de fondo |
| `.validation-result` | Sub-vista 3 (CAEL-23) — badges → título → `.validation-divider` → resumen → archivo → lista de ítems, `gap:8px` |
| `.validation-badge` | Pill base compartido por ambas variantes — `--radius-pill`, `--text-sm` 600 |
| `.validation-badge--success` | Variante default — `color-mix(green 10%)`/`var(--green-text)`. Usada en badge "Checkpoint" (fijo) y badge de proyecto cuando coincide con el Worker activo |
| `.validation-badge--warning` | Variante mismatch — mismo badge, `color-mix(amber 10%)`/`var(--amber-text)`. Rune la aplica sobre `#ingest-result-badge-project` vía `classList.replace` cuando el proyecto del checkpoint no coincide con el Worker activo — no requiere wireframe nuevo, es sustitución de token sobre un elemento ya aprobado |
| `.validation-result-title` / `.validation-result-summary` / `.validation-result-file` | Texto jerárquico — `--text-base` 600 / `--text-sm` `var(--text-secondary)` / `--text-xs` `var(--text3)` respectivamente |
| `.validation-divider` | `<hr>` de separación — `border-top:1px solid var(--border2)`, sin margin |
| `.validation-result-items` | Contenedor de filas — `border-top`, `max-height:130px` + `overflow-y:auto` (AC de overflow — más de 5 ítems hace scroll interno, el panel no crece) |
| `.validation-result-item` | Fila individual — JS-generada, no estática (existe solo si hay ítems, `BR-Execution §5`). `display:flex; justify-content:space-between` — dos hijos: `.validation-result-item-left` (badge + texto) y `.validation-result-item-status` |
| `.validation-result-item-left` | Wrapper del badge + texto descriptivo — `display:flex; align-items:center; gap:6px; min-width:0`. Único hijo nuevo de estructura — no es separador de rama Planeada/Reactiva (fuera de scope del TKT), solo agrupa badge+texto para que `justify-content:space-between` de la fila padre siga separando el grupo izquierdo del status a la derecha |
| `.validation-result-item-type` | Badge de tipo — `flex-shrink:0`, `10px`/`600`/`line-height:1.4`, `padding:1px 5px`, `--radius-pill`. Texto = `item.type` verbatim (nunca `.toLowerCase()`/`.toUpperCase()`) — evita el mismatch de casing abierto en `renderQIncStats()`/`locus-backlog-zone-engine.js` (`tc-inc` generado vs selector `.tc-INC`, ver nota de `mod:124` más abajo) |
| `.validation-result-item-type--REQ` | `color-mix(purple 10%)` / `var(--purple-text)` — alineado al swap DISC↔REQ de `mod:55` (`locus-backlog-item.css` mod:51), no al mapeo REQ=azul de `BR-Ecosystem §4` sin swap |
| `.validation-result-item-type--TKT` | `color-mix(green 10%)` / `var(--green-text)` |
| `.validation-result-item-type--DISC` | `color-mix(blue 10%)` / `var(--blue-text)` — mismo criterio del swap que `--REQ` arriba |
| `.validation-result-item-type--INC` | `color-mix(red 10%)` / `var(--red-text)` |
| `.validation-result-item-type--PRB` | `color-mix(amber 10%)` / `var(--amber-text)` |
| `.validation-result-item-type--CHG` | `color-mix(slate 10%)` / `var(--slate-text)` |
| `.validation-result-item-type--unknown` | Fallback — `item.type` ausente o no reconocido contra `_GEN2_TYPES` (`locus-backlog-core.js`, fuente única de tipos válidos ya importada en el módulo). `var(--surface3)`/`var(--text3)`, texto `'—'` |
| `.validation-result-next-step` | Fila próximo paso (CAEL-30/TKT6) — `border-top:1px solid var(--border2)`, `padding-top:8px`, entre archivo y bloqueantes |
| `.validation-result-next-step-label` | Label — `--text-xs`, `var(--text3)`, `text-transform:lowercase` — mismo tratamiento que el resto de labels de esta sub-vista |
| `.validation-result-next-step-text` | Valor — `--text-base`, `var(--text)`, sin variante de tono (texto plano siempre) |
| `.validation-result-blockers` | Fila bloqueantes (CAEL-30/TKT6) — `border-top`, `display:flex; flex-direction:column; gap:6px` — contiene 0..N `.blocker-row` |
| `.validation-result-blockers-label` | Label — mismo tratamiento que `.validation-result-next-step-label` |
| `.blocker-row` | Fila individual de bloqueante — `display:flex; align-items:center; gap:6px; --text-sm` |
| `.blocker-row--ok` | Estado n/a — `var(--green-text)`, ícono `ti-check` (`aria-hidden`). Mismo par que `.validation-badge--success` |
| `.blocker-row--ref` | Estado referencia a ítem — texto neutro `var(--text)` + `.blocker-chip` inline para el código |
| `.blocker-row--warning` | Estado texto libre sin ID — `var(--amber-text)`, ícono `ti-alert-triangle` (`aria-hidden`). Mismo par que `.validation-badge--warning` |
| `.blocker-chip` | Chip inline del código referenciado — `var(--surface3)`/`var(--text3)`, `--radius-xs`, `padding:1px 6px`. Remapeo de `--bg-accent`/`--text-accent` (no existen), mismo par que `.pill-project` (CAEL-15) |

**Mapeo de tokens del wireframe (no existen tal cual, remapeados a los reales):** `--bg-danger`→`var(--bg-danger-subtle)` · `--text-danger`→`var(--red-text)` · `--bg-warning`→`color-mix(in srgb, var(--amber) 10%, transparent)` · `--text-warning`→`var(--amber-text)` (corregido `mod:112` — declaraba `var(--amber)` crudo sin `-text`, desactualizado respecto al código real desde la migración `§Cambios mod:99`) · `--bg-success`→`color-mix(in srgb, var(--green) 10%, transparent)` · `--text-success`→`var(--green-text)` · `--bg-accent`/`--text-accent`→`var(--surface3)`/`var(--text3)` (CAEL-30, mismo remapeo ya usado en `.pill-project`/CAEL-15).

**Población dinámica pendiente (Rune):** contenido de texto de `.validation-msg`, texto de `#ingest-result-badge-project`, variante success/warning del badge de proyecto, título/resumen/archivo del resultado, filas de `.validation-result-items`, texto de `.validation-result-next-step-text`, variante y contenido de cada `.blocker-row` (incluye envolver en `.blocker-chip` solo el código matcheado, no la fila completa) — todo vía JS al recibir el resultado de `saveSession`/validación de paste. Toggle de `is-hidden` entre las tres sub-vistas y el panel completo también es responsabilidad de Rune.

### Quick Capture — estados de guardado/error/vacío `qc-*` (REQ-1 CAEL-01, TKT1/TKT2)

Canónico en `locus-modals-misc.css`, dentro de `.qc-panel` (`#qc-panel-2` para guardando/error, `#qc-panel-1` para el empty state). Documenta solo lo entregado en REQ-1 — el resto de la familia `qc-*` no tiene entrada propia (ver Hallazgo abajo).

| Selector | Rol |
|---|---|
| `.qc-empty` / `.qc-empty-title` / `.qc-empty-hint` | Empty state de Paso 1 cuando `available.length === 0` — reemplaza el contenido de `.qc-worker-list`, mismo patrón textual que `.sps-empty` |
| `#qc-empty-cta` | CTA "Crear Worker" — `.btn-primary` sin clase propia, delegado en `#qc-worker-list` junto con `.qc-worker-item` |
| `#qc-next-btn:disabled` | Scope acotado al ID — deliberadamente no global sobre `.btn-primary`, para no afectar `modal-actions`/`gconfirm-actions`/`proj-modal-footer`. `opacity:0.35`, `cursor:not-allowed`, `pointer-events:none` (patrón D-04) |
| `#qc-next-btn.is-loading` + `.qc-spinner` | Estado "Guardando…" — spinner inline 12px, `animation: qc-spin` (respeta `prefers-reduced-motion`) |
| `.qc-error-banner` / `.qc-error-msg` / `.qc-error-retry-btn` | Banner de error de guardado — `aria-live="polite"` (JS), mismo patrón boxed que `.validation-error` (no el patrón plano de `.hdr-menu-error-msg`). Sin `margin` propio — ver Anti-pattern |
| `.quick-wip-check` | Checkbox "Este worker tiene un WIP" (REQ CAEL-0723-01, TKT1) — sin marcar: pasivo `--surface3`/`--text3` (criterio `.mg-output-check`); marcado: `color-mix(in srgb, var(--purple) 12%/35%, transparent)` + `var(--purple-text)`. Ver `§Cambios (mod:111)` |

**Anti-pattern registrado:** un hijo directo de un contenedor `flex` con `gap` (ej. `.qc-panel { display:flex; flex-direction:column; gap:10px }`) no debe declarar `margin` propio para separación vertical — el `gap` del padre ya la resuelve, y un `margin` adicional la duplica. Si el padre además aplica `padding` horizontal para el inset de sus hijos (ej. `.qc-panel { padding: 16px 18px }`), un `margin` horizontal en el hijo lo duplica también y lo desalinea (deja de quedar flush) respecto a sus hermanos sin ese margin. Caso detectado y corregido: `.qc-error-banner` declaraba `margin: 0 18px 10px` — retirado en `locus-modals-misc.css` mod:3.

**Hallazgo fuera de scope:** el resto de la familia `qc-*` (`.qc-modal`, `.qc-overlay`, `.qc-header`, `.qc-stepper`, `.qc-dot*`, `.qc-panel`, `.qc-panel-label`, `.qc-worker-list`/`-item`/`-item--selected`/`-avatar`/`-name`/`-check`, `.qc-worker-chip*`, `.qc-footer`) existe en el codebase desde antes de este REQ pero nunca tuvo entrada propia en este doc — mismo patrón de gap ya señalado para `.modal--ingest` (`§Modal de ingesta`, CAEL-15). No se documenta aquí — destino: Cael, evaluar en próximo sprint de deuda documental.

### Panel "+ Sprint nuevo" — familia `spnp-*` (mod:125, TKT2/TKT4 `REQ-[pendiente-ID]` — migración Step 0 DIFF → panel Sprint subtab)

Canónico en `locus-sprint.css` (~L1714-1950). Shell estático en `index.html` (`#spnp-trigger-btn` + `#spnp-panel` vacío, `is-hidden`) — contenido lo puebla `_renderSpnpPanel()`/`_spnpRenderGate()` (`locus-sprint.js`). **No es un formulario de creación libre de sprint** — es la ruta de paste + confirmación del `sprint_proposal` que Cael ya emite (`__BR-Ecosystem §8`/`§12`), reubicada dentro del sub-tab Sprints en vez de vivir solo en el Step 0 del DIFF global. `.sps-empty-hint` ("La apertura de sprint se propone desde Cael — no hay creación manual") sigue siendo la descripción correcta del comportamiento — este panel es su vehículo, no una excepción a la regla.

**Flujo — 3 estados mutuamente excluyentes dentro de `#spnp-panel`, sin ítems propios de markup adicionales entre uno y otro (se reemplaza el `innerHTML` completo):**

1. Sin propuesta pendiente (`getPendingSprintProposal()` → `null`) → textarea de paste + botón "Parsear".
2. Propuesta parseada y persistida (`setPendingSprintProposal()`) → fields de solo lectura + "Aprobar apertura" / "Rechazar".
3. Tras aprobar, si hay ítems en Q-Backlog sin sprint (`_spnpQBacklogItems()`, sin filtro de área/scope — decisión del founder) → gate de selección "Mover seleccionados" / "Omitir".

| Selector | Rol |
|---|---|
| `.spnp-trigger-row` | Wrapper del botón trigger — `justify-content: flex-end` |
| `.spnp-trigger-btn` | Botón "+ Sprint nuevo" — outline neutro (`var(--border)`/`var(--text2)`), no `.btn-primary`. `aria-expanded` dinámico, `aria-controls="spnp-panel"` |
| `.spnp-panel` | Contenedor — mismos tokens que `.sps-card` (borde + `--radius-lg`) pero clase propia, no reuso: `.sps-card` es `overflow:hidden`+flex-column con semántica de "card de sprint", este panel no lo es. Recibe foco al abrir (`tabindex="-1"` + `.focus()`, D-02) |
| `.spnp-header` | Fila flex — badge + título |
| `.spnp-badge` | Pill "Propuesta pendiente" — `var(--accent-dim)`/`var(--accent-text)` |
| `.spnp-title` | ID del sprint propuesto |
| `.spnp-fields` / `.spnp-row` / `.spnp-label` / `.spnp-value` | Lista label/valor (Sprint, Versión, Tipo, Scope, Goal, Out of scope condicional) — mismo patrón `space-between` que `.sps-meta-item`. Colapsa a una columna en `≤640px` (breakpoint compartido E-03) |
| `.spnp-actions` | Fila de botones — `.sps-btn`/`.btn-primary` a `flex:1` |
| `.spnp-error` | Mensaje inline de error — `var(--red)`, `--text-xs`. Cubre parseo inválido, JSON malformado, `sprint_proposal` ausente, y fallo de `_tryIngestSprintProposalFromParsed` (ID colisiona, etc.) |
| `.spnp-paste-ta` | Textarea del paste — `monospace`, `resize:vertical` (a diferencia de `.hdr-menu-textarea`, que no permite resize — se pega un CHECKPOINT completo, no texto corto) |
| `.spnp-empty-hint` | Instrucción itálica sobre el textarea — "Pegá acá el CHECKPOINT con `sprint_proposal`…" |

**Gate de Q-Backlog — familia `.spnp-gate-*` (TKT4, `design_intent: spnp-gate-inline-v1`, Opción 1 inline aprobada por el founder sobre Opción 2 modal):**

| Selector | Rol |
|---|---|
| `.spnp-gate` | Contenedor — `border-top` divisor sobre el resto del panel (reemplaza fields+actions tras aprobar) |
| `.spnp-gate-header` | Reusa `.spnp-badge` ("Ítems sin sprint") — sin variante de color nueva |
| `.spnp-gate-desc` | Texto "N ítems en Q-Backlog — ¿mover al sprint recién creado?" |
| `.spnp-gate-list` | Lista scrolleable — `max-height:96px` (~3 filas visibles), mismo patrón que `.spi-list` |
| `.spnp-gate-item` | Fila — checkbox + label, hover `var(--surface3)` |
| `.spnp-gate-cb` | Checkbox 16px — `accent-color: var(--accent)`. Sin precedente reusable en el archivo, único componente con CSS genuinamente nuevo de esta familia |
| `.spnp-gate-item-label` | Código + título del ítem |
| `.spnp-gate-actions` | Reusa `.spnp-actions` — "Mover seleccionados" / "Omitir" |

**Nota — sin filtro de relación:** `_spnpQBacklogItems()` no filtra por área/scope contra el sprint recién creado — todo REQ/TKT sin `sprint` asignado en el proyecto activo entra al gate. Decisión del founder, documentada en comentario de código (código original de una versión previa no recuperable) — no es un gap a corregir sin instrucción explícita.

### Sprint close modal — familia `.sprint-close-*` + `scm-*`

Canónico en `locus-sprint-close.css`. Wizard de 3 pasos con stepper + paso de retro integrado.

Selectores principales: `.sprint-close-overlay`, `.sprint-close-dialog`, `.sprint-close-header`, `.sprint-close-steps`, `.sprint-close-body`, `.sprint-close-footer`, `.scs-step`.

Estado de visibilidad: `.sprint-close-overlay.open`.

Selectores auxiliares `scm-*` (CSS Purity, layout): `.scm-nowrap`, `.scm-flex-shrink-0`, `.scm-item-title-cell`, `.scm-retro-header`, `.scm-retro-badge`, `.scm-release-*`, `.scm-kpi`, `.scm-effort-*`, `.scm-migration-*`.

#### DOC-UPDATEs list — familia `scm-du-*` (T-202606-120)

| Selector | Rol |
|---|---|
| `.scm-du-list` | Contenedor lista — flex column, gap 6px, sin viñetas |
| `.scm-du-row` | Fila grid `1fr auto` — surface2, border, radius-md |
| `.scm-du-row.is-aplicado` | Estado aplicado — c-low-bg/border |
| `.scm-du-row.is-descartado` | Estado descartado — surface, opacity 0.55 |
| `.scm-du-row.is-pending-indicator` | Sin resolución — border c-medium-border |
| `.scm-du-meta` | Metadatos — flex column, gap 2px, min-width 0 |
| `.scm-du-doc` | Nombre del doc — text-sm, 500, ellipsis |
| `.scm-du-seccion` | Sección — text-xs, text2, ellipsis |
| `.scm-du-escalar` | Rol escalar_a — text-2xs, hint |
| `.scm-du-actions` | Botones — flex, gap 6px, flex-shrink 0 |
| `.scm-du-btn` | Botón base — padding 4px 10px, text-xs, surface3 |
| `.scm-du-btn:hover` | Hover — color text, border hint |
| `.scm-du-btn.aplicado.active` | Activo aplicado — c-low-bg/border/text |
| `.scm-du-btn.descartado.active` | Activo descartado — surface/hint |
| `.scm-du-badge` | Badge — oculto por defecto (`display: none`) |
| `.scm-du-row.is-aplicado .scm-du-badge` | Badge visible — c-low-bg/text/border |
| `.scm-du-row.is-descartado .scm-du-badge` | Badge visible — surface/hint/border |
| `.scm-du-empty` | Estado vacío — dashed border, hint, padding 28px 16px |

### Inline confirm — patrón `.item-inline-confirm`

Canónico en `locus-backlog.css`. Confirmación no-bloqueante para cambio de status de ítem.

**Variante A — sin impacto en sprint activo:** micro-flash en el chip de status (`.item-status-confirmed`).
**Variante B — con impacto en sprint activo:** par de botones inline con auto-cancelación a 6s.

| Selector | Rol |
|---|---|
| `.item-status-confirmed` | Micro-flash — animación `statusConfirmFlash` 600ms |
| `.item-inline-confirm` | Contenedor — oculto por defecto |
| `.item-inline-confirm.is-visible` | Estado activo |
| `.item-inline-confirm__accept` | Botón confirmar — colores `--c-low-*` |
| `.item-inline-confirm__cancel` | Botón cancelar — colores neutros |

Convenciones: visibilidad via `.is-visible`. `prefers-reduced-motion`: sin animación en `.item-status-confirmed`, sin `transform` en `.item-inline-confirm`.

### Vista Planificación — familia `bl-plan-*`

Canónico en `locus-sprint-ui.css`. Layout de drag & drop backlog → sprint (dos columnas).

| Selector | Rol |
|---|---|
| `.bl-planning-view` | Contenedor principal — animación `blPlanFadeIn` |
| `.bl-plan-columns` | Grid `1fr 28px 1fr` (col izq · separador · col der) |
| `.bl-plan-col` | Columna base — `border-radius: var(--radius-lg)` |
| `.bl-plan-col--over` | Estado drop-target activo — borde accent |
| `.bl-plan-col--right` | Columna sprint destino — tinted header |
| `.bl-plan-meter` | Medidor de effort en columna derecha |
| `.bl-plan-card` | Card de ítem arrastrable |
| `.bl-plan-card--dragging` | Estado de arrastre activo |
| `.bl-plan-card--child` (mod:122) | TKT con parent visible en la misma lista — indentación + guía vertical vía `::before`, independiente del `border-left` de `--item-type-color` |

`--plan-meter-pct` se setea via `style.setProperty` en JS — excepción CSS Purity permitida.

**Sub-familia `.bl-plan-dest-*` — múltiples sprints destino (T-202605-028, tabla completada mod:119):**

| Selector | Rol |
|---|---|
| `.bl-plan-dest-list` | Lista de sprint-dest cards dentro de `.bl-plan-col-body` |
| `.bl-plan-dest-sprint` | Card individual de sprint destino — zona de drop propia, `data-plan-col="[sprint.id]"` |
| `.bl-plan-dest-sprint--current` | Sprint activo actual — borde/header tono `--accent` |
| `.bl-plan-dest-current-badge` | Badge "en curso" — tono `--accent`/`--accent-text` |
| `.bl-plan-dest-sprint--programado` (mod:119) | Sprint `programado` — mismo tratamiento que `--current`, tono `--blue` |
| `.bl-plan-dest-programado-badge` (mod:119) | Badge "programado" — tono `--blue`/`--blue-text`, reusa semántica de `.sprint-badge-programado` |
| `.bl-plan-dest-empty` | Empty state — sin sprints abiertos |
| `.bl-plan-dest-chevron` | Chevron colapsable de header (T-202606-091), `.is-rotated` cuando colapsado |

### Sprint selector (Vista Planificación) — familia `bl-sprint-trigger-*` / `bl-sprint-option-*` / `bl-sprint-*`

**Reconciliado en mod:53 (REQ CAEL-01, sesión 2026-07-12).** El drift documentado en mod:50/mod:51 está resuelto — Rune corrigió el lado JS (custom properties, atributos ARIA) y Nova extendió el CSS para la funcionalidad agregada post-TKT-D7 (barra/badge por-opción, contador de cerrados, positioning del dropdown, animación de cierre). Decisión de reconciliación: **JS se alineó al contrato semántico ya declarado en CSS** (atributos `aria-expanded`/`aria-selected` en vez de duplicar estado en clases `.is-open`/`.is-selected`, que se conservan además por compatibilidad con lógica JS existente) — no al revés.

Canónico en `locus-sprint.css` (bloque `TKT-D7`, extendido). Consumido por `locus-sprint-planificacion.js`.

| Selector | Estado |
|---|---|
| `.bl-sprint-trigger` (+ `:hover`/`:focus-visible`) | ✅ |
| `.bl-sprint-trigger-bar-wrap` / `.bl-sprint-trigger-bar-fill` | ✅ — JS setea `--sprint-pct` (corregido de `--sbar-w`) |
| `.bl-sprint-trigger-pct` | ✅ |
| `.bl-sprint-trigger-label` | ✅ — label estático "Sprint", elemento propio, no confundir con `-active-name` |
| `.bl-sprint-active-name` (+ `.is-empty`) | ✅ — agregada en mod:53, faltaba desde origen |
| `.bl-sprint-trigger-progress` | ✅ — agregada en mod:53 (gap detectado en sesión de cierre del REQ, no en el diagnóstico inicial) |
| `.bl-sprint-trigger-arrow` (+ rotación en `[aria-expanded="true"]`) | ✅ — JS ahora setea `aria-expanded` en el trigger (antes solo `.is-open`, la rotación nunca disparaba) |
| `#bl-sprint-bar` | ✅ — `position:relative` agregado en mod:53, ancla del dropdown |
| `.bl-sprint-dropdown` (wrapper) | ✅ — `position:absolute` + `z-index:var(--z-dropdown)` + animación de cierre (`@keyframes bl-sprint-drop-out`) agregados en mod:53. JS mantiene fallback de remoción con `setTimeout` como red de seguridad |
| `.bl-sprint-overlay` (+ `.open`) | ✅ — JS ahora agrega `.open` al insertar (antes nunca lo hacía; overlay era invisible/no-clicable) |
| `.bl-sprint-list` | ✅ |
| `.bl-sprint-closed-list` | ✅ — agregada en mod:53 (gap detectado en sesión de cierre del REQ) |
| `.bl-sprint-option` (+ `[aria-selected="true"]`) | ✅ — JS ahora setea el atributo (antes solo clase `.is-selected`, el highlight nunca aparecía) |
| `.bl-sprint-option-mark` | ✅ — depende de `[aria-selected]`, ya resuelto arriba |
| `.bl-sprint-option-name` | ✅ — reemplaza `.bl-sprint-option-label`/`.bl-sprint-option-id` (retirados, huérfanos sin instancia JS — sin retrocompatibilidad, `__BR-Execution §2`) |
| `.bl-sprint-option-meta` / `-bar-wrap` / `-pct` / `-badge` (+ `--active`/`--closed`) | ✅ — agregadas en mod:53 |
| `.bl-sprint-option-bar-fill` | ✅ — vive en `locus-backlog.css` mod:87 (`--sprint-option-bar-w`), ubicación distinta al resto de la familia por herencia del TKT original (CAEL-02) — funcional, sin plan de mover en este REQ |
| `.bl-sprint-retro-btn` (+ `:hover`) | ✅ — vive en `locus-backlog.css` (~L3232), ubicación inconsistente pero funcional, sin cambio en este REQ |
| `.bl-sprint-closed-toggle` (+ `-label`/`-arrow`, `[aria-expanded="true"]`) | ✅ — JS ahora setea `aria-expanded` (antes solo `.is-open`) |
| `.bl-sprint-closed-toggle-count` | ✅ — agregada en mod:53 |
| `.bl-sprint-separator` / `.bl-sprint-empty` | ⚪ Sin instancia JS confirmada — candidatas a huérfanas, requieren grep contra el resto del codebase. No resuelto en este REQ, fuera de scope declarado en TKT3/TKT4 |

**Barrido de cierre (Finn, sesión de cierre del REQ):** cero selectores `bl-sprint-*` consumidos por `locus-sprint-planificacion.js` sin regla CSS — confirmado por grep exhaustivo contra `locus-sprint.css` + `locus-backlog.css`.

**Variables CSS:** `--sprint-pct` (convención única ahora — `--sbar-w` eliminado del codebase), `--sprint-option-bar-w` (`locus-backlog.css` mod:87). Todas excepción CSS Purity permitida.

### Execution Plan sessions — familia `plan-*`

Canónico en `locus-sprint-ui.css` (corregido en esta auditoría — `locus-sprint-plan.css` no existe, renombrado a `locus-contracts.css` y esta familia específica migró a `locus-sprint-ui.css`, confirmado por grep contra el zip real). Visualización de sesiones por scope (sesion/sprint).

| Selector | Rol |
|---|---|
| `.plan-scope-section` | Contenedor por scope |
| `.plan-scope-section--sesion` | Scope sesión activa — borde-left accent |
| `.plan-scope-section--sprint` | Scope sprint — neutro |
| `.plan-sessions-row` | Fila de sesiones — toggle colapso via `.is-hidden` |
| `.plan-zone` / `.plan-zone--done` / `.plan-zone--available` / `.plan-zone--sequential` | Zonas de estado de sesión |
| `.plan-session-*` | Elementos de card de sesión |

Visibilidad de `.plan-sessions-row`: via `.is-hidden` (CSS Purity — no `style.display`).

### Sección Icebox — familia `bl-icebox-*`

Canónico en `locus-backlog.css`. Agrupa ítems sin sprint asignado.

| Selector | Rol |
|---|---|
| `.bl-icebox-group` | Contenedor raíz — `margin-bottom: 2rem` |
| `.bl-icebox-header` | Header colapsable — `border-left: 2px solid var(--hint)`, cursor pointer |
| `.bl-icebox-arrow` | Flecha de colapso — `.collapsed` aplica `rotate(-90deg)` |
| `.bl-icebox-count` | Conteo de ítems — monospace, `margin-left: auto` |
| `.bl-icebox-body` | Cuerpo de ítems — `.collapsed` aplica `display: none` |
| `.bl-icebox-item-alert` | `<div>` contenedor de alerta por ítem — precede al `buildBacklogItem()` del ítem afectado. Contiene una `staleness-pill.staleness--stale` con el label de días. Solo se renderiza cuando `_iceboxStaleness(item)` retorna valor no nulo. Archivo canónico: `locus-backlog.css` — pendiente de definición CSS. |
| `.bl-icebox-alert-count` | Clase adicional aplicada sobre `.staleness-pill.staleness--stale` en el **header del grupo icebox** — muestra el conteo total de ítems con alerta (`⚠ N`). No es un elemento independiente: es `staleness-pill staleness--stale bl-icebox-alert-count` como clase compuesta. Archivo canónico: `locus-backlog.css` — pendiente de definición CSS. |

**Estructura de renderizado (extraída de `locus-backlog-render.js` T-202606-163):**

```html
<!-- Header del grupo icebox — badge de conteo total -->
<span class="staleness-pill staleness--stale bl-icebox-alert-count">⚠ N</span>

<!-- Por cada ítem en icebox con alerta -->
<div class="bl-icebox-item-alert">
  <span class="staleness-pill staleness--stale">Xd en icebox</span>
</div>
<!-- seguido de buildBacklogItem(item) -->
```

**Umbrales de alerta icebox (calculados por `_iceboxStaleness()` en `locus-backlog-render.js`):**

| Tipo | Umbral |
|---|---|
| R · T | 14 días |
| P | 30 días |
| B `priority: high` | 7 días |
| B priority no-high | Sin alerta |

**CSS pendiente:** `.bl-icebox-item-alert` y `.bl-icebox-alert-count` sin definición CSS actual. Patrón de referencia:
```css
.bl-icebox-item-alert {
  padding: 2px 14px 0;
}

/* bl-icebox-alert-count usa los estilos de staleness--stale — no requiere reglas propias */
```

**Regla semántica:** `.bl-icebox-alert-count` no agrega estilos propios — es un selector adicional para identificar el badge de conteo en el header vs. los badges por ítem (`.bl-icebox-item-alert > .staleness-pill`). Ambos usan `staleness--stale` como fuente de color.

---

### Archivo Histórico — familia `historico-*`

Canónico en `locus-historico.css` (renombrado desde `locus-archive.css` — ver header mod:22 del archivo). Vista Por sprint y Lista plana de sprints cerrados.

| Selector | Rol |
|---|---|
| `.historico-header` | Header colapsable del bloque histórico |
| `.historico-body--collapsed` | Estado colapsado — `display: none` |
| `.historico-tabs` | View tabs (Por sprint / Lista plana) |
| `.historico-tab` / `.historico-tab--active` | Tabs de vista |
| `.historico-sprint-entry` / `.historico-sprint-entry-header` | Acordeón por sprint |
| `.historico-sprint-items--collapsed` | Items de sprint colapsados — `display: none` |
| `.historico-item-row` | Fila compacta de ítem en vista lista |
| `.historico-row-type--req/tkt/inc/disc` | Tipo de ítem con color semántico. Migración `--r/--t/--b/--p` → `--req/--tkt/--inc/--disc` ya aplicada en codebase y en JS — sin pendiente. |
| `.historico-se-effort` | Effort entregado — badge accent |

Read-only treatment: ítems en `#historico-body` tienen `opacity: 0.9` (`:hover` → `0.95`) — subido desde `0.65`/`0.8` (mod:6/mod:7, `locus-historico.css`). Motivo: diferenciación fuerte innecesaria con Histórico en tab propio; valor 0.9 verificado por cálculo de luminancia relativa contra `4.5:1` (peor caso: dark theme, texto `--text2` en filas `is-done`) — no confirmado con DevTools en vivo.

### AI Card rediseño — familia `sc-*` + `card-dot-*`

Canónico en `locus-sesiones-card.css`. Extracción de `locus-sesiones.css`. Aplica a `buildCard()` y `_buildCurrentSessionCard()`.

#### Estructura de la card

| Selector | Rol |
|---|---|
| `.sc-header` | Header principal — flex, `border-bottom: 0.5px solid var(--border)` |
| `.sc-header-left` | Grupo izquierdo — avatar + nombre de proyecto |
| `.sc-header-right` | Grupo derecho — badge + sprint-id + menú |
| `.sc-avatar` | Avatar 28px circular — `background: var(--accent-dim)`. Base para los modificadores de estado — worker-header, ver `#### Worker-header — modificadores de estado` |
| `.sc-avatar--available` | Modificador estado disponible — `box-shadow: 0 0 0 2px var(--green)`, `color: var(--green)`. Anillo pulsante `::after`. CAEL-01 (worker-header). **Dentro de `#worker-header` el `box-shadow` se anula (TKT-202607-132) — ver nota abajo** |
| `.sc-avatar--insession` | Modificador estado en sesión — `box-shadow: 0 0 0 2px var(--purple)`, `color: var(--purple)`. Anillo pulsante `::after`. CAEL-01. **Dentro de `#worker-header` el `box-shadow` se anula (TKT-202607-132)** |
| `.sc-avatar--interrupted` | Modificador estado interrumpido — `box-shadow: 0 0 0 2px var(--amber)`, `color: var(--amber)`. Sin pulso. CAEL-01. **Dentro de `#worker-header` el `box-shadow` se anula (TKT-202607-132)** |
| `.sc-avatar--exhausted` | Modificador estado agotado — `box-shadow: 0 0 0 2px var(--red-border)`, `color: var(--red)`. Sin pulso. CAEL-01. **Dentro de `#worker-header` el `box-shadow` se anula (TKT-202607-132)** |
| `.sc-project` | Nombre del proyecto — truncado con ellipsis |
| `.sc-badge` | Badge de estado activo — inline-flex, dot animado. Base para los modificadores de estado |
| `.sc-badge-dot` | Dot dentro del badge — animación `sc-pulse-dot` 2s. Oculto en variantes `--avail` y `--exhausted`. `background: currentColor` (TKT-202607-132 — antes `var(--c-low-text)` fijo, desalineado del color de texto del badge que lo contiene) — un solo selector cubre los 4 modificadores, sin regla por estado |
| `.sc-badge--avail` | Modificador estado disponible — `var(--green-dim/green/green-border)`. Sin dot. B-202606-047, corregido mod:75 (usaba `c-pulido-*`, cian — no coincidía con `.sc-avatar--available`) |
| `.sc-badge--insession` | Modificador estado en sesión — `color: var(--purple)`, `border-color: rgb(124 106 247 / 35%)`, `background: rgb(124 106 247 / 8%)`. CAEL-01 (worker-header) |
| `.sc-badge--interrupted` | Modificador estado interrumpido — cierra gap anticipado en `T-202606-074 AC-8`, nunca resuelto hasta CAEL-01 |
| `.sc-badge--exhausted` | Modificador estado agotado — `var(--red-dim/red/red-border)`. Sin dot. B-202606-047, corregido mod:75 (usaba `c-won-*`, ámbar — no coincidía con `.sc-avatar--exhausted`) |
| `.sc-sprint-id` | ID de sprint — monospace, `var(--text3)` |
| `.sc-menu-btn` | Botón menú 26×26px — `background: transparent` |

#### Worker-header — modificadores de estado

`#worker-header` vive en `locus-sesiones.css` (no en este archivo — extracción no aplica aquí, documentado en este bloque por compartir base `.sc-header`/`.sc-avatar`/`.sc-badge` con la AI Card). CAEL-01.

| Selector | Rol |
|---|---|
| `.worker-header--available` | `border-left: 3px solid var(--green)` + fondo gradiente tenue |
| `.worker-header--insession` | `border-left: 3px solid var(--purple)` + fondo gradiente tenue |
| `.worker-header--interrupted` | `border-left: 3px solid var(--amber)` + fondo gradiente tenue |
| `.worker-header--exhausted` | `border-left: 3px solid var(--red)` + fondo gradiente tenue |

Mutuamente excluyentes por diseño — Rune aplica un único modificador a la vez en `_populateWorkerHeader` (JS), sin lógica de prioridad en CSS. Estado unificado con `.sc-avatar--*` y `.sc-badge--*` del mismo worker — nunca colores distintos entre los tres para el mismo estado.

**Pulso de actividad (mod:27, CAEL-02) — vive en el header, no en el avatar:** `.worker-header--available::before` / `--insession::before` — `box-shadow: inset 0 0 22px -4px var(--green|--purple)`, animación `whHeaderPulse` (`opacity 0↔0.6`, 2.4s ease-in-out infinite). `prefers-reduced-motion: reduce` lo desactiva. El avatar dentro de `#worker-header` no pulsa — `.worker-header .sc-avatar--available::after`/`--insession::after` anulados; el resto del ecosistema (AI Card, tab Por IA) conserva el pulso de avatar sin cambio.

**Tipografía y contraste de controles (mod:27, CAEL-02):** `.worker-header .sc-project` a `var(--text-2xl)`/600 (título principal del tab). `.worker-header .sc-save`/`.sc-menu-btn` con `background: var(--surface2)` + `border-color: var(--border2, var(--border))` — contraste propio en los 4 estados, independiente del gradiente ambiente.

**Avatar sin ring de color dentro del header (TKT-202607-132):** `.worker-header .sc-avatar--available/--insession/--interrupted/--exhausted { box-shadow: none; color: var(--accent-text); }` — el acento de estado ya vive por duplicado en `border-left` del header (tabla de arriba) y en `.sc-badge`/`.sc-badge-dot`; el ring del avatar lo triplicaba. Selector acotado a `#worker-header` — fuera de él (AI Card, tab Por IA) `.sc-avatar--*` conserva su ring sin cambio (ver `#### Estructura de la card` arriba).

**Rayo de sesión rápida — `.worker-header-quick` (TKT-202607-132/133):** botón HTML estático (hermano de `.worker-header-reset-icon` en `.sc-header-right`, `index.html`), `is-hidden` por default. Visible solo en `available`/`insession` — `_populateWorkerHeader()` alterna la clase, sin insertar/remover nodo. `color` heredado del estado activo (`--green-text` en `available`, `--amber-text` en `insession`) — mismo tono que `border-left` del header y `.sc-badge-dot`, sin tono propio. Click resuelto por el delegador global de `data-action="open-quick-capture"` ya existente (`locus-sesiones.js`, `openQuickCapture(aiId)`) — sin `addEventListener` propio, solo `data-ai-id` poblado en JS.

**Countdown de agotado — familia `.worker-header-cd-inline` (TKT-202607-132/133, reemplaza `.worker-header-unlock`):** contenedor HTML estático (hermano de `.worker-header-quick`, dentro de `#worker-header`) — deja de insertarse/removerse del DOM; solo se muestra/oculta con `is-hidden` según `state === 'exhausted'`, mismo mecanismo que el rayo arriba. Motivo del cambio: `.worker-header-unlock` se insertaba como hermano de `#worker-header` (fuera de su fila flex) para poder ocupar una fila completa propia — eso producía altura distinta entre `exhausted` y el resto de los estados. El contenedor inline vive dentro de la misma fila, igualando altura en los 4 estados.

| Selector | Rol |
|---|---|
| `.worker-header-cd-inline` | Contenedor — `display:flex; align-items:baseline; gap:6px`, hijo estático de `#worker-header` |
| `.worker-header-cd-inline-label` | "Disponible en" — `var(--text-xs)`, `var(--text3)` |
| `.worker-header-cd-inline-value` | hh:mm:ss — JetBrains Mono 700, `var(--text-sm)` (antes `--text-xl)` en `.worker-header-unlock-value` — reducido a escala de fila compacta, ya no de bloque dramático), `var(--red)` |

`.worker-header-cd-inline-value` recibe `id="cd-${ai.id}"` como nodo hoja sin hijos — misma convención que el bloque superado, consumida por el interval de reset global (`locus-sesiones-utils.js`, `document.getElementById('cd-'+id).textContent = cd`).

**`.worker-header-unlock` — superada, no retirada (TKT-202607-132/133):** `_populateWorkerHeader()` dejó de insertarla — la regla CSS se conserva en `locus-sesiones.css` sin consumidor JS activo, deuda intencional (retirarla es un TKT de limpieza aparte, fuera de scope de este REQ). No usar como referencia para trabajo nuevo — ver `.worker-header-cd-inline` arriba.

#### Stats grid

| Selector | Rol |
|---|---|
| `.sc-stats` | Grid 3 columnas — `border-bottom: 0.5px solid var(--border)` |
| `.sc-stat` | Celda stat — `padding: 0.75rem 1.125rem` |
| `.sc-stat-val` | Valor numérico — `var(--text-display-sm)`, `font-weight: 500` |
| `.sc-stat-lbl` | Label stat — `var(--text-2xs-plus)`, uppercase, hint |

#### Stepper de 3 estados

| Selector | Rol |
|---|---|
| `.sc-stepper` | Contenedor flex row |
| `.sc-step` | Paso — `flex: 1`, borde compartido |
| `.sc-step.active` | Estado activo — `box-shadow: inset 0 -2px 0 var(--accent)` |
| `.sc-step.done` | Estado completado — colores `--c-low-*` |
| `.sc-step-num` | Número circular 15px |

#### Footer y elementos auxiliares

| Selector | Rol |
|---|---|
| `.sc-footer` | Footer — flex, `background: var(--surface2)` |
| ~~`.sc-unlock` / `.sc-unlock-label` / `.sc-unlock-icon`~~ | **deprecated** — ver sección Deprecated |
| ~~`.hora-input`~~ (instancia card footer) | **deprecated** — ver sección Deprecated |
| `.sc-save` | Botón guardar — deshabilitado por defecto, `.ready` activa acento |
| `.sc-preview-block` | Preview CHECKPOINT — monospace, `max-height: 160px`, scroll |
| `.sc-success-state` | Feedback éxito — `background: var(--c-low-bg)` |
| `.sc-notes-toggle` | Toggle notas — ancho completo, `.open` rota el ícono |

#### Dropdown menú de card

| Selector | Rol |
|---|---|
| `.card-dot-menu` | Contenedor relativo |
| `.card-dot-dropdown` | Dropdown — `position: fixed`, `z-index: var(--z-toast)`, `display: none` por defecto |
| `.card-dot-dropdown.open` | Estado visible — `display: flex` |
| `.card-dot-item` | Ítem de menú — hover `var(--surface3)` |
| `.card-dot-item.danger` | Ítem destructivo — `var(--red)` |
| `.card-dot-divider` | Separador horizontal |
| `.danger-zone` | Zona destructiva — `display: flex; flex-direction: column` |

**Nota de extracción:** `locus-sesiones-card.css` extrae únicamente selectores `sc-*` y `card-dot-*` de `locus-sesiones.css`. Los demás selectores de Tracker siguen en `locus-sesiones.css`.

**Nota de auditoría (mod:40):** existía un segundo bloque `.card-dot-menu`/`.card-dot-btn`/`.card-dot-dropdown`/`.card-dot-item`/`.card-dot-divider`/`.card-dot-dropdown .danger-zone` en `locus-backlog.css` — muerto, superseded por este mismo componente desde B-202605-020 (portal `position: fixed`). Cero consumidor en `index.html` ni en otro `.css`, confirmado con grep completo antes de eliminar. `.dot-confirm-row` (mismo bloque original) tenía consumidor activo — se conservó en `locus-backlog.css`.

**Decisión registrada (mod:41):** `.danger-zone` no lleva fondo crítico persistente (`--c-critical-bg`) — solo `color`/hover-tint en `.card-dot-item.danger`, igual que `.sps-dropdown-item--danger` y `.blf-*`/`.blt-*`. La versión vieja eliminada en `locus-backlog.css` sí tenía ese fondo persistente; founder confirmó mantener consistencia con el tratamiento liviano ya establecido en el resto de dropdowns del sistema en vez de restaurarlo solo aquí. No reabrir sin evidencia nueva.

### HTML-MAP viewer — familia `htmlmap-*` + `mm-*` + `hmfilter-*`

Canónico en `locus-docs.css`. Extracción de `locus-backlog.css` (T-202605-112).

#### Tabla clásica (vista legacy)

| Selector | Rol |
|---|---|
| `.htmlmap-meta-banner` | Banner de metadatos — oculto por defecto, `.visible` lo activa |
| `.htmlmap-filter-bar` | Barra de filtros por tipo |
| `.htmlmap-filter-btn` | Botón filtro — `.active` usa `var(--accent)`. Mecanismo unificado (REQ-202608-098): `border-radius: var(--radius-xs)`, padding `3px 8px` normal y activo, `border-width: 1.5px` en `.active` — mismo mecanismo que `.filter-btn`/`.filter-type-btn`/`.filter-status-btn`/`.bl-strip-btn` |
| `.htmlmap-table` | Tabla de archivos — `border-collapse: collapse` |
| `.htmlmap-type-badge` | Badge de tipo — `.htmlmap-type-css/html/js` con colores semánticos |

#### Árbol modular (Module Map)

| Selector | Rol |
|---|---|
| `.mm-toolbar` | Toolbar — flex, pills + search |
| `.hmfilter-pill` | Pill de filtro — border sutil por tipo, `opacity: 0.75` idle. `border-radius: var(--radius-xs)` desde REQ-202608-098 — **única excepción del mecanismo unificado:** NO migra a padding `3px 8px`, retiene su padding propio (`4px 11px` base, `padding-left:8px` en `.active`) por su dependencia del `::before` checkmark y el token `--text-sm` — excepción confirmada por el founder (AC de coherencia de REQ-202608-098 la declara explícitamente). Grosor de borde activo sí es `1.5px` — ya lo era antes de este REQ, sin cambio |
| `.hmfilter-pill.active` | Estado activo — fondo color-mix del tipo, subrayado |
| `.hmfilter-pill--all.active` | "Todos" activo — quita énfasis a pills individuales |
| `.hmfilter-pill.mm-fc-js/css/html` | Variantes por tipo — color de borde semántico |
| `.mm-module` | Módulo individual — `border: 1px solid var(--border)`, overflow hidden |
| `.mm-module-header` | Header clicable — `cursor: pointer` |
| `.mm-module-body` / `.mm-module-body.mm-open` | Cuerpo — `display: none` / `display: block` |
| `.mm-file-badge` | Badge tipo archivo — `.mm-fc-js/css/html` |
| `.mm-arrow` / `.mm-arrow.mm-arrow-open` | Flecha colapsado/expandido — `rotate(90deg)` |
| `.mm-bar-wrap` / `.mm-bar-fill` | Barra de tamaño de módulo — `transition: width 0.4s var(--ease-bounce)` |
| `.mm-fn-row` | Fila de función |
| `.mm-area-group` / `.mm-area-label` | Agrupación por área funcional |

#### Context vivo

| Selector | Rol |
|---|---|
| `.context-placeholder` | Empty state centrado del sub-tab Context |
| `.context-raw-block` | Bloque raw de texto de contexto — monospace, `white-space: pre-wrap` |
| `.context-nav` | Navegador de secciones — flex column |
| `.context-conflict-banner` | Alerta de conflicto — fondo `rgb(232 85 85 / 10%)`, color `var(--red)` |
| `.sstab-modified-dot` | Dot pulsante en sub-tab modificado — animación `pulse-dot` 2s |

**Regla de extracción:** Todo selector de HTML-MAP y Context nuevo va en `locus-docs.css`. No agregar a `locus-backlog.css` ni a ningún otro módulo.

### Teaser de notificación — familia `tvh-notif-*`

Canónico en `locus-sesiones.css`. Slot único dentro de `#tracker-view-header` — reemplaza al Setup Checklist Banner eliminado. Muestra la notificación no leída de mayor severidad, con link para expandir el Radar Sidebar (`.rsb-*`, `locus-radar.css`).

| Selector | Rol |
|---|---|
| `.tvh-notif-teaser` | Contenedor raíz — shell HTML estático, siempre presente en el DOM |
| `.tvh-notif-icon` | Ícono de tipo — emoji Unicode vía `textContent`, reusa el campo `icon` de `_computeNotifications()` |
| `.tvh-notif-title` | Título de la notificación — truncado a una línea |
| `.tvh-notif-body` | Body truncado a una línea — oculto en viewport `<480px` |
| `.tvh-notif-viewall` | Botón "Ver todas (N)" — invoca `toggleRadarSidebar()` solo si el sidebar está colapsado |

**Estado vacío:** `.tvh-notif-teaser.is-hidden` — mismo comportamiento de colapso a 0 altura que tenía el SCB, clase canónica `.is-hidden` sin excepción (a diferencia de `.tmpl-trigger-body`, ver arriba).

**Tokens:** `--card-bg-hover` (fondo), `--text` (texto), `--color-primary` (acento del ícono/hover del link) — mismos tokens que `.rsb-notif-item--unseen`/`.rsb-notif-title` en `locus-radar.css`. Sin tokens nuevos — contraste heredado del componente ya validado.

**Regla:** El teaser no reimplementa `_computeNotifications`/`_notifReadSet`/`_notifGoto` — solo los consume. Cualquier estilo nuevo de severidad o ícono va en `locus-radar.css` (fuente del dato), no en `tvh-notif-*`.

### tmpl-trigger-wrap — colapso animado

Canónico en `locus-proyectos.css`. Controla visibilidad del cuerpo del template trigger mediante animación de colapso — **no** `display: none`.

**Nota de anidamiento intencional:** `.tmpl-trigger-body.is-hidden` sobreescribe el comportamiento canónico de `.is-hidden`. No produce `display: none` — produce colapso por `max-height` y `opacity`. Única excepción al comportamiento canónico de `.is-hidden` en el proyecto.

| Selector | Rol |
|---|---|
| `.tmpl-trigger-wrap` | Contenedor raíz |
| `.tmpl-trigger-body` | Cuerpo colapsable — visible por defecto |
| `.tmpl-trigger-body.is-hidden` | Estado colapsado — `max-height: 0`, `opacity: 0` |

### Preview de ítems parseados — familia `preview-tg-*`

Canónico en `locus-backlog-item.css`. Componente `buildTGPreview()` en `locus-session-parse.js`.

**Estructura del componente:**

| Selector | Rol |
|---|---|
| `.preview-tg-header` | Fila superior del preview — flex row, space-between. Contiene label + count |
| `.preview-tg-header-label` | Etiqueta de sección — uppercase, `var(--text3)`, `text-2xs`, `font-weight: 600` |
| `.preview-tg-header-count` | Conteo de ítems en el preview — `var(--text3)`, `text-2xs` |
| `.preview-tg-discrepancy` | Bloque de alerta de discrepancia — fondo `var(--red)` dim, borde `var(--red)` dim, texto `var(--red)`. Se muestra cuando hay conflicto entre estado declarado y estado en backlog |
| `.preview-tg-badges-row` | Fila de badges — flex row, `gap: 5px`, `flex-wrap: wrap`. Contiene los `preview-tg-tag--*` |

**Badges semánticos:**

| Selector | Rol |
|---|---|
| `.preview-tg-tag--warn` | Badge de advertencia — fondo amber dim, texto amber. Uso: ítem nuevo sin AC |
| `.preview-tg-tag--info` | Badge informativo — fondo `var(--blue-dim)`, borde `var(--blue-border)`, texto `var(--blue)`. Uso: ítem nuevo con campo obligatorio ausente (`no_incluye` en T, `intencion` en R, `triggered_by` en B) |

**Regla semántica:** `--warn` = falta que bloquea verificabilidad (sin AC). `--info` = falta que reduce trazabilidad pero no bloquea QA. No intercambiar.

**CSS de `.preview-tg-tag--info`:**
```css
.preview-tg-tag--info {
  background: rgb(from var(--blue) r g b / 0.12);
  border: 1px solid var(--blue-border);
  color: var(--blue);
}
```

**Contraste:** `var(--blue)` pasa 4.5:1 en ambos temas (declarado en tokens §1). ✅

**Estados del componente:** Sin estados adicionales — visibilidad controlada por presencia/ausencia del elemento en el DOM, no por clases CSS.

**⚠️ Gap pendiente:** Los badges `preview-tg-tag--warn` y `preview-tg-tag--info` no se encontraron en `locus-backlog.css` ni en `locus-backlog-item.css` al cerrar T-202606-143. Archivo canónico de los badges pendiente de confirmación. **Auditoría v0.5.0 (2026-06-21):** indicios de resolución parcial detectados contra los 17 CSS reales — no reconciliado en esta versión, requiere re-adjuntar los archivos reales para confirmar archivo canónico exacto antes de cerrar el gap.

---

### Staleness pill — `.staleness-pill` + modificadores `staleness--*`

Canónico en `locus-backlog-item.css`. Implementado en `locus-backlog-item.js` (`buildBacklogItem()`) y reutilizado en `locus-backlog-render.js` para ítems icebox. Pill inline que indica antigüedad del último cambio de status — calculado por `_staleness()` y `_iceboxStaleness()`.

**✅ Implementado en `locus-backlog-item.css` (sección T-202606-211).** Nota histórica: esta sección declaraba el CSS como "pendiente de definir" — desactualizado, corregido en mod:45. Patrón vigente:

```css
.staleness-pill {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-size: var(--text-2xs);
  font-weight: 600;
  border-radius: var(--radius-pill);
  padding: 1px 6px;
  white-space: nowrap;
  font-family: var(--mono);
  font-variant-numeric: tabular-nums;
  border: 1px solid;
}

.staleness-pill.staleness--fresh {
  color: var(--green);
  background: color-mix(in srgb, var(--green) 10%, transparent);
  border-color: color-mix(in srgb, var(--green) 28%, transparent);
}

.staleness-pill.staleness--warn {
  color: var(--amber);
  background: color-mix(in srgb, var(--amber) 10%, transparent);
  border-color: color-mix(in srgb, var(--amber) 28%, transparent);
}

.staleness-pill.staleness--stale {
  color: var(--red);
  background: color-mix(in srgb, var(--red) 10%, transparent);
  border-color: color-mix(in srgb, var(--red) 28%, transparent);
}

.staleness-pill.staleness--orphaned {
  color: var(--amber);
  background: color-mix(in srgb, var(--amber) 10%, transparent);
  border-color: color-mix(in srgb, var(--amber) 28%, transparent);
}

.staleness-pill.staleness--itil-incompleto {
  color: var(--amber);
  background: color-mix(in srgb, var(--amber) 10%, transparent);
  border-color: color-mix(in srgb, var(--amber) 28%, transparent);
}
```

**Modificadores y umbrales (calculados por `_staleness()` en `locus-backlog-item.js`, salvo los dos últimos):**

| Modificador | Condición | Color semántico |
|---|---|---|
| `staleness--fresh` | ≤ 3 días desde último cambio de status | `--green` |
| `staleness--warn` | 4–7 días | `--amber` |
| `staleness--stale` | > 7 días | `--red` |
| `staleness--orphaned` | REQ sin TKT hijo válido (`item.orphaned`) — B-202606-015 | `--amber` |
| `staleness--itil-incompleto` | INC/PRB/CHG con campo ITIL obligatorio ausente (`item.itil_incomplete`) — TKT-202607-063. Corregido mod:124 — listaba KE, retirado (infra_version 51) | `--amber` |

**Regla semántica de color:** `--amber` se reserva para gaps de completitud de especificación (orphaned, itil-incompleto) — no antigüedad. `--red`/`stale` es exclusivo de tiempo transcurrido.

**Contexto de uso:** Renderizado dentro de `.bitem-subline`. Solo aplica a ítems con `status: pendiente`, con sprint asignado (no icebox), sin sesión reciente vinculada. No aplica a ítems `done` ni `descartado`. En ítems icebox se usa siempre `staleness--stale` (umbral superado por definición al activarse la alerta).

---

### Tokens semánticos de status — familia `c-*-bg / c-*-text / c-*-border`

Variables CSS declaradas en `locus-base.css`. Usadas por `bl-strip-btn`, `sc-badge` y cualquier componente que coloree por estado de ítem o estado de sprint.

| Familia | Status asociado | Color de referencia |
|---|---|---|
| `--c-done-bg` · `--c-done-text` · `--c-done-border` | `done` / hecho | Verde — `--green` dim |
| `--c-high-bg` · `--c-high-text` · `--c-high-border` | `en-revision` / en revisión — naming heredado de severidad, reutilizado para status (ver nota abajo) | Naranja — `#e8742e` dark / `#b05020` light |
| `--c-pulido-bg` · `--c-pulido-text` · `--c-pulido-border` | `en-curso` / disponible | Cian-verde — derivado de `--accent` dim |
| `--c-won-bg` · `--c-won-text` · `--c-won-border` | `descartado` / agotado | Ámbar apagado — derivado de `--amber` dim |

**Regla de uso:** No usar valores hardcoded cuando existe token `c-*`. Cualquier componente nuevo que coloree por estado de ítem o worker consume esta familia — no redefine colores propios.

**Anti-pattern de naming — no confundir con `--c-severity-high-*`:** `--c-high-*` es status (`en-revision`), no severidad — el nombre es heredado y engañoso. La familia de severidad (`high`/`medium`/`low` de items y INC) usa el token separado `--c-severity-high-*` declarado en `_Locus-ux-ref §A-04`. Ambos comparten color naranja por coincidencia, no por relación semántica — no asumir que son el mismo token.

**⚠️ Token `--c-medium-*` no existe** — ver nota en §Tokens de sprint (L.474). Estado pausado usa `--surface2` / `--hint`.

---

### Filter strip de status — familia `bl-strip-btn` + `s-*`

Canónico en `locus-backlog.css`. Barra de filtros de status del tab Backlog (`#filter-bar-status`).

| Selector | Rol |
|---|---|
| `.bl-strip-btn` | Botón base del filter strip — inactivo por defecto |
| `.bl-strip-btn.active` | Estado activo — accent dim con border |
| `.bl-strip-btn.active.s-done` | Activo — variables `c-done-*` |
| `.bl-strip-btn.active.s-en-revision` | Activo — variables `c-high-*` |
| `.bl-strip-btn.active.s-en-curso` | Activo — variables `c-pulido-*` |
| `.bl-strip-btn.active.s-descartado` | Activo — variables `c-won-*` |
| `.bl-strip-btn.active.s-bloqueado` | Activo — familia `--red` (`border-color:var(--red-border)`, `background:var(--red-dim)`, `color:var(--red-text)`) — corregida en TKT-202608-248 (REQ-202608-098); entrada anterior decía "variables amber", incorrecto desde antes de este TKT |

**Regla de naming:** Todo botón del filter strip de status usa `bl-strip-btn` como clase base + modificador `s-[status]` para el color de estado activo. El id sigue el patrón `fstatus-[status]`.

**⚠️ No confundir con `bl-fs-btn`:** La familia `bl-fs-btn` + `fs-*` existe en CSS pero no tiene instancias activas en `index.html` — es legacy. Para nuevos botones de filtro de status: usar siempre `bl-strip-btn`.

**Mecanismo visual unificado (REQ-202608-098):** `.bl-strip-btn` comparte con `.filter-btn`/`.filter-type-btn`/`.filter-status-btn`/`.htmlmap-filter-btn` el mismo mecanismo de pill de filtro — `border-radius: var(--radius-xs)`, padding `3px 8px` en normal y activo, `border-width: 1.5px` en `.active` (mismo token de color por variante, solo cambia el grosor). Ver `§HTML-MAP viewer` para el detalle de `.htmlmap-filter-btn`/`.hmfilter-pill` — este último es la única excepción del grupo, no unifica padding.

---

### Chips de filtros activos — familia `afc-*`

Canónico en `locus-backlog.css`. Fila de chips debajo de la toolbar que muestra los filtros activos al usuario sin requerir abrir el panel de filtros. Introducido en T-202606-058 (R-202606-006).

| Selector | Rol |
|---|---|
| `#active-filter-chips` | Contenedor de la fila — `display: none` por defecto, visible solo cuando hay filtros activos |
| `.afc-chip` | Chip individual — pill con label del filtro activo + botón de cierre `×` |
| `.afc-chip:hover` | Hover — brightness sutil sobre el fondo del chip |
| `.afc-chip .afc-close` | Botón `×` dentro del chip — elimina ese filtro al hacer click |

**Comportamiento:** El contenedor `#active-filter-chips` es visible solo cuando `activeTypes` o `activeStatuses` tienen al menos un valor seleccionado. Sin filtros activos el contenedor no ocupa espacio en el layout (`display: none`).

**Badge de conteo:** reemplazado por `.blf-badge` sobre el trigger `#fbar-filter-btn` — ver `### Popovers de toolbar/stats — familia .blf-* / .blt-* (TKT1/TKT2)` en `§Patrones de componentes flotantes`. `#bl-filter-badge` (T-202606-057) no tiene instancia activa en el codebase desde el REQ de consolidación de toolbar anterior — entrada obsoleta, corregida en mod:35.

---

### Sección Cerradas — DISC terminales (promoted + descartado)

Canónico en `locus-backlog.css`. Agrupa Ps en status terminal bajo un único `.section-group.sg-cerradas`. Reemplaza el grupo `.sg-discarded` que solo aceptaba descartadas.

| Selector | Rol |
|---|---|
| `.section-group.sg-cerradas` | Contenedor de la sección Cerradas — scope de todos los overrides siguientes |
| `.section-group.sg-cerradas .section-group-header` | Header con `opacity: 0.72` — levemente más visible que `.sg-discarded` (0.70) |
| `.section-group.sg-cerradas .bitem--idea.bitem--promoted .idea-promoted-chip` | Badge verde positivo — `--green` con `color-mix` al 10%/28% para bg/border |
| `.section-group.sg-cerradas .bitem--idea.bitem--promoted .idea-promoted-chip:hover` | Hover del chip verde — brightness(1.08) |
| `.section-group.sg-cerradas .bitem--idea.bitem--promoted .bitem-title` | Sin `text-decoration: line-through` — promovida no es cancelada |
| `.section-group.sg-cerradas .bitem--idea.bitem--promoted .item-quick-actions` | `pointer-events: none; visibility: hidden` — row terminal, sin acciones |

**Tokens consumidos:** `--green` · `color-mix(in srgb, var(--green) 10%/18%/28%, transparent)`

**Comportamiento por status dentro de Cerradas:**

| Status | Clase en row | Chip / badge | Título |
|---|---|---|---|
| `promovida` | `bitem--promoted` | Verde — `--green` — texto `↗` + código de ítem si `promovida_a` existe | Normal, sin line-through |
| `descartado` | `bitem--discarded` / `is-discarded` | `.idea-discard-reason` — muted, italic | Line-through en `--hint` (estilos existentes sin cambio) |

**Nota JS para Rune:** El header de la sección debe renderizar el label "Cerradas" y aplicar clase `.sg-cerradas` al `.section-group` contenedor. El label anterior "Descartadas" y la clase `.sg-discarded` pueden coexistir si hay otra sección que solo muestre descartados en otra vista — evaluar en sesión de Rune.

---

### `mdiff-queue-badge` — badge de cola fija en modal DIFF

Reemplaza `.mdiff-sprint-select` cuando el ítem no acepta sprint/Q-Backlog — ítems de cola fija ITIL (INC/PRB/CHG → Q-INC) y DISC (→ Q-DISC). No interactivo. Corregido mod:124 — listaba KE como cuarto tipo ITIL, retirado (fusión a `PRB.root_cause_confirmed`, infra_version 51).

| Selector | Uso | Color |
|---|---|---|
| `.mdiff-queue-badge` | Clase base — estructura compartida (altura, padding, tipografía, radius) | Neutro — `var(--hint)` / `var(--surface2)` |
| `.mdiff-queue-badge--qinc` | Modificador para INC/PRB/CHG (corregido mod:124 — listaba KE, retirado/infra_version 51) | Sin color propio — hereda el neutro de la clase base. No confundir con `qinc-type-badge` (`§Tabla de prefijos`), que sí tiene color rojo propio en otro contexto |
| `.mdiff-queue-badge--qdisc` | Modificador para DISC (TKT-202607-001) | `var(--blue)` — mismo token que `.item-type-pill.DISC`/`.bitem-type-DISC`, alineado desde `locus-backlog-item.css` mod:51 (TKT1 CAEL-11, swap DISC↔REQ). Fondo `color-mix(in srgb, var(--blue) 15%, transparent)`, borde `color-mix(in srgb, var(--blue) 30%, transparent)`. Doc alcanzó al código en mod:57 — ver `§Cambios (mod:57)` |

**Selección de tipo — lógica en JS:** `_sprintSelect(code, sprintOverride, itemType)` en `locus-backlog-merge.js` decide la rama vía `_QINC_TYPES` / `_QDISC_TYPES` (arrays de tipo). Cualquier tipo nuevo que se agregue a una cola fija futura debe declarar su propio array y su propia rama — no reutilizar `_QINC_TYPES` para tipos no-ITIL.

**Anti-pattern:** No asumir que declarar una clase modificadora en JS (`mdiff-queue-badge--X`) implica que el CSS ya existe — `--qinc` estuvo sin color propio desde su introducción original hasta esta auditoría, sin que nadie lo notara porque el badge seguía siendo visualmente aceptable en su tono neutro.

---

### Diff action chips — familia `diff-chip-*` (`locus-base.css`)

Canónico en `locus-base.css` — único archivo cargado antes que sus dos consumidores (`locus-sesiones-card.css` pos.11, `locus-backlog-item.css` pos.4). Resume el diff de un CHECKPOINT por tipo de acción (creado/avance/actualizado/retroceso/descarte) — mismo componente en ambas superficies, ver `§Cambios (mod:58)`.

| Selector | Tono | Color texto | Fondo / borde |
|---|---|---|---|
| `.diff-chip` | Base — estructura compartida (padding, radius, tipografía) | `var(--text)` por defecto | Ninguno hasta aplicar modificador |
| `.diff-chip--creado` | Positivo — ítem nuevo | `var(--c-done-text)` | `color-mix(in srgb, var(--green) 10%, transparent)` / `color-mix(in srgb, var(--green) 28%, transparent)` |
| `.diff-chip--avance` | Informativo — status avanzó | `var(--blue-text)` | `color-mix(in srgb, var(--blue) 10%, transparent)` / `color-mix(in srgb, var(--blue) 28%, transparent)` |
| `.diff-chip--actualizado` | Neutro — patch de campo sin cambio de status | `var(--text2)` | `var(--surface2)` / `var(--border)` |
| `.diff-chip--retroceso` | Atención — status retrocedió | `var(--c-high-text)` | `var(--c-high-bg)` / `var(--c-high-border)` |
| `.diff-chip--descarte` | Retirado del alcance — excepción consciente, ver `§Cambios (mod:58)` | `var(--red-text)` | `color-mix(in srgb, var(--red) 10%, transparent)` / `color-mix(in srgb, var(--red) 28%, transparent)` |

**Consumidores concretos:**

| Selector | Archivo | Rol |
|---|---|---|
| `.sc-diff-preview` | `locus-sesiones-card.css` | Contenedor nuevo dentro de `.sc-preview-block` — muestra los `.diff-chip*` antes de habilitar 'Revisar cambios'. `aria-live="polite"` obligatorio (`_Locus-ux-ref §G-02` — todo contenedor que inyecta contenido dinámico) |
| `#merge-diff-header .mdiff-header-chips` | `locus-backlog-item.css` | Nuevo — hereda visualmente el mismo chip visto en el card, dentro del header del modal DIFF |
| `#mdiff-summary-chips` | `locus-backlog-item.css` | Ya existente (ui-Inventory fila 48) — migra sus hijos a `.diff-chip.diff-chip--*`, ver gap registrado arriba |

**Regla de uso:** Ningún consumidor declara color propio para estos chips — siempre vía modificador `.diff-chip--*`. Un componente nuevo que necesite un sexto tono de acción no inventa hex — propone modificador nuevo a Nova reusando la familia `--c-*`/`--*-text` existente.

---

### Divisor de zona — `.historico-zone-divider` (`locus-historico.css`)

**Corregido en esta auditoría — selector y archivo ambos desactualizados, no solo el archivo:** esta entrada documentaba `.arch-zone-divider`/`locus-archive.css`. Confirmado contra el zip real (`locus-historico.css:463-470`): el rename `arch-*` → `historico-*` (mod:22 del archivo) alcanzó también a este selector — `.arch-zone-divider` no existe en el codebase, la clase real es `.historico-zone-divider`. Mismo patrón de drift ya corregido para `.arch-row-type--*` (ver `§Selectores Gen 1`, abajo).

Separador visual entre zonas de sprint cerrado consecutivas en el panel Histórico de pantalla completa. Se inserta en el DOM por `renderArchivoHistorico()` (`locus-backlog-archive.js`) — no interactivo, sin texto.

| Selector | Rol |
|---|---|
| `.historico-zone-divider` | Línea de 1px entre dos zonas de sprint consecutivas — `height: 1px; background: var(--border); margin: 12px 0` |

**Tokens consumidos:** `--border` — mismo token que `.historico-body` (border-top) y `.historico-item-row` (border-bottom) en el mismo archivo, sin token nuevo.

**Accesibilidad:** Sin texto ni ícono — el mínimo de contraste 4.5:1 no aplica (regla es para elementos con contenido textual).

**Gap cerrado:** La clase se insertaba en el DOM desde antes de este sprint sin definición CSS — divisor invisible. Detectado en auditoría de Finn, cerrado en TKT3 del REQ Fixes subtab Backlog Histórico.

---

### Document Generator — checkbox de Incidentes (REQ CAEL-0720-01) · Shell persistente Q-INC — toolbar + stats-bar (REQ CAEL-0720-05)

Ver `§Cambios (mod:96)` para el porqué de la decisión activo/pasivo y el token `--accent-text` del checkbox.

| Selector | Archivo | Rol |
|---|---|---|
| `.mg-output-check--incidents` | `locus-document-generator.css` | Modificador de `.mg-output-check` — checkbox `#mg-out-incidents` (TKT2 AC6, REQ CAEL-0720-01). Tratamiento pasivo: `background: var(--surface3)`, `color: var(--text3)` — toggle entre iguales, no una acción. Aplicado en el `<label class="mg-output-check mg-output-check--incidents">` |

**`.qinc-export-btn` / `.qinc-export-btn-label` — retirados (TKT1, REQ CAEL-0720-05):** El botón dinámico de exportación embebido en `qinc-stats-bar` (`data-qi-action="qi-export-incidents"`) fue reemplazado por `#btn-export-qinc` — botón estático dentro de `#qinc-toolbar` (`.tpl-sidebar-actions` + `.tpl-action-btn`, ver entrada `tpl-` en tabla de prefijos), disparado vía evento `shell:export-qinc` (mismo patrón que `shell:export-backlog`). Mismo generador/lógica de descarga que antes vivía embebida en `_attachQIncDelegation` — sin cambio funcional, solo de shell. `qinc-stats-bar` ahora es exclusivamente chips (`.stat-type-chip`/`.stat-pri-chip`), sin botón propio ni AC5 asociado.

**Accesibilidad — foco visible en el shell persistente Q-INC (TKT2/TKT3, REQ CAEL-0720-05):** `:focus-visible` agregado en `.tpl-action-btn` (`locus-proyectos.css`), `.stat-type-chip` y `.stat-pri-chip` (`locus-backlog.css`) — `outline: 2px solid var(--accent); outline-offset: 2px;`, mismo patrón que `.bl-toolbar-new-item-btn`/`.blf-trigger`. Cierra el gap que dejó el retiro de `.qinc-export-btn` (que tenía foco propio) sin que el reemplazo lo heredara automáticamente. Sin tokens nuevos — reuso de `--accent`.

---

## CSS Purity — Locus

Regla completa en `__BR-Execution §3`. Excepciones específicas de Locus:

```js
// ✓ Permitido — CSS custom properties con valor calculado en runtime
element.style.setProperty('--sprint-progress', '42%');
element.style.setProperty('--hsr-pct', pct + '%');
element.style.setProperty('--plan-meter-pct', pct + '%');
element.style.setProperty('--sph-bd-width', pct + '%');
```

Todo lo demás (`style.color`, `style.display`, `cssText`) — prohibido.

---

## Selectores compartidos — fuente canónica

Selectores usados en múltiples módulos CSS. La definición base vive en un único archivo. Los demás solo pueden agregar **modificadores calificados** — nunca redefinir propiedades base.

| Selector | Fuente canónica | Scope de uso | Estados en fuente canónica |
|---|---|---|---|
| `.card` | `locus-layout.css` | backlog · layout · proyectos · tracker | `.card` base únicamente |
| `.btn-primary` | `locus-layout.css` | backlog · layout | `:hover` `:active` `:focus-visible` |
| `.tab-btn` | `locus-layout.css` | analytics · backlog · layout · modals | `:hover` `.active` `::after` `.active::after` `:focus-visible` |
| `.item` | `locus-backlog.css` | backlog · proyectos | Base únicamente — modificadores en módulo destino |

**Regla:** Si un módulo necesita agregar un estado de estos selectores — el estado va en la fuente canónica, no en el módulo. Si hay ambigüedad, devolver a Nova.

---

## Checklist antes de hacer merge

- [ ] `npm run lint:css` pasa sin errores nuevos
- [ ] No introduce `style=` inline en HTML estático
- [ ] No introduce propiedades de presentación directas en JS
- [ ] No introduce `font-size` hardcodeado — usar tokens de escala
- [ ] No introduce `border-radius` hardcodeado (excepto `0`, `50%` documentados — `1px` y `2px` ahora tienen tokens `--radius-3xs` y `--radius-2xs`)
- [ ] No introduce `z-index` hardcodeado — usar tokens
- [ ] Variables globales nuevas declaradas en `locus-base.css`, no en el módulo
- [ ] Variables de instancia de componente declaradas dentro del selector que las usa
- [ ] Selector nuevo en el módulo correcto — consultar prefijo en tabla de naming
- [ ] Si agrega animación → incluye bloque `prefers-reduced-motion`
- [ ] Si agrega clase de visibilidad → usa `.is-hidden`, no crea nueva
- [ ] Si falta una clase CSS necesaria → devolver a Nova antes de implementar
- [ ] Si usa alias de texto legacy (`--text-muted`, `--text1`) → migrar a canónico
- [ ] Si necesita texto terciario/placeholder/inactivo → usar `--text3` directamente, nunca `--hint`

---

## Selectores Gen 1 — nota de migración para Rune

Los selectores listados abajo usan nomenclatura de letras cortas heredada de Generación 1 del ecosistema. El codebase los tiene implementados tal cual — los Doc Refs los documentan en su estado actual hasta que Rune ejecute la migración.

**Scope de la migración:** renombrar selectores en los archivos CSS correspondientes + actualizar todos los call sites JS que los generan o consumen.

| Selector actual (Gen 1) | Selector objetivo (Gen 2) | Archivo CSS | Notas |
|---|---|---|---|
| ~~`.spl-type--r`~~ | `.spl-type--req` | `locus-sprint.css` | ✅ Migración completada, confirmada contra el zip real en esta auditoría (2026-07-17) — generado por `_renderPlannedSprints()` en `locus-sprint.js` |
| ~~`.spl-type--t`~~ | `.spl-type--tkt` | `locus-sprint.css` | ✅ Migración completada — ídem |
| ~~`.spl-type--b`~~ | `.spl-type--inc` | `locus-sprint.css` | ✅ Migración completada — ídem, en Gen 2 `B` (bug) → `INC` |
| ~~`.arch-row-type--r`~~ | `.historico-row-type--req` | `locus-historico.css` | **✅ Migración completada, confirmada contra el zip real en esta auditoría (2026-07-17)** — no solo el archivo cambió de `locus-archive.css` a `locus-historico.css`, el selector también migró de `arch-row-type--*` a `historico-row-type--*`. Fila conservada para historial de la migración, no representa trabajo pendiente |
| ~~`.arch-row-type--t`~~ | `.historico-row-type--tkt` | `locus-historico.css` | ✅ Migración completada — ídem |
| ~~`.arch-row-type--b`~~ | `.historico-row-type--inc` | `locus-historico.css` | ✅ Migración completada — ídem |
| ~~`.arch-row-type--p`~~ | `.historico-row-type--disc` | `locus-historico.css` | ✅ Migración completada — en Gen 2 `P` (DISC original) → `DISC` |
| `.item-type-pill.R` | `.item-type-pill.REQ` | `locus-backlog.css` / `locus-backlog-item.css` | Clase de un carácter — verificar todas las instancias en JS antes de migrar |
| `.item-type-pill.T` | `.item-type-pill.TKT` | Ídem | Ídem |
| `.item-type-pill.B` | `.item-type-pill.INC` | Ídem | Ídem |
| `.item-type-pill.P` | `.item-type-pill.DISC` | Ídem | Ídem |
| `.item-type-pill.I` | Confirmar con Cael — sin equivalente Gen 2 declarado | Ídem | Verificar si `I` sigue siendo tipo activo |
| `.ct-pill-r` | `.ct-pill-req` | `locus-analytics.css` | Cycle Time por tipo — generado en `_cycleTimeData()` / render 'Por tipo', `locus-analytics-digest.js` — migrado en TKT-202607-003 |
| `.ct-pill-t` | `.ct-pill-tkt` | `locus-analytics.css` | Ídem |
| `.ct-pill-b` | `.ct-pill-inc` | `locus-analytics.css` | Ídem — en Gen 2 `B` (bug) → `INC` |

**Colores declarados — item-type-pill Gen2:**

| Selector | Token color | Fondo (color-mix 10%) | Borde (color-mix 28%) |
|---|---|---|---|
| `.item-type-pill.REQ` | `--purple` | `color-mix(in srgb, var(--purple) 10%, transparent)` | `color-mix(in srgb, var(--purple) 28%, transparent)` |
| `.item-type-pill.TKT` | `--green` | `color-mix(in srgb, var(--green) 10%, transparent)` | `color-mix(in srgb, var(--green) 28%, transparent)` |
| `.item-type-pill.INC` | `--red` | `color-mix(in srgb, var(--red) 10%, transparent)` | `color-mix(in srgb, var(--red) 28%, transparent)` |
| `.item-type-pill.DISC` | `--blue` | `color-mix(in srgb, var(--blue) 10%, transparent)` | `color-mix(in srgb, var(--blue) 28%, transparent)` |

`.item-type-pill.DISC` absorbe `.P` (promovida) y `.I` (idea) — un único selector, color azul semántico desde mod:55 (antes purple — ver `§Cambios (mod:55)`). `text` usa `var(--blue)` directamente. Token `--blue` declarado en `locus-base.css` — ver §1 Tokens de color utilitarios.

**Colores declarados — `.ct-pill-*` (`locus-analytics.css`, Tab Analytics · Cycle Time por tipo):**

Familia propia — no reusa selectores de `.item-type-pill`. Patrón visual distinto: sin borde, fondo `color-mix` 18% (vs 10%/28% bg/border de `.item-type-pill`). Extendida a los 7 tipos Gen2 en TKT-202607-003 — reducida a 6 tipos en TKT-202607-168 (retiro de `.ct-pill-ke`, ver nota abajo).

| Selector | Texto | Fondo (color-mix 18%) |
|---|---|---|
| `.ct-pill-req` | `var(--purple)` | `color-mix(in srgb, var(--purple) 18%, transparent)` |
| `.ct-pill-tkt` | `var(--green)` | `color-mix(in srgb, var(--green) 18%, transparent)` |
| `.ct-pill-disc` | `var(--blue)` | `color-mix(in srgb, var(--blue) 18%, transparent)` |
| `.ct-pill-inc` | `var(--red)` | `color-mix(in srgb, var(--red) 18%, transparent)` |
| `.ct-pill-prb` | `var(--orange-text)` | `color-mix(in srgb, var(--orange) 18%, transparent)` |
| `.ct-pill-chg` | `var(--slate-text)` | `color-mix(in srgb, var(--slate) 18%, transparent)` |

**Retiro de `.ct-pill-ke` (`locus-analytics.css` mod:18, TKT-202607-168):** La pill correspondiente al tipo `KE` (Known Error) se retiró del array `CT_RIGHT` en `locus-analytics-render.js` — `KE` fue fusionado a `PRB.root_cause_confirmed` desde infra_version 51 y ya no es un tipo alcanzable en ningún generador de UI. La regla `.ct-pill-ke` quedó huérfana (ningún selector la consume) y se elimina en el mismo movimiento. El token `--yellow-text` (Cluster B, `locus-base.css` mod:7) no se retira — sigue en uso por otros componentes fuera de esta familia; verificar antes de eliminar el token si en el futuro `--yellow-text` queda sin ningún consumidor.

`.ct-pill-prb/chg` usan los tokens `--orange-text` / `--slate-text` (Cluster B, `locus-base.css` mod:7) — `--orange`/`--slate` crudos caen bajo 4.5:1 como color de texto (dark: `--slate` 3.31–4.02:1 · light: `--orange` 2.93–3.42:1). El fondo sigue usando el token base sin cambio — solo el texto necesitaba corrección de contraste.

`.ct-pill-req/tkt/disc/inc` reusan el token directo, igual que `.item-type-pill` — mismo gap de contraste pre-existente en `--blue`/`--red` sobre light theme (`--surface3`/`--bg2`, ~3.31–4.11:1) que `.item-type-pill.REQ`/`.INC`. Registrado como DISC por Nova — no se corrige en este TKT, fuera de scope.

**Fila DISC — familia `--idea-*` (`locus-backlog.css`, `.bitem--idea`):** `--idea-color` / `--idea-color-dim` / `--idea-bg` / `--idea-bg-hover` / `--idea-border` / `--idea-badge-bg` / `--idea-badge-text` — todos derivados de `var(--blue)` vía `color-mix`, light y `[data-theme="dark"]` (swap a `--blue` en mod:95, TKT1 CAEL-08 — ver `§Cambios (mod:57)`). No declarar hue crudo para esta familia — cualquier cambio de acento de DISC pasa por `--blue`, nunca por un valor HSL independiente.

Desde mod:96, `.bitem--idea` ya **no** es una card boxeada — es una fila flat (concepto inbox, Linear/Things). El acento de tipo (border-left + tint de header) lo resuelve `.item.bitem[data-type="DISC"]` en `locus-backlog-item.css` mod:52, no `.bitem--idea`. `.bitem--idea` solo cubre lo exclusivo de la idea: hover de fila, acciones reveladas en hover/foco (antes siempre visibles), badges no aplicables (effort dots, AC block). Detalle completo → `§Sección Cerradas — DISC terminales` para el estado terminal; ver abajo para el estado activo.

**Type block sin caja — especificidad frente a `.bitem-type-DISC`:** `.item.bitem[data-type="DISC"] .bitem-type-block` (especificidad 0,4,0) resetea `background`/`border` a `none` y cambia el layout a texto inline — gana sobre `.bitem-type-DISC` (0,1,0, definida arriba en `§Colores declarados`) sin importar el orden de origen en el archivo. Si `.bitem-type-DISC` se sigue aplicando vía JS a ese elemento, es inofensivo para la fila del backlog — pero **sí sigue siendo el selector activo en cualquier otra vista que renderice el badge de tipo DISC fuera de `buildBacklogItem()`** (ninguna identificada en esta sesión — Rune confirma antes de asumir que `.bitem-type-DISC` es código muerto).

**Quick actions — comportamiento por defecto cambiado (mod:96):** antes `opacity:1; visibility:visible` siempre. Ahora `opacity:0; pointer-events:none` por defecto, reveladas en `.bitem-header:hover`/`:focus-within` dentro de `.bitem--idea` — mismo patrón hover-reveal que el resto del sistema usa para acciones secundarias. La sección Cerradas sigue forzando `pointer-events:none; visibility:hidden` sin importar hover (fila terminal, ver tabla arriba) — ese override no cambió.

**Criterio de migración:** Las clases de un carácter (`.R .T .B .P .I`) son aplicadas desde JS al construir ítems del backlog. La migración requiere grep completo contra los 50 módulos JS para asegurar que no queda ningún call site sin actualizar. Rune no migra en silencio — emite TKT con AC que incluya verificación de cero instancias Gen 1 tras la migración.

---

### Item Detail Panel — familia `idp-*` (`.item-detail-panel`, `#backlog-list` two-column)

**Canónico:** `locus-backlog-item.css` (mod:81) + `locus-sesiones.css` (base de `.idp-dep-chip`, ver `_Locus-ui-Inventory §12`). Origen distribuido en varias entregas — `R-202604-015` (layout two-column), `R-202604-015 Sesión 2` (título editable + meta grid), `T-202604-307` (quick actions, timeline notes, unlink), `R-202605-004` (`idp-dep-chip--origin`/`idp-pill--origin`), fix directo mod:55 (Auditoría Nova IDP — contraste `--hint`→`--text2`, `:focus-visible`). Documentado en este doc por primera vez en `§Cambios (mod:142)` — antes solo tenía fila en `§Arquitectura de módulos CSS`.

**Estructura por zona:**

| Zona | Selectores clave | Notas |
|---|---|---|
| Wrapper / layout | `.backlog-two-col`, `.item-detail-panel(.open)`, `.idp-inner` | Panel `width:0→340px` con transición, `position:sticky`. `max-height` descuenta header (`B-202605-034`) — `.idp-inner` usa `min-height:0`+`overflow-y:auto`+`height:100%` para que el scroll interno no rompa el contenedor flex (`B-202606-057`) |
| Header + type chip | `.idp-header`, `.idp-type-chip`, `.idp-header-meta`, `.idp-code`, `.idp-type-name`, `.idp-close-btn(:hover)` | Color por tipo vía custom property `--_type-color` — ver tabla abajo |
| Título | `.idp-title(-wrap/:hover/:focus-visible/-input)` | Editable inline — `:focus-visible` agregado en mod:55 (antes sin foco visible, Hallazgo #3 de la auditoría de Nova) |
| Meta pills / grid | `.idp-meta-row`, `.idp-pill`, `.idp-meta-grid`, `.idp-meta-cell(--wide)`, `.idp-meta-label`, `.idp-meta-select(:focus/option)`, `.idp-meta-input(::placeholder/:focus)`, `.idp-meta-value`, `.idp-inherited-badge` | Grid 2 columnas — separación entre celdas vía `background:var(--border)` en el contenedor (efecto grid-line sin `border` por celda). `.idp-meta-value` sin regla de origen propia — reusa tamaño/familia de `.idp-meta-select` para no romper la grilla en campos no editables (Sprint heredado, Status de DISC) — comportamiento intencional, no gap |
| Sections | `.idp-section(-label/-toggle:hover)`, `.idp-toggle-arrow`, `.idp-divider` | Header colapsable — mismo mecanismo genérico documentado a nivel de criterio en `_Locus-ux-ref §E-17` |
| AC | `.idp-section--ac`, `.idp-ac-label`, `.idp-ac-count-badge`, `.idp-ac-list(.open/--open)`, `.idp-ac-item`, `.idp-ac-dot` | `T-202604-415`: AC siempre visible — `.idp-ac-list--open` es el estado vigente; `.idp-ac-list.open` (sin doble guion) queda como par legado del mismo mecanismo, no duplicado activo |
| Notes | `.idp-notes-ta(:focus)`, `.idp-notes-status` | Textarea libre — `border-color:var(--accent)` en foco |
| Sessions | `.idp-sessions-list`, `.idp-session-chip(:hover/:focus-visible)`, `.idp-sess-ai`, `.idp-sess-date`, `.idp-sess-title`, `.idp-sess-unlink` | Botón unlink revelado solo en hover del chip padre (`opacity:0→1`) |
| Timeline | `.idp-timeline`, `.idp-tl-entry`, `.idp-tl-dot(-col)`, `.idp-tl-line`, `.idp-tl-content`, `.idp-tl-main`, `.idp-tl-icon`, `.idp-tl-label`, `.idp-tl-ts`, `.idp-tl-sub`, `.idp-tl-note-(row/input/btn)` | Variantes semánticas `--success/--info/--muted/--hint/--accent/--purple` en dot y label — ver gap de contraste abajo. `.idp-tl-line` se oculta en la última entrada (`:last-child`) |
| Actions bar | `.idp-actions-bar`, `.idp-action-btn(:hover)`, `.idp-action-done(:hover)` | Botón "done" con acento verde — mismo `--green`/`--green-text` que el resto del sistema |
| Origin (`R-202605-004`) | `.idp-dep-chip--origin(:hover/:focus-visible)`, `.idp-pill--origin`, `.idp-origin-row` | Dos variantes: chip navegable (el código referenciado existe en backlog) vs pill texto plano (código no existe) — mismo patrón dual ya generalizado en `.mdiff-dep-pill` y variantes |

**Colores por tipo — custom property `--_type-color` (`.idp-type-chip`, `.idp-ac-dot`):**

| Tipo | Token | Nota |
|---|---|---|
| `INC` | `var(--red)` | |
| `TKT` | `var(--green)` — override `#16914c` en `[data-theme="light"]` | Mismo ajuste de contraste ya usado en `TKT1-diff-visual` |
| `REQ` | `var(--purple)` | |
| `DISC` | `var(--blue)` | |
| `PRB` | `var(--orange)` | |
| `CHG` | `var(--slate)` | |

**Contraste — `.idp-tl-label--success`:** resuelto — `color: var(--green-text)` (`locus-backlog-item.css` mod:84). Ver `§Cambios (mod:144)`. `.idp-tl-dot--success` conserva `var(--green)`/override `#16914c` en light — elemento gráfico, umbral 3:1, sin cambio.

---

## Estándar de Spacing & Layout (Fase 1 — Auditoría · Fase 2 — Estándar propuesto, mod:149)

Locus es desktop-only (`_pp-strategy §6` — 1920×1080 y 2560×1080, sin breakpoints de mobile/tablet salvo `--bp-ipad` declarado y no usado activamente en spacing). El estándar de esta sección no necesita variantes responsive de spacing — solo los dos viewports declarados.

### A. Hallazgos de auditoría — cuantitativos

| # | Hallazgo | Evidencia |
|---|---|---|
| A1 | La escala de spacing declarada está casi sin adoptar | `--spacing-sm:8px` / `--spacing-md:16px` (únicos tokens de spacing puro en `locus-base.css §A3`) — **2 usos reales** en todo el codebase (`locus-modals-misc.css`, `locus-sesiones.css`) contra **2.465 declaraciones** de `padding`/`margin`/`gap` con valor numérico directo |
| A2 | No existe escala completa de spacing — solo dos peldaños (`sm`/`md`), sin `xs`, `lg`, `xl`, `2xl` | Comparar con la escala de radios (`§Espaciado/Radios`, `locus-base.css` L41-51): 11 peldaños documentados y en uso activo. La escala de spacing tiene 2. |
| A3 | Los valores reales usados no siguen ninguna progresión (ni 4px base, ni 8pt grid) | Distribución real (top valores, conteo de ocurrencias): `8px`→403 · `6px`→396 · `4px`→389 · `2px`→268 · `10px`→204 · `3px`→161 · `1px`→154 · `5px`→139 · `12px`→126 · `7px`→57 · `16px`→52 · `14px`→34 · `20px`→20 · `9px`→19. Prácticamente todos los enteros de 1 a 20 están en uso con frecuencia significativa — no hay "peldaños canónicos" que concentren el uso |
| A4 | `--gutter-shell` (24px) y `--subtab-gutter` (12px) sí están adoptados como token — pero de forma incompleta | En uso en 6 de los ~10 shells de tab/subtab (`locus-analytics.css`, `locus-backlog.css`, `locus-incidents.css`, `locus-modals-base.css`, `locus-sesiones.css`, `locus-sprint.css`). `#tab-proyectos` usa `var(--subtab-gutter)` solo en `padding-left` — sin lado derecho declarado con el mismo token (asimetría no documentada, verificar si es intencional u omisión) |
| A5 | Mezcla de unidades `rem`/`px` en el mismo valor de padding de shell — **corregido tras verificar contra código real**: el valor computado NO es 32px | `#tab-backlog`, `#tab-analytics`, `#tab-incidentes`: `padding: 0 var(--gutter-shell) 2rem` (patrón repetido en los 3). `html { font-size: var(--text-base) }` (`locus-base.css` L451) = **13px**, no el default de 16px del navegador — por lo tanto `2rem` computa **26px real**, no 32px. El propio comentario en `locus-backlog.css:353` asume 32px ("`.spt-nav` quedaba 32px separado") — la misma confusión ya vive en el codebase, no es exclusiva de esta auditoría. **No unificar mecánicamente a `--space-2xl` (32px)** — sería una regresión visual de +23%. Ver DISC abierta para decidir tratamiento (nuevo token de 26px vs. mantener `rem` deliberado vs. corregir a 32px real si `.spt-nav` de hecho depende de ese valor). Con `rem` en 33 ocurrencias en `locus-sesiones.css`, 24 en `locus-backlog.css`, 11 en `locus-analytics.css` — el patrón de usar `rem` sobre un root que no es 16px es más amplio que estos 3 casos |
| A6 | ~~`--header-h` tiene fallback inconsistente con su propio valor declarado~~ — **cerrado (TKT-202607-218, `locus-sesiones.css` mod:46)** | Token real: `--header-h: 53px` (`locus-base.css` L125, con comentario que documenta el cálculo exacto). Uso real: `calc(100vh - var(--header-h, 54px))` en las 2 declaraciones de `#tab-sesiones` (L143, L6623) — el fallback (`54px`) no coincidía con el valor real del token (`53px`). Corregido a `53px` en ambas |
| A7 | Variantes del mismo patrón (`stats-row`) con `gap` distinto sin criterio documentado | `.stats-row` (base, pre-unificación): `gap: 6px`. `.stats-row--compact` (patrón "unificado" declarado en `_pp-context §5` para Backlog/Histórico/Q-Backlog/Q-DISC): `gap: 8px`. `.sps-stats-block` (grid de Sprint, mismo tipo de superficie — 4 celdas de stats): `gap: 8px` + `margin: 0 0 16px`. Dos de tres coinciden en `8px` — el tercero (`stats-row` base, aún vivo donde no se migró a `--compact`) queda en `6px` sin nota de por qué difiere |
| A8 | No hay auditoría previa de este tema — ni en `_Locus-css-ref` ni en `_Locus-ux-ref` existe una sección de spacing/gutter/alineación como criterio transversal antes de esta entrada | Confirmado por lectura de ambos Doc Refs al iniciar esta sesión |

**Alcance de lo no cubierto en esta pasada:** el grep cuantitativo (A1-A3) es exhaustivo sobre los 22 `.css`. Los hallazgos A4-A7 son muestreo dirigido sobre superficies representativas (shells de tab, stats bars) — no una revisión selector-por-selector de los ~2.465 casos. Esa revisión exhaustiva es trabajo de Fase 3, por superficie, a medida que cada TKT toca su archivo.

### B. Estándar propuesto — escala de spacing

Criterio de diseño: adoptar el 8pt grid ya dominante en la distribución real (A3 — `8px`/`4px` son, junto con `6px`, los tres valores más frecuentes) en vez de inventar una escala nueva sin relación con el código existente — resuelve la causa (falta de escala completa) sin descartar el patrón que el codebase ya sigue de facto en su mayoría.

| Token propuesto | Valor | Reemplaza (uso típico observado) |
|---|---|---|
| `--space-3xs` | 2px | separación mínima entre elementos inline (dots, iconos pegados a texto) |
| `--space-2xs` | 4px | gap interno de chips/badges, padding de elementos compactos |
| `--space-xs` | 6px | gap entre elementos de una fila densa (`.stats-row` base) |
| `--space-sm` | 8px | **alias de `--spacing-sm` existente** — gap estándar entre bloques pequeños, padding de botones compactos |
| `--space-md` | 12px | **equivalente a `--subtab-gutter` existente** — gap entre secciones de un panel |
| `--space-lg` | 16px | **alias de `--spacing-md` existente** — separación entre bloques mayores, `margin-bottom` de secciones |
| `--space-xl` | 24px | **equivalente a `--gutter-shell` existente** — gutter horizontal de shell completo |
| `--space-2xl` | 32px | separación entre secciones mayores dentro de un tab |

**Regla de consolidación — no introducir tokens duplicados:** `--space-md` (12px) y `--space-xl` (24px) no reemplazan a `--subtab-gutter`/`--gutter-shell` — los tres siguen siendo tokens válidos y usables donde ya están adoptados; `--space-*` es el nombre canónico de la escala completa hacia el futuro. Cuando Fase 3 toque un archivo, unifica hacia `--space-*` en ese archivo — no se sale a renombrar `--gutter-shell`/`--subtab-gutter` en los 6 archivos que ya lo usan solo por consistencia de nombre, salvo que el TKT ya esté tocando esa línea.

### C. Estándar propuesto — gutters por tipo de superficie

| Superficie | Gutter horizontal | Gutter vertical (entre secciones) | Nota |
|---|---|---|---|
| Shell de tab completo (`#tab-backlog`, `#tab-analytics`, `#tab-incidentes`) | `--space-xl` (24px) — ya adoptado como `--gutter-shell` | **Pendiente decisión (ver DISC)** — el `2rem` real computa 26px, no 32px; no forzar `--space-2xl` sin confirmar si el valor intencional es 26px o 32px | A5 corregido tras verificar `html{font-size:var(--text-base)}` = 13px. No aplicar sin la decisión de la DISC |
| Subtab / panel secundario (`#tab-proyectos`, `#tab-sesiones` interno, `#sprint-panel-sprints`) | `--space-md` (12px) | `--space-lg` (16px) | `#tab-proyectos` debe declarar el gutter en ambos lados (A4) — no solo `padding-left` |
| Stats row / stats block (cualquier superficie) | n/a (es `gap`, no padding) | `--space-sm` (8px) uniforme | Cierra A7 — `.stats-row` base migra a `8px` cuando se toque, o se documenta explícitamente por qué se mantiene en `6px` si hay razón de densidad visual deliberada |
| Cards dentro de grid (`.stat-card`, `.sps-stat-cell`) | `--space-sm` a `--space-md` interno (padding) | `--space-sm` (gap entre cards) | Ya mayormente consistente — confirmar en Fase 3 |

### D. Regla de alineación — criterio transversal

Sin auditoría exhaustiva de `align-items`/`justify-content`/`grid-template-columns` en esta pasada (fuera del muestreo de stats grids). Regla a aplicar en Fase 3 cuando se audite cada superficie: **toda superficie que repite un patrón visual equivalente (stats bar, meta-grid, toolbar de dos filas) usa el mismo `display` (flex o grid, no ambos para el mismo propósito) y el mismo eje de alineación** — si `.sps-stats-block` es grid de 4 columnas y una superficie nueva de stats necesita el mismo layout, hereda el patrón en vez de reimplementar con flex + wrap.

### E. Anti-patterns — declarados a partir de esta auditoría

| Anti-pattern | Por qué |
|---|---|
| Declarar `padding`/`margin`/`gap` con valor numérico directo en código nuevo | Repite A1-A3 — todo spacing nuevo usa `var(--space-*)` (o los tokens de gutter existentes donde aplique), sin excepción |
| Mezclar `rem` y `px`/token en el mismo `padding` shorthand | Repite A5 — un solo eje de unidad por declaración |
| Declarar fallback de `var()` con valor distinto al del token real | Repite A6 — si el token existe y está en `:root`, no necesita fallback; si se declara, debe coincidir |
| Introducir una nueva variante de un patrón existente (ej. otro `--*-compact`) sin comparar su `gap`/`padding` contra las variantes ya vivas del mismo patrón | Repite A7 |
| Asumir que `1rem` = 16px en Locus sin verificar `html{font-size}` | Repite A5 (corregido) — `html` usa `var(--text-base)` = 13px, no el default del navegador. Cualquier valor en `rem` de este proyecto computa distinto de lo esperado por convención web genérica |

### F. Fase 3 — progreso por archivo

Registro acumulativo de qué superficies ya migraron a `--space-*` y qué quedó documentado como excepción — para que el siguiente TKT que toque el mismo archivo no reaudite lo ya resuelto.

| Archivo · superficie | TKT | Migrado a `--space-*` | Excepciones dejadas literales (no forzadas al peldaño más cercano) |
|---|---|---|---|
| `locus-layout.css` — HEADER REDESIGN (`header`, `.header-inner`, `.header-zone`, `#header-search-wrap`, `#search-global`, `.header-search-clear`) | TKT-202607-218 | `.header-inner{gap}` 12px→`--space-md` · `.header-zone{gap}` 8px→`--space-sm` · `.header-zone+.header-zone{padding-left}` 12px→`--space-md` · `#header-search-wrap{gap}` 8px→`--space-sm` · `#search-global{padding}` 4px/8px/4px→`--space-2xs`/`--space-sm`/`--space-2xs` (26px izq. queda literal) · `.header-search-clear{padding}` 2px→`--space-3xs` | `header{padding}` 1.1rem/1.25rem/.85rem y `.header-inner{padding-inline}` 1.5rem — `rem` sobre root 13px (A5), no computan a un peldaño exacto · `#search-global{padding-left}` 26px — da espacio al ícono absolutamente posicionado, no es valor de escala · `.logo{gap}` 10px — entre `--space-sm`(8) y `--space-md`(12), ninguno exacto · `padding-left:0`/`margin:0` (2 casos) — cero no requiere token |
| `locus-layout.css` — TAB SCROLL PROGRESS BAR (`#tab-scroll-progress`, `#tab-scroll-progress-fill`) | TKT-202607-218 | n/a — sin declaraciones directas de `padding`/`margin`/`gap` en la sección | — |
| `locus-backlog.css` — `.stats-row` | TKT-202607-219 | `.stats-row{gap}` 6px→`--space-sm` — cierra A7 | `.stats-row--compact`/`.sps-stats-block` ya en 8px hardcoded — documentados como fuente canónica, sin cambio de código (fuera del AC de este TKT) |
| `locus-backlog-item.css` — bloque IDP (L967-1545: secciones del panel de detalle de ítem) | TKT-202607-220 (REQ-202607-086, TKT3, gap de log cerrado en mod:156) | 26 valores → `--space-3xs`/`--space-2xs`/`--space-xs`/`--space-sm`/`--space-md`/`--space-lg`, incluye `.idp-dep-chip--origin{padding}` 2px 8px→`var(--space-3xs) var(--space-sm)` | 10px en 4 pares mixtos (`8px 10px`→`var(--space-sm) 10px` ×2, `6px 10px`→`var(--space-xs) 10px`, `10px 12px`→`10px var(--space-md)`) · 1px (2 casos gap + 1 par mixto `1px 6px`→`1px var(--space-xs)`) · 5px (2 casos gap) · 3px (2 casos margin-top) · `gap:0`/`padding:0` (5 casos) — cero no requiere token. **Fuera de scope, no cerrado:** `var(--header-h, 54px)` en L994/L1009 de este mismo archivo repite el patrón A6 (fallback 54px ≠ token real 53px) — no estaba en los AC de este TKT |

**Hallazgo (mod:156) cerrado en mod:157 — `--spacing-xl` sin declarar:** `locus-modals-misc.css` L2238, `.clean-project-panel{padding}` — resuelto vía INC-202608-082, ver `§Cambios (mod:157)` arriba. No es fila de progreso Fase 3 (no es migración de superficie completa, es corrección de token roto puntual) — se deja fuera de esta tabla por el mismo criterio que otros fixes de INC puntuales.

---

## Deprecated

Clases sin instancias activas en el codebase — candidatas a eliminación en sprint siguiente. Rune no las usa en código nuevo.

| Clase | Reemplazo canónico | Eliminada de | Sprint |
|---|---|---|---|
| `.sc-unlock` | n/a — funcionalidad movida al DIFF | `locus-sesiones.js` footer available | PP-S-01 |
| `.sc-unlock-label` | n/a | `locus-sesiones.js` footer available | PP-S-01 |
| `.sc-unlock-icon` | n/a | `locus-sesiones.js` footer available | PP-S-01 |
| `.hora-input` (instancia card footer) | `mdiff-duration-input` | `locus-sesiones.js` footer available | PP-S-01 |

**Nota:** sin instancias activas tras R-202606-016 — candidatas a eliminación de `locus-sesiones-card.css` en sprint siguiente. Las declaraciones CSS pueden conservarse hasta confirmar que no hay otras instancias en el codebase.
