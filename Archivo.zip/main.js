// [PP] mod:25 · autor:Rune · 2026-08-18 22:30 UTC-6
// TKT-202608-379 (REQ-202608-153): retirados imports huérfanos `parsePaste`/`handlePaste`/
// `handleInput` desde locus-session-parse.js. El comentario B-202606-024 (más abajo en este
// mismo archivo) ya documentaba que la exposición window.parsePaste/handlePaste/handleInput
// fue eliminada a favor de import ESM directo en cada consumidor real — pero el import ESM en
// este archivo quedó huérfano desde entonces: grep exhaustivo confirma cero uso fuera de la
// línea de import y de ese mismo comentario histórico. locus-session-parse.js sigue siendo
// importado normalmente por los otros 5 consumidores (locus-session-save.js,
// locus-session-popup.js, locus-sesiones.js, locus-backlog-item.js, locus-sprint.js) — sin
// cambio de comportamiento en runtime, el módulo sigue cargando igual.
// [PP] mod:23 · autor:Rune · 2026-08-09 21:00 UTC-6
// TKT-202608-289 (REQ-202608-118): import de side-effect de locus-cmdk.js agregado. El Backlog
// declaraba este TKT `done`, pero verificado contra main.js real (mod:22) el import nunca
// existió — _initCmdkListeners() (locus-cmdk.js) jamás se ejecutaba en la app cargada. Mismo
// patrón de gap ya visto en mod:21 (locus-incidents-render.js) y mod:15 (getIncidents). Sin
// cambio en opts de _initApp — openCmdk()/closeCmdk() no se inyectan por ciclo, se
// autorregistran al importar (mismo criterio que locus-backlog-qbacklog.js/qdisc.js abajo).
// [PP] v0.8.0 · sprint:PP-S-06 · mod:22 · autor:Rune · 2026-07-24 UTC-6
// INC histórico — sin CHECKPOINT confirmado (Tab Analytics no renderiza — causa 2, timing async): _markAnalyticsDirty
// y renderAnalytics importados como named imports (antes solo side-effect) e inyectados en
// opts de _initApp como renderAnalytics: () => { _markAnalyticsDirty(); renderAnalytics(); } —
// mismo patrón que renderSprintTab. Cierra el wiring del lado de main.js para que
// locus-storage.js (mod:145) pueda invocar el refresh de Analytics al final de
// _loadFromSupabase() cuando el batch remoto (incluye tracker_sessions) termina después de que
// el tab ya estaba abierto con el empty-state congelado. Ver también locus-analytics-render.js
// mod:15 (fix relacionado, listener de shell:render-analytics — mismo INC, causa 1, distinta).
// [PP] v0.8.0 · sprint:PP-S-06 · mod:21 · autor:Rune · 2026-07-20 UTC-6
// INC histórico — sin CHECKPOINT confirmado (Tab INC no renderiza): agregado import de efecto lateral de
// locus-incidents-render.js — TKT2 (REQ CAEL-0720-03) extrajo renderQIncPanel() ahí pero
// ningún módulo lo importaba, así que el listener 'shell:render-qinc' nunca se registraba.
// Fix de una línea, sin cambio de lógica de negocio — ver locus-ui-shell.js switchTab('incidentes').
// Deprecación Command Palette (cont.): removidos import + llamada de initCommandPalette() —
// el módulo locus-command-palette.js fue eliminado del proyecto. Ver locus-ui-shell.js.
// INC histórico — sin CHECKPOINT confirmado (deprecación Sesiones/Pulso, founder confirmó): eliminados imports
// estáticos de locus-pulso.js y locus-sesiones-arranque.js — causa raíz del fallo de
// arranque (MIME type error) que reveló que TKT-202607-042 declaró 'sin importadores' de
// forma incorrecta. Ambos módulos se borraron del repositorio junto con todos sus call
// sites verificados (locus-sesiones-stats.js, locus-storage.js, locus-ui-shell.js).
// TKT-202607-042 (REQ-202607-014): locus-sprint-plan.js eliminado del repositorio — feature
// Plan cancelada. Import de side-effect ya removido en mod:16; el archivo huérfano confirmado
// sin importadores en todo el proyecto se borró en esta entrega. AC1 del TKT cerrado completo.
// [PP] v0.8.0 · sprint:PP-S-XX · mod:15 · autor:Rune · 2026-07-06 18:35 UTC-6
// TKT-202607-044 (REQ-202607-015): getIncidents importado desde locus-backlog-core.js +
// agregado a opts de _initApp — cierra el wiring del lado de main.js para que
// locus-storage.js reciba la referencia real en vez del fallback [] con warning.
// getIncidents asumido exportado desde locus-backlog-core.js — no verificado directamente
// (archivo no adjunto en esta sesión); evidenciado por AC de TKT-202607-045 y por el
// comentario ya presente en locus-storage.js ("INCIDENTS separado de ITEMS desde
// TKT-202607-005"). Gap de verificación registrado — ver CHECKPOINT.
// REQ refactor-zonas TKT5: side-effect imports de locus-backlog-qbacklog.js y
// locus-backlog-qdisc.js agregados — sus IIFEs de listener de sub-tab y (qbacklog)
// _attachDoneGroupToggle deben ejecutar al cargar la app. locus-backlog-zone-engine.js y
// locus-backlog-hierarchy.js no requieren import explícito aquí — son módulos puramente
// exportadores sin side effects de nivel módulo, se resuelven transitivamente.
// REQ histórico — sin CHECKPOINT confirmado Unificar vocabulario historico — TKT2: side-effect import
// actualizado hacia locus-backlog-historico.js (ex locus-backlog-archive.js).
// main.js — punto de entrada único de Locus (ES Modules nativos)
// El ciclo storage↔sprint-project se resuelve inyectando las referencias via opts en _initApp
// Limpieza: imports duplicados consolidados (side-effect imports redundantes eliminados)

import { _getActiveProjectFilter, _initApp, _effectiveVersion, getProjectById, LOCUS_KEYS, verifyConstraintsSync } from './locus-storage.js';
import { _initUiShellRefs } from './locus-ui-shell.js';
import './locus-analytics-core.js';
import './locus-analytics-digest.js';
import { _markAnalyticsDirty, renderAnalytics } from './locus-analytics-render.js';
import './locus-analytics-charts.js';
import './locus-toast.js';
import './locus-sesiones.js';
import { _maybeShowWeeklySummary } from './locus-sesiones-utils.js';
import './locus-modals.js';
import './locus-workers.js';
import './locus-notifications.js';
import './locus-sesiones-stats.js';
import './locus-sesiones-capture.js';
import { _itemVizConfirm, _itemVizClose, closeCkptPanel } from './locus-sesiones-viz.js';
import './locus-radar.js';
import { relDate } from './locus-session-hora.js';
import './locus-session-save.js';
import './locus-tags.js';
import './locus-session-popup.js';
import './locus-cmdk.js'; // TKT-202608-289 (REQ-202608-118) — side-effect import: registra el listener global de ⌘K al cargar la app
import './locus-reports.js';
import './locus-backlog-editor.js';
import './locus-projects.js';
import './locus-docs.js';
import './locus-contracts.js';
import './locus-map-viewer.js';
import { getItems, getIncidents, _localStorageUsageRatio, _migrateItemTypes, _purgeStaleBacklogCache } from './locus-backlog-core.js';
import './locus-backlog-item.js';
import './locus-backlog-merge.js';
import './locus-backlog-panel.js';
import './locus-backlog-render.js';
import './locus-incidents-render.js'; // INC histórico — sin CHECKPOINT confirmado: TKT2 (REQ CAEL-0720-03) extrajo renderQIncPanel/_attachQIncDelegation
  // a este módulo pero ningún archivo lo importaba — el listener 'shell:render-qinc' nunca se
  // registraba y switchTab('incidentes') disparaba el evento al vacío. Import de efecto lateral,
  // mismo patrón que locus-backlog-qbacklog.js/locus-backlog-qdisc.js en las líneas siguientes.
import './locus-backlog-qbacklog.js';
import './locus-backlog-qdisc.js';
import './locus-backlog-sprints.js';
import './locus-backlog-historico.js';
import { renderSprintTab } from './locus-sprint.js';
import { exportBacklogMd } from './locus-backlog-generator.js';
import './locus-map-generator.js';

// ── Funciones migradas desde inline script de index.html (T-202606-006) ──────

// _updateBackupBadge: actualiza badge del botón backup según datos en localStorage
// T-202604-210: migrado desde inline script
function _updateBackupBadge() {
  try {
    const badge = document.getElementById('backup-badge');
    if (!badge) return;
    const raw = localStorage.getItem(LOCUS_KEYS.STATE);
    const hasData = raw && raw.length > 50;
    badge.classList.toggle('visible', !!hasData);
    const vp = document.getElementById('version-pill');
    if (vp) {
      const ver = _effectiveVersion?.() ?? '';
      vp.title = ver + ' · Ver changelog';
    }
  } catch(e) {}
}

// R-202606-002: _validateResetSessionsInput / _validateResetBacklogInput
// Los overlays reset-sessions-overlay y reset-backlog-overlay no existen en index.html aún —
// se registran por delegation para cuando sean añadidos al DOM.
function _validateResetSessionsInput(el) {
  const v = el.value.trim();
  const ok = v === 'RESET';
  document.getElementById('reset-sessions-confirm-btn').disabled = !ok;
  const hint = document.getElementById('reset-sessions-hint');
  if (v.length > 0 && !ok) { hint.textContent = 'Debe ser exactamente: RESET (mayúsculas)'; hint.classList.remove('is-hidden'); }
  else { hint.classList.add('is-hidden'); }
}

function _validateResetBacklogInput(el) {
  const v = el.value.trim();
  const ok = v === 'RESET';
  document.getElementById('reset-backlog-confirm-btn').disabled = !ok;
  const hint = document.getElementById('reset-backlog-hint');
  if (v.length > 0 && !ok) { hint.textContent = 'Debe ser exactamente: RESET (mayúsculas)'; hint.classList.remove('is-hidden'); }
  else { hint.classList.add('is-hidden'); }
}

// B-202606-024: window.parsePaste · handlePaste · handleInput eliminados — todos los consumidores usan ESM import

// ─────────────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  // R-202605-002: title dinámico con versión efectiva
  try {
    const ver = _effectiveVersion();
    document.title = ver ? 'Locus ' + ver : 'Locus';
  } catch(e) { document.title = 'Locus'; }

  // T-202606-006: _updateBackupBadge — ejecutar 800ms post-DOMContentLoaded
  setTimeout(_updateBackupBadge, 800);

  // T-202605-448: panel de resumen semanal — se activa los lunes al abrir la app
  setTimeout(function() {
    _maybeShowWeeklySummary();
  }, 1200);

  // T-202605-062: inline handlers → addEventListener (CSS Purity)
  const _ivzConfirm = document.getElementById('item-viz-confirm-btn');
  if (_ivzConfirm) _ivzConfirm.addEventListener('click', function() { _itemVizConfirm(); });
  const _ivzClose = document.getElementById('item-viz-close-btn');
  if (_ivzClose) _ivzClose.addEventListener('click', function() { _itemVizClose(); });
  const _ckptClose = document.getElementById('ckpt-header-close-btn');
  if (_ckptClose) _ckptClose.addEventListener('click', function() { closeCkptPanel(); });

  // Arrancar app — inyectar referencias directas para romper ciclos storage↔sprint-project y storage↔backlog-core
  // ESM-B: getProjectById · _localStorageUsageRatio · _migrateItemTypes · _purgeStaleBacklogCache agregados
  // T-202606-006 T3: renderSprintTab agregado — elimina window.renderSprintTab en storage
  _initApp({
    getActiveProjectFilter: _getActiveProjectFilter,
    exportBacklogMd,
    getItems,
    // TKT-202607-044 (REQ-202607-015): getIncidents inyectado — locus-storage.js ya
    // acepta opts.getIncidents (mismo patrón lazy ref que getItems). Completa el wiring
    // que _getIncidents en locus-storage.js dejó pendiente.
    getIncidents,
    localStorageUsageRatio: _localStorageUsageRatio,
    migrateItemTypes: _migrateItemTypes,
    purgeStaleBacklogCache: _purgeStaleBacklogCache,
    getProjectById,
    renderSprintTab,
    // INC histórico — sin CHECKPOINT confirmado: renderAnalytics inyectado — mismo patrón que renderSprintTab arriba.
    // _loadFromSupabase() lo invoca al terminar la carga remota para refrescar el tab Analytics
    // si quedó con el empty-state congelado (abierto antes de que tracker_sessions terminara de
    // mergear). _markAnalyticsDirty() es obligatorio antes de renderAnalytics() — mismo guard
    // que usan los setters de locus-analytics-core.js.
    renderAnalytics: () => { _markAnalyticsDirty(); renderAnalytics(); },
  });

  // T-202606-006 T3: inyectar refs en ui-shell — rompe ciclos ui-shell ↔ backlog-core y ui-shell ↔ session-hora
  _initUiShellRefs({ getItems, relDate });

  // R-202606-002: registrar listeners de validación de reset — delegation para overlays futuros
  const _rsInput = document.getElementById('reset-sessions-input');
  if (_rsInput) _rsInput.addEventListener('input', function() { _validateResetSessionsInput(this); });
  const _rbInput = document.getElementById('reset-backlog-input');
  if (_rbInput) _rbInput.addEventListener('input', function() { _validateResetBacklogInput(this); });

  // TKT1b: verifyConstraintsSync — herramienta de consola, sin consumidores ESM internos.
  // Expuesta en window por diseño (mismo patrón que las herramientas de diagnóstico ya
  // retiradas) — uso manual del founder, no se invoca desde ningún módulo de la app.
  window._verifyConstraintsSync = verifyConstraintsSync;
});
